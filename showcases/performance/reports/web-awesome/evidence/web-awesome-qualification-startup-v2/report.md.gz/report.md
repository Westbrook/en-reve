# web-awesome-qualification-startup-v2

Protocol: b34f5d09f30f211ece2bda07fbbe60beec157c01044b67ac99398fd83221ce1e. 6/6 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| en-reve | desktop/cold | on | 1 / 0 | 152.0 | — | 0.0000 | 140.2 | 32.0 |
| en-reve | mobile/cold | on | 1 / 0 | 652.0 | — | 0.0000 | 649.6 | 48.0 |
| web-awesome | mobile/cold | on | 1 / 0 | 652.0 | — | 0.0000 | 652.4 | 48.0 |
| web-awesome | desktop/cold | on | 1 / 0 | 100.0 | — | 0.0000 | 88.6 | 40.0 |
| fluent-web-components | mobile/cold | on | 1 / 0 | 536.0 | — | 0.0000 | 568.0 | 56.0 |
| fluent-web-components | desktop/cold | on | 1 / 0 | 88.0 | — | 0.0001 | 76.7 | 40.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
