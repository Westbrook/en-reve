import test from 'node:test';
import assert from 'node:assert/strict';
import { selectSystems } from '../src/config.mjs';
import { additiveInventory, selectedInventory } from '../src/prepare.mjs';

test('selected panels keep registered order and reject unknown selectors', () => {
  const registered = [{ id: 'old' }, { id: 'control' }, { id: 'new' }];
  assert.deepEqual(selectSystems('new,control', registered), [registered[1], registered[2]]);
  assert.throws(() => selectSystems('old,typo', registered), /Unknown system/);
  assert.throws(() => selectSystems('old,', registered), /Unknown system/);
});

test('challenger addition preserves frozen entries and prior qualification while requiring its own checks', () => {
  const previous = {
    schema: 1,
    systems: [{ id: 'old', fingerprint: 'immutable', assets: [{ path: 'a.js', sha256: 'same' }] }],
    qualification: { status: 'passed', receipt: 'original.json' },
    requiresFunctionalQualification: false,
  };
  const before = JSON.stringify(previous);
  const entry = { id: 'new', fingerprint: 'challenger', assets: [] };
  const result = additiveInventory(previous, [entry], 'Add a comparison library');
  assert.equal(JSON.stringify(previous), before);
  assert.deepEqual(result.systems, [...previous.systems, entry]);
  assert.deepEqual(result.qualificationHistory, [previous.qualification]);
  assert.equal(result.requiresFunctionalQualification, true);
  assert.deepEqual(result.pendingSystems, ['new']);
  assert.throws(() => additiveInventory(previous, [{ id: 'old' }], 'Replace'), /cannot replace/);
});

test('adding a challenger never clears another pending qualification', () => {
  const previous = { systems: [{ id: 'pending' }], requiresFunctionalQualification: true, qualification: { status: 'pending' } };
  assert.deepEqual(additiveInventory(previous, [{ id: 'new' }], 'Add').pendingSystems, ['pending', 'new']);
});

test('selected candidate refresh preserves unselected frozen controls and their ordering', () => {
  const previous = { systems: [{ id: 'control', fingerprint: 'frozen' }, { id: 'new', fingerprint: 'first' }], requiresFunctionalQualification: false, qualification: { status: 'passed' } };
  const updated = selectedInventory(previous, [{ id: 'new', fingerprint: 'corrected' }], 'Fix initial tab content');
  assert.deepEqual(updated.systems, [previous.systems[0], { id: 'new', fingerprint: 'corrected' }]);
  assert.equal(previous.systems[1].fingerprint, 'first');
  assert.deepEqual(updated.pendingSystems, ['new']);
  assert.throws(() => selectedInventory(previous, [{ id: 'unregistered' }], 'Add'), /cannot add/);
});

test('additions and selected refresh retain receipt provenance without changing unselected evidence', () => {
  const originalReceipt = { path: 'original.json', sha256: 'original-hash' };
  const sources = [{ path: 'addition.json', sha256: 'addition-hash', systems: ['new'] }];
  const previous = { systems: [{ id: 'control', fingerprint: 'frozen', verificationReceipt: originalReceipt }], qualification: { status: 'passed' } };
  const entry = { id: 'new', fingerprint: 'new', verificationReceipt: { path: 'addition.json', sha256: 'addition-hash' } };
  const added = additiveInventory(previous, [entry], 'Add', sources);
  assert.deepEqual(added.qualification.sourceReceipts, sources);
  assert.deepEqual(added.systems[0], previous.systems[0]);
  const refreshed = selectedInventory(added, [{ ...entry, fingerprint: 'corrected' }], 'Correct', sources);
  assert.deepEqual(refreshed.qualification.sourceReceipts, sources);
  assert.deepEqual(refreshed.systems[0].verificationReceipt, originalReceipt);
  assert.deepEqual(refreshed.systems[1].verificationReceipt, entry.verificationReceipt);
  assert.deepEqual(added.systems[1].fingerprint, 'new');
});
