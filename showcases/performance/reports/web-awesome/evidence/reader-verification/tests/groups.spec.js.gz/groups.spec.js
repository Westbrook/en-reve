import { test, expect } from "@playwright/test";
import { readFileSync } from "node:fs";
const tables = JSON.parse(
  readFileSync(new URL("../src/tables.json", import.meta.url), "utf8"),
);
test("every measurement column sorts numerically in both directions; missing values stay last", async ({
  page,
}) => {
  // The expanded report retains historical tables and adds a new acquisition.
  // Bound time by the verified work (two clicks per numeric column). Firefox
  // exceeded six minutes at table 115/142 in the expanded report; retain every
  // assertion with a ten-minute ceiling for the complete comparison.
  const numericColumns = tables.reduce(
    (count, table) => count + table.numeric.filter(Boolean).length,
    0,
  );
  test.setTimeout(Math.min(600000, Math.max(180000, numericColumns * 600)));
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto("/?progress-report#second-pass-measurements");
  await expect(page.locator("en-data-table")).toHaveCount(tables.length);
  for (const definition of tables) {
    const wrapper = page.locator(`[data-table-id="${definition.id}"]`);
    const table = wrapper.locator("en-data-table");
    await expect(table.locator("tbody tr")).toHaveCount(definition.rows.length);
    for (let index = 0; index < definition.headers.length; index++) {
      if (!definition.numeric[index]) continue;
      const header = table.locator("thead th").nth(index);
      for (const direction of ["ascending", "descending"]) {
        await header.getByRole("button").click();
        await expect(header).toHaveAttribute("aria-sort", direction);
        const texts = await table
          .locator("tbody tr")
          .evaluateAll(
            (rows, index) =>
              rows.map((row) => row.children[index].textContent.trim()),
            index,
          );
        const values = texts.map((value) =>
          value === "—" || value === ""
            ? null
            : Number(value.replaceAll(",", "")),
        );
        let missing = false;
        let previous = null;
        for (const value of values) {
          if (value === null) {
            missing = true;
            continue;
          }
          expect(
            missing,
            `${definition.title}: ${definition.headers[index]} must place missing values last`,
          ).toBe(false);
          expect(Number.isFinite(value)).toBe(true);
          if (previous !== null)
            expect(
              direction === "ascending" ? value >= previous : value <= previous,
              `${definition.title}: ${definition.headers[index]} ${direction}`,
            ).toBe(true);
          previous = value;
        }
        await expect(table.locator("[aria-sort]")).toHaveCount(1);
      }
    }
  }
  expect(errors).toEqual([]);
});
test("CSV exports the current comparison order and report remains within a mobile viewport", async ({
  page,
}) => {
  await page.goto("/#first-reference-comparison");
  const wrapper = page.locator("#reference-comparison");
  const table = wrapper.locator("en-data-table");
  await table.locator("thead th").nth(4).getByRole("button").click();
  const downloadPromise = page.waitForEvent("download");
  await wrapper
    .getByRole("button", { name: "Download CSV", exact: true })
    .click();
  const download = await downloadPromise;
  const stream = await download.createReadStream();
  let text = "";
  for await (const chunk of stream) text += chunk.toString();
  expect(text).toContain('"Median LCP ms"');
  expect(text.split("\r\n")[1]).toMatch(/^"Fluent Web Components",/);
  expect(text).toContain('"1,380"');
  await page.setViewportSize({ width: 390, height: 844 });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  for (const table of await page.locator("en-data-table").all()) {
    const bounds = await table.evaluate((el) => ({
      host: el.getBoundingClientRect().width,
      viewport: innerWidth,
      scroll: el.scrollElement?.scrollWidth,
      client: el.scrollElement?.clientWidth,
    }));
    expect(bounds.host).toBeLessThanOrEqual(bounds.viewport);
    expect(bounds.scroll).toBeGreaterThanOrEqual(bounds.client);
    const pinned = await table.evaluate((el) => {
      const viewport = el.scrollElement;
      viewport.scrollLeft = viewport.scrollWidth;
      const left = viewport.getBoundingClientRect().left;
      return [...el.shadowRoot.querySelectorAll("th.implementation-column, td.implementation-column")]
        .every((cell) => Math.abs(cell.getBoundingClientRect().left - left) <= 2);
    });
    expect(pinned).toBe(true);
  }
});
