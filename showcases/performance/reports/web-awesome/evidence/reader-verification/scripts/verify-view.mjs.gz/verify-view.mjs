import { chromium, firefox, webkit } from "@playwright/test";
import { readFile, writeFile, mkdir, stat } from "node:fs/promises";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import { validateReaderTestReceipts } from "./reader-test-receipts.mjs";
const root = resolve(import.meta.dirname, "..");
const source = JSON.parse(await readFile(resolve(root, "public/source.json")));
const tables = JSON.parse(await readFile(resolve(root, "src/tables.json")));
const webAwesomeTables = tables.filter((table) =>
  table.title.startsWith("Web Awesome "),
);
const nineSystemTables = tables.filter((table) =>
  table.title.startsWith("Nine-system "),
);
if (!webAwesomeTables.length || !nineSystemTables.length)
  throw new Error("Integrate the completed Web Awesome report before verifying its reader");
for (const table of nineSystemTables) {
  if (
    table.headers[0] !== "Implementation" ||
    table.headers[1] !== "Acquisition" ||
    table.rows.length !== 9 ||
    table.rows.filter((row) => row[0] === "Web Awesome").length !== 1 ||
    table.rows.some((row) => !row[1])
  )
    throw new Error(`Invalid acquisition-labelled reference table: ${table.title}`);
}
const receiptPaths = ["artifacts/browser-tests.json"];
const initialBytes = await readFile(resolve(root, receiptPaths[0]));
const tests = JSON.parse(initialBytes);
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
const receiptHashes = { [receiptPaths[0]]: digest(initialBytes) };
let focused;
if (tests.stats.unexpected) {
  const retained = "artifacts/expanded-reader-initial-timeout/browser-tests.json";
  const retainedBytes = await readFile(resolve(root, retained));
  if (digest(retainedBytes) !== digest(initialBytes))
    throw new Error("Initial test receipt differs from its retained timeout archive");
  const recheck = "artifacts/browser-tests-firefox-sort-recheck.json";
  const focusedBytes = await readFile(resolve(root, recheck));
  focused = JSON.parse(focusedBytes);
  receiptPaths.push(retained, recheck);
  receiptHashes[retained] = digest(retainedBytes);
  receiptHashes[recheck] = digest(focusedBytes);
}
const browserVerification = validateReaderTestReceipts(
  tests,
  focused,
  (await stat(resolve(root, "dist/index.html"))).mtimeMs,
);
const browsers = {};
for (const [name, type] of Object.entries({ chromium, firefox, webkit })) {
  const browser = await type.launch();
  browsers[name] = browser.version();
  if (name === "chromium") {
    const page = await browser.newPage({
      viewport: { width: 1500, height: 1100 },
    });
    await mkdir(resolve(root, "artifacts"), { recursive: true });
    await page.goto(
      "http://127.0.0.1:4188/?progress-report#second-pass-measurements",
    );
    await page.locator("en-data-table").last().waitFor();
    await page.waitForFunction(() =>
      [...document.querySelectorAll(".table-fallback")].every(
        (el) => el.hidden,
      ),
    );
    await page.locator("#second-pass-measurements").scrollIntoViewIfNeeded();
    await page.screenshot({
      path: resolve(root, "artifacts/second-pass-overview.png"),
    });
    await page.goto(
      "http://127.0.0.1:4188/?progress-report#loading-and-visual-stability",
    );
    await page.waitForFunction(() =>
      [...document.querySelectorAll(".table-fallback")].every(
        (el) => el.hidden,
      ),
    );
    await page
      .locator("#loading-and-visual-stability")
      .scrollIntoViewIfNeeded();
    await page.screenshot({
      path: resolve(root, "artifacts/second-pass-loading.png"),
    });
    await page.goto(
      "http://127.0.0.1:4188/?progress-report#comparing-gaps-and-choosing-remediation",
    );
    await page.waitForFunction(() =>
      [...document.querySelectorAll(".table-fallback")].every(
        (el) => el.hidden,
      ),
    );
    await page
      .locator("#comparing-gaps-and-choosing-remediation")
      .scrollIntoViewIfNeeded();
    await page.screenshot({
      path: resolve(root, "artifacts/second-pass-gaps.png"),
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(
      "http://127.0.0.1:4188/?progress-report#mobile-cold-loading",
    );
    await page.waitForFunction(() =>
      [...document.querySelectorAll(".table-fallback")].every(
        (el) => el.hidden,
      ),
    );
    await page.locator("#mobile-cold-loading").scrollIntoViewIfNeeded();
    await page.screenshot({
      path: resolve(root, "artifacts/second-pass-mobile.png"),
    });
    await page.setViewportSize({ width: 1500, height: 1100 });
    await page.locator("#initial-connected-dom-with-and-without-dates").scrollIntoViewIfNeeded();
    await page.screenshot({ path: resolve(root, "artifacts/dom-review-counts.png") });
    await page.locator("#en-reve-mounted-base-responsibilities").scrollIntoViewIfNeeded();
    await page.screenshot({ path: resolve(root, "artifacts/dom-review-base.png") });
    await page.setViewportSize({ width: 390, height: 844 });
    await page.locator("#initial-connected-dom-with-and-without-dates").scrollIntoViewIfNeeded();
    await page.screenshot({ path: resolve(root, "artifacts/dom-review-mobile.png") });
    await page.setViewportSize({ width: 1500, height: 1100 });
    for (const [anchor, file] of [
      ["web-awesome-comparison", "web-awesome-overview.png"],
      ["web-awesome-mobile-cold-loading", "web-awesome-loading.png"],
      ["nine-system-production-payload-comparison", "web-awesome-nine-system-payload.png"],
      ["web-awesome-connected-totals-with-and-without-dates", "web-awesome-dom.png"],
    ]) {
      await page.locator(`#${anchor}`).scrollIntoViewIfNeeded();
      if (anchor !== "web-awesome-comparison") {
        const title = await page.locator(`#${anchor}`).textContent();
        const definition = tables.find((table) => table.title === title.trim());
        if (!definition) throw new Error(`Missing screenshot table: ${title}`);
        await page.locator(`[data-table-id="${definition.id}"]`).scrollIntoViewIfNeeded();
      }
      await page.screenshot({ path: resolve(root, "artifacts", file) });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    const mobileComparison = tables.find((table) => table.title === "Nine-system mobile cold loading comparison");
    await page.locator(`[data-table-id="${mobileComparison.id}"]`).scrollIntoViewIfNeeded();
    await page.screenshot({ path: resolve(root, "artifacts/web-awesome-mobile.png") });
  }
  await browser.close();
}
// Invoke after every unique case passes; retain any permitted focused recheck.
await writeFile(
  resolve(root, "verification.json"),
  JSON.stringify(
    {
      checkedAt: new Date().toISOString(),
      ...source,
      browsers,
      tableCount: tables.length,
      webAwesomeTableCount: webAwesomeTables.length,
      nineSystemComparisonTableCount: nineSystemTables.length,
      numericColumns: tables.reduce(
        (n, t) => n + t.numeric.filter(Boolean).length,
        0,
      ),
      result: browserVerification.result,
      browserTestReceipt: "artifacts/browser-tests.json",
      browserTestReceipts: receiptPaths,
      browserTestReceiptSha256: receiptHashes,
      browserVerification,
      checks: [
        "Every numeric column in every table sorts ascending and descending; missing values stay last",
        "Original reference columns and keyboard sorting, reset, focus and aria-sort",
        "CSV preserves current order, numeric separators and formula protection",
        "All source sections, explicit local evidence links and exact downloadable Markdown",
        "390px viewport without document overflow; independently scrolling tables",
        "Progress return shown only with the explicit flag",
        "Print and JavaScript-disabled fallbacks for grouped tables",
        "All Implementation columns remain pinned in narrow interactive and static tables",
        "Every nine-system comparison has nine implementations and an explicit acquisition column",
        "Web Awesome acquisition, grouped historical comparisons, payload, connected DOM and mobile screenshots",
      ],
      command: focused
        ? "npm run build && npm test; focused Firefox numeric-sort recheck after increasing only its timeout budget"
        : "npm run build && npm test",
      preview:
        "http://127.0.0.1:4188/?progress-report#web-awesome-comparison",
      screenshots: [
        "artifacts/second-pass-overview.png",
        "artifacts/second-pass-loading.png",
        "artifacts/second-pass-gaps.png",
        "artifacts/second-pass-mobile.png",
        "artifacts/dom-review-counts.png",
        "artifacts/dom-review-base.png",
        "artifacts/dom-review-mobile.png",
        "artifacts/web-awesome-overview.png",
        "artifacts/web-awesome-loading.png",
        "artifacts/web-awesome-nine-system-payload.png",
        "artifacts/web-awesome-dom.png",
        "artifacts/web-awesome-mobile.png",
      ],
    },
    null,
    2,
  ) + "\n",
);
