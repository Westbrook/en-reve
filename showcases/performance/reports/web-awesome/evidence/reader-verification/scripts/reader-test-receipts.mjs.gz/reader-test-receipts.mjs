import assert from 'node:assert/strict';

const numericTitle = 'every measurement column sorts numerically in both directions; missing values stay last';
const expectedCases = [
  ['groups.spec.js', numericTitle],
  ['groups.spec.js', 'CSV exports the current comparison order and report remains within a mobile viewport'],
  ['results.spec.js', 'all columns sort in both directions using the native En Reve table'],
  ['results.spec.js', 'full report, evidence links, narrow viewport, and progress return'],
  ['results.spec.js', 'all source rows remain readable without JavaScript'],
];
const key = entry => JSON.stringify([entry.project, entry.file, entry.title]);
function cases(report) {
  const entries = [];
  function visit(suites) {
    for (const suite of suites ?? []) {
      for (const spec of suite.specs ?? []) for (const test of spec.tests ?? []) {
        entries.push({ id: spec.id, file: spec.file ?? suite.file, title: spec.title, project: test.projectId, test });
      }
      visit(suite.suites);
    }
  }
  visit(report.suites);
  return entries;
}
function cleanPass(entry) {
  return entry.test.expectedStatus === 'passed' && entry.test.status === 'expected' && entry.test.results.length === 1 && entry.test.results[0].status === 'passed' && !entry.test.results[0].error && !entry.test.results[0].errors?.length && entry.test.results[0].retry === 0;
}
function checkReport(report, buildMtimeMs) {
  assert.equal(report.errors?.length ?? 0, 0, 'Receipt contains a global runner error');
  assert.equal(report.stats.flaky, 0, 'Flaky outcomes cannot complete verification');
  assert.equal(report.stats.skipped, 0, 'Skipped outcomes cannot complete verification');
  const start = Date.parse(report.stats.startTime);
  assert(Number.isFinite(start) && start >= buildMtimeMs, 'Run tests after the latest build');
  assert(Number.isFinite(report.stats.duration) && report.stats.duration >= 0, 'Missing receipt duration');
  return start;
}

// A targeted rerun may replace only the known overall-budget timeout, never an
// unrelated assertion failure, skipped case, or missing part of the suite.
export function validateReaderTestReceipts(initial, focused, buildMtimeMs) {
  const initialStart = checkReport(initial, buildMtimeMs), all = cases(initial);
  const expected = new Set(['chromium', 'firefox', 'webkit'].flatMap(project => expectedCases.map(([file, title]) => key({ project, file, title }))));
  assert.equal(all.length, 15, 'Initial receipt must cover every three-browser case');
  assert.equal(new Set(all.map(key)).size, 15, 'Duplicate initial test cases');
  assert(all.every(entry => expected.has(key(entry))), 'Unexpected initial test identity');
  const passed = all.filter(cleanPass), failed = all.filter(entry => !cleanPass(entry));
  if (!failed.length) {
    assert.equal(initial.stats.expected, 15);
    assert.equal(initial.stats.unexpected, 0);
    return { status: 'complete-first-attempt', uniqueCases: 15, attempts: 15, initialStats: initial.stats, result: '15/15 browser cases and 2/2 reader unit tests passed on the initial run' };
  }
  assert.equal(initial.stats.expected, 14);
  assert.equal(initial.stats.unexpected, 1);
  assert.equal(passed.length, 14);
  assert.equal(failed.length, 1);
  const original = failed[0], attempt = original.test.results[0];
  assert.equal(original.project, 'firefox', 'Only the recorded Firefox timeout can be rechecked');
  assert.equal(original.file, 'groups.spec.js');
  assert.equal(original.title, numericTitle);
  assert.equal(original.test.expectedStatus, 'passed');
  assert.equal(original.test.status, 'unexpected');
  assert.equal(original.test.timeout, 360000);
  assert.equal(original.test.results.length, 1);
  assert.equal(attempt.status, 'timedOut', 'An assertion failure is not a timeout-budget correction');
  assert.equal(attempt.retry, 0);
  assert(attempt.duration >= 360000, 'Failure happened before the full test budget');
  assert(/Test timeout of 360000ms exceeded/.test(attempt.error?.message ?? ''), 'Missing overall test-timeout evidence');
  assert(focused, 'The focused Firefox numeric-sort recheck has not completed');
  const focusedStart = checkReport(focused, buildMtimeMs), rerun = cases(focused);
  assert(focusedStart >= initialStart + initial.stats.duration, 'Recheck predates completion of the original suite');
  assert.equal(focused.stats.expected, 1);
  assert.equal(focused.stats.unexpected, 0);
  assert.equal(rerun.length, 1, 'Focused receipt must contain only the exact failed case');
  assert.equal(key(rerun[0]), key(original), 'Focused receipt does not recheck the failed case');
  assert.equal(rerun[0].id, original.id, 'Focused test ID differs from the retained failure');
  assert.equal(rerun[0].test.timeout, 600000, 'Expected the documented corrected timeout budget');
  assert(cleanPass(rerun[0]), 'Focused recheck must pass once without retries, errors or flakiness');
  return {
    status: 'complete-after-timeout-budget-correction', uniqueCases: 15, attempts: 16,
    initialStats: initial.stats, focusedStats: focused.stats,
    correction: { fromMs: 360000, toMs: 600000, scope: 'Only the numeric-sort test budget changed; application build and assertions were retained' },
    initialFailure: { id: original.id, project: original.project, file: original.file, title: original.title, result: attempt },
    focusedPass: { id: rerun[0].id, project: rerun[0].project, file: rerun[0].file, title: rerun[0].title, result: rerun[0].test.results[0] },
    result: '15/15 unique browser cases completed after a timeout-budget correction: 14 initial passes and the Firefox numeric-sort case passed on focused recheck; the initial timeout is retained. 2/2 reader unit tests passed',
  };
}
