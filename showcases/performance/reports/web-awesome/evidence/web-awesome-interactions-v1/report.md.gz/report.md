# web-awesome-interactions-v1

Protocol: b34f5d09f30f211ece2bda07fbbe60beec157c01044b67ac99398fd83221ce1e. 60/60 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| web-awesome | desktop/cold | on | 10 / 0 | 100.0 | 100.0 | 0.0000 | 87.0 | 40.0 |
| en-reve | mobile/cold | on | 10 / 0 | 632.0 | 632.0 | 0.0000 | 627.6 | 56.0 |
| web-awesome | mobile/cold | on | 10 / 0 | 616.0 | 616.0 | 0.0000 | 612.9 | 48.0 |
| en-reve | desktop/cold | on | 10 / 0 | 100.0 | 100.0 | 0.0000 | 88.1 | 48.0 |
| fluent-web-components | mobile/cold | on | 10 / 0 | 536.0 | 536.0 | 0.0000 | 530.2 | 64.0 |
| fluent-web-components | desktop/cold | on | 10 / 0 | 84.0 | 84.0 | 0.0001 | 74.5 | 48.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
