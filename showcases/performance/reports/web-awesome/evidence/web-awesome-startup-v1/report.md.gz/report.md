# web-awesome-startup-v1

Protocol: b34f5d09f30f211ece2bda07fbbe60beec157c01044b67ac99398fd83221ce1e. 60/60 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| web-awesome | desktop/cold | on | 10 / 0 | 96.0 | — | 0.0000 | 85.6 | 32.0 |
| en-reve | mobile/cold | on | 10 / 0 | 622.0 | — | 0.0000 | 618.0 | 48.0 |
| web-awesome | mobile/cold | on | 10 / 0 | 606.0 | — | 0.0000 | 607.5 | 40.0 |
| en-reve | desktop/cold | on | 10 / 0 | 100.0 | — | 0.0000 | 89.9 | 32.0 |
| fluent-web-components | mobile/cold | on | 10 / 0 | 524.0 | — | 0.0000 | 522.1 | 40.0 |
| fluent-web-components | desktop/cold | on | 10 / 0 | 88.0 | — | 0.0001 | 76.6 | 40.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
