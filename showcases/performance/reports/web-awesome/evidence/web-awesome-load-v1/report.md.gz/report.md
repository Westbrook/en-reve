# web-awesome-load-v1

Protocol: b34f5d09f30f211ece2bda07fbbe60beec157c01044b67ac99398fd83221ce1e. 120/120 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| en-reve | mobile/warm | on | 10 / 0 | 298.0 | 298.0 | 0.0000 | 308.2 | — |
| web-awesome | desktop/warm | on | 10 / 0 | 36.0 | 36.0 | 0.0000 | 31.4 | — |
| en-reve | desktop/warm | on | 10 / 0 | 44.0 | 44.0 | 0.0000 | 40.6 | — |
| fluent-web-components | desktop/warm | on | 10 / 0 | 32.0 | 32.0 | 0.0001 | 28.2 | — |
| web-awesome | desktop/cold | on | 10 / 0 | 96.0 | 96.0 | 0.0000 | 83.0 | — |
| en-reve | desktop/cold | on | 10 / 0 | 96.0 | 96.0 | 0.0000 | 83.6 | — |
| web-awesome | mobile/cold | on | 10 / 0 | 604.0 | 604.0 | 0.0000 | 602.0 | — |
| fluent-web-components | mobile/warm | on | 10 / 0 | 218.0 | 218.0 | 0.0000 | 226.6 | — |
| web-awesome | mobile/warm | on | 10 / 0 | 246.0 | 246.0 | 0.0000 | 255.6 | — |
| en-reve | mobile/cold | on | 10 / 0 | 614.0 | 614.0 | 0.0000 | 609.6 | — |
| fluent-web-components | mobile/cold | on | 10 / 0 | 516.0 | 516.0 | 0.0000 | 509.9 | — |
| fluent-web-components | desktop/cold | on | 10 / 0 | 84.0 | 84.0 | 0.0001 | 76.2 | — |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
