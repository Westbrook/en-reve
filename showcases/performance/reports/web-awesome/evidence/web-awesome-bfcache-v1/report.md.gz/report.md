# web-awesome-bfcache-v1

Protocol: b34f5d09f30f211ece2bda07fbbe60beec157c01044b67ac99398fd83221ce1e. 15/15 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| en-reve | desktop/cold | on | 5 / 0 | 34.5 | 34.5 | 0.0000 | 101.5 | 32.0 |
| web-awesome | desktop/cold | on | 5 / 0 | 38.0 | 38.1 | 0.0000 | 81.4 | 32.0 |
| fluent-web-components | desktop/cold | on | 5 / 0 | 29.4 | 29.4 | 0.0000 | 72.8 | 40.0 |

## Return navigation

Automation diagnostic, not field hit rate. Non-restoration is an explicit outcome; raw navigation entries retain available reasons.

| System | Attempts | Same document and persisted pageshow | Interactive after return |
| --- | ---: | ---: | ---: |
| en-reve | 5 | 3 | 5 |
| web-awesome | 5 | 5 | 5 |
| fluent-web-components | 5 | 4 | 5 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
