# web-awesome-diagnostic-v1

Protocol: b34f5d09f30f211ece2bda07fbbe60beec157c01044b67ac99398fd83221ce1e. 3/3 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| en-reve | desktop/cold | on | 1 / 0 | 168.0 | 168.0 | 0.0000 | 157.1 | 48.0 |
| web-awesome | desktop/cold | on | 1 / 0 | 136.0 | 136.0 | 0.0000 | 123.9 | 48.0 |
| fluent-web-components | desktop/cold | on | 1 / 0 | 104.0 | 104.0 | 0.0001 | 92.3 | 48.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
