# web-awesome-memory-v2

Protocol: b34f5d09f30f211ece2bda07fbbe60beec157c01044b67ac99398fd83221ce1e. 3/3 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| en-reve | desktop/cold | off | 1 / 0 | 153.3 | — | — | — | — |
| web-awesome | desktop/cold | off | 1 / 0 | 112.7 | — | — | — | — |
| fluent-web-components | desktop/cold | off | 1 / 0 | 167.6 | — | — | — | — |

## Separate memory diagnostics

Bytes; medians of available samples only. API statuses remain explicit. JS heap and browser-wide DOM counters are different scopes from API memory and connected DOM. A short lifecycle pilot does not establish a leak.

| System | Cycles | API statuses | API bytes | JS heap bytes | Browser DOM nodes |
| --- | ---: | --- | ---: | ---: | ---: |
| en-reve | 0 | {"ok":1} | 5077331 | 4287536 | 6339 |
| en-reve | 10 | {"ok":1} | 5575318 | 5255292 | 6456 |
| en-reve | 50 | {"ok":1} | 5730219 | 5601604 | 6496 |
| web-awesome | 0 | {"ok":1} | 4667509 | 3860980 | 5136 |
| web-awesome | 10 | {"ok":1} | 4974954 | 4800468 | 5223 |
| web-awesome | 50 | {"ok":1} | 5092678 | 5041492 | 5263 |
| fluent-web-components | 0 | {"ok":1} | 3680458 | 3479144 | 3851 |
| fluent-web-components | 10 | {"ok":1} | 4084765 | 4616352 | 4617 |
| fluent-web-components | 50 | {"ok":1} | 4566934 | 5053372 | 7497 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
