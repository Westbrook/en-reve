/** Browser-reported response bytes, not TCP/TLS packet accounting.
 * Freeze networkObservation before leaving the measured page. Legacy samples
 * retain lifecycle requests; explicitly exclude those harness-only URLs.
 */
export function deliveryMetrics(sample) {
  const requests = (sample.networkObservation ?? sample.network ?? []).filter(
    (r) => {
      try {
        return !new URL(r.url).pathname.startsWith("/__perf/");
      } catch {
        return false;
      }
    },
  );
  const complete = requests.filter((r) =>
    Number.isFinite(r.finishedEncodedDataLength),
  );
  const sum = (xs) => xs.reduce((n, r) => n + r.finishedEncodedDataLength, 0);
  const allComplete =
    requests.length > 0 && requests.length === complete.length;
  const category = (match) =>
    allComplete ? sum(complete.filter(match)) : null;
  const nav = sample.collector?.navigation;
  const resources = sample.collector?.entries?.resource ?? [];
  const timing = [
    ...(nav ? [nav] : []),
    ...resources.filter((r) => !r.name.includes("/__perf/")),
  ];
  return {
    responseTransferBytes: allComplete ? sum(complete) : null,
    partialResponseBytes: sum(complete),
    incompleteResponses: requests.length - complete.length,
    responseCount: requests.length,
    cachedResponses: requests.filter(
      (r) => r.fromDiskCache || r.fromServiceWorker || r.servedFromCache,
    ).length,
    htmlTransferBytes: category((r) => r.type === "Document"),
    jsTransferBytes: category((r) => r.type === "Script"),
    cssTransferBytes: category((r) => r.type === "Stylesheet"),
    fontTransferBytes: category((r) => r.type === "Font"),
    otherTransferBytes: category(
      (r) => !["Document", "Script", "Stylesheet", "Font"].includes(r.type),
    ),
    timingTransferBytes: nav
      ? timing.reduce((n, r) => n + (r.transferSize ?? 0), 0)
      : null,
    htmlEncodedBodyBytes: nav?.encodedBodySize ?? null,
    htmlDecodedBodyBytes: nav?.decodedBodySize ?? null,
    decodedPageBodyBytes:
      nav && timing.every((r) => r.decodedBodySize > 0)
        ? timing.reduce((n, r) => n + r.decodedBodySize, 0)
        : null,
    timingZeroSizeEntries: timing.filter((r) => !r.transferSize).length,
  };
}
