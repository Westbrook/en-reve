# web-awesome-qualification-startup-v1

Protocol: def0281214728bff2cc7a4626692748fb7308d61f5ef358e89b098635f18a77a. 6/6 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| en-reve | desktop/cold | on | 1 / 0 | 128.0 | — | 0.0000 | 112.9 | 40.0 |
| en-reve | mobile/cold | on | 1 / 0 | 652.0 | — | 0.0000 | 647.3 | 56.0 |
| web-awesome | mobile/cold | on | 1 / 0 | 684.0 | — | 0.0000 | 680.8 | 48.0 |
| web-awesome | desktop/cold | on | 1 / 0 | 152.0 | — | 0.0000 | 135.1 | 48.0 |
| fluent-web-components | mobile/cold | on | 1 / 0 | 608.0 | — | 0.0000 | 605.9 | 64.0 |
| fluent-web-components | desktop/cold | on | 1 / 0 | 96.0 | — | 0.0001 | 83.0 | — |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
