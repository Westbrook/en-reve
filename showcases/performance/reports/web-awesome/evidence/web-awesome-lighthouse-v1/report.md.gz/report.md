# web-awesome-lighthouse-v1

Protocol: b34f5d09f30f211ece2bda07fbbe60beec157c01044b67ac99398fd83221ce1e. 15/15 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| en-reve | mobile/cold | Lighthouse | 5 / 0 | 869.9 | 869.9 | 0.0000 | — | — |
| web-awesome | mobile/cold | Lighthouse | 5 / 0 | 765.6 | 765.6 | 0.0000 | — | — |
| fluent-web-components | mobile/cold | Lighthouse | 5 / 0 | 636.4 | 636.4 | 0.0000 | — | — |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
