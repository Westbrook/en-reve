(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function e(e){let t=new Map,n=new Map,r=[],i=new Set,a=e=>{let r=t.get(e.tagName);if(r&&r.elementClass!==e.elementClass)throw Error(`Conflicting constructors for ${e.tagName}.`);if(t.set(e.tagName,e),i.has(e))return;i.add(e);let o=n.get(e.tagName)??new Set;n.set(e.tagName,o);for(let t of e.dependencies??[])o.add(t.tagName),a(t)};for(let t of e)a(t);let o=new Set,s=new Set,c=e=>{if(!(o.has(e)||s.has(e))){s.add(e);for(let t of n.get(e)??[])c(t);s.delete(e),o.add(e),r.push(t.get(e))}};for(let e of t.keys())c(e);return Object.freeze(r)}function t(t,n){let r=e(n),i=new Map;for(let e of r){let n=i.get(e.elementClass);if(n&&n!==e.tagName)throw Error(`One constructor cannot define both ${n} and ${e.tagName}.`);i.set(e.elementClass,e.tagName);let r=t.get(e.tagName);if(r&&r!==e.elementClass)throw Error(`A different version of ${e.tagName} is already registered.`)}for(let e of r)t.get(e.tagName)||t.define(e.tagName,e.elementClass)}function n(e,n){t(e,[n])}function r(e){let t=e,n=e.getRootNode();return`customElementRegistry`in t?t.customElementRegistry:`customElementRegistry`in n?n.customElementRegistry:e.ownerDocument.defaultView?.customElements}var i=new WeakMap,a=e=>{i.set(e,e.ownerDocument)},o=e=>{i.delete(e)},s=`en-internal-registry-initialized`,c=new WeakMap;function l(e,t){let n=c.get(e);n||c.set(e,n=new Map);let r=n.get(t);return r||(r=new Set,n.set(t,r),u(e.whenDefined(t),n,t,r)),r}function u(e,t,n,r){e.then(()=>{t.delete(n);for(let e of r)e.target.deref()?.definitionReady(e.epoch);r.clear()})}var d=class{host;changed;subscriptions=new Map;epoch=0;documents=new Set;queued=!1;attempted=new WeakSet;constructor(e,t){this.host=e,this.changed=t,e.addController(this)}watch(e){let t=new Set,n=new Set;for(let i of e){if(!i.localName.includes(`-`)||i.matches(`:defined`))continue;let e=r(i);if(!e){e===null&&this.host.isConnected&&n.add(i.ownerDocument);continue}if(e.get(i.localName)){this.attempted.has(i)||(this.attempted.add(i),e.upgrade(i));continue}let a=l(e,i.localName);if(t.add(a),!this.subscriptions.has(a)){let e={target:new WeakRef(this),epoch:this.epoch};a.add(e),this.subscriptions.set(a,e)}}for(let[e,n]of this.subscriptions)t.has(e)||(e.delete(n),this.subscriptions.delete(e));for(let e of this.documents)n.has(e)||e.removeEventListener(s,this.initialized,!0);for(let e of n)this.documents.has(e)||e.addEventListener(s,this.initialized,!0);this.documents=n}initialized=()=>{this.definitionReady(this.epoch)};definitionReady(e){e===this.epoch&&this.host.isConnected&&!this.queued&&(this.queued=!0,queueMicrotask(()=>{this.queued=!1,e===this.epoch&&this.host.isConnected&&this.changed()}))}hostConnected(){this.definitionReady(this.epoch)}hostDisconnected(){++this.epoch;for(let e of this.documents)e.removeEventListener(s,this.initialized,!0);this.documents.clear();for(let[e,t]of this.subscriptions)e.delete(t);this.subscriptions.clear(),this.queued=!1}},f=globalThis,p=f.ShadowRoot&&(f.ShadyCSS===void 0||f.ShadyCSS.nativeShadow)&&`adoptedStyleSheets`in Document.prototype&&`replace`in CSSStyleSheet.prototype,m=Symbol(),h=new WeakMap,ee=class{constructor(e,t,n){if(this._$cssResult$=!0,n!==m)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(p&&e===void 0){let n=t!==void 0&&t.length===1;n&&(e=h.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),n&&h.set(t,e))}return e}toString(){return this.cssText}},g=e=>new ee(typeof e==`string`?e:e+``,void 0,m),_=(e,...t)=>new ee(e.length===1?e[0]:t.reduce((t,n,r)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if(typeof e==`number`)return e;throw Error(`Value passed to 'css' function must be a 'css' function result: `+e+`. Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.`)})(n)+e[r+1],e[0]),e,m),v=(e,t)=>{if(p)e.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(let n of t){let t=document.createElement(`style`),r=f.litNonce;r!==void 0&&t.setAttribute(`nonce`,r),t.textContent=n.cssText,e.appendChild(t)}},te=p?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t=``;for(let n of e.cssRules)t+=n.cssText;return g(t)})(e):e,{is:y,defineProperty:ne,getOwnPropertyDescriptor:re,getOwnPropertyNames:ie,getOwnPropertySymbols:ae,getPrototypeOf:oe}=Object,se=globalThis,ce=se.trustedTypes,le=ce?ce.emptyScript:``,ue=se.reactiveElementPolyfillSupport,de=(e,t)=>e,fe={toAttribute(e,t){switch(t){case Boolean:e=e?le:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},pe=(e,t)=>!y(e,t),me={attribute:!0,type:String,converter:fe,reflect:!1,useDefault:!1,hasChanged:pe};Symbol.metadata??=Symbol(`metadata`),se.litPropertyMetadata??=new WeakMap;var b=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=me){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let n=Symbol(),r=this.getPropertyDescriptor(e,n,t);r!==void 0&&ne(this.prototype,e,r)}}static getPropertyDescriptor(e,t,n){let{get:r,set:i}=re(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:r,set(t){let a=r?.call(this);i?.call(this,t),this.requestUpdate(e,a,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??me}static _$Ei(){if(this.hasOwnProperty(de(`elementProperties`)))return;let e=oe(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(de(`finalized`)))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(de(`properties`))){let e=this.properties,t=[...ie(e),...ae(e)];for(let n of t)this.createProperty(n,e[n])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[e,n]of t)this.elementProperties.set(e,n)}this._$Eh=new Map;for(let[e,t]of this.elementProperties){let n=this._$Eu(e,t);n!==void 0&&this._$Eh.set(n,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let n=new Set(e.flat(1/0).reverse());for(let e of n)t.unshift(te(e))}else e!==void 0&&t.push(te(e));return t}static _$Eu(e,t){let n=t.attribute;return!1===n?void 0:typeof n==`string`?n:typeof e==`string`?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let n of t.keys())this.hasOwnProperty(n)&&(e.set(n,this[n]),delete this[n]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return v(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$ET(e,t){let n=this.constructor.elementProperties.get(e),r=this.constructor._$Eu(e,n);if(r!==void 0&&!0===n.reflect){let i=(n.converter?.toAttribute===void 0?fe:n.converter).toAttribute(t,n.type);this._$Em=e,i==null?this.removeAttribute(r):this.setAttribute(r,i),this._$Em=null}}_$AK(e,t){let n=this.constructor,r=n._$Eh.get(e);if(r!==void 0&&this._$Em!==r){let e=n.getPropertyOptions(r),i=typeof e.converter==`function`?{fromAttribute:e.converter}:e.converter?.fromAttribute===void 0?fe:e.converter;this._$Em=r;let a=i.fromAttribute(t,e.type);this[r]=a??this._$Ej?.get(r)??a,this._$Em=null}}requestUpdate(e,t,n,r=!1,i){if(e!==void 0){let a=this.constructor;if(!1===r&&(i=this[e]),n??=a.getPropertyOptions(e),!((n.hasChanged??pe)(i,t)||n.useDefault&&n.reflect&&i===this._$Ej?.get(e)&&!this.hasAttribute(a._$Eu(e,n))))return;this.C(e,t,n)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:n,reflect:r,wrapped:i},a){n&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),!0!==i||a!==void 0)||(this._$AL.has(e)||(this.hasUpdated||n||(t=void 0),this._$AL.set(e,t)),!0===r&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}let e=this.constructor.elementProperties;if(e.size>0)for(let[t,n]of e){let{wrapped:e}=n,r=this[t];!0!==e||this._$AL.has(t)||r===void 0||this.C(t,void 0,n,r)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(e=>e.hostUpdate?.()),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(e){}firstUpdated(e){}};b.elementStyles=[],b.shadowRootOptions={mode:`open`},b[de(`elementProperties`)]=new Map,b[de(`finalized`)]=new Map,ue?.({ReactiveElement:b}),(se.reactiveElementVersions??=[]).push(`2.1.2`);var he=globalThis,ge=e=>e,_e=he.trustedTypes,ve=_e?_e.createPolicy(`lit-html`,{createHTML:e=>e}):void 0,ye=`$lit$`,x=`lit$${Math.random().toFixed(9).slice(2)}$`,be=`?`+x,xe=`<${be}>`,Se=document,Ce=()=>Se.createComment(``),we=e=>e===null||typeof e!=`object`&&typeof e!=`function`,Te=Array.isArray,Ee=e=>Te(e)||typeof e?.[Symbol.iterator]==`function`,De=`[ 	
\f\r]`,Oe=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,ke=/-->/g,Ae=/>/g,je=RegExp(`>|${De}(?:([^\\s"'>=/]+)(${De}*=${De}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,`g`),Me=/'/g,Ne=/"/g,Pe=/^(?:script|style|textarea|title)$/i,Fe=e=>(t,...n)=>({_$litType$:e,strings:t,values:n}),S=Fe(1),C=Fe(2),w=Symbol.for(`lit-noChange`),T=Symbol.for(`lit-nothing`),Ie=new WeakMap,Le=Se.createTreeWalker(Se,129);function Re(e,t){if(!Te(e)||!e.hasOwnProperty(`raw`))throw Error(`invalid template strings array`);return ve===void 0?t:ve.createHTML(t)}var ze=(e,t)=>{let n=e.length-1,r=[],i,a=t===2?`<svg>`:t===3?`<math>`:``,o=Oe;for(let t=0;t<n;t++){let n=e[t],s,c,l=-1,u=0;for(;u<n.length&&(o.lastIndex=u,c=o.exec(n),c!==null);)u=o.lastIndex,o===Oe?c[1]===`!--`?o=ke:c[1]===void 0?c[2]===void 0?c[3]!==void 0&&(o=je):(Pe.test(c[2])&&(i=RegExp(`</`+c[2],`g`)),o=je):o=Ae:o===je?c[0]===`>`?(o=i??Oe,l=-1):c[1]===void 0?l=-2:(l=o.lastIndex-c[2].length,s=c[1],o=c[3]===void 0?je:c[3]===`"`?Ne:Me):o===Ne||o===Me?o=je:o===ke||o===Ae?o=Oe:(o=je,i=void 0);let d=o===je&&e[t+1].startsWith(`/>`)?` `:``;a+=o===Oe?n+xe:l>=0?(r.push(s),n.slice(0,l)+ye+n.slice(l)+x+d):n+x+(l===-2?t:d)}return[Re(e,a+(e[n]||`<?>`)+(t===2?`</svg>`:t===3?`</math>`:``)),r]},Be=class e{constructor({strings:t,_$litType$:n},r){let i;this.parts=[];let a=0,o=0,s=t.length-1,c=this.parts,[l,u]=ze(t,n);if(this.el=e.createElement(l,r),Le.currentNode=this.el.content,n===2||n===3){let e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;(i=Le.nextNode())!==null&&c.length<s;){if(i.nodeType===1){if(i.hasAttributes())for(let e of i.getAttributeNames())if(e.endsWith(ye)){let t=u[o++],n=i.getAttribute(e).split(x),r=/([.?@])?(.*)/.exec(t);c.push({type:1,index:a,name:r[2],strings:n,ctor:r[1]===`.`?Ge:r[1]===`?`?Ke:r[1]===`@`?qe:We}),i.removeAttribute(e)}else e.startsWith(x)&&(c.push({type:6,index:a}),i.removeAttribute(e));if(Pe.test(i.tagName)){let e=i.textContent.split(x),t=e.length-1;if(t>0){i.textContent=_e?_e.emptyScript:``;for(let n=0;n<t;n++)i.append(e[n],Ce()),Le.nextNode(),c.push({type:2,index:++a});i.append(e[t],Ce())}}}else if(i.nodeType===8){if(i.data===be)c.push({type:2,index:a});else{let e=-1;for(;(e=i.data.indexOf(x,e+1))!==-1;)c.push({type:7,index:a}),e+=x.length-1}}a++}}static createElement(e,t){let n=Se.createElement(`template`);return n.innerHTML=e,n}};function Ve(e,t,n=e,r){if(t===w)return t;let i=r===void 0?n._$Cl:n._$Co?.[r],a=we(t)?void 0:t._$litDirective$;return i?.constructor!==a&&(i?._$AO?.(!1),a===void 0?i=void 0:(i=new a(e),i._$AT(e,n,r)),r===void 0?n._$Cl=i:(n._$Co??=[])[r]=i),i!==void 0&&(t=Ve(e,i._$AS(e,t.values),i,r)),t}var He=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:n}=this._$AD,r=(e?.creationScope??Se).importNode(t,!0);Le.currentNode=r;let i=Le.nextNode(),a=0,o=0,s=n[0];for(;s!==void 0;){if(a===s.index){let t;s.type===2?t=new Ue(i,i.nextSibling,this,e):s.type===1?t=new s.ctor(i,s.name,s.strings,this,e):s.type===6&&(t=new Je(i,this,e)),this._$AV.push(t),s=n[++o]}a!==s?.index&&(i=Le.nextNode(),a++)}return Le.currentNode=Se,r}p(e){let t=0;for(let n of this._$AV)n!==void 0&&(n.strings===void 0?n._$AI(e[t]):(n._$AI(e,n,t),t+=n.strings.length-2)),t++}},Ue=class e{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,n,r){this.type=2,this._$AH=T,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=Ve(this,e,t),we(e)?e===T||e==null||e===``?(this._$AH!==T&&this._$AR(),this._$AH=T):e!==this._$AH&&e!==w&&this._(e):e._$litType$===void 0?e.nodeType===void 0?Ee(e)?this.k(e):this._(e):this.T(e):this.$(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==T&&we(this._$AH)?this._$AA.nextSibling.data=e:this.T(Se.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:n}=e,r=typeof n==`number`?this._$AC(e):(n.el===void 0&&(n.el=Be.createElement(Re(n.h,n.h[0]),this.options)),n);if(this._$AH?._$AD===r)this._$AH.p(t);else{let e=new He(r,this),n=e.u(this.options);e.p(t),this.T(n),this._$AH=e}}_$AC(e){let t=Ie.get(e.strings);return t===void 0&&Ie.set(e.strings,t=new Be(e)),t}k(t){Te(this._$AH)||(this._$AH=[],this._$AR());let n=this._$AH,r,i=0;for(let a of t)i===n.length?n.push(r=new e(this.O(Ce()),this.O(Ce()),this,this.options)):r=n[i],r._$AI(a),i++;i<n.length&&(this._$AR(r&&r._$AB.nextSibling,i),n.length=i)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let t=ge(e).nextSibling;ge(e).remove(),e=t}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},We=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,n,r,i){this.type=1,this._$AH=T,this._$AN=void 0,this.element=e,this.name=t,this._$AM=r,this.options=i,n.length>2||n[0]!==``||n[1]!==``?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=T}_$AI(e,t=this,n,r){let i=this.strings,a=!1;if(i===void 0)e=Ve(this,e,t,0),a=!we(e)||e!==this._$AH&&e!==w,a&&(this._$AH=e);else{let r=e,o,s;for(e=i[0],o=0;o<i.length-1;o++)s=Ve(this,r[n+o],t,o),s===w&&(s=this._$AH[o]),a||=!we(s)||s!==this._$AH[o],s===T?e=T:e!==T&&(e+=(s??``)+i[o+1]),this._$AH[o]=s}a&&!r&&this.j(e)}j(e){e===T?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??``)}},Ge=class extends We{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===T?void 0:e}},Ke=class extends We{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==T)}},qe=class extends We{constructor(e,t,n,r,i){super(e,t,n,r,i),this.type=5}_$AI(e,t=this){if((e=Ve(this,e,t,0)??T)===w)return;let n=this._$AH,r=e===T&&n!==T||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,i=e!==T&&(n===T||r);r&&this.element.removeEventListener(this.name,this,n),i&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH==`function`?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},Je=class{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){Ve(this,e)}},Ye={M:ye,P:x,A:be,C:1,L:ze,R:He,D:Ee,V:Ve,I:Ue,H:We,N:Ke,U:qe,B:Ge,F:Je},Xe=he.litHtmlPolyfillSupport;Xe?.(Be,Ue),(he.litHtmlVersions??=[]).push(`3.3.3`);var Ze=(e,t,n)=>{let r=n?.renderBefore??t,i=r._$litPart$;if(i===void 0){let e=n?.renderBefore??null;r._$litPart$=i=new Ue(t.insertBefore(Ce(),e),e,void 0,n??{})}return i._$AI(e),i},Qe=globalThis,$e=class extends b{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Ze(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return w}};$e._$litElement$=!0,$e.finalized=!0,Qe.litElementHydrateSupport?.({LitElement:$e});var et=Qe.litElementPolyfillSupport;et?.({LitElement:$e}),(Qe.litElementVersions??=[]).push(`4.2.2`);function tt(e){return S`<div class="en-accordion" part="base"><slot @slotchange=${e}></slot></div>`}var nt=new WeakMap,rt=new WeakMap,it=new WeakMap;function at(e){let t=e.defaultView;if(!t?.customElements)throw Error(`Element scopes require a document with a browser window. Supply the owning browser document explicitly.`);return t}function ot(e,t){if(t.nodeType!==11)throw Error(`Dormant creation accepts only inert template fragments.`);let n=e.createElement(`template`);n.content.append(t.cloneNode(!0));let r=e.createElement(`div`,{customElementRegistry:null});r.innerHTML=n.innerHTML;let i=e.createDocumentFragment();return i.append(...r.childNodes),i}function st(e){let t=at(e),n=nt.get(t);if(n)return n;let r={native:!1,importMode:`global`,dormant:!1};try{let n=new t.CustomElementRegistry,i=e.createElement(`div`,{customElementRegistry:n}),a=i.attachShadow({mode:`open`,customElementRegistry:n}),o=`en-registry-capability`,s=t.HTMLElement;class c extends s{}if(i.customElementRegistry!==n||a.customElementRegistry!==n)throw Error(`Registry association unavailable`);if(i.innerHTML=`<${o}></${o}>`,n.define(o,c),n.upgrade(i),!(i.firstElementChild instanceof c))throw Error(`Scoped upgrade unavailable`);let l=e.createElement(`template`);l.innerHTML=`<${o}></${o}>`;let u=`options`;try{let t=e.importNode(l.content,{customElementRegistry:n,selfOnly:!1}),r=e.importNode(l.content,{customElementRegistry:n,selfOnly:!0});if(!(t.firstElementChild instanceof c)||r.childNodes.length)throw Error(`Import options ignored`)}catch{let t=e.implementation.createHTMLDocument();if(n.initialize(t),!(t.importNode(l.content,!0).firstElementChild instanceof c))throw Error(`Scoped import unavailable`);u=`document`}let d=!1;try{let t=ot(e,l.content),r=t.firstElementChild,i=e.createElement(`div`,{customElementRegistry:null});i.append(t),d=i.customElementRegistry===null&&r.customElementRegistry===null&&!(r instanceof c),n.initialize(i),n.upgrade(i),d&&=i.customElementRegistry===n&&r instanceof c}catch{}r={native:!0,importMode:u,dormant:d}}catch{}return r=Object.freeze(r),nt.set(t,r),r}function ct(e,t){if(t===at(e).customElements)return e;let n=st(e);if(!n.native)throw Error(`Scoped element construction is unavailable in this document.`);if(t===null){if(!n.dormant)throw Error(`Dormant template construction is unavailable; initialize the root before rendering.`);let t=it.get(e);return t||(t=e.implementation.createHTMLDocument(),t.importNode=((t,n=!1)=>{if(!n)throw Error(`Dormant template imports must be deep.`);return ot(e,t)}),it.set(e,t)),t}let r=rt.get(e);r||(r=new WeakMap,rt.set(e,r));let i=r.get(t);return i||(i=e.implementation.createHTMLDocument(),n.importMode===`options`?i.importNode=((n,r=!1)=>e.importNode(n,{customElementRegistry:t,selfOnly:!r})):t.initialize(i),r.set(t,i)),i}function lt({document:e,registry:n=`auto`}){let r=at(e),i=n===`global`?void 0:st(e),a=n===`global`?r.customElements:n===`auto`?i.native?new r.CustomElementRegistry:r.customElements:n,o=a!==r.customElements;if(o){if(!i?.native)throw Error(`The explicitly requested registry cannot be used in this document.`);if(e.createElement(`div`,{customElementRegistry:a}).customElementRegistry!==a)throw Error(`The requested registry association was not honored.`)}let c=ct(e,a);return Object.freeze({document:e,registry:a,mode:o?`scoped`:`global`,creationScope:c,register:e=>t(a,e),createElement:t=>o?e.createElement(t,{customElementRegistry:a}):e.createElement(t),attachShadow(t,n={mode:`open`}){if(t.ownerDocument!==e)throw Error(`The shadow host belongs to another document.`);if(`customElementRegistry`in n&&n.customElementRegistry!==a)throw Error(`The requested shadow registry conflicts with this scope.`);if(t.shadowRoot){if((`customElementRegistry`in t.shadowRoot?t.shadowRoot.customElementRegistry:r.customElements)!==a)throw Error(`The existing shadow root belongs to another registry; initialize a null root explicitly.`);return t.shadowRoot}return t.attachShadow(o?{...n,customElementRegistry:a}:n)},initialize(t){if(t.ownerDocument!==e)throw Error(`The root belongs to another document.`);if(!(`customElementRegistry`in t)){if(!o)return;throw Error(`Registry initialization is unavailable.`)}if(t.customElementRegistry!==null&&t.customElementRegistry!==a)throw Error(`Cannot rebind a root that already belongs to another registry.`);if(typeof a.initialize!=`function`){if(t.customElementRegistry===a)return;throw Error(`Registry initialization is unavailable.`)}a.initialize(t),t.dispatchEvent(new r.Event(s,{bubbles:!0,composed:!0})),t.isConnected||e.dispatchEvent(new r.Event(s))},get:e=>a.get(e),whenDefined:e=>a.whenDefined(e),upgrade:e=>a.upgrade(e)})}var ut=`data-en-static-styles`,dt=new WeakMap,ft=new WeakMap;function pt(e){let t=e.constructor;if(dt.has(t))return dt.get(t);let n=t.elementStyles,r=n.length>0&&n.every(e=>`cssText`in e&&typeof e.cssText==`string`&&!/@(?:import|namespace)\b/i.test(e.cssText))?n:null;return dt.set(t,r),r}var mt=class{#e;#t=!1;#n;#r;#i;#a;#o=[];#s=``;constructor(e){this.#e=e,e.addController(this)}hostConnected(){if(this.#i&&this.#i!==this.#e.ownerDocument){this.#l();return}if(this.#t)return;let e=this.#e.shadowRoot,t=e?.firstElementChild;e&&t?.localName===`style`&&t.getAttribute(`data-en-static-styles`)===`v1`&&(this.#r=e,this.#n=t)}hostUpdated(){if(this.#t)return;this.#t=!0;let e=this.#e.renderRoot;if(!this.#n&&e&&`adoptedStyleSheets`in e&&e.adoptedStyleSheets.length){let t=pt(this.#e);t&&(this.#r=e,this.#i=this.#e.ownerDocument,this.#a=t,this.#o=t.map(e=>e.styleSheet).filter(e=>!!e))}this.#e.updateComplete.then(()=>this.#c(),()=>{this.#n=void 0})}#c(){let e=this.#r,t=this.#n;if(this.#n=void 0,!p||!e||e!==this.#e.shadowRoot||!t||t.parentNode!==e||t.getAttribute(`data-en-static-styles`)!==`v1`||!(`adoptedStyleSheets`in e)||[...e.querySelectorAll(`style, link[rel~="stylesheet" i]`)].some(e=>e!==t)||t.getAttributeNames().some(e=>e!==`data-en-static-styles`&&e!==`nonce`)||!t.sheet||t.sheet.disabled)return;let n=pt(this.#e);if(!n)return;let r=[...e.adoptedStyleSheets];try{let t=n.map(e=>e.styleSheet);if(t.some(e=>e===void 0))return;let i=t.filter(e=>!r.includes(e));e.adoptedStyleSheets=[...i,...r],this.#o=i}catch{try{e.adoptedStyleSheets=r}catch{}return}this.#i=this.#e.ownerDocument,this.#a=n,this.#s=t.nonce,t.remove()}#l(){let e=this.#r,t=this.#a;if(!e||e!==this.#e.renderRoot||!t)return;let n=ft.get(t);n===void 0&&(n=t.map(e=>e.cssText).join(``),ft.set(t,n));let r=this.#e.ownerDocument.createElement(`style`);r.setAttribute(ut,`v1`),this.#s&&(r.nonce=this.#s),r.textContent=n,e.insertBefore(r,e.firstChild);try{e.adoptedStyleSheets=e.adoptedStyleSheets.filter(e=>!this.#o.includes(e))}catch{}this.#i=void 0,this.#a=void 0,this.#o=[]}};function ht(e){return e===`inherit`||e===`small`||e===`large`?e:`medium`}var E=class extends $e{#e;#t;getRenderRegistry(){return this.constructor.shadowRootOptions.customElementRegistry}attachShadow(e){if(this.#e!==void 0&&`customElementRegistry`in e&&e.customElementRegistry!==this.#e)throw Error(`Conflicting explicit shadow registry options.`);return this.#t=super.attachShadow(this.#e===void 0?e:{...e,customElementRegistry:this.#e})}createRenderRoot(){let e=this.getRenderRegistry(),t=this.shadowRoot,n=t&&`customElementRegistry`in t?t.customElementRegistry:void 0;if(t&&e!==void 0&&e!==(n===void 0?this.ownerDocument?.defaultView?.customElements:n))throw Error(`The explicitly requested render registry conflicts with the existing shadow root.`);let i=t&&n!==void 0?n:e===void 0?r(this):e;i!==void 0&&this.ownerDocument?.defaultView&&(this.renderOptions.creationScope=ct(this.ownerDocument,i),this.#e=i);try{return super.createRenderRoot()}catch(e){let t=this.shadowRoot??this.#t,n=this.ownerDocument.defaultView,r=this.constructor.elementStyles;if(e.name!==`NotAllowedError`||!t||!n||n.HTMLElement.prototype.isPrototypeOf(this)||!r.every(e=>`cssText`in e))throw e;let i=this.ownerDocument.createElement(`style`);i.textContent=r.map(e=>`cssText`in e?e.cssText:``).join(``);let a=globalThis.litNonce;return a&&(i.nonce=a),t.append(i),this.renderOptions.renderBefore??=t.firstChild,t}}update(e){this.#e===null&&this.renderRoot?.customElementRegistry&&(this.#e=this.renderRoot.customElementRegistry,this.renderOptions.creationScope=ct(this.ownerDocument,this.#e)),super.update(e)}connectedCallback(){a(this),super.connectedCallback()}disconnectedCallback(){super.disconnectedCallback(),o(this)}adoptedCallback(){let e=this.renderRoot;if(e&&this.ownerDocument.defaultView){let t=`customElementRegistry`in e?e.customElementRegistry:r(this);t!==void 0&&(this.#e=t,this.renderOptions.creationScope=ct(this.ownerDocument,t))}}staticStyles=new mt(this);static properties={size:{reflect:!0,useDefault:!0,noAccessor:!0,converter:{fromAttribute:ht,toAttribute:ht}}};#n=`medium`;get size(){return this.#n}set size(e){let t=this.#n,n=ht(e);this.#n=n;let r=this.getAttribute(`size`)===n?void 0:Object.assign(Object.create(this.constructor.getPropertyOptions(`size`)),{hasChanged:()=>!0});this.requestUpdate(`size`,t,r)}},gt=Object.defineProperty,_t=(e,t,n)=>t in e?gt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,vt=(e,t,n)=>(_t(e,typeof t==`symbol`?t:t+``,n),n),yt=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},bt=(e,t)=>{if(Object(t)!==t)throw TypeError(`Cannot use the "in" operator on this value`);return e.has(t)},xt=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},St=(e,t,n)=>(yt(e,t,`access private method`),n);function Ct(e,t){return Object.is(e,t)}var D=null,wt=!1,Tt=1,Et=Symbol(`SIGNAL`);function Dt(e){let t=D;return D=e,t}function Ot(){return D}function kt(){return wt}var At={version:0,lastCleanEpoch:0,dirty:!1,producerNode:void 0,producerLastReadVersion:void 0,producerIndexOfThis:void 0,nextProducerIndex:0,liveConsumerNode:void 0,liveConsumerIndexOfThis:void 0,consumerAllowSignalWrites:!1,consumerIsAlwaysLive:!1,producerMustRecompute:()=>!1,producerRecomputeValue:()=>{},consumerMarkedDirty:()=>{},consumerOnSignalRead:()=>{}};function jt(e){if(wt)throw Error(typeof ngDevMode<`u`&&ngDevMode?`Assertion error: signal read during notification phase`:``);if(D===null)return;D.consumerOnSignalRead(e);let t=D.nextProducerIndex++;if(Ut(D),t<D.producerNode.length&&D.producerNode[t]!==e&&Ht(D)){let e=D.producerNode[t];Vt(e,D.producerIndexOfThis[t])}D.producerNode[t]!==e&&(D.producerNode[t]=e,D.producerIndexOfThis[t]=Ht(D)?Bt(e,D,t):0),D.producerLastReadVersion[t]=e.version}function Mt(){Tt++}function Nt(e){if(e.dirty||e.lastCleanEpoch!==Tt){if(!e.producerMustRecompute(e)&&!zt(e)){e.dirty=!1,e.lastCleanEpoch=Tt;return}e.producerRecomputeValue(e),e.dirty=!1,e.lastCleanEpoch=Tt}}function Pt(e){if(e.liveConsumerNode===void 0)return;let t=wt;wt=!0;try{for(let t of e.liveConsumerNode)t.dirty||It(t)}finally{wt=t}}function Ft(){return D?.consumerAllowSignalWrites!==!1}function It(e){var t;e.dirty=!0,Pt(e),(t=e.consumerMarkedDirty)==null||t.call(e.wrapper??e)}function Lt(e){return e&&(e.nextProducerIndex=0),Dt(e)}function Rt(e,t){if(Dt(t),e&&e.producerNode!==void 0&&e.producerIndexOfThis!==void 0&&e.producerLastReadVersion!==void 0){if(Ht(e))for(let t=e.nextProducerIndex;t<e.producerNode.length;t++)Vt(e.producerNode[t],e.producerIndexOfThis[t]);for(;e.producerNode.length>e.nextProducerIndex;)e.producerNode.pop(),e.producerLastReadVersion.pop(),e.producerIndexOfThis.pop()}}function zt(e){Ut(e);for(let t=0;t<e.producerNode.length;t++){let n=e.producerNode[t],r=e.producerLastReadVersion[t];if(r!==n.version||(Nt(n),r!==n.version))return!0}return!1}function Bt(e,t,n){var r;if(Wt(e),Ut(e),e.liveConsumerNode.length===0){(r=e.watched)==null||r.call(e.wrapper);for(let t=0;t<e.producerNode.length;t++)e.producerIndexOfThis[t]=Bt(e.producerNode[t],e,t)}return e.liveConsumerIndexOfThis.push(n),e.liveConsumerNode.push(t)-1}function Vt(e,t){var n;if(Wt(e),Ut(e),typeof ngDevMode<`u`&&ngDevMode&&t>=e.liveConsumerNode.length)throw Error(`Assertion error: active consumer index ${t} is out of bounds of ${e.liveConsumerNode.length} consumers)`);if(e.liveConsumerNode.length===1){(n=e.unwatched)==null||n.call(e.wrapper);for(let t=0;t<e.producerNode.length;t++)Vt(e.producerNode[t],e.producerIndexOfThis[t])}let r=e.liveConsumerNode.length-1;if(e.liveConsumerNode[t]=e.liveConsumerNode[r],e.liveConsumerIndexOfThis[t]=e.liveConsumerIndexOfThis[r],e.liveConsumerNode.length--,e.liveConsumerIndexOfThis.length--,t<e.liveConsumerNode.length){let n=e.liveConsumerIndexOfThis[t],r=e.liveConsumerNode[t];Ut(r),r.producerIndexOfThis[n]=t}}function Ht(e){return e.consumerIsAlwaysLive||(e?.liveConsumerNode?.length??0)>0}function Ut(e){e.producerNode??=[],e.producerIndexOfThis??=[],e.producerLastReadVersion??=[]}function Wt(e){e.liveConsumerNode??=[],e.liveConsumerIndexOfThis??=[]}function Gt(e){if(Nt(e),jt(e),e.value===Yt)throw e.error;return e.value}function Kt(e){let t=Object.create(Xt);t.computation=e;let n=()=>Gt(t);return n[Et]=t,n}var qt=Symbol(`UNSET`),Jt=Symbol(`COMPUTING`),Yt=Symbol(`ERRORED`),Xt={...At,value:qt,dirty:!0,error:null,equal:Ct,producerMustRecompute(e){return e.value===qt||e.value===Jt},producerRecomputeValue(e){if(e.value===Jt)throw Error(`Detected cycle in computations.`);let t=e.value;e.value=Jt;let n=Lt(e),r,i=!1;try{r=e.computation.call(e.wrapper),i=t!==qt&&t!==Yt&&e.equal.call(e.wrapper,t,r)}catch(t){r=Yt,e.error=t}finally{Rt(e,n)}if(i){e.value=t;return}e.value=r,e.version++}};function Zt(){throw Error()}var Qt=Zt;function $t(){Qt()}function en(e){let t=Object.create(rn);t.value=e;let n=()=>(jt(t),t.value);return n[Et]=t,n}function tn(){return jt(this),this.value}function nn(e,t){Ft()||$t(),e.equal.call(e.wrapper,e.value,t)||(e.value=t,an(e))}var rn={...At,equal:Ct,value:void 0};function an(e){e.version++,Mt(),Pt(e)}var O=Symbol(`node`),k;(e=>{var t,n,r,i;class a{constructor(r,i={}){xt(this,n),vt(this,t);let a=en(r)[Et];if(this[O]=a,a.wrapper=this,i){let t=i.equals;t&&(a.equal=t),a.watched=i[e.subtle.watched],a.unwatched=i[e.subtle.unwatched]}}get(){if(!(0,e.isState)(this))throw TypeError(`Wrong receiver type for Signal.State.prototype.get`);return tn.call(this[O])}set(t){if(!(0,e.isState)(this))throw TypeError(`Wrong receiver type for Signal.State.prototype.set`);if(kt())throw Error(`Writes to signals not permitted during Watcher callback`);let n=this[O];nn(n,t)}}t=O,n=new WeakSet,e.isState=e=>typeof e==`object`&&bt(n,e),e.State=a;class o{constructor(t,n){xt(this,i),vt(this,r);let a=Kt(t)[Et];if(a.consumerAllowSignalWrites=!0,this[O]=a,a.wrapper=this,n){let t=n.equals;t&&(a.equal=t),a.watched=n[e.subtle.watched],a.unwatched=n[e.subtle.unwatched]}}get(){if(!(0,e.isComputed)(this))throw TypeError(`Wrong receiver type for Signal.Computed.prototype.get`);return Gt(this[O])}}r=O,i=new WeakSet,e.isComputed=e=>typeof e==`object`&&bt(i,e),e.Computed=o,(t=>{var n,r,i,a;function o(e){let t,n=null;try{n=Dt(null),t=e()}finally{Dt(n)}return t}t.untrack=o;function s(t){if(!(0,e.isComputed)(t)&&!(0,e.isWatcher)(t))throw TypeError(`Called introspectSources without a Computed or Watcher argument`);return t[O].producerNode?.map(e=>e.wrapper)??[]}t.introspectSources=s;function c(t){if(!(0,e.isComputed)(t)&&!(0,e.isState)(t))throw TypeError(`Called introspectSinks without a Signal argument`);return t[O].liveConsumerNode?.map(e=>e.wrapper)??[]}t.introspectSinks=c;function l(t){if(!(0,e.isComputed)(t)&&!(0,e.isState)(t))throw TypeError(`Called hasSinks without a Signal argument`);let n=t[O].liveConsumerNode;return n?n.length>0:!1}t.hasSinks=l;function u(t){if(!(0,e.isComputed)(t)&&!(0,e.isWatcher)(t))throw TypeError(`Called hasSources without a Computed or Watcher argument`);let n=t[O].producerNode;return n?n.length>0:!1}t.hasSources=u;class d{constructor(e){xt(this,r),xt(this,i),vt(this,n);let t=Object.create(At);t.wrapper=this,t.consumerMarkedDirty=e,t.consumerIsAlwaysLive=!0,t.consumerAllowSignalWrites=!1,t.producerNode=[],this[O]=t}watch(...t){if(!(0,e.isWatcher)(this))throw TypeError(`Called unwatch without Watcher receiver`);St(this,i,a).call(this,t);let n=this[O];n.dirty=!1;let r=Dt(n);for(let e of t)jt(e[O]);Dt(r)}unwatch(...t){if(!(0,e.isWatcher)(this))throw TypeError(`Called unwatch without Watcher receiver`);St(this,i,a).call(this,t);let n=this[O];Ut(n);for(let e=n.producerNode.length-1;e>=0;e--)if(t.includes(n.producerNode[e].wrapper)){Vt(n.producerNode[e],n.producerIndexOfThis[e]);let t=n.producerNode.length-1;if(n.producerNode[e]=n.producerNode[t],n.producerIndexOfThis[e]=n.producerIndexOfThis[t],n.producerNode.length--,n.producerIndexOfThis.length--,n.nextProducerIndex--,e<n.producerNode.length){let t=n.producerIndexOfThis[e],r=n.producerNode[e];Wt(r),r.liveConsumerIndexOfThis[t]=e}}}getPending(){if(!(0,e.isWatcher)(this))throw TypeError(`Called getPending without Watcher receiver`);return this[O].producerNode.filter(e=>e.dirty).map(e=>e.wrapper)}}n=O,r=new WeakSet,i=new WeakSet,a=function(t){for(let n of t)if(!(0,e.isComputed)(n)&&!(0,e.isState)(n))throw TypeError(`Called watch/unwatch without a Computed or State argument`)},e.isWatcher=e=>bt(r,e),t.Watcher=d;function f(){return Ot()?.wrapper}t.currentComputed=f,t.watched=Symbol(`watched`),t.unwatched=Symbol(`unwatched`)})(e.subtle||={})})(k||={});function on(e,t={}){let n=t.normalize??(e=>e),r=t.equals??Object.is,i=n(e),a=new k.State(Object.freeze({value:i,revision:0})),o=e=>{let t=n(e),i=a.get();return!r(i.value,t)&&(a.set(Object.freeze({value:t,revision:i.revision+1})),!0)};return{value:new k.Computed(()=>a.get().value),view:new k.Computed(()=>a.get()),set:o,reset:()=>o(i)}}function sn(e=[],{multiple:t=!1}={}){let n=(e,t)=>e===t||Object.is(e,t),r=on(e,{normalize:e=>{let n=[...new Set(e)];if(!t&&n.length>1)throw RangeError(`Single selection accepts at most one key.`);return Object.freeze(n)},equals:(e,t)=>e.length===t.length&&e.every((e,r)=>n(e,t[r]))});return{selected:r.value,view:new k.Computed(()=>{let{value:e,revision:t}=r.view.get();return Object.freeze({selected:e,revision:t})}),setSelected:r.set,toggle:e=>{let i=r.value.get();return r.set(i.includes(e)?i.filter(t=>!n(t,e)):t?[...i,e]:[e])},selectOnly:e=>r.set([e]),clear:()=>r.set([]),has:e=>r.value.get().includes(e),reset:r.reset}}var cn=new WeakMap;function ln(e,t,n,r){return new((e.ownerDocument?.defaultView?.CustomEvent)??globalThis.CustomEvent)(t,{detail:n,bubbles:!0,composed:!0,cancelable:r})}function A(e,t,n={}){if(Object.is(t.previous,t.proposed))return`unchanged`;let r=Object.freeze({...n.extraDetail,previous:t.previous,proposed:t.proposed,reason:t.reason}),i=ln(e,n.eventName??`en-change`,r,!0),a={authorRevision:t.getRevision(),acceptedEpoch:cn.get(e)?.acceptedEpoch??0},o=cn.get(e);o||(o={acceptedEpoch:0,frames:[]},cn.set(e,o));let s=o;s.frames.push(a);let c=!1,l=()=>s.frames[s.frames.length-1]===a&&t.getRevision()===a.authorRevision&&s.acceptedEpoch===a.acceptedEpoch,u=()=>{c=!0,t.rollback(t.previous)};try{if(t.stage(t.proposed),!l())return c=!0,`superseded`;let n=e.dispatchEvent(i);if(!l())return c=!0,`superseded`;if(!n)return u(),`canceled`;let r=t.canCommit?.(t.proposed)??!0;if(r||i.preventDefault(),!l())return c=!0,`superseded`;if(!r)return u(),`canceled`;s.acceptedEpoch+=1;let o=s.acceptedEpoch;return c=!0,t.commit?.(t.proposed),t.getRevision()!==a.authorRevision||s.acceptedEpoch!==o?`superseded`:`committed`}catch(e){if(!c&&l())try{u()}catch(t){throw AggregateError([e,t],`Change transaction and its rollback both failed.`)}throw e}finally{s.frames.pop(),s.frames.length===0&&cn.delete(e)}}function un(e,t,{cancelable:n=!1}={}){return e.dispatchEvent(ln(e,`en-action`,Object.freeze({...t}),n))}function dn(e,t){e.dispatchEvent(ln(e,`en-input`,Object.freeze({...t}),!1))}function fn(e,t,n){e.dispatchEvent(ln(e,t,Object.freeze({...n}),!1))}var pn={active:!1,lastError:null},mn=class{original;name=`ReactionError`;constructor(e){this.original=e}},hn=(e,t,n=Object.is)=>{let r=new k.Computed(e,{equals:n}),i=r.get(),a=async()=>{if(await 0,a===void 0)return;let e=r.get();if(!n(e,i))try{t(e,i)}catch(e){if(pn)console.error(e),pn.lastError=e;else throw new mn(e)}finally{i=e}o.watch()},o=new k.subtle.Watcher(()=>a?.());return o.watch(r),()=>{o.unwatch(r),a=void 0}},j=class{#e;#t;#n;#r=0;#i=!1;constructor(e,t){this.#e=e,this.#t=t,e.addController(this)}get snapshot(){return this.#t()}hostConnected(){if(this.#i)return;this.#n?.();let e=++this.#r;this.#n=hn(this.#t,()=>{!this.#i&&e===this.#r&&this.#e.requestUpdate()}),this.#e.requestUpdate()}hostDisconnected(){++this.#r,this.#n?.(),this.#n=void 0}dispose(){this.#i=!0,this.hostDisconnected(),this.#e.removeController(this)}},gn=Object.freeze({"--en-border-invalid-width":`2px`,"--en-border-width":`1px`,"--en-calendar-hover-opacity":`0.1`,"--en-calendar-pressed-opacity":`0.16`,"--en-palette-accent":`rgb(36 87 214 / 1)`,"--en-palette-action":`rgb(36 87 214 / 1)`,"--en-color-action":`rgb(36 87 214 / 1)`,"--en-palette-surface":`rgb(255 255 255 / 1)`,"--en-color-surface":`rgb(255 255 255 / 1)`,"--en-color-accent-border":`rgb(181.65277272 203.4391786 246.40882708 / 1)`,"--en-color-accent-subtle":`rgb(227.10943415 235.68356672 252.33563096 / 1)`,"--en-palette-emphasis":`rgb(0 0 0 / 1)`,"--en-color-action-hover":`rgb(31.04856826 77.00062118 191.430243 / 1)`,"--en-color-action-pressed":`rgb(26.20372458 67.21650774 169.34637937 / 1)`,"--en-color-action-text":`rgb(36 87 214 / 1)`,"--en-palette-boundary":`rgb(123 135 152 / 1)`,"--en-color-boundary":`rgb(123 135 152 / 1)`,"--en-color-brand":`rgb(36 87 214 / 1)`,"--en-palette-canvas":`rgb(247 248 250 / 1)`,"--en-color-canvas":`rgb(247 248 250 / 1)`,"--en-palette-danger-text":`rgb(180 35 24 / 1)`,"--en-color-danger-text":`rgb(180 35 24 / 1)`,"--en-palette-focus":`rgb(36 87 214 / 1)`,"--en-color-focus":`rgb(36 87 214 / 1)`,"--en-color-focus-halo":`rgb(36 87 214 / 1)`,"--en-palette-line":`rgb(214 220 228 / 1)`,"--en-color-line":`rgb(214 220 228 / 1)`,"--en-color-link":`rgb(36 87 214 / 1)`,"--en-palette-foreground-dark":`rgb(16 27 57 / 1)`,"--en-palette-foreground-light":`rgb(255 255 255 / 1)`,"--en-color-on-action":`rgb(255 255 255 / 1)`,"--en-color-on-brand":`rgb(255 255 255 / 1)`,"--en-color-scrim":`rgb(0 0 0 / 0.45)`,"--en-palette-selected":`rgb(231 238 255 / 1)`,"--en-color-selected":`rgb(231 238 255 / 1)`,"--en-palette-success-text":`rgb(20 108 67 / 1)`,"--en-color-success-text":`rgb(20 108 67 / 1)`,"--en-palette-surface-raised":`rgb(255 255 255 / 1)`,"--en-color-surface-raised":`rgb(255 255 255 / 1)`,"--en-palette-surface-subtle":`rgb(238 241 245 / 1)`,"--en-color-surface-subtle":`rgb(238 241 245 / 1)`,"--en-palette-text":`rgb(27 31 36 / 1)`,"--en-color-text":`rgb(27 31 36 / 1)`,"--en-palette-text-muted":`rgb(86 97 113 / 1)`,"--en-color-text-muted":`rgb(86 97 113 / 1)`,"--en-palette-warning-text":`rgb(138 75 5 / 1)`,"--en-color-warning-text":`rgb(138 75 5 / 1)`,"--en-duration-press":`80ms`,"--en-motion-press-offset":`0px`,"--en-motion-press-scale":`1`,"--en-shadow-none":`0px 0px 0px 0px rgb(0 0 0 / 0)`,"--en-duration-release":`80ms`,"--en-rhythm-base":`0.25rem`,"--en-space-3":`0.75rem`,"--en-space-4":`1rem`,"--en-radius-container":`1rem`,"--en-focus-halo-width":`0px`,"--en-focus-offset":`2px`,"--en-focus-width":`2px`,"--en-space-control-inline":`0.75rem`,"--en-radius-control":`0.5rem`,"--en-size-icon":`1.125rem`,"--en-space-12":`3rem`,"--en-space-2":`0.5rem`,"--en-space-6":`1.5rem`,"--en-size-control-min":`2.5rem`,"--en-duration-immediate":`0ms`,"--en-duration-enter":`0ms`,"--en-ease-standard":`cubic-bezier(0.2, 0, 0, 1)`,"--en-ease-enter":`cubic-bezier(0.2, 0, 0, 1)`,"--en-duration-exit":`0ms`,"--en-ease-exit":`cubic-bezier(0.2, 0, 0, 1)`,"--en-space-0-5":`0.125rem`,"--en-space-1":`0.25rem`,"--en-space-1-5":`0.375rem`,"--en-space-8":`2rem`,"--en-focus-accent-width":`0px`,"--en-size-navigation-indicator":`0px`,"--en-space-0":`0rem`,"--en-layout-panel-preferred":`20rem`,"--en-shadow-overlay":`0px 4px 16px 0px rgb(0 0 0 / 0.18)`,"--en-space-control-block":`0.375rem`,"--en-focus-inset-offset":`-2px`,"--en-font-ui-weight":`400`,"--en-font-label-strong-weight":`600`,"--en-space-actions":`0.375rem`,"--en-space-panel":`1.5rem`,"--en-size-switch-block":`1.5rem`,"--en-size-switch-inline":`2.5rem`,"--en-size-switch-thumb":`1rem`,"--en-duration-fast":`120ms`,"--en-duration-focus-enter":`0ms`,"--en-duration-focus-exit":`0ms`,"--en-duration-regular":`180ms`,"--en-duration-slow":`240ms`,"--en-duration-spin":`800ms`,"--en-ease-focus-enter":`cubic-bezier(0.2, 0, 0, 1)`,"--en-ease-focus-exit":`cubic-bezier(0.2, 0, 0, 1)`,"--en-focus-scroll-margin-block":`1rem`,"--en-focus-scroll-margin-inline":`1rem`,"--en-font-body-family":`system-ui, sans-serif`,"--en-font-body-line-height":`1.5`,"--en-font-body-size":`1rem`,"--en-size-type-scale-large":`1.125`,"--en-font-body-size-large":`1.125rem`,"--en-size-type-scale-medium":`1`,"--en-font-body-size-medium":`1rem`,"--en-size-type-scale-small":`0.9375`,"--en-font-body-size-small":`0.9375rem`,"--en-font-body-style":`normal`,"--en-font-body-tracking":`0px`,"--en-font-body-weight":`400`,"--en-font-code-family":`ui-monospace, monospace`,"--en-font-data-family":`system-ui, sans-serif`,"--en-font-data-line-height":`1.5`,"--en-font-data-size":`0.875rem`,"--en-font-data-size-large":`0.984375rem`,"--en-font-data-size-medium":`0.875rem`,"--en-font-data-size-small":`0.8203125rem`,"--en-font-data-style":`normal`,"--en-font-data-tracking":`0px`,"--en-font-data-weight":`400`,"--en-font-heading-large-family":`system-ui, sans-serif`,"--en-font-heading-large-line-height":`1.2`,"--en-font-heading-large-size":`2rem`,"--en-font-heading-large-size-large":`2.25rem`,"--en-font-heading-large-size-medium":`2rem`,"--en-font-heading-large-size-small":`1.875rem`,"--en-font-heading-large-style":`normal`,"--en-font-heading-large-tracking":`0px`,"--en-font-heading-large-weight":`600`,"--en-font-heading-medium-family":`system-ui, sans-serif`,"--en-font-heading-medium-line-height":`1.3`,"--en-font-heading-medium-size":`1.5rem`,"--en-font-heading-medium-size-large":`1.6875rem`,"--en-font-heading-medium-size-medium":`1.5rem`,"--en-font-heading-medium-size-small":`1.40625rem`,"--en-font-heading-medium-style":`normal`,"--en-font-heading-medium-tracking":`0px`,"--en-font-heading-medium-weight":`600`,"--en-font-heading-small-family":`system-ui, sans-serif`,"--en-font-heading-small-line-height":`1.4`,"--en-font-heading-small-size":`1.125rem`,"--en-font-heading-small-size-large":`1.265625rem`,"--en-font-heading-small-size-medium":`1.125rem`,"--en-font-heading-small-size-small":`1.0546875rem`,"--en-font-heading-small-style":`normal`,"--en-font-heading-small-tracking":`0px`,"--en-font-heading-small-weight":`600`,"--en-font-ui-family":`system-ui, sans-serif`,"--en-font-input-family":`system-ui, sans-serif`,"--en-font-ui-line-height":`1.5`,"--en-font-input-line-height":`1.5`,"--en-font-ui-size":`1rem`,"--en-font-input-size":`1rem`,"--en-font-input-size-large":`1.125rem`,"--en-font-input-size-medium":`1rem`,"--en-font-input-size-small":`1rem`,"--en-font-ui-style":`normal`,"--en-font-input-style":`normal`,"--en-font-ui-tracking":`0px`,"--en-font-input-tracking":`0px`,"--en-font-input-weight":`400`,"--en-font-label-strong-family":`system-ui, sans-serif`,"--en-font-label-strong-line-height":`1.5`,"--en-font-label-strong-size":`1rem`,"--en-font-label-strong-style":`normal`,"--en-font-label-strong-tracking":`0px`,"--en-font-metadata-family":`system-ui, sans-serif`,"--en-font-metadata-line-height":`1.5`,"--en-font-metadata-size":`0.8125rem`,"--en-font-metadata-size-large":`0.9140625rem`,"--en-font-metadata-size-medium":`0.8125rem`,"--en-font-metadata-size-small":`0.8125rem`,"--en-font-metadata-style":`normal`,"--en-font-metadata-tracking":`0px`,"--en-font-metadata-weight":`400`,"--en-font-ui-size-large":`1.125rem`,"--en-font-ui-size-medium":`1rem`,"--en-font-ui-size-small":`1rem`,"--en-layout-article-max":`48rem`,"--en-layout-dialog-collapse":`48rem`,"--en-layout-form-max":`28rem`,"--en-size-scale-large":`1.25`,"--en-layout-form-max-large":`35rem`,"--en-size-scale-medium":`1`,"--en-layout-form-max-medium":`28rem`,"--en-size-scale-small":`0.875`,"--en-layout-form-max-small":`24.5rem`,"--en-layout-panel-preferred-large":`25rem`,"--en-layout-panel-preferred-medium":`20rem`,"--en-layout-panel-preferred-small":`17.5rem`,"--en-layout-prose-max":`66ch`,"--en-motion-surface-offset":`0px`,"--en-motion-surface-scale":`1`,"--en-palette-on-action":`rgb(255 255 255 / 1)`,"--en-radius-choice":`2px`,"--en-radius-choice-large":`2.5px`,"--en-radius-choice-medium":`2px`,"--en-radius-choice-small":`1.75px`,"--en-radius-container-large":`1.25rem`,"--en-radius-container-medium":`1rem`,"--en-radius-container-small":`0.875rem`,"--en-radius-control-large":`0.625rem`,"--en-radius-control-medium":`0.5rem`,"--en-radius-control-small":`0.4375rem`,"--en-radius-dialog":`1.25rem`,"--en-radius-dialog-large":`1.5625rem`,"--en-radius-dialog-medium":`1.25rem`,"--en-radius-dialog-small":`1.09375rem`,"--en-radius-pill":`9999px`,"--en-shadow-dialog":`0px 12px 40px 0px rgb(0 0 0 / 0.18)`,"--en-size-avatar":`2.5rem`,"--en-size-avatar-large":`3.125rem`,"--en-size-avatar-medium":`2.5rem`,"--en-size-avatar-small":`2.1875rem`,"--en-size-choice-dot":`8px`,"--en-size-choice-dot-large":`10px`,"--en-size-choice-dot-medium":`8px`,"--en-size-choice-dot-small":`7px`,"--en-size-choice-mark-block":`10px`,"--en-size-choice-mark-block-large":`12.5px`,"--en-size-choice-mark-block-medium":`10px`,"--en-size-choice-mark-block-small":`8.75px`,"--en-size-choice-mark-inline":`6px`,"--en-size-choice-mark-inline-large":`7.5px`,"--en-size-choice-mark-inline-medium":`6px`,"--en-size-choice-mark-inline-small":`5.25px`,"--en-size-choice-mark-stroke":`2px`,"--en-size-control-large":`3.125rem`,"--en-size-control-medium":`2.5rem`,"--en-size-control-small":`2.1875rem`,"--en-size-icon-large":`1.40625rem`,"--en-size-icon-medium":`1.125rem`,"--en-size-icon-small":`0.984375rem`,"--en-size-icon-stroke":`1.5px`,"--en-size-progress":`0.5rem`,"--en-size-progress-large":`0.625rem`,"--en-size-progress-medium":`0.5rem`,"--en-size-progress-small":`0.4375rem`,"--en-size-quote-border":`2px`,"--en-size-range-length":`12rem`,"--en-size-range-track":`4px`,"--en-size-range-track-large":`5px`,"--en-size-range-track-medium":`4px`,"--en-size-range-track-small":`3.5px`,"--en-size-skeleton-line":`1rem`,"--en-size-skeleton-line-large":`1.25rem`,"--en-size-skeleton-line-medium":`1rem`,"--en-size-skeleton-line-small":`0.875rem`,"--en-size-spinner":`1.25rem`,"--en-size-spinner-large":`1.5625rem`,"--en-size-spinner-medium":`1.25rem`,"--en-size-spinner-small":`1.09375rem`,"--en-size-spinner-stroke":`2px`,"--en-size-target-min":`24px`,"--en-size-splitter":`24px`,"--en-size-splitter-large":`30px`,"--en-size-splitter-medium":`24px`,"--en-size-splitter-small":`21px`,"--en-size-swatch":`4rem`,"--en-size-swatch-large":`5rem`,"--en-size-swatch-medium":`4rem`,"--en-size-swatch-small":`3.5rem`,"--en-size-switch-block-large":`1.875rem`,"--en-size-switch-block-medium":`1.5rem`,"--en-size-switch-block-small":`1.3125rem`,"--en-size-switch-inline-large":`3.125rem`,"--en-size-switch-inline-medium":`2.5rem`,"--en-size-switch-inline-small":`2.1875rem`,"--en-size-switch-thumb-large":`1.25rem`,"--en-size-switch-thumb-medium":`1rem`,"--en-size-switch-thumb-small":`0.875rem`,"--en-size-tab-indicator":`2px`,"--en-size-target-touch":`2.75rem`,"--en-space-16":`4rem`,"--en-space-2-5":`0.625rem`,"--en-space-5":`1.25rem`,"--en-space-actions-large":`0.46875rem`,"--en-space-actions-medium":`0.375rem`,"--en-space-actions-small":`0.328125rem`,"--en-space-badge-block":`0.125rem`,"--en-space-badge-block-large":`0.15625rem`,"--en-space-badge-block-medium":`0.125rem`,"--en-space-badge-block-small":`0.109375rem`,"--en-space-badge-inline":`0.5rem`,"--en-space-badge-inline-large":`0.625rem`,"--en-space-badge-inline-medium":`0.5rem`,"--en-space-badge-inline-small":`0.4375rem`,"--en-space-control-block-large":`0.46875rem`,"--en-space-control-block-medium":`0.375rem`,"--en-space-control-block-small":`0.328125rem`,"--en-space-control-description":`0.375rem`,"--en-space-control-description-large":`0.46875rem`,"--en-space-control-description-medium":`0.375rem`,"--en-space-control-description-small":`0.328125rem`,"--en-space-control-inline-large":`0.9375rem`,"--en-space-control-inline-medium":`0.75rem`,"--en-space-control-inline-small":`0.65625rem`,"--en-space-fields":`1.5rem`,"--en-space-fields-large":`1.875rem`,"--en-space-fields-medium":`1.5rem`,"--en-space-fields-small":`1.3125rem`,"--en-space-icon-label":`0.5rem`,"--en-space-icon-label-large":`0.625rem`,"--en-space-icon-label-medium":`0.5rem`,"--en-space-icon-label-small":`0.4375rem`,"--en-space-label-control":`0.5rem`,"--en-space-label-control-large":`0.625rem`,"--en-space-label-control-medium":`0.5rem`,"--en-space-label-control-small":`0.4375rem`,"--en-space-panel-large":`1.875rem`,"--en-space-panel-medium":`1.5rem`,"--en-space-panel-small":`1.3125rem`,"--en-space-rows":`0.75rem`,"--en-space-rows-large":`0.9375rem`,"--en-space-rows-medium":`0.75rem`,"--en-space-rows-small":`0.65625rem`,"--en-space-sections":`2rem`,"--en-space-sections-large":`2.5rem`,"--en-space-sections-medium":`2rem`,"--en-space-sections-small":`1.75rem`,"--en-space-switch-inset":`0.1875rem`,"--en-space-switch-inset-large":`0.234375rem`,"--en-space-switch-inset-medium":`0.1875rem`,"--en-space-switch-inset-small":`0.1640625rem`});function _n(e){if(!Object.hasOwn(gn,e))throw RangeError(`Unknown token `+e);return gn[e]}var vn=Object.freeze([`small`,`medium`,`large`]);Object.freeze({small:.875,medium:1,large:1.25}),Object.freeze({small:.9375,medium:1,large:1.125});var yn=Object.freeze({"size.control":`size.control-min`,"size.icon":`size.icon`,"size.avatar":`size.avatar`,"size.swatch":`size.swatch`,"size.spinner":`size.spinner`,"size.progress":`size.progress`,"size.skeleton-line":`size.skeleton-line`,"size.splitter":`size.splitter`,"size.switch-inline":`size.switch-inline`,"size.switch-block":`size.switch-block`,"size.switch-thumb":`size.switch-thumb`,"size.choice-mark-inline":`size.choice-mark-inline`,"size.choice-mark-block":`size.choice-mark-block`,"size.choice-dot":`size.choice-dot`,"size.range-track":`size.range-track`,"space.switch-inset":`space.switch-inset`,"space.control-inline":`space.control-inline`,"space.control-block":`space.control-block`,"space.panel":`space.panel`,"space.rows":`space.rows`,"space.actions":`space.actions`,"space.fields":`space.fields`,"space.sections":`space.sections`,"space.icon-label":`space.icon-label`,"space.label-control":`space.label-control`,"space.control-description":`space.control-description`,"space.badge-inline":`space.badge-inline`,"space.badge-block":`space.badge-block`,"radius.control":`radius.control`,"radius.container":`radius.container`,"radius.dialog":`radius.dialog`,"radius.choice":`radius.choice`,"layout.form-max":`layout.form-max`,"layout.panel-preferred":`layout.panel-preferred`,"font.ui.size":`font.ui.size`,"font.input.size":`font.input.size`,"font.data.size":`font.data.size`,"font.metadata.size":`font.metadata.size`,"font.body.size":`font.body.size`,"font.heading-small.size":`font.heading-small.size`,"font.heading-medium.size":`font.heading-medium.size`,"font.heading-large.size":`font.heading-large.size`}),bn=Object.freeze(Object.entries(yn).map(([e,t])=>Object.freeze({role:`--en-${e.replaceAll(`.`,`-`)}`,base:`--en-${t.replaceAll(`.`,`-`)}`,variants:Object.freeze(Object.fromEntries(vn.map(t=>[t,`--en-${e.replaceAll(`.`,`-`)}-${t}`])))})));function xn(e){let t=_n(e);if(!t)throw Error(`Missing stylesheet token default: ${e}`);return`var(${e}, ${t})`}var Sn=new Map(bn.map(({base:e,role:t})=>[e,`--_en-sized-${t.slice(5)}`]));function Cn(e){let t=xn(e),n=Sn.get(e);return n?`var(${n}, ${t})`:t}function wn(e){return g(xn(e))}function M(e){return g(Cn(e))}function N(e,t){return _`var(${g(e)}, ${t})`}var Tn=_`scale var(--_en-press-duration, 0ms) ${M(`--en-ease-standard`)}, translate var(--_en-press-duration, 0ms) ${M(`--en-ease-standard`)}`;function En(e,t,n){return _`
    ${e} { --_en-press-duration: clamp(0ms, ${n.release}, 200ms); }
    ${t} { scale: clamp(.9, ${n.scale}, 1); translate: 0 clamp(-2px, ${n.offset}, 2px); --_en-press-duration: clamp(0ms, ${n.press}, 200ms); }
    :host([data-press='none']) ${e} { scale: none !important; translate: none !important; }
    @media (prefers-reduced-motion: reduce) { ${e} { scale: none !important; translate: none !important; transition: none !important; } }
  `}function P(e,t,n){return _`
    ${e} { --_en-press-shadow: 0 0 0 0 transparent; box-shadow: var(--_en-press-shadow); transition: ${Tn}; }
    ${t} { ${n.paint} --_en-press-shadow: ${n.shadow}; }
    ${En(e,t,n)}
    @media (forced-colors: active) { ${t} { background-color: Highlight; color: HighlightText; box-shadow: none; } }
  `}function Dn(e,t,n){return e?N(`--en-${e}-focus-${t}`,n):n}function On(e){let t=Dn(e.family,`width`,M(`--en-focus-width`));return{width:t,offset:Dn(e.family,`offset`,e.inset?_`calc(0px - ${t})`:M(`--en-focus-offset`)),color:Dn(e.family,`color`,M(`--en-color-focus`)),haloWidth:e.halo===!1?_`0px`:Dn(e.family,`halo-width`,M(`--en-focus-halo-width`)),haloColor:Dn(e.family,`halo-color`,M(`--en-color-focus-halo`))}}function F(e={}){let t=On(e);return _`max(0px, calc(${t.width} + ${t.offset}), ${t.haloWidth})`}var kn=_`max(${F()}, ${F({family:`button`})}, ${F({family:`input`})}, ${F({family:`option`,inset:!0})}, ${F({family:`overlay`})})`;function An(e,t={}){return _`${e} {
    scroll-margin-block: max(${M(`--en-focus-scroll-margin-block`)}, ${F(t)});
    scroll-margin-inline: max(${M(`--en-focus-scroll-margin-inline`)}, ${F(t)});
  }`}function I(e,t={}){return L(_`${e}:focus-visible`,{...t,restSelector:t.restSelector??e})}function L(e,t={}){let n=On(t),r=t.restSelector,i=r&&t.halo!==!1,a=t.baseShadow??_`var(--_en-press-shadow, 0 0 0 0 transparent)`,o=_`${t.baseTransitions??Tn},`;return _`
    ${r?An(r,t):_``}
    ${i?_`${r} {
      box-shadow: 0 0 0 0 ${n.haloColor}, ${a};
      transition: ${o} box-shadow ${M(`--en-duration-focus-exit`)} ${M(`--en-ease-focus-exit`)};
    }`:_``}
    ${e} {
      outline: ${n.width} solid ${n.color};
      outline-offset: ${n.offset};
      box-shadow: 0 0 0 ${n.haloWidth} ${n.haloColor}, ${a};
      ${i?_`transition: ${o} box-shadow ${M(`--en-duration-focus-enter`)} ${M(`--en-ease-focus-enter`)};`:_``}
    }
    ${i?_`@media (prefers-reduced-motion: reduce) {
      ${r}, ${e} { transition: none; }
    }`:_``}
    @media (forced-colors: active) {
      ${e} { outline-color: Highlight; box-shadow: none; }
      ${i?_`${r}, ${e} { box-shadow: none; transition: none; }`:_``}
    }
  `}function R(e){let t=bn.filter(({role:t})=>e.cssText.includes(`var(--_en-sized-${t.slice(5)},`)).map(({role:e,variants:t})=>`--_en-sized-${e.slice(5)}: calc(${wn(t.small).cssText} * var(--_en-size-small, 0) + ${wn(t.medium).cssText} * var(--_en-size-medium, 1) + ${wn(t.large).cssText} * var(--_en-size-large, 0));`).join(`
`);return t?_`:host, .en-foundation { ${g(t)} } ${e}`:e}var jn=R(_`.en-body, .en-prose, .en-heading-small, .en-heading-medium, .en-heading-large, .en-metadata, .en-data {
  margin: 0;
  overflow-wrap: break-word;
}
.en-body, .en-prose {
  color: var(--en-color-text, rgb(27 31 36 / 1));
    font: var(--en-font-body-weight, 400) var(--_en-sized-font-body-size, var(--en-font-body-size, 1rem)) / var(--en-font-body-line-height, 1.5) var(--en-font-body-family, system-ui, sans-serif);
  font-style: var(--en-font-body-style, normal);
  letter-spacing: var(--en-font-body-tracking, 0px);
}
.en-prose {
  max-inline-size: var(--en-prose-max-inline-size, var(--en-layout-prose-max, 66ch));
}
.en-prose :where(p, ul, ol, dl, blockquote) { margin-block: 0 var(--en-space-4, 1rem); }
.en-prose :where(ul, ol) { padding-inline-start: var(--en-space-6, 1.5rem); }
.en-heading-small {
    font: var(--en-font-heading-small-weight, 600) var(--_en-sized-font-heading-small-size, var(--en-font-heading-small-size, 1.125rem)) / var(--en-font-heading-small-line-height, 1.4) var(--en-font-heading-small-family, system-ui, sans-serif);
  font-style: var(--en-font-heading-small-style, normal);
  letter-spacing: var(--en-font-heading-small-tracking, 0px);
}
.en-heading-medium {
    font: var(--en-font-heading-medium-weight, 600) var(--_en-sized-font-heading-medium-size, var(--en-font-heading-medium-size, 1.5rem)) / var(--en-font-heading-medium-line-height, 1.3) var(--en-font-heading-medium-family, system-ui, sans-serif);
  font-style: var(--en-font-heading-medium-style, normal);
  letter-spacing: var(--en-font-heading-medium-tracking, 0px);
}
.en-heading-large {
    font: var(--en-font-heading-large-weight, 600) var(--_en-sized-font-heading-large-size, var(--en-font-heading-large-size, 2rem)) / var(--en-font-heading-large-line-height, 1.2) var(--en-font-heading-large-family, system-ui, sans-serif);
  font-style: var(--en-font-heading-large-style, normal);
  letter-spacing: var(--en-font-heading-large-tracking, 0px);
}
.en-metadata {
  color: var(--en-color-text-muted, rgb(86 97 113 / 1));
    font: var(--en-font-metadata-weight, 400) var(--_en-sized-font-metadata-size, var(--en-font-metadata-size, 0.8125rem)) / var(--en-font-metadata-line-height, 1.5) var(--en-font-metadata-family, system-ui, sans-serif);
  font-style: var(--en-font-metadata-style, normal);
  letter-spacing: var(--en-font-metadata-tracking, 0px);
}
.en-data {
    font: var(--en-font-data-weight, 400) var(--_en-sized-font-data-size, var(--en-font-data-size, 0.875rem)) / var(--en-font-data-line-height, 1.5) var(--en-font-data-family, system-ui, sans-serif);
  font-style: var(--en-font-data-style, normal);
  letter-spacing: var(--en-font-data-tracking, 0px);
  font-variant-numeric: tabular-nums;
}
`),z=_`:host { display: block; min-inline-size: 0; }`,Mn=_`:host { display: inline-block; vertical-align: middle; max-inline-size: 100%; }`,Nn=_`:host { display: inline-flex; align-items: center; justify-content: center; color: inherit; line-height: 0; vertical-align: middle; }`,B=R(_`
  ${_`
  :host, .en-foundation { --_en-size-small: 0; --_en-size-medium: 1; --_en-size-large: 0; }
  :host([size='inherit']), .en-foundation[data-size='inherit'] { --_en-size-small: inherit; --_en-size-medium: inherit; --_en-size-large: inherit; }
  :host([size='small']), .en-foundation[data-size='small'] { --_en-size-small: 1; --_en-size-medium: 0; --_en-size-large: 0; }
  :host([size='medium']), .en-foundation[data-size='medium'] { --_en-size-small: 0; --_en-size-medium: 1; --_en-size-large: 0; }
  :host([size='large']), .en-foundation[data-size='large'] { --_en-size-small: 0; --_en-size-medium: 0; --_en-size-large: 1; }
`}
  :host, .en-foundation {
    box-sizing: border-box;
    color: ${M(`--en-color-text`)};
    font-family: ${M(`--en-font-ui-family`)};
    font-style: ${M(`--en-font-ui-style`)};
    letter-spacing: ${M(`--en-font-ui-tracking`)};
    font-size: ${M(`--en-font-ui-size`)};
    font-weight: ${M(`--en-font-ui-weight`)};
    line-height: ${M(`--en-font-ui-line-height`)};
    text-align: start;
  }
  :host *, :host *::before, :host *::after,
  .en-foundation *, .en-foundation *::before, .en-foundation *::after { box-sizing: border-box; }
  :host([hidden]), :host [hidden], .en-foundation [hidden] { display: none !important; }
  :host :where(button, input, textarea, select), .en-foundation :where(button, input, textarea, select) {
    font: inherit;
    letter-spacing: inherit;
    word-spacing: inherit;
  }
  ${An(_`:where(:host([tabindex]), .en-foundation[tabindex]),
    :where(:host, .en-foundation) :where(button, input, textarea, select, a[href], [tabindex])`)}
  :host(:focus-visible), .en-foundation:focus-visible {
    outline: ${M(`--en-focus-width`)} solid ${M(`--en-color-focus`)};
    outline-offset: ${M(`--en-focus-offset`)};
  }
  .en-sr-only {
    position: absolute;
    inline-size: 1px;
    block-size: 1px;
    padding: 0;
    border: 0;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
  .en-break { overflow-wrap: anywhere; }
  .en-truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  @media (forced-colors: active) {
    :host, .en-foundation { color: CanvasText; }
    :host(:focus-visible), .en-foundation:focus-visible { outline-color: Highlight; }
  }
`),V={segmented:{scale:_`var(--en-segmented-pressed-scale, 1)`,offset:_`var(--en-segmented-pressed-offset, 0px)`,press:_`var(--en-segmented-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-segmented-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-segmented-pressed-shadow, 0 0 0 0 transparent)`,paint:_`background: var(--en-segmented-pressed-background, ${M(`--en-color-accent-subtle`)}); color: var(--en-segmented-pressed-color, ${M(`--en-color-text`)}); border-color: var(--en-segmented-pressed-border-color, ${M(`--en-color-boundary`)});`},accordion:{scale:_`var(--en-accordion-pressed-scale, 1)`,offset:_`var(--en-accordion-pressed-offset, 0px)`,press:_`var(--en-accordion-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-accordion-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-accordion-pressed-shadow, 0 0 0 0 transparent)`,paint:_`background: var(--en-accordion-pressed-background, ${M(`--en-color-accent-subtle`)}); color: var(--en-accordion-pressed-color, ${M(`--en-color-text`)});`},tab:{scale:_`var(--en-tab-pressed-scale, 1)`,offset:_`var(--en-tab-pressed-offset, 0px)`,press:_`var(--en-tab-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-tab-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-tab-pressed-shadow, 0 0 0 0 transparent)`,paint:_`background: var(--en-tab-pressed-background, ${M(`--en-color-accent-subtle`)}); color: var(--en-tab-pressed-color, var(--en-tab-color, ${M(`--en-color-action-text`)}));`},rating:{scale:_`var(--en-rating-pressed-scale, 1)`,offset:_`var(--en-rating-pressed-offset, 0px)`,press:_`var(--en-rating-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-rating-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-rating-pressed-shadow, 0 0 0 0 transparent)`,paint:_`background: var(--en-rating-pressed-background, ${M(`--en-color-accent-subtle`)}); color: var(--en-rating-pressed-color, ${M(`--en-color-text`)});`},"combobox-trigger":{scale:_`var(--en-combobox-trigger-pressed-scale, 1)`,offset:_`var(--en-combobox-trigger-pressed-offset, 0px)`,press:_`var(--en-combobox-trigger-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-combobox-trigger-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-combobox-trigger-pressed-shadow, 0 0 0 0 transparent)`,paint:_`background: var(--en-combobox-trigger-pressed-background, ${M(`--en-color-accent-subtle`)}); color: var(--en-combobox-trigger-pressed-color, ${M(`--en-color-text`)});`},navigation:{scale:_`var(--en-navigation-pressed-scale, 1)`,offset:_`var(--en-navigation-pressed-offset, 0px)`,press:_`var(--en-navigation-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-navigation-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-navigation-pressed-shadow, 0 0 0 0 transparent)`,paint:_`background: var(--en-navigation-pressed-background, ${M(`--en-color-accent-subtle`)}); color: var(--en-navigation-pressed-color, ${M(`--en-color-action-text`)});`},"editor-token":{scale:_`var(--en-editor-token-pressed-scale, 1)`,offset:_`var(--en-editor-token-pressed-offset, 0px)`,press:_`var(--en-editor-token-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-editor-token-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-editor-token-pressed-shadow, 0 0 0 0 transparent)`,paint:_`background: var(--en-editor-token-pressed-background, ${M(`--en-color-accent-subtle`)}); color: var(--en-editor-token-pressed-color, var(--en-editor-token-color, ${M(`--en-color-text`)})); border-color: var(--en-editor-token-pressed-border-color, var(--en-editor-token-border-color, ${M(`--en-color-line`)}));`},option:{scale:_`var(--en-option-pressed-scale, 1)`,offset:_`var(--en-option-pressed-offset, 0px)`,press:_`var(--en-option-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-option-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-option-pressed-shadow, 0 0 0 0 transparent)`,paint:_``},calendar:{scale:_`var(--en-calendar-pressed-scale, 1)`,offset:_`var(--en-calendar-pressed-offset, 0px)`,press:_`var(--en-calendar-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-calendar-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-calendar-pressed-shadow, 0 0 0 0 transparent)`,paint:_``},checkbox:{scale:_`var(--en-checkbox-pressed-scale, 1)`,offset:_`var(--en-checkbox-pressed-offset, 0px)`,press:_`var(--en-checkbox-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-checkbox-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-checkbox-pressed-shadow, inset 0 0 0 1px currentColor)`,paint:_`border-color: var(--en-checkbox-pressed-border-color, ${M(`--en-color-action-pressed`)});`},radio:{scale:_`var(--en-radio-pressed-scale, 1)`,offset:_`var(--en-radio-pressed-offset, 0px)`,press:_`var(--en-radio-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-radio-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-radio-pressed-shadow, inset 0 0 0 1px currentColor)`,paint:_`border-color: var(--en-radio-pressed-border-color, ${M(`--en-color-action-pressed`)});`},switch:{scale:_`var(--en-switch-pressed-scale, 1)`,offset:_`var(--en-switch-pressed-offset, 0px)`,press:_`var(--en-switch-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-switch-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-switch-pressed-shadow, inset 0 0 0 1px currentColor)`,paint:_`border-color: var(--en-switch-pressed-border-color, ${M(`--en-color-action-pressed`)});`},select:{scale:_`var(--en-select-pressed-scale, 1)`,offset:_`var(--en-select-pressed-offset, 0px)`,press:_`var(--en-select-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-select-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-select-pressed-shadow, 0 0 0 0 transparent)`,paint:_`background: var(--en-select-pressed-background, var(--en-input-background, ${M(`--en-color-accent-subtle`)})); color: var(--en-select-pressed-color, var(--en-input-color, ${M(`--en-color-text`)}));`},"number-step":{scale:_`var(--en-number-step-pressed-scale, var(--en-button-pressed-scale, 1))`,offset:_`var(--en-number-step-pressed-offset, var(--en-button-pressed-offset, 0px))`,press:_`var(--en-number-step-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-number-step-release-duration, ${M(`--en-duration-release`)})`,shadow:_`var(--en-number-step-pressed-shadow, 0 0 0 0 transparent)`,paint:_`background: var(--en-number-step-pressed-background, var(--en-button-pressed-background, ${M(`--en-color-accent-subtle`)}));`}};function Pn(e){return _`
    ${e.motion===!1?_``:P(e.base,_`${e.pressed}:not([aria-disabled='true']):not(:disabled):not([data-press='none']):not([data-reorderable])`,V.option)}
    ${e.base} {
      /* Reset each row's state slots: a nested option must not inherit its parent's state. */
      --_en-option-selected-background: initial;
      --_en-option-selected-color: initial;
      --_en-option-active-background: initial;
      --_en-option-active-color: initial;
      --_en-option-hover-background: initial;
      --_en-option-hover-color: initial;
      --_en-option-pressed-background: initial;
      --_en-option-pressed-color: initial;
      --_en-option-disabled-background: initial;
      --_en-option-disabled-color: initial;
      --_en-option-rest-background: var(--en-option-rest-background, var(--en-option-background));
      --_en-option-rest-color: var(--en-option-rest-color, var(--en-option-color));
      background: var(--_en-option-disabled-background, var(--_en-option-pressed-background, var(--_en-option-hover-background, var(--_en-option-active-background, var(--_en-option-selected-background, var(--_en-option-rest-background, ${e.restBackground}))))));
      color: var(--_en-option-disabled-color, var(--_en-option-pressed-color, var(--_en-option-hover-color, var(--_en-option-active-color, var(--_en-option-selected-color, var(--_en-option-rest-color, ${e.restColor}))))));
      font-weight: ${N(`--en-option-font-weight`,_`inherit`)};
    }
    ${e.selected?_`${e.selected} {
      --_en-option-selected-background: ${N(`--en-option-selected-background`,N(`--en-option-background`,M(`--en-color-selected`)))};
      --_en-option-selected-color: ${N(`--en-option-selected-color`,N(`--en-option-color`,e.selectedColor??e.restColor))};
      font-weight: ${N(`--en-option-selected-font-weight`,N(`--en-option-font-weight`,M(`--en-font-label-strong-weight`)))};
    }`:_``}
    @media (hover: hover) { ${e.hover} {
      --_en-option-hover-background: ${N(`--en-option-hover-background`,N(`--en-option-background`,e.hoverBackground))};
      /* With neither override set, the state slot is invalid and falls through
         to active/selected/rest paint, rather than resetting it. */
      --_en-option-hover-color: var(--en-option-hover-color, var(--en-option-color));
    } }
    ${e.focus?_`${e.focus} {
      --_en-option-hover-background: ${N(`--en-option-hover-background`,N(`--en-option-background`,e.hoverBackground))};
      --_en-option-hover-color: var(--en-option-hover-color, var(--en-option-color));
    }`:_``}
    ${e.active?_`${e.active} {
      --_en-option-active-background: var(--en-option-active-background, var(--en-option-background));
      --_en-option-active-color: var(--en-option-active-color, var(--en-option-color));
    }`:_``}
    ${e.pressed} {
      --_en-option-pressed-background: var(--en-option-pressed-background, var(--en-option-background, color-mix(in srgb, ${e.hoverBackground} 82%, currentColor)));
      --_en-option-pressed-color: var(--en-option-pressed-color, var(--en-option-color));
    }
    ${e.disabled} {
      --_en-option-disabled-background: var(--en-option-disabled-background, var(--en-option-background));
      --_en-option-disabled-color: ${N(`--en-option-disabled-color`,N(`--en-option-color`,M(`--en-color-text-muted`)))};
    }
  `}function H(e=!1){return e?_`max(${M(`--en-size-target-min`)}, ${M(`--en-size-target-touch`)})`:M(`--en-size-target-min`)}function U(e=!1,t=M(`--en-size-control-min`)){return _`max(${N(`--en-control-min-size`,t)}, ${H(e)})`}var Fn=Tn,In=_`
  .en-button {
    --_en-button-shadow: var(--en-button-shadow, 0 0 0 0 transparent);
    --_en-button-state-background: var(--en-button-rest-background);
    --_en-button-state-color: var(--en-button-rest-color);
    padding-inline: ${N(`--en-button-inline-padding`,N(`--en-control-inline-padding`,M(`--en-space-control-inline`)))};
    display: inline-flex;
    min-inline-size: ${M(`--en-size-target-min`)};
    align-items: center;
    justify-content: center;
    gap: ${M(`--en-space-icon-label`)};
    border-color: ${N(`--en-button-border-color`,M(`--en-color-action`))};
    border-radius: ${N(`--en-button-radius`,N(`--en-control-radius`,M(`--en-radius-control`)))};
    background: var(--_en-button-state-background, ${N(`--en-button-background`,M(`--en-color-action`))});
    color: var(--_en-button-state-color, ${N(`--en-button-color`,M(`--en-color-on-action`))});
    font-weight: ${M(`--en-font-label-strong-weight`)};
    text-align: center;
    text-decoration: none;
    white-space: normal;
    overflow-wrap: break-word;
    cursor: pointer;
    transition: background-color ${M(`--en-duration-fast`)} ${M(`--en-ease-standard`)},
      border-color ${M(`--en-duration-fast`)} ${M(`--en-ease-standard`)}, ${Fn};
  }
  @media (hover: hover) { .en-button:where(:not(:disabled):not([aria-disabled='true']):hover) { background: var(--_en-button-state-background, ${N(`--en-button-background`,M(`--en-color-action-hover`))}); } }
  .en-button:where(:not(:disabled):not([aria-disabled='true']):active) { background: var(--_en-button-state-background, ${N(`--en-button-background`,M(`--en-color-action-pressed`))}); }
  .en-button--secondary, .en-button[data-variant='secondary'] {
    background: var(--_en-button-state-background, ${N(`--en-button-background`,M(`--en-color-surface-subtle`))});
    color: var(--_en-button-state-color, ${N(`--en-button-color`,M(`--en-color-text`))});
    border-color: ${N(`--en-button-border-color`,M(`--en-color-boundary`))};
  }
  .en-button--quiet, .en-button[data-variant='ghost'] {
    background: var(--_en-button-state-background, none);
    color: var(--_en-button-state-color, ${N(`--en-button-color`,M(`--en-color-action-text`))});
    border-color: ${N(`--en-button-border-color`,M(`--en-color-line`))};
  }
  @media (hover: hover) { :is(.en-button--secondary, .en-button--quiet, .en-button[data-variant='secondary'], .en-button[data-variant='ghost']):not(:disabled):not([aria-disabled='true']):hover {
    background: var(--_en-button-state-background, ${N(`--en-button-background`,M(`--en-color-selected`))});
  } }
  .en-button--danger, .en-button[data-variant='danger'] {
    background: var(--_en-button-state-background, ${N(`--en-button-background`,M(`--en-color-surface`))});
    color: var(--_en-button-state-color, ${N(`--en-button-color`,M(`--en-color-danger-text`))});
    border-color: ${N(`--en-button-border-color`,M(`--en-color-danger-text`))};
  }
  @media (hover: hover) { :is(.en-button--danger, .en-button[data-variant='danger']):not(:disabled):not([aria-disabled='true']):hover {
    background: var(--_en-button-state-background, ${N(`--en-button-background`,M(`--en-color-surface-subtle`))});
  } }
  /* Explicit state refinements have a shared order across variants. Clearing an
     absent state slot preserves each variant's existing broad/semantic fallback. */
  @media (hover: hover) {
    .en-button:where(:not(:disabled):not([aria-disabled='true']):hover) {
      --_en-button-state-background: var(--en-button-hover-background);
      --_en-button-state-color: var(--en-button-hover-color);
    }
  }
  .en-button:where(:not(:disabled):not([aria-disabled='true']):active) {
    --_en-button-state-background: var(--en-button-pressed-background);
    --_en-button-state-color: var(--en-button-pressed-color);
  }
  /* Held feedback is distinct on neutral variants, including no-hover pointers. */
  :is(.en-button--secondary, .en-button--quiet, .en-button--danger, .en-button[data-variant='secondary'], .en-button[data-variant='ghost'], .en-button[data-variant='danger']):not(:disabled):not([aria-disabled='true']):active {
    background: var(--en-button-pressed-background, var(--en-button-background, color-mix(in srgb, ${M(`--en-color-surface`)} 82%, currentColor)));
  }
  :is(.en-button--danger, .en-button[data-variant='danger']):not(:disabled):not([aria-disabled='true']):active {
    background: var(--en-button-pressed-background, var(--en-button-background, ${M(`--en-color-danger-text`)}));
    color: var(--en-button-pressed-color, var(--en-button-color, ${M(`--en-color-surface`)}));
  }
  .en-button:not(:disabled):not([aria-disabled='true']):active {
    --_en-button-shadow: var(--en-button-pressed-shadow, var(--en-button-shadow, 0 0 0 0 transparent));
  }
  /* Transform the complete control, including its surface, border and glyphs.
     Popup semantics do not imply a universal motion policy: a theme may refine
     their held geometry independently. Layout allocation remains unchanged. */
  ${En(_`.en-button`,_`.en-button:not(:disabled):not([aria-disabled='true']):not([data-press='none']):active`,{scale:_`var(--en-button-pressed-scale, ${M(`--en-motion-press-scale`)})`,offset:_`var(--en-button-pressed-offset, ${M(`--en-motion-press-offset`)})`,press:_`var(--en-button-press-duration, ${M(`--en-duration-press`)})`,release:_`var(--en-button-release-duration, ${M(`--en-duration-release`)})`})}
  .en-button[aria-haspopup]:not([aria-haspopup='false']):not(:disabled):not([aria-disabled='true']):not([data-press='none']):active {
    scale: clamp(.9, var(--en-button-popup-pressed-scale, var(--en-button-pressed-scale, ${M(`--en-motion-press-scale`)})), 1);
    translate: 0 clamp(-2px, var(--en-button-popup-pressed-offset, var(--en-button-pressed-offset, ${M(`--en-motion-press-offset`)})), 2px);
  }
  :host([data-press='none']) .en-button { scale: none !important; translate: none !important; }
  @media (prefers-reduced-motion: reduce) {
    .en-button { scale: none !important; translate: none !important; transition: none !important; }
  }
  @media (forced-colors: active) {
    .en-button:not(:disabled):not([aria-disabled='true']):active { background: Highlight !important; color: HighlightText !important; }
  }
  .en-button__prefix, .en-button__suffix { display: contents; }
  .en-button__label { min-inline-size: 0; }
  .en-icon-button { padding-inline: ${M(`--en-space-2`)}; min-inline-size: max(${N(`--en-control-min-size`,M(`--en-size-control-min`))}, ${M(`--en-size-target-min`)}); }
  /* Explicit button mode; existing stepper/overlay icon recipes retain their layout. */
  .en-button[data-icon-only] {
    --_en-icon-button-side: max(var(--_en-text-control-block-size), calc(max(${N(`--en-icon-size`,M(`--en-size-icon`))}, ${M(`--en-size-spinner`)}) + 2 * ${M(`--en-space-control-block`)} + 2 * ${M(`--en-border-width`)}));
    min-inline-size: var(--_en-icon-button-side);
    min-block-size: var(--_en-icon-button-side);
    inline-size: max-content;
    aspect-ratio: 1;
    padding: ${M(`--en-space-control-block`)};
    gap: 0;
    flex-shrink: 0;
  }
  .en-button[data-icon-only] > .en-button__label {
    position: absolute;
    inline-size: 1px;
    block-size: 1px;
    padding: 0;
    margin: -1px;
    border: 0;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
  /* Keep one visual glyph while busy. The label and slotted nodes remain intact. */
  .en-button[data-icon-only][aria-busy='true'] > :is(.en-button__prefix, .en-button__suffix) { display: none; }

`,Ln=_`background-color ${M(`--en-duration-fast`)} ${M(`--en-ease-standard`)}, border-color ${M(`--en-duration-fast`)} ${M(`--en-ease-standard`)}, ${Fn}`,Rn=I(_`.en-button`,{family:`button`,baseTransitions:Ln,baseShadow:_`var(--_en-button-shadow, 0 0 0 0 transparent)`}),zn=_`@media (hover: hover) { .en-button:not(:disabled):not([aria-disabled='true']):hover { background: Highlight !important; color: HighlightText !important; } }`,Bn=_`
  ${Rn}
  ${I(_`.en-accordion-trigger`,{family:`button`})}
  ${I(_`:where(.en-input, .en-textarea, .en-select, .en-color-control)`,{family:`input`})}
  ${I(_`.en-option`,{family:`option`})}
  ${I(_`:where(.en-link, .en-control:not(.en-color-control), .en-checkbox, .en-radio, .en-switch,
    .en-range, .en-tab, .en-split-separator, .en-rating-item)`)}
`,Vn=On({family:`input`}),Hn=_`
  .en-field-focus-frame {
    position: relative;
    min-inline-size: 0;
    --_en-field-focus-accent-width: ${N(`--en-input-focus-accent-width`,M(`--en-focus-accent-width`))};
  }
  .en-field-focus-frame:not(.en-number-group) { display: grid; }
  .en-field-focus-frame > :is(input, textarea) { display: block; }
  .en-field-focus-frame::after {
    content: '';
    position: absolute;
    pointer-events: none;
    inset-inline: 0;
    inset-block-end: 0;
    box-sizing: border-box;
    block-size: max(var(--_en-field-focus-accent-width), ${N(`--en-control-radius`,M(`--en-radius-control`))});
    border-end-start-radius: ${N(`--en-control-radius`,M(`--en-radius-control`))};
    border-end-end-radius: ${N(`--en-control-radius`,M(`--en-radius-control`))};
    border-block-end: var(--_en-field-focus-accent-width) solid ${N(`--en-input-focus-accent-color`,M(`--en-color-focus`))};
    clip-path: inset(calc(100% - var(--_en-field-focus-accent-width)) 0 0 0);
    transform: scaleX(0);
    transform-origin: center;
    transition: transform ${M(`--en-duration-focus-exit`)} ${M(`--en-ease-focus-exit`)};
  }
  .en-number-group.en-field-focus-frame {
    box-shadow: 0 0 0 0 ${Vn.haloColor};
    transition: box-shadow ${M(`--en-duration-focus-exit`)} ${M(`--en-ease-focus-exit`)};
  }
  .en-number-group.en-field-focus-frame:focus-within {
    box-shadow: 0 0 0 ${Vn.haloWidth} ${Vn.haloColor};
    transition-duration: ${M(`--en-duration-focus-enter`)};
    transition-timing-function: ${M(`--en-ease-focus-enter`)};
  }
  .en-field-focus-frame:focus-within::after {
    transform: scaleX(1);
    transition-duration: ${M(`--en-duration-focus-enter`)};
    transition-timing-function: ${M(`--en-ease-focus-enter`)};
  }
  @media (prefers-reduced-motion: reduce) {
    .en-field-focus-frame::after, .en-field-focus-frame:focus-within::after,
    .en-number-group.en-field-focus-frame, .en-number-group.en-field-focus-frame:focus-within { transition: none; }
  }
  @media (forced-colors: active) {
    .en-field-focus-frame::after, .en-field-focus-frame:focus-within::after { border-block-end-color: Highlight; transition: none; }
    .en-number-group.en-field-focus-frame, .en-number-group.en-field-focus-frame:focus-within { box-shadow: none; transition: none; }
  }
`,Un=_`max(0px, ${N(`--en-segmented-control-frame-inset`,M(`--en-space-1`))})`,Wn=_`calc(${Un} + ${M(`--en-border-width`)})`;function Gn(e=!1,t=!1){let n=H(e),r=M(`--en-space-control-block`),i=M(`--en-border-width`),a=_`calc(${M(`--en-space-1`)} + ${i})`,o=t?_`max(${a}, ${Wn})`:a;return _`max(
    ${N(`--en-control-min-size`,M(`--en-size-control-min`))},
    calc(${n} + 2 * ${o}),
    calc(${M(`--en-font-input-size`)} * ${M(`--en-font-input-line-height`)} + 2 * ${r} + 2 * ${i}),
    calc(${M(`--en-font-ui-size`)} * ${M(`--en-font-ui-line-height`)} + 2 * max(${r}, ${o}) + 2 * ${i})
  )`}var W=R(_`
  /* Recompute for both frame and item; descendant overrides stay effective. */
  .en-segmented-control, .en-segmented-item {
    --_en-text-control-block-size: ${Gn(!1,!0)};
  }
  .en-option, .en-tab, .en-accordion-trigger {
    min-inline-size: ${M(`--en-size-target-min`)};
    min-block-size: ${U()};
    padding-block: ${M(`--en-space-control-block`)};
    padding-inline: ${M(`--en-space-control-inline`)};
    color: ${N(`--en-option-color`,M(`--en-color-text`))};
    font: inherit;
    text-align: start;
    overflow-wrap: break-word;
    cursor: pointer;
  }
  .en-option {
    display: flex;
    align-items: center;
    gap: ${M(`--en-space-icon-label`)};
    border-radius: ${N(`--en-option-radius`,M(`--en-radius-control`))};
    background: ${N(`--en-option-background`,M(`--en-color-surface`))};
  }
  ${Pn({base:_`.en-option`,selected:_`.en-option[aria-selected='true'], .en-option[aria-checked='true'], .en-option[data-selected]`,hover:_`.en-option:not([aria-disabled='true']):hover`,active:_`.en-option[data-active]`,pressed:_`.en-option:not([aria-disabled='true']):active`,disabled:_`.en-option[aria-disabled='true']`,restBackground:M(`--en-color-surface`),restColor:M(`--en-color-text`),hoverBackground:M(`--en-color-surface-subtle`)})}
  /* Keep the native recipe's visible keyboard candidate fallback. */
  .en-option[data-active] { --_en-option-active-background: var(--en-option-active-background, var(--en-option-background, ${M(`--en-color-surface-subtle`)})); }
  .en-option[aria-disabled='true'] { cursor: default; }
  .en-listbox, .en-tree { display: flex; flex-direction: column; gap: ${M(`--en-space-1`)}; min-inline-size: 0; }
  .en-tree-group { padding-inline-start: ${M(`--en-space-4`)}; }
  .en-choice-group, .en-rating, .en-toolbar, .en-segmented { display: flex; align-items: center; flex-wrap: wrap; gap: ${M(`--en-space-actions`)}; min-inline-size: 0; }
  .en-choice-group[data-orientation='vertical'], .en-choice-group[aria-orientation='vertical'] { flex-direction: column; align-items: stretch; }
  .en-choice-group > slot, .en-rating > slot, .en-toolbar > slot, .en-segmented > slot { display: contents; }
  .en-rating-item, .en-rating-clear, .en-segmented-item {
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-inline-size: ${M(`--en-size-target-min`)};
    min-block-size: ${U()};
    border: ${M(`--en-border-width`)} solid transparent;
    border-radius: ${M(`--en-radius-control`)};
    color: ${M(`--en-color-text`)};
    cursor: pointer;
    overflow-wrap: break-word;
  }
  .en-rating-values {
    display: flex;
    flex-wrap: wrap;
    gap: ${M(`--en-space-0-5`)};
    min-inline-size: 0;
    max-inline-size: 100%;
  }
  /* Preserve each target instead of squeezing stars to keep a row on one line. */
  .en-rating-item {
    --_en-rating-target-min: ${M(`--en-size-target-min`)};
    --_en-rating-target-size: max(${U()}, var(--_en-rating-target-min), calc(${M(`--en-size-icon`)} + 2 * ${M(`--en-space-control-block`)} + 2 * ${M(`--en-border-width`)}));
    flex: 0 0 auto;
    inline-size: var(--_en-rating-target-size);
    block-size: var(--_en-rating-target-size);
    padding: ${M(`--en-space-control-block`)};
    border-radius: ${N(`--en-rating-star-radius`,M(`--en-radius-control`))};
  }
  .en-rating-clear { max-inline-size: 100%; }
  .en-rating-clear, .en-segmented-item { padding: ${M(`--en-space-control-block`)} ${M(`--en-space-control-inline`)}; }
  .en-rating-clear { color: ${M(`--en-color-text-muted`)}; }
  .en-rating-clear:has(:checked) { background: ${M(`--en-color-selected`)}; color: ${M(`--en-color-action-text`)}; border-color: ${M(`--en-color-accent-border`)}; }
  .en-rating-star { font-size: ${M(`--en-size-icon`)}; line-height: 1; color: ${M(`--en-color-text-muted`)}; }
  .en-rating-star[data-filled] { color: ${M(`--en-color-action-text`)}; }
  .en-rating-item:has(:disabled), .en-rating-clear:has(:disabled), .en-segmented-item[data-disabled] { cursor: default; color: ${M(`--en-color-text-muted`)}; }
  .en-rating-item:has(:disabled) .en-rating-star { color: ${M(`--en-color-text-muted`)}; }
  ${L(_`.en-rating-item:has(:focus-visible), .en-rating-clear:has(:focus-visible), .en-segmented-item:has(:focus-visible)`)}
  .en-segmented-control { display: flex; align-items: stretch; flex-wrap: wrap; gap: ${M(`--en-space-0-5`)}; min-inline-size: 0; min-block-size: var(--_en-text-control-block-size); padding: ${Un}; border: ${M(`--en-border-width`)} solid ${M(`--en-color-line`)}; border-radius: ${N(`--en-control-radius`,M(`--en-radius-control`))}; background: ${M(`--en-color-surface-subtle`)}; }
  .en-segmented-item {
    flex: 1 1 auto;
    /* The shared control height includes the frame; each label keeps its target floor. */
    min-block-size: max(calc(var(--_en-text-control-block-size) - 2 * ${Wn}), ${M(`--en-size-target-min`)});
    padding-block: max(0px, calc(${M(`--en-space-control-block`)} - ${Wn}));
    border-radius: max(0px, ${N(`--en-control-radius`,M(`--en-radius-control`))} - ${Wn});
    text-align: center;
  }
  .en-segmented-item[data-selected] { background: ${M(`--en-color-surface`)}; border-color: ${M(`--en-color-boundary`)}; color: ${M(`--en-color-action-text`)}; font-weight: ${M(`--en-font-label-strong-weight`)}; }
  @media (hover: hover) { .en-segmented-item:not([data-disabled]):hover { background: ${M(`--en-color-selected`)}; } }
  .en-segmented-item:not([data-disabled]):active, .en-rating-item:not(:has(:disabled)):active, .en-rating-clear:not(:has(:disabled)):active, .en-accordion-trigger:not(:disabled):not([aria-disabled='true']):active { background: ${M(`--en-color-accent-subtle`)}; }
  .en-segmented-item[data-disabled] { color: ${M(`--en-color-text-muted`)}; }
  .en-segmented-label { min-inline-size: 0; }
  .en-tabs { min-inline-size: 0; isolation: isolate; }
  .en-tab-list { position: relative; display: flex; flex-wrap: wrap; gap: ${M(`--en-space-1`)}; min-inline-size: 0; border-block-end: ${M(`--en-border-width`)} solid ${M(`--en-color-line`)}; }
  .en-tab-list > slot { display: contents; }
  /* Raise focus paint within the tabs, including over following rows and panels.
     Slotted hosts and native tabs are flex items; their z-index needs no positioning. */
  .en-tab-list:focus-within { z-index: 1; }
  .en-tab-list > slot::slotted(:focus-within), .en-tab-list > .en-tab:focus-within { z-index: 1; }
  .en-tab-list[aria-orientation='vertical'], .en-tab-list[data-orientation='vertical'] { flex-direction: column; border-block-end: 0; border-inline-end: ${M(`--en-border-width`)} solid ${M(`--en-color-line`)}; }
  .en-tab {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: ${M(`--en-space-icon-label`)};
    border: 0;
    border-block-end: ${M(`--en-size-tab-indicator`)} solid ${M(`--en-color-line`)};
    background: ${N(`--en-tab-background`,M(`--en-color-surface`))};
    color: ${N(`--en-tab-color`,M(`--en-color-text`))};
  }
  @media (hover: hover) { .en-tab:not([aria-disabled='true']):hover { background: ${N(`--en-tab-hover-background`,N(`--en-tab-background`,M(`--en-color-surface-subtle`)))}; color: ${N(`--en-tab-hover-color`,N(`--en-tab-color`,M(`--en-color-text`)))}; } }
  .en-tab[aria-selected='true'], :host([role='tab'][aria-selected='true']) .en-tab {
    color: ${N(`--en-tab-selected-color`,N(`--en-tab-color`,M(`--en-color-action-text`)))};
    border-block-end-color: ${N(`--en-tab-indicator-color`,M(`--en-color-action`))};
    background: ${N(`--en-tab-selected-background`,N(`--en-tab-background`,M(`--en-color-selected`)))};
    font-weight: ${M(`--en-font-label-strong-weight`)};
  }
  .en-tab:not([aria-disabled='true']):not(:host([aria-disabled='true']) *):active { background: ${N(`--en-tab-pressed-background`,M(`--en-color-accent-subtle`))}; }
  .en-tab[aria-disabled='true'], :host([role='tab'][aria-disabled='true']) .en-tab { color: ${M(`--en-color-text-muted`)}; cursor: default; }
  .en-tab-panel { min-inline-size: 0; padding-block: ${M(`--en-space-4`)}; }
  .en-accordion { display: flex; flex-direction: column; min-inline-size: 0; isolation: isolate; }
  .en-accordion > slot { display: contents; }
  /* Keep the focused item's outline above adjacent surfaces within this group.
     Slotted hosts are flex items, so no positioned containing block is needed. */
  .en-accordion > slot::slotted(:focus-within) { z-index: 1; }
  .en-accordion-item { border-block-end: ${M(`--en-border-width`)} solid ${M(`--en-color-line`)}; min-inline-size: 0; }
  .en-accordion-trigger { display: flex; align-items: center; justify-content: space-between; gap: ${M(`--en-space-icon-label`)}; inline-size: 100%; border: 0; background: ${M(`--en-color-surface`)}; font-weight: ${M(`--en-font-label-strong-weight`)}; }
  @media (hover: hover) { .en-accordion-trigger:hover { background: ${M(`--en-color-surface-subtle`)}; } }
  .en-accordion-trigger[aria-disabled='true'], .en-accordion-trigger:disabled { color: ${M(`--en-color-text-muted`)}; cursor: default; }
  .en-accordion-panel { padding-block: ${M(`--en-space-3`)} ${M(`--en-space-4`)}; padding-inline: ${M(`--en-space-control-inline`)}; }
  ${Bn}
  @media (any-pointer: coarse) {
    .en-option, .en-tab, .en-accordion-trigger, .en-rating-item, .en-rating-clear { min-inline-size: ${H(!0)}; min-block-size: ${U(!0)}; }
    .en-segmented-control, .en-segmented-item { --_en-text-control-block-size: ${Gn(!0,!0)}; }
    .en-segmented-item { min-inline-size: ${H(!0)}; min-block-size: max(calc(var(--_en-text-control-block-size) - 2 * ${Wn}), ${H(!0)}); }
    .en-rating-item { --_en-rating-target-min: ${H(!0)}; min-inline-size: ${H(!0)}; }
  }
  ${P(_`:is(.en-segmented-item)`,_`.en-segmented-item:not([data-disabled]):not([data-press='none']):active`,V.segmented)}
  ${P(_`:is(.en-rating-item, .en-rating-clear)`,_`:is(.en-rating-item, .en-rating-clear):not(:has(:disabled)):not([data-press='none']):active`,V.rating)}
  ${P(_`.en-accordion-trigger`,_`.en-accordion-trigger:not(:disabled):not([aria-disabled='true']):not([data-press='none']):active`,V.accordion)}
  ${P(_`.en-tab`,_`.en-tab:not([aria-disabled='true']):not(:host([aria-disabled='true']) *):not([data-press='none']):active`,V.tab)}
  @media (forced-colors: active) {
    .en-option, .en-tab, .en-accordion-trigger { background: Canvas; color: CanvasText; }
    .en-option[aria-selected='true'], .en-option[aria-checked='true'], .en-option[data-selected], .en-tab[aria-selected='true'], :host([role='tab'][aria-selected='true']) .en-tab { background: Highlight; color: HighlightText; border-color: Highlight; }
    .en-option[aria-disabled='true'], .en-tab[aria-disabled='true'], :host([role='tab'][aria-disabled='true']) .en-tab { color: GrayText; }
    .en-segmented-control { background: Canvas; border-color: CanvasText; }
    .en-segmented-item { color: CanvasText; }
    .en-segmented-item[data-selected], .en-rating-clear:has(:checked) { background: Highlight; color: HighlightText; border-color: Highlight; }
    @media (hover: hover) { .en-segmented-item:not([data-disabled]):hover { background: Highlight; color: HighlightText; } }
    /* Chromium can draw an opaque text backplate even for explicit system colors.
       Only this text span avoids that second adjustment; its inherited foreground
       and the parent surface still come entirely from the user's system palette. */
    .en-segmented-label { forced-color-adjust: none; color: inherit; background: none; }
    .en-segmented-label[data-rich] { forced-color-adjust: auto; }
    .en-rating-star { color: CanvasText; }
    .en-rating-star[data-filled] { color: Highlight; }
    .en-segmented-item[data-disabled] { background: Canvas; color: GrayText; border-color: GrayText; }
    .en-rating-item:has(:disabled) .en-rating-star, .en-rating-clear:has(:disabled) { color: GrayText; }
    .en-rating-item:has(:focus-visible), .en-rating-clear:has(:focus-visible), .en-segmented-item:has(:focus-visible) { outline-color: Highlight; }
  }
`);n(customElements,{tagName:`en-accordion`,elementClass:class extends E{static properties={value:{attribute:!1,noAccessor:!0},multiple:{type:Boolean,reflect:!0}};static styles=[B,z,W];model=sn([],{multiple:!0});authorRevision=0;presentedValue=[];items=[];observer;upgrades=new d(this,()=>this.readItems());constructor(){super(),this.multiple=!1,new j(this,()=>this.model.view.get())}get value(){return this.model.selected.get()}set value(e){this.authorRevision+=1;let t=this.presentedValue,n=Array.isArray(e)?e.filter(e=>typeof e==`string`):[];this.model.setSelected(n),this.presentedValue=this.value,this.requestUpdate(`value`,t)}disconnectedCallback(){this.observer?.disconnect();for(let e of this.items)e.setOwner(void 0);super.disconnectedCallback()}connectedCallback(){super.connectedCallback();for(let e of this.items)e.setOwner(this);this.observer=new MutationObserver(()=>this.readItems()),this.observer.observe(this,{subtree:!0,childList:!0,attributes:!0,attributeFilter:[`value`,`slot`]})}toggleItem(e){this.requestItemOpen(e,!this.value.includes(e.value),`toggle`)}requestItemOpen(e,t,n=`api`){if(!this.items.includes(e)||e.disabled||!e.value)return`canceled`;let r=e.value,i=this.multiple,a=this.value;if(a.includes(r)===t)return`unchanged`;let o=Object.freeze(t?this.multiple?[...a,r]:[r]:a.filter(e=>e!==r));return A(this,{previous:a,proposed:o,reason:n,getRevision:()=>this.authorRevision,canCommit:()=>this.isConnected&&!e.disabled&&e.value===r&&this.multiple===i&&!!this.renderRoot.querySelector(`slot`)?.assignedElements({flatten:!0}).includes(e),stage:e=>{this.model.setSelected(e)},rollback:e=>{this.model.setSelected(e)},commit:()=>{let e=this.presentedValue;this.presentedValue=this.value,this.requestUpdate(`value`,e),this.syncItems()}})}readItems(){for(let e of this.items)e.setOwner(void 0);let e=this.renderRoot.querySelector(`slot`)?.assignedElements({flatten:!0})??[];this.upgrades.watch(e),this.items=e.filter(e=>e.localName===`en-accordion-item`&&e.matches(`:defined`)&&typeof e.setOwner==`function`&&`open`in e);for(let e of this.items)e.setOwner(this);this.syncItems()}syncItems(){for(let e of this.items)e.open=this.presentedValue.includes(e.value)}updated(e){(e.has(`value`)||e.has(`multiple`))&&this.syncItems()}render(){return tt(()=>this.readItems())}}});function Kn(e,t){return S`
    <section class="en-accordion-item" part="base">
      <div part="heading" role="heading" aria-level=${e.headingLevel}>
        <button id="trigger" class="en-accordion-trigger" part="control" type="button"
          aria-expanded=${String(e.open)} aria-controls="panel" ?disabled=${e.disabled}
          @click=${t}>
          <slot name="label"><slot name="heading">${e.label}</slot></slot>
          <span part="indicator" aria-hidden="true">${e.open?`−`:`+`}</span>
        </button>
      </div>
      <div id="panel" class="en-accordion-panel" part="panel" ?hidden=${!e.open}>
        <slot></slot>
      </div>
    </section>`}function qn(e=!1){let t=on(e);return{open:t.value,view:new k.Computed(()=>{let{value:e,revision:n}=t.view.get();return Object.freeze({open:e,revision:n})}),setOpen:t.set,toggle:()=>t.set(!t.value.get()),reset:t.reset}}n(customElements,{tagName:`en-accordion-item`,elementClass:class extends E{static properties={value:{type:String,reflect:!0},label:{type:String},open:{type:Boolean,reflect:!0,noAccessor:!0},disabled:{type:Boolean,reflect:!0},headingLevel:{type:Number,attribute:`heading-level`}};static styles=[B,z,W];model=qn(!1);authorRevision=0;presentedOpen=!1;owner;constructor(){super(),this.value=``,this.label=``,this.disabled=!1,this.headingLevel=3,new j(this,()=>this.model.view.get())}get open(){return this.model.open.get()}set open(e){this.authorRevision+=1;let t=this.presentedOpen;this.model.setOpen(!!e),this.presentedOpen=this.open,this.requestUpdate(`open`,t)}setOwner(e){this.owner=e}focus(e){this.renderRoot.querySelector(`button`)?.focus(e)}requestOpen(e){return this.changeOpen(!!e,`api`)}toggle(){this.disabled||(this.owner?this.owner.toggleItem(this):this.changeOpen(!this.open,`toggle`))}changeOpen(e,t){if(this.disabled)return`canceled`;if(this.owner)return this.owner.requestItemOpen(this,e,t);let n=this.parentNode;return A(this,{previous:this.open,proposed:e,reason:t,getRevision:()=>this.authorRevision,canCommit:()=>this.isConnected&&this.parentNode===n&&!this.disabled&&!this.owner,stage:e=>{this.model.setOpen(e)},rollback:e=>{this.model.setOpen(e)},commit:()=>{let e=this.presentedOpen;this.presentedOpen=this.open,this.requestUpdate(`open`,e)}})}updated(e){if(e.has(`open`)&&!this.presentedOpen){let e=this.renderRoot.querySelector(`#panel`),t=this.ownerDocument.activeElement;(t&&e?.contains(t)||t&&this.contains(t)&&t.slot!==`heading`&&t.slot!==`label`)&&this.focus()}}render(){let e=Math.max(1,Math.min(6,Math.trunc(this.headingLevel)||3));return Kn({open:this.presentedOpen,disabled:this.disabled,label:this.label,headingLevel:e},()=>this.toggle())}}});var Jn=R(_`
  .en-spinner {
    display: inline-block;
    flex: none;
    inline-size: ${M(`--en-size-spinner`)};
    block-size: ${M(`--en-size-spinner`)};
    border: ${M(`--en-size-spinner-stroke`)} solid currentColor;
    border-inline-end-color: ${M(`--en-color-line`)};
    border-radius: ${M(`--en-radius-pill`)};
    animation: en-style-spin ${M(`--en-duration-spin`)} linear infinite;
  }
  @keyframes en-style-spin { to { transform: rotate(1turn); } }
  .en-skeleton { display: block; inline-size: 100%; block-size: ${N(`--en-skeleton-size`,M(`--en-size-skeleton-line`))}; background: ${N(`--en-skeleton-color`,M(`--en-color-surface-subtle`))}; border-radius: ${M(`--en-radius-control`)}; }
  .en-skeleton[data-shape='circle'] { inline-size: ${N(`--en-skeleton-size`,M(`--en-size-avatar`))}; block-size: ${N(`--en-skeleton-size`,M(`--en-size-avatar`))}; border-radius: ${M(`--en-radius-pill`)}; }
  .en-skeleton[data-shape='rectangle'] { block-size: ${N(`--en-skeleton-size`,M(`--en-space-16`))}; }
  @media (prefers-reduced-motion: reduce) { .en-spinner { animation: none; } }
  @media (forced-colors: active) { .en-spinner { border-color: CanvasText; border-inline-end-color: GrayText; } .en-skeleton { background: Canvas; border: ${M(`--en-border-width`)} solid GrayText; } }
`),Yn=R(_`
  .en-alert { display: flex; align-items: flex-start; gap: ${M(`--en-space-3`)}; min-inline-size: 0; padding: ${M(`--en-space-4`)}; border: ${M(`--en-border-width`)} solid ${N(`--en-alert-border-color`,M(`--en-color-accent-border`))}; border-radius: ${M(`--en-radius-container`)}; background: ${N(`--en-alert-background`,M(`--en-color-surface`))}; color: ${N(`--en-alert-color`,M(`--en-color-text`))}; }
  .en-alert__icon { flex: none; color: ${M(`--en-color-action`)}; }
  .en-alert__content { min-inline-size: 0; flex: 1 1 auto; overflow-wrap: break-word; }
  .en-alert__close { flex: none; margin-inline-start: auto; }
  .en-alert[data-variant='success'] { border-color: ${N(`--en-alert-border-color`,M(`--en-color-success-text`))}; }
  .en-alert[data-variant='warning'] { border-color: ${N(`--en-alert-border-color`,M(`--en-color-warning-text`))}; }
  .en-alert[data-variant='danger'] { border-color: ${N(`--en-alert-border-color`,M(`--en-color-danger-text`))}; }
  .en-alert[data-variant='success'] .en-alert__icon { color: ${M(`--en-color-success-text`)}; }
  .en-alert[data-variant='warning'] .en-alert__icon { color: ${M(`--en-color-warning-text`)}; }
  .en-alert[data-variant='danger'] .en-alert__icon { color: ${M(`--en-color-danger-text`)}; }
  .en-badge { display: inline-flex; align-items: center; gap: ${M(`--en-space-icon-label`)}; max-inline-size: 100%; padding-block: ${M(`--en-space-badge-block`)}; padding-inline: ${M(`--en-space-badge-inline`)}; border: ${M(`--en-border-width`)} solid ${M(`--en-color-line`)}; border-radius: ${N(`--en-badge-radius`,M(`--en-radius-control`))}; background: ${N(`--en-badge-background`,M(`--en-color-surface-subtle`))}; color: ${N(`--en-badge-color`,M(`--en-color-text`))}; font-size: ${M(`--en-font-metadata-size`)}; line-height: ${M(`--en-font-metadata-line-height`)}; overflow-wrap: break-word; }
  .en-badge__prefix { display: contents; }
  .en-badge__label { min-inline-size: 0; }
  .en-badge[data-variant='accent'] { background: ${N(`--en-badge-background`,M(`--en-color-accent-subtle`))}; color: ${N(`--en-badge-color`,M(`--en-color-action-text`))}; }
  .en-badge:is([data-variant='success'], [data-variant='warning'], [data-variant='danger']) { background: ${N(`--en-badge-background`,M(`--en-color-surface`))}; }
  .en-badge[data-variant='success'] { color: ${N(`--en-badge-color`,M(`--en-color-success-text`))}; }
  .en-badge[data-variant='warning'] { color: ${N(`--en-badge-color`,M(`--en-color-warning-text`))}; }
  .en-badge[data-variant='danger'] { color: ${N(`--en-badge-color`,M(`--en-color-danger-text`))}; }
  .en-progress, .en-progress-track { display: block; inline-size: 100%; block-size: ${N(`--en-progress-size`,M(`--en-size-progress`))}; overflow: hidden; border: 0; border-radius: ${M(`--en-radius-pill`)}; background: ${N(`--en-progress-track-color`,M(`--en-color-surface-subtle`))}; }
  .en-progress { appearance: none; accent-color: ${N(`--en-progress-color`,M(`--en-color-action`))}; }
  .en-progress-fill { display: block; inline-size: clamp(0%, var(--en-progress-value, 0%), 100%); block-size: 100%; border-radius: inherit; background: ${N(`--en-progress-color`,M(`--en-color-action`))}; }
  .en-progress::-webkit-progress-bar { background: ${N(`--en-progress-track-color`,M(`--en-color-surface-subtle`))}; border-radius: inherit; }
  .en-progress::-webkit-progress-value { background: ${N(`--en-progress-color`,M(`--en-color-action`))}; border-radius: inherit; }
  .en-progress::-moz-progress-bar { background: ${N(`--en-progress-color`,M(`--en-color-action`))}; border-radius: inherit; }
  ${Jn}
  @media (forced-colors: active) {
    .en-alert, .en-alert[data-variant], .en-badge, .en-badge[data-variant] { color: CanvasText; background: Canvas; border-color: CanvasText; }
    .en-alert__icon, .en-alert[data-variant] .en-alert__icon { color: CanvasText; }
    .en-progress, .en-progress-track { background: Canvas; border: ${M(`--en-border-width`)} solid CanvasText; }
    .en-progress-fill { background: Highlight; }
    .en-progress::-webkit-progress-bar { background: Canvas; }
    .en-progress::-webkit-progress-value { background: Highlight; }
    .en-progress::-moz-progress-bar { background: Highlight; }
  }
`),Xn=R(_`
  .en-icon { display: inline-flex; align-items: center; justify-content: center; flex: none; inline-size: ${N(`--en-icon-size`,M(`--en-size-icon`))}; block-size: ${N(`--en-icon-size`,M(`--en-size-icon`))}; vertical-align: middle; color: inherit; }
  svg.en-icon[data-logical]:dir(rtl) { scale:-1 1; }
  .en-icon > :where(svg, img), .en-icon ::slotted(svg), .en-icon ::slotted(img) { display: block; inline-size: 100%; block-size: 100%; }
  svg.en-icon, .en-icon > svg, .en-icon ::slotted(svg) { display: block; stroke-width: ${M(`--en-size-icon-stroke`)}; }
  .en-avatar { display: inline-grid; place-items: center; vertical-align: middle; flex: none; inline-size: ${N(`--en-avatar-size`,M(`--en-size-avatar`))}; block-size: ${N(`--en-avatar-size`,M(`--en-size-avatar`))}; overflow: hidden; border-radius: ${N(`--en-avatar-radius`,M(`--en-radius-pill`))}; background: ${M(`--en-color-surface-subtle`)}; color: ${M(`--en-color-text`)}; }
  .en-avatar__image { display: block; inline-size: 100%; block-size: 100%; object-fit: cover; }
  .en-avatar__fallback { font-weight: ${M(`--en-font-label-strong-weight`)}; }
  .en-media { display: block; max-inline-size: 100%; block-size: auto; border-radius: ${N(`--en-media-radius`,M(`--en-radius-container`))}; aspect-ratio: ${N(`--en-media-aspect-ratio`,_`auto`)}; }
  @media (forced-colors: active) { .en-avatar { color: CanvasText; background: Canvas; border: ${M(`--en-border-width`)} solid CanvasText; } }
`),Zn=R(_`
  :host { inline-size: max(${N(`--en-swatch-size`,M(`--en-size-swatch`))}, ${U(!1,M(`--en-size-target-min`))}); min-inline-size: ${U(!1,M(`--en-size-target-min`))}; }
  .en-swatch__sample { position: relative; display: block; appearance: none; inline-size: 100%; block-size: max(${N(`--en-swatch-size`,M(`--en-size-swatch`))}, ${U(!1,M(`--en-size-target-min`))}); min-inline-size: ${U(!1,M(`--en-size-target-min`))}; padding: 0; margin: 0; overflow: hidden; border: ${M(`--en-border-width`)} solid ${M(`--en-color-boundary`)}; border-radius: ${M(`--en-radius-control`)}; background: transparent; color: inherit; cursor: pointer; }
  @media (any-pointer: coarse) {
    :host { inline-size:max(${N(`--en-swatch-size`,M(`--en-size-swatch`))},${U(!0,M(`--en-size-target-min`))}); min-inline-size:${U(!0,M(`--en-size-target-min`))}; }
    .en-swatch__sample { min-inline-size:${U(!0,M(`--en-size-target-min`))}; min-block-size:${U(!0,M(`--en-size-target-min`))}; }
  }
  @media (hover: hover) { .en-swatch__sample:not(:disabled):hover { border-color: ${M(`--en-color-action`)}; } }
  .en-swatch__sample:not(:disabled):active { border-width: max(2px, ${M(`--en-border-width`)}); }
  .en-swatch__sample:disabled { cursor: default; }
  .en-swatch__color { display: block; inline-size: 100%; block-size: 100%; }
  ${Bn}
  @media (forced-colors: active) {
    .en-swatch__sample { border-color: ButtonText; background: Canvas; }
  @media (hover: hover) { .en-swatch__sample:not(:disabled):hover { border-color: ButtonText; background: Canvas; } }
    .en-swatch__sample:disabled { border-color: GrayText; }
    .en-swatch__color { forced-color-adjust: none; }
  }
`),Qn=e=>S`
  <span
    class="en-avatar"
    part="base"
    data-size=${e.size}
    role=${e.name?`img`:T}
    aria-label=${e.name||T}
    aria-hidden=${e.name?T:`true`}
  >
    ${e.src&&!e.failed?S`<img class="en-avatar__image" part="image" src=${e.src} alt="" @error=${e.onError} />`:S`<span class="en-avatar__fallback" part="fallback" aria-hidden="true">${e.initials}</span>`}
  </span>
`;n(customElements,{tagName:`en-avatar`,elementClass:class extends E{static properties={name:{type:String},src:{type:String},initials:{type:String},failed:{state:!0}};static styles=[B,Mn,Xn];constructor(){super(),this.name=``,this.src=``,this.initials=``,this.failed=!1}willUpdate(e){e.has(`src`)&&(this.failed=!1)}onError=()=>{this.failed=!0};get fallbackInitials(){if(this.initials)return this.initials;let e=(this.name||``).trim().split(/\s+/u).filter(Boolean);if(e.length===0)return``;let t=new Intl.Segmenter(void 0,{granularity:`grapheme`}),n=e=>t.segment(e)[Symbol.iterator]().next().value?.segment??``;return`${n(e[0])}${e.length>1?n(e[e.length-1]):``}`}render(){return Qn({name:this.name,src:this.src,initials:this.fallbackInitials,size:this.size,failed:this.failed,onError:this.onError})}}});var $n=e=>S`
  <span class="en-badge" part="base" data-variant=${e}>
    <slot class="en-badge__prefix" name="prefix"></slot><span class="en-badge__label" part="label"><slot name="label"><slot></slot></slot></span>
  </span>
`;n(customElements,{tagName:`en-badge`,elementClass:class extends E{static properties={variant:{reflect:!0}};static styles=[B,Mn,Yn];constructor(){super(),this.variant=`neutral`}render(){return $n(this.variant)}}});var er=`data-en-breadcrumbs-plan`,tr=`en-crumb-`,nr=new WeakMap,rr=class{#e;#t=new WeakMap;#n=new Map;#r=[];#i=[];#a=``;#o=0;#s=!1;#c=!1;#l;#u;constructor(e){if(this.#e=e,nr.has(e))throw TypeError(`Only one breadcrumb projection controller can own a host.`);nr.set(e,this),e.addController(this)}get view(){let e=!1;return{entries:this.#r.map((t,n)=>{let r=this.#i[n]??!1,i=!r&&e;return r||(e=!0),{key:t,hidden:r,separator:i}}),error:this.#a}}prepareSSR(e,t=[]){if(!Array.isArray(e)||e.some(e=>typeof e!=`string`||!e)||new Set(e).size!==e.length)throw TypeError(`Invalid breadcrumb SSR projection plan.`);if(!Array.isArray(t)||t.some(t=>!e.includes(t))||new Set(t).size!==t.length)throw TypeError(`Invalid breadcrumb SSR visibility plan.`);this.#r=[...e],this.#i=e.map(e=>t.includes(e)),this.#e.requestUpdate()}hostConnected(){this.#d();let e=this.#e.ownerDocument.defaultView?.MutationObserver;e&&(this.#l??=new e(()=>this.#h()),this.#l.observe(this.#e,{childList:!0}),this.#u??=new e(()=>this.#h()),this.#c&&this.#h())}hostUpdated(){this.#c=!0,this.#h()}hostDisconnected(){this.#l?.disconnect(),this.#u?.disconnect();for(let[e,t]of this.#n)e.getAttribute(`slot`)===t&&e.removeAttribute(`slot`);this.#n.clear()}#d(){if(this.#s)return;this.#s=!0;let e=this.#e.getAttribute(er);if(e===null)return;let t;try{t=JSON.parse(e)}catch{throw TypeError(`Invalid breadcrumb SSR projection metadata.`)}if(!t||typeof t!=`object`)throw TypeError(`Invalid breadcrumb SSR projection metadata.`);let n=t;if(n.version!==1||!Array.isArray(n.keys)||n.keys.some((e,t)=>e!==`ssr-${t}`))throw TypeError(`Invalid breadcrumb SSR projection metadata.`);this.prepareSSR(n.keys,n.hiddenKeys);let r=new Set(n.keys);for(let e of this.#e.children){let t=e.getAttribute(`slot`);if(!t?.startsWith(`en-crumb-`))continue;let n=t.slice(9);if(!r.delete(n))throw TypeError(`Invalid or repeated breadcrumb SSR assignment.`);this.#t.set(e,n),this.#n.set(e,t)}}#f(){for(let e of this.#e.childNodes)if(e.nodeType===3&&[...e.textContent??``].some(e=>![9,10,12,13,32].includes(e.charCodeAt(0))))throw TypeError(`Breadcrumb direct text must be inside an a or span child.`);let e=[...this.#e.children];for(let t of e){if(t.namespaceURI!==`http://www.w3.org/1999/xhtml`||![`a`,`span`].includes(t.localName))throw TypeError(`Breadcrumbs require direct native a or noninteractive span children.`);if(t.getAttribute(`hidden`)?.toLowerCase()===`until-found`)throw TypeError(`hidden=until-found is not supported by breadcrumb projection.`)}return e}#p(e){this.#u?.disconnect();for(let t of e)this.#u?.observe(t,{attributes:!0,attributeFilter:[`slot`,`hidden`]})}#m(e){e!==this.#a&&(this.#a=e,this.#e.requestUpdate())}#h(){let e=this.#e;if(this.#c&&e.isConnected&&e.shadowRoot){this.#p([...e.children]);try{let t=this.#f(),n=new Set,r=t.map(e=>{let t=this.#t.get(e),r=e.getAttribute(`slot`);if(this.#n.has(e)&&r!==this.#n.get(e))throw TypeError(`The slot attribute is owned by breadcrumb projection; do not remove or replace it.`);if(r!==null&&(!t||r!==`en-crumb-${t}`))throw TypeError(`The slot attribute is reserved for breadcrumb projection; author no slot attribute.`);if(t??=`client-${++this.#o}`,n.has(t))throw TypeError(`Duplicate breadcrumb projection assignment.`);return n.add(t),this.#t.set(e,t),{node:e,key:t,hidden:e.hasAttribute(`hidden`)}});this.#m(``);for(let[e,n]of this.#n)t.includes(e)||(e.getAttribute(`slot`)===n&&e.removeAttribute(`slot`),this.#n.delete(e));let i=r.map(({key:e})=>e),a=r.map(e=>e.hidden);if((a.length!==this.#i.length||a.some((e,t)=>e!==this.#i[t]))&&(this.#i=a,e.requestUpdate()),i.length!==this.#r.length||i.some((e,t)=>e!==this.#r[t])){this.#r=i,e.requestUpdate();return}let o=new Map([...e.shadowRoot.querySelectorAll(`slot[data-projection-key]`)].map(e=>[e.dataset.projectionKey,e]));for(let{node:t,key:n}of r){let r=o.get(n);if(r){if(e.shadowRoot.slotAssignment===`manual`){let e=r.assignedNodes();(e.length!==1||e[0]!==t)&&r.assign(t)}else{let e=`${tr}${n}`;t.getAttribute(`slot`)!==e&&t.setAttribute(`slot`,e),this.#n.set(t,e)}}}}catch(e){this.#m(e instanceof Error?e.message:String(e))}}}},ir={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},ar=e=>(...t)=>({_$litDirective$:e,values:t}),or=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,n){this._$Ct=e,this._$AM=t,this._$Ci=n}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}},{I:sr}=Ye,cr=e=>e,lr=()=>document.createComment(``),ur=(e,t,n)=>{let r=e._$AA.parentNode,i=t===void 0?e._$AB:t._$AA;if(n===void 0)n=new sr(r.insertBefore(lr(),i),r.insertBefore(lr(),i),e,e.options);else{let t=n._$AB.nextSibling,a=n._$AM,o=a!==e;if(o){let t;n._$AQ?.(e),n._$AM=e,n._$AP!==void 0&&(t=e._$AU)!==a._$AU&&n._$AP(t)}if(t!==i||o){let e=n._$AA;for(;e!==t;){let t=cr(e).nextSibling;cr(r).insertBefore(e,i),e=t}}}return n},dr=(e,t,n=e)=>(e._$AI(t,n),e),fr={},pr=(e,t=fr)=>e._$AH=t,mr=e=>e._$AH,hr=e=>{e._$AR(),e._$AA.remove()},gr=(e,t,n)=>{let r=new Map;for(let i=t;i<=n;i++)r.set(e[i],i);return r},_r=ar(class extends or{constructor(e){if(super(e),e.type!==ir.CHILD)throw Error(`repeat() can only be used in text expressions`)}dt(e,t,n){let r;n===void 0?n=t:t!==void 0&&(r=t);let i=[],a=[],o=0;for(let t of e)i[o]=r?r(t,o):o,a[o]=n(t,o),o++;return{values:a,keys:i}}render(e,t,n){return this.dt(e,t,n).values}update(e,[t,n,r]){let i=mr(e),{values:a,keys:o}=this.dt(t,n,r);if(!Array.isArray(i))return this.ut=o,a;let s=this.ut??=[],c=[],l,u,d=0,f=i.length-1,p=0,m=a.length-1;for(;d<=f&&p<=m;)if(i[d]===null)d++;else if(i[f]===null)f--;else if(s[d]===o[p])c[p]=dr(i[d],a[p]),d++,p++;else if(s[f]===o[m])c[m]=dr(i[f],a[m]),f--,m--;else if(s[d]===o[m])c[m]=dr(i[d],a[m]),ur(e,c[m+1],i[d]),d++,m--;else if(s[f]===o[p])c[p]=dr(i[f],a[p]),ur(e,i[d],i[f]),f--,p++;else if(l===void 0&&(l=gr(o,p,m),u=gr(s,d,f)),l.has(s[d])){if(l.has(s[f])){let t=u.get(o[p]),n=t===void 0?null:i[t];if(n===null){let t=ur(e,i[d]);dr(t,a[p]),c[p]=t}else c[p]=dr(n,a[p]),ur(e,i[d],n),i[t]=null;p++}else hr(i[f]),f--}else hr(i[d]),d++;for(;p<=m;){let t=ur(e,c[m+1]);dr(t,a[p]),c[p++]=t}for(;d<=f;){let e=i[d++];e!==null&&hr(e)}return this.ut=o,pr(e,c),w}});function vr({label:e,entries:t,error:n}){return S`
		<nav class="en-breadcrumbs" part="base" aria-label=${e}>
			<p class="en-breadcrumbs__diagnostic" role="status" ?hidden=${!n}>${n||T}</p>
			<ol class="en-breadcrumbs__list" part="list" role="list">
				${_r(t,e=>e.key,({key:e,hidden:t,separator:n})=>S`
					<li class="en-breadcrumbs__item" part="item" data-projection-key=${e} ?hidden=${t}>
						${n?S`<span class="en-breadcrumbs__separator" part="separator" aria-hidden="true">/</span>`:T}
						<slot name=${`${tr}${e}`} data-projection-key=${e}></slot>
					</li>
				`)}
			</ol>
		</nav>
	`}var yr=_`
  .en-breadcrumbs__list, .en-recipe-breadcrumbs {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: ${M(`--en-space-2`)};
    margin: 0;
    padding: 0;
    list-style: none;
  }
  .en-breadcrumbs__item, .en-recipe-breadcrumbs li {
    display: inline-flex;
    align-items: center;
    gap: ${M(`--en-space-2`)};
    min-inline-size: 0;
  }
`,br=R(_`
  .en-section-nav, .en-breadcrumbs, .en-navigation-link, .en-breadcrumbs__label, .en-skip-link {
    box-sizing: border-box;
    min-inline-size: 0;
    max-inline-size: 100%;
    font: ${M(`--en-font-ui-weight`)} ${M(`--en-font-ui-size`)} / ${M(`--en-font-ui-line-height`)} ${M(`--en-font-ui-family`)}; font-style: ${M(`--en-font-ui-style`)}; letter-spacing: ${M(`--en-font-ui-tracking`)};
    text-align: start;
    overflow-wrap: anywhere;
  }
  .en-section-nav {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: ${N(`--en-navigation-gap`,M(`--en-space-1`))};
    margin-block: ${M(`--en-space-6`)};
    padding-block: ${M(`--en-space-2`)};
    background: ${N(`--en-navigation-background`,M(`--en-color-canvas`))};
    border-block-end: ${M(`--en-border-width`)} solid ${N(`--en-navigation-border-color`,M(`--en-color-line`))};
  }
  /* Stay in normal flow until a controller or author supplies measured sticky geometry. */
  .en-section-nav--sticky {
    position: var(--en-navigation-position, static);
    inset-block-start: var(--en-navigation-offset, 0px);
    z-index: var(--en-navigation-z-index, 20);
  }
  .en-navigation-link {
    display: inline-flex;
    align-items: center;
    min-inline-size: ${M(`--en-size-target-min`)};
    min-block-size: ${M(`--en-size-target-min`)};
    color: ${N(`--en-navigation-color`,M(`--en-color-text-muted`))};
    text-decoration: underline;
    text-underline-offset: ${M(`--en-border-width`)};
  }
  .en-navigation-link[aria-current]:not([aria-current='false']) {
    color: ${N(`--en-navigation-current-color`,N(`--en-navigation-active-color`,M(`--en-color-text`)))};
  }
  @media (hover: hover) { .en-navigation-link:hover {
    color: ${N(`--en-navigation-hover-color`,N(`--en-navigation-active-color`,M(`--en-color-text`)))};
  } }
  .en-navigation-link[aria-current]:not([aria-current='false']), .en-breadcrumbs__label[aria-current]:not([aria-current='false']) {
    font-weight: ${M(`--en-font-label-strong-weight`)};
  }
  .en-section-nav .en-navigation-link {
    min-block-size: ${U()};
    padding-block: ${M(`--en-space-2`)};
    padding-inline: ${M(`--en-space-control-inline`)};
    border-radius: ${N(`--en-navigation-link-radius`,M(`--en-radius-pill`))};
    text-decoration: none;
  }
  .en-section-nav .en-navigation-link[aria-current]:not([aria-current='false']) {
    background: ${N(`--en-navigation-current-background`,N(`--en-navigation-active-background`,M(`--en-color-surface-subtle`)))};
  }
  @media (hover: hover) { .en-section-nav .en-navigation-link:hover {
    background: ${N(`--en-navigation-hover-background`,N(`--en-navigation-active-background`,M(`--en-color-surface-subtle`)))};
  } }
  ${yr}
  .en-breadcrumbs { color: ${N(`--en-navigation-color`,M(`--en-color-text-muted`))}; }
  .en-breadcrumbs__list { gap: ${N(`--en-navigation-gap`,M(`--en-space-2`))}; }
  .en-breadcrumbs__item { max-inline-size: 100%; gap: ${N(`--en-navigation-gap`,M(`--en-space-2`))}; }
  .en-breadcrumbs__label { color: ${N(`--en-navigation-hover-color`,N(`--en-navigation-active-color`,M(`--en-color-text`)))}; }
  .en-breadcrumbs__separator { flex: none; color: ${M(`--en-color-text-muted`)}; }
  .en-navigation-target {
    scroll-margin-block-start: calc(var(--en-navigation-height, 0px) + var(--en-navigation-offset, 0px) + ${M(`--en-space-6`)});
  }
  .en-skip-link {
    position: fixed;
    inset-block-start: ${M(`--en-space-3`)};
    inset-inline-start: ${M(`--en-space-3`)};
    z-index: calc(var(--en-navigation-z-index, 20) + 1);
    max-inline-size: calc(100% - 2 * ${M(`--en-space-3`)});
    min-inline-size: ${M(`--en-size-target-min`)};
    min-block-size: ${M(`--en-size-target-min`)};
    padding: ${M(`--en-space-3`)};
    border: ${M(`--en-border-width`)} solid ${M(`--en-color-boundary`)};
    border-radius: ${M(`--en-radius-control`)};
    background: ${M(`--en-color-surface`)};
    color: ${M(`--en-color-text`)};
    text-decoration: underline;
    text-underline-offset: ${M(`--en-border-width`)};
    transform: translateY(calc(-100% - 2 * ${M(`--en-space-3`)}));
    transition: none;
  }
  .en-skip-link:focus { transform: none; }
  ${P(_`:is(.en-navigation-link, summary)`,_`:is(.en-navigation-link, summary):not([aria-disabled='true']):not([data-press='none']):active`,V.navigation)}
  ${P(_`::slotted(a[href])`,_`::slotted(a[href]:not([aria-disabled='true']):not([data-press='none']):active)`,V.navigation)}
  ${I(_`:where(.en-navigation-link, .en-skip-link)`)}
  @media (any-pointer: coarse) {
    .en-navigation-link, .en-skip-link {
      min-inline-size: ${U(!0,M(`--en-size-target-min`))};
      min-block-size: ${U(!0,M(`--en-size-target-min`))};
    }
    .en-section-nav .en-navigation-link { min-block-size: ${U(!0)}; }
  }
  @media (prefers-reduced-motion: reduce) {
    .en-skip-link { transition: none; animation: none; }
  }

  .en-navigation-link[aria-current]:not([aria-current='false']), ::slotted(a[aria-current]:not([aria-current='false'])) {
    border-inline-start: var(--en-navigation-current-indicator-width, 0px) solid var(--en-navigation-current-indicator-color, ${M(`--en-color-action`)});
  }
  .en-navigation-link:not([aria-disabled='true']):active, .en-section-nav .en-navigation-link:not([aria-disabled='true']):active, ::slotted(a[href]:not([aria-disabled='true']):active), summary:not([aria-disabled='true']):active {
    background: var(--en-navigation-pressed-background, ${M(`--en-color-accent-subtle`)});
  }
  @media (forced-colors: active) {
    .en-section-nav { background: Canvas; border-color: CanvasText; }
    .en-navigation-link { color: LinkText; }
    .en-navigation-link[aria-current]:not([aria-current='false']) { color: LinkText; }
  @media (hover: hover) { .en-navigation-link:hover { color: LinkText; } }
    .en-section-nav .en-navigation-link[aria-current]:not([aria-current='false']) { background: Highlight; color: HighlightText; }
  @media (hover: hover) { .en-section-nav .en-navigation-link:hover { background: Highlight; color: HighlightText; } }
    .en-breadcrumbs, .en-breadcrumbs__label, .en-breadcrumbs__separator { color: CanvasText; }
    .en-skip-link { background: Canvas; color: LinkText; border-color: CanvasText; }
  }
`),xr=_`
  :host { margin-block: ${M(`--en-space-6`)}; }
  .en-section-nav { margin-block: 0; }
  .en-section-nav > slot:not([hidden]) { display: contents; }
  :host([sticky]) {
    position: var(--en-navigation-position, static);
    inset-block-start: var(--en-navigation-offset, 0px);
    z-index: var(--en-navigation-z-index, 20);
  }
  ::slotted(a) {
    box-sizing: border-box;
    min-inline-size: 0;
    max-inline-size: 100%;
    font: inherit;
    text-align: start;
    overflow-wrap: anywhere;
    color: ${N(`--en-navigation-color`,M(`--en-color-text-muted`))};
  }
  ::slotted(a[href]:not([hidden])) {
    /* Preserve authored inline phrasing and spaces while centering a single line. */
    display: inline-block;
    min-inline-size: ${M(`--en-size-target-min`)};
    min-block-size: ${U()};
    padding-block: max(${M(`--en-space-2`)}, calc((${U()} - 1lh) / 2));
    padding-inline: ${M(`--en-space-control-inline`)};
    border-radius: ${N(`--en-navigation-link-radius`,M(`--en-radius-pill`))};
    text-decoration: none;
  }
  ::slotted(a:not([href])), ::slotted(a[href][aria-current]:not([aria-current='false'])) {
    color: ${N(`--en-navigation-current-color`,N(`--en-navigation-active-color`,M(`--en-color-text`)))};
  }
  @media (hover: hover) { ::slotted(a[href]:hover) {
    color: ${N(`--en-navigation-hover-color`,N(`--en-navigation-active-color`,M(`--en-color-text`)))};
  } }
  ::slotted(a[href][aria-current]:not([aria-current='false'])) {
    background: ${N(`--en-navigation-current-background`,N(`--en-navigation-active-background`,M(`--en-color-surface-subtle`)))};
  }
  @media (hover: hover) { ::slotted(a[href]:hover) {
    background: ${N(`--en-navigation-hover-background`,N(`--en-navigation-active-background`,M(`--en-color-surface-subtle`)))};
  } }
  ::slotted(a[aria-current]:not([aria-current='false'])) {
    font-weight: ${M(`--en-font-label-strong-weight`)};
  }
  ${P(_`:is(.en-navigation-link, summary)`,_`:is(.en-navigation-link, summary):not([aria-disabled='true']):not([data-press='none']):active`,V.navigation)}
  ${P(_`::slotted(a[href])`,_`::slotted(a[href]:not([aria-disabled='true']):not([data-press='none']):active)`,V.navigation)}
  ${An(_`::slotted(a[href])`)}
  ${L(_`::slotted(a[href]:focus-visible)`)}
  @media (any-pointer: coarse) {
    ::slotted(a[href]:not([hidden])) {
      min-inline-size: ${U(!0,M(`--en-size-target-min`))};
      min-block-size: ${U(!0)};
      padding-block: max(${M(`--en-space-2`)}, calc((${U(!0)} - 1lh) / 2));
    }
  }

  .en-navigation-link[aria-current]:not([aria-current='false']), ::slotted(a[aria-current]:not([aria-current='false'])) {
    border-inline-start: var(--en-navigation-current-indicator-width, 0px) solid var(--en-navigation-current-indicator-color, ${M(`--en-color-action`)});
  }
  .en-navigation-link:not([aria-disabled='true']):active, .en-section-nav .en-navigation-link:not([aria-disabled='true']):active, ::slotted(a[href]:not([aria-disabled='true']):active), summary:not([aria-disabled='true']):active {
    background: var(--en-navigation-pressed-background, ${M(`--en-color-accent-subtle`)});
  }
  @media (forced-colors: active) {
    ::slotted(a[href]) { color: LinkText; }
    ::slotted(a:not([href])) { color: CanvasText; }
    ::slotted(a[href][aria-current]:not([aria-current='false'])) {
      background: Highlight;
      color: HighlightText;
    }
  @media (hover: hover) { ::slotted(a[href]:hover) {
      background: Highlight;
      color: HighlightText;
    } }
  }
`,Sr=_`
  :host([layout='sidebar']), :host(en-navigation-group) { margin: 0; }
  :host([layout='sidebar']) .en-section-nav {
    display: grid;
    align-items: stretch;
    gap: ${N(`--en-navigation-gap`,M(`--en-space-1`))};
    border: 0;
    padding: 0;
    background: transparent;
  }
  :host([layout='sidebar']) ::slotted(a[href]), :host(en-navigation-group) ::slotted(a[href]) {
    display: block;
    inline-size: 100%;
    border-radius: ${N(`--en-navigation-link-radius`,M(`--en-radius-control`))};
  }
  details, .group-content { min-inline-size: 0; }
  /* Explicit display rules otherwise override closed-details content in WebKit. */
  details:not([open]) > :not(summary) { display: none !important; }
  summary {
    box-sizing: border-box;
    cursor: pointer;
    overflow-wrap: anywhere;
    min-block-size: ${U()};
    padding: ${M(`--en-space-2`)} ${M(`--en-space-control-inline`)};
    border-radius: ${N(`--en-navigation-link-radius`,M(`--en-radius-control`))};
    color: ${N(`--en-navigation-color`,M(`--en-color-text-muted`))};
    font-weight: ${M(`--en-font-label-strong-weight`)};
  }
  summary[hidden] { display: none; }
  .group-content {
    display: grid;
    gap: ${N(`--en-navigation-gap`,M(`--en-space-1`))};
    margin-inline-start: ${N(`--en-navigation-indent`,M(`--en-space-4`))};
    border-inline-start: ${M(`--en-border-width`)} solid ${N(`--en-navigation-border-color`,M(`--en-color-line`))};
    padding-inline-start: ${M(`--en-space-1`)};
  }
  .group-content > slot { display: contents; }
  @media (hover: hover) {
    summary:hover {
      color: ${N(`--en-navigation-hover-color`,N(`--en-navigation-active-color`,M(`--en-color-text`)))};
      background: ${N(`--en-navigation-hover-background`,N(`--en-navigation-active-background`,M(`--en-color-surface-subtle`)))};
    }
  }
  ${P(_`:is(.en-navigation-link, summary)`,_`:is(.en-navigation-link, summary):not([aria-disabled='true']):not([data-press='none']):active`,V.navigation)}
  ${P(_`::slotted(a[href])`,_`::slotted(a[href]:not([aria-disabled='true']):not([data-press='none']):active)`,V.navigation)}
  ${An(_`summary`)}
  ${L(_`summary:focus-visible`)}
  @media (any-pointer: coarse) { summary { min-block-size: ${U(!0)}; } }
  @media (forced-colors: active) { summary { color: ButtonText; } .group-content { border-color: CanvasText; } }
`,Cr=_`
  ::slotted(a), ::slotted(span) {
    box-sizing: border-box;
    min-inline-size: 0;
    max-inline-size: 100%;
    font: inherit;
    text-align: start;
    overflow-wrap: anywhere;
  }
  ::slotted(a[href]:not([hidden])) {
    /* Keep authored phrasing in an inline formatting context, including its spaces. */
    display: inline-block;
    min-inline-size: ${M(`--en-size-target-min`)};
    min-block-size: ${M(`--en-size-target-min`)};
    padding-block: max(0px, calc((${M(`--en-size-target-min`)} - 1lh) / 2));
    color: ${N(`--en-navigation-color`,M(`--en-color-text-muted`))};
    text-decoration: underline;
    text-underline-offset: ${M(`--en-border-width`)};
  }
  ::slotted(span), ::slotted(a:not([href])), ::slotted(a[href][aria-current]:not([aria-current='false'])) {
    color: ${N(`--en-navigation-current-color`,N(`--en-navigation-active-color`,M(`--en-color-text`)))};
  }
  @media (hover: hover) { ::slotted(a[href]:hover) {
    color: ${N(`--en-navigation-hover-color`,N(`--en-navigation-active-color`,M(`--en-color-text`)))};
  } }
  ::slotted(a[aria-current]:not([aria-current='false'])),
  ::slotted(span[aria-current]:not([aria-current='false'])) {
    font-weight: ${M(`--en-font-label-strong-weight`)};
  }
  ::slotted([hidden]:not([hidden='until-found' i])),
  .en-breadcrumbs__item[hidden], .en-breadcrumbs__diagnostic[hidden] {
    display: none !important;
  }
  ${An(_`::slotted(a[href])`)}
  ${L(_`::slotted(a[href]:focus-visible)`)}
  @media (any-pointer: coarse) {
    ::slotted(a[href]:not([hidden])) {
      min-inline-size: ${U(!0,M(`--en-size-target-min`))};
      min-block-size: ${U(!0,M(`--en-size-target-min`))};
      padding-block: max(0px, calc((${U(!0,M(`--en-size-target-min`))} - 1lh) / 2));
    }
  }
  @media (forced-colors: active) {
    ::slotted(a[href]), ::slotted(a[href][aria-current]:not([aria-current='false'])) { color: LinkText; }
  @media (hover: hover) { ::slotted(a[href]:hover) { color: LinkText; } }
    ::slotted(span), ::slotted(a:not([href])) { color: CanvasText; }
  }
`;n(customElements,{tagName:`en-breadcrumbs`,elementClass:class extends E{static shadowRootOptions={mode:`open`,slotAssignment:`manual`};static properties={label:{type:String,useDefault:!0}};static styles=[B,z,br,Cr];#e=new rr(this);constructor(){super(),this.label=`Breadcrumbs`}render(){return vr({label:this.label,...this.#e.view})}}});function wr(e,t,n,r){return _`
    ${e} {
      --_en-inset-gap: max(${M(`--en-space-1`)}, ${F({family:`button`})});
      --_en-inset-radius: max(0px, calc(${n} - ${r} - var(--_en-inset-gap)));
      --_en-inset-size: max(${H()}, calc(${Gn()} - 2 * var(--_en-inset-gap)));
      --_en-inset-padding: max(0px, calc(${M(`--en-space-control-block`)} - var(--_en-inset-gap)));
    }
    ${t} {
      --_en-inset-action-radius: var(--_en-inset-radius);
      --_en-inset-action-size: var(--_en-inset-size);
      --_en-inset-action-padding: var(--_en-inset-padding);
      margin: var(--_en-inset-gap);
      flex-shrink: 0;
    }
    @media (any-pointer: coarse) {
      ${e} { --_en-inset-size: max(${H(!0)}, calc(${Gn(!0)} - 2 * var(--_en-inset-gap))); }
    }
  `}var Tr=_`
  .en-button {
    padding-block: var(--_en-inset-action-padding, ${M(`--en-space-control-block`)});
    border-radius: var(--_en-inset-action-radius, ${N(`--en-button-radius`,N(`--en-control-radius`,M(`--en-radius-control`)))});
  }
  .en-button:not(.en-icon-button) { min-block-size: var(--_en-inset-action-size, var(--_en-text-control-block-size)); }
  .en-button.en-icon-button:not([data-icon-only]) {
    min-block-size: var(--_en-inset-action-size, ${U()});
    min-inline-size: var(--_en-inset-action-size, ${U()});
  }
  .en-button[data-icon-only] {
    min-block-size: var(--_en-inset-action-size, var(--_en-icon-button-side));
    min-inline-size: var(--_en-inset-action-size, var(--_en-icon-button-side));
  }
  @media (any-pointer: coarse) {
    .en-button.en-icon-button:not([data-icon-only]) {
      min-block-size: var(--_en-inset-action-size, ${U(!0)});
      min-inline-size: var(--_en-inset-action-size, ${U(!0)});
    }
  }
`;function Er(e,t=!1){return _`${e} { --_en-text-control-block-size: ${Gn(t)}; }`}function Dr(e){return _`${e} {
    box-sizing: border-box;
    min-inline-size: 0;
    min-block-size: ${U()};
    max-inline-size: 100%;
    padding-block: ${M(`--en-space-control-block`)};
    padding-inline: ${N(`--en-control-inline-padding`,M(`--en-space-control-inline`))};
    border: ${M(`--en-border-width`)} solid ${N(`--en-control-border-color`,M(`--en-color-boundary`))};
    border-radius: ${N(`--en-control-radius`,M(`--en-radius-control`))};
    background: ${N(`--en-control-background`,M(`--en-color-surface`))};
    color: ${N(`--en-control-color`,M(`--en-color-text`))};
    font: inherit;
    text-align: start;
  }`}function Or(e){return _`${e} { min-block-size: var(--_en-text-control-block-size); }`}function kr(e){return _`${e} {
    color: ${M(`--en-color-text-muted`)};
    background: ${M(`--en-color-surface-subtle`)};
    border-color: ${M(`--en-color-boundary`)};
    cursor: default;
  }`}function Ar(e){return _`${e} { min-block-size: ${U(!0)}; }`}function jr(e){return _`${e} { min-inline-size: ${U(!0)}; }`}function Mr(e){return _`${e} { transition: none; }`}function Nr(e){return _`${e} { color: CanvasText !important; background: Canvas !important; border-color: ButtonText !important; }`}function Pr(e){return _`${e} { color: GrayText !important; border-color: GrayText !important; }`}var Fr=R(_`
  ${Er(_`.en-button:not(.en-icon-button), .en-button[data-icon-only]`)}
  ${Dr(_`.en-button`)}
  ${Or(_`.en-button:not(.en-icon-button)`)}
  ${In}
  ${kr(_`:is(.en-button):is(:disabled, [aria-disabled='true'])`)}
  ${Rn}
  @media (any-pointer: coarse) {
    ${Er(_`.en-button:not(.en-icon-button), .en-button[data-icon-only]`,!0)}
    ${Ar(_`.en-button`)}
    ${Or(_`.en-button:not(.en-icon-button)`)}
    ${jr(_`.en-icon-button`)}
  }
  @media (prefers-reduced-motion: reduce) { ${Mr(_`.en-button`)} }
  @media (forced-colors: active) {
    ${Nr(_`.en-button`)}
    ${Pr(_`:is(.en-button):is(:disabled, [aria-disabled='true'])`)}
    ${zn}
  }
  ${Tr}
`),G=e=>e??T,Ir=e=>S`
  <button
    class=${e.iconOnly?`en-button en-icon-button`:`en-button`}
    ?data-icon-only=${e.iconOnly}
    part="control"
    type="button"
    tabindex=${e.tabIndex??0}
    data-variant=${e.variant}
    data-size=${e.size}
    ?disabled=${e.disabled||e.loading}
    aria-pressed=${G(e.pressed??void 0)}
    aria-busy=${e.loading?`true`:`false`}
    aria-haspopup=${G(e.popupRole??void 0)}
    aria-expanded=${G(e.popupExpanded??void 0)}
    aria-disabled=${G(e.ariaDisabled??void 0)}
  >
    ${e.loading?S`<span class="en-spinner" part="indicator" aria-hidden="true"></span>`:null}
    <slot class="en-button__prefix" name="prefix"></slot>
    <span class="en-button__label" part="label"><slot name="label"><slot></slot></slot></span>
    <slot class="en-button__suffix" name="suffix"></slot>
  </button>
`,Lr=new WeakMap,Rr=new WeakMap;function zr(e,t){Lr.set(e,{write:t})}function Br(e){let t=Lr.get(e);if(t){let e={};return t.owner=e,{set(n){t.owner===e&&t.write(n)},release(){t.owner===e&&(t.owner=void 0,t.write(0))}}}let n=Rr.get(e),r=e.getAttribute(`tabindex`),i={owner:{},original:n?.last===r?n.original:r};Rr.set(e,i);let a=!0;return{set(t){if(a&&Rr.get(e)===i){if(i.last!==void 0&&e.getAttribute(`tabindex`)!==i.last){a=!1,Rr.delete(e);return}i.last=String(t),e.getAttribute(`tabindex`)!==i.last&&e.setAttribute(`tabindex`,i.last)}},release(){a&&Rr.get(e)===i&&(a=!1,Rr.delete(e),i.last!==void 0&&e.getAttribute(`tabindex`)===i.last&&(i.original===null?e.removeAttribute(`tabindex`):e.setAttribute(`tabindex`,i.original)))}}}var Vr={tagName:`en-button`,elementClass:class extends E{static properties={variant:{reflect:!0},disabled:{type:Boolean,reflect:!0},loading:{type:Boolean,reflect:!0},iconOnly:{type:Boolean,attribute:`icon-only`,reflect:!0},popupRole:{attribute:`aria-haspopup`},pressedSemantics:{attribute:`aria-pressed`},popupExpanded:{attribute:`aria-expanded`},disabledSemantics:{attribute:`aria-disabled`},descriptionIds:{attribute:`aria-describedby`,hasChanged:()=>!0}};static styles=[B,Mn,Fr,Jn];tabStop=0;constructor(){super(),this.variant=`primary`,this.disabled=!1,this.loading=!1,this.iconOnly=!1,this.popupRole=null,this.pressedSemantics=null,this.popupExpanded=null,this.disabledSemantics=null,this.addEventListener(`click`,e=>{this.getAttribute(`aria-disabled`)===`true`&&(e.preventDefault(),e.stopImmediatePropagation())},{capture:!0}),this.descriptionIds=null,zr(this,e=>{if(this.tabStop===e)return;this.tabStop=e;let t=this.renderRoot?.querySelector(`button`);t&&(t.tabIndex=e),this.requestUpdate()})}connectedCallback(){super.connectedCallback(),this.requestUpdate()}focus(e){this.renderRoot.querySelector(`button`)?.focus(e)}get buttonPressed(){return[`true`,`false`,`mixed`].includes(this.pressedSemantics??``)?this.pressedSemantics:null}render(){return Ir({variant:this.variant,size:this.size,disabled:this.disabled,loading:this.loading,iconOnly:this.iconOnly,popupRole:this.popupRole,popupExpanded:this.popupExpanded,ariaDisabled:this.disabledSemantics,tabIndex:this.tabStop,pressed:this.buttonPressed})}updated(){let e=this.renderRoot.querySelector(`button`);if(!e)return;for(let[t,n]of[[`aria-pressed`,this.buttonPressed],[`aria-haspopup`,this.popupRole],[`aria-expanded`,this.popupExpanded],[`aria-disabled`,this.disabledSemantics]])n===null?e.hasAttribute(t)&&e.removeAttribute(t):e.getAttribute(t)!==n&&e.setAttribute(t,n);if(!(`ariaDescribedByElements`in e))return;let t=this.ariaDescribedByElements,n=e.ariaDescribedByElements;(n?.length!==t?.length||n?.some((e,n)=>e!==t?.[n]))&&(e.ariaDescribedByElements=t)}}};n(customElements,Vr);var Hr=R(_`.en-panel, .en-card {
  min-inline-size: 0;
  padding: var(--en-surface-padding, var(--_en-sized-space-panel, var(--en-space-panel, 1.5rem)));
  border: var(--en-border-width, 1px) solid var(--en-surface-border-color, var(--en-color-line, rgb(214 220 228 / 1)));
  border-radius: var(--en-surface-radius, var(--_en-sized-radius-container, var(--en-radius-container, 1rem)));
  background: var(--en-surface-background, var(--en-color-surface, rgb(255 255 255 / 1)));
  color: var(--en-surface-color, var(--en-color-text, rgb(27 31 36 / 1)));
  box-shadow: var(--en-surface-shadow, none);
}
.en-card {
  box-shadow: var(--en-card-shadow, var(--en-surface-shadow, none));
  display: flex;
  flex-direction: column;
  gap: var(--en-space-4, 1rem);
  background: var(--en-card-background, var(--en-surface-background, var(--en-color-surface, rgb(255 255 255 / 1))));
}
.en-card__header, .en-card__body, .en-card__footer { min-inline-size: 0; }
.en-card__header { font-weight: var(--en-font-label-strong-weight, 600); }
.en-card__footer { display: flex; align-items: center; flex-wrap: wrap; gap: var(--_en-sized-space-actions, var(--en-space-actions, 0.375rem)); }
.en-card__footer > slot { display: contents; }
.en-inset-surface {
  border-radius: var(--en-inset-child-radius, max(0px, var(--en-inset-outer-radius, var(--_en-sized-radius-container, var(--en-radius-container, 1rem))) - var(--en-inset-distance, var(--en-space-2, 0.5rem))));
}
.en-divider { margin: 0; border: 0; border-block-start: var(--en-border-width, 1px) solid var(--en-divider-color, var(--en-color-line, rgb(214 220 228 / 1))); }
.en-divider[aria-orientation='vertical'] { align-self: stretch; border-block-start: 0; border-inline-start: var(--en-border-width, 1px) solid var(--en-divider-color, var(--en-color-line, rgb(214 220 228 / 1))); }
@media (forced-colors: active) {
  .en-panel, .en-card { color: CanvasText; background: Canvas; border-color: CanvasText; box-shadow: none; }
  .en-divider { border-color: CanvasText; box-shadow: none; }
}
`),Ur=R(_`
  .en-stack { display: flex; flex-direction: column; gap: ${N(`--en-stack-gap`,M(`--en-space-rows`))}; min-inline-size: 0; }
  .en-stack[data-direction='horizontal'] { flex-direction: row; align-items: center; }
  .en-stack[data-align='start'] { align-items: flex-start; }
  .en-stack[data-align='center'] { align-items: center; }
  .en-stack[data-align='end'] { align-items: flex-end; }
  .en-stack[data-align='stretch'] { align-items: stretch; }
  .en-stack[data-justify='start'] { justify-content: flex-start; }
  .en-stack[data-justify='center'] { justify-content: center; }
  .en-stack[data-justify='end'] { justify-content: flex-end; }
  .en-stack[data-justify='between'] { justify-content: space-between; }
  .en-stack[data-wrap], .en-stack[data-wrap='true'] { flex-wrap: wrap; }
  .en-stack[data-wrap='false'] { flex-wrap: nowrap; }
  .en-stack[data-gap='small'] { gap: ${N(`--en-stack-gap`,M(`--en-space-2`))}; }
  .en-stack[data-gap='medium'] { gap: ${N(`--en-stack-gap`,M(`--en-space-4`))}; }
  .en-stack[data-gap='large'] { gap: ${N(`--en-stack-gap`,M(`--en-space-6`))}; }
  .en-cluster { display: flex; align-items: center; flex-wrap: wrap; gap: ${N(`--en-cluster-gap`,M(`--en-space-actions`))}; min-inline-size: 0; }
  .en-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, ${N(`--en-grid-item-min`,M(`--en-layout-form-max`))}), 1fr)); gap: ${N(`--en-grid-gap`,M(`--en-space-4`))}; min-inline-size: 0; }
  .en-stack > slot, .en-cluster > slot, .en-grid > slot { display: contents; }
  .en-stack > *, .en-cluster > *, .en-grid > * { min-inline-size: 0; }
  .en-scroll-region { min-inline-size: 0; min-block-size: 0; overflow: auto; scrollbar-gutter: stable; }
  .en-query-region { container-type: inline-size; container-name: en-layout; }
  .en-split-view {
    --_en-split-target:max(${M(`--en-size-splitter`)},${U(!1,M(`--en-size-target-min`))});
    display: grid;
    isolation: isolate;
    grid-template-columns: minmax(0, calc((100% - var(--_en-split-target)) * var(--en-split-ratio, 0.5))) var(--_en-split-target) minmax(0, 1fr);
    min-inline-size: 0;
    min-block-size: 0;
  }
  .en-split-view[data-orientation='vertical'] { grid-template-columns: minmax(0, 1fr); grid-template-rows: minmax(0, calc((100% - var(--_en-split-target)) * var(--en-split-ratio, 0.5))) var(--_en-split-target) minmax(0, 1fr); }
  @media (any-pointer: coarse) { .en-split-view { --_en-split-target:max(${M(`--en-size-splitter`)},${U(!0,M(`--en-size-target-min`))}); } }
  .en-split-pane { min-inline-size: 0; min-block-size: 0; overflow: auto; }
  .en-split-handle { display: block; min-inline-size: 0; min-block-size: 0; }
  /* Raise only the focused grid item above adjacent pane surfaces, locally. */
  .en-split-view > .en-split-handle:focus-visible { z-index: 1; }
  .en-split-separator { display: grid; place-items: center; inline-size: 100%; block-size: 100%; min-inline-size: 0; min-block-size: 0; cursor: col-resize; }
  .en-split-grip { inline-size: ${M(`--en-border-width`)}; block-size: 100%; background: ${M(`--en-color-boundary`)}; }
  .en-split-separator[data-orientation='horizontal'], :host([role='separator'][aria-orientation='horizontal']) .en-split-separator { cursor: row-resize; }
  .en-split-separator[data-orientation='horizontal'] .en-split-grip, :host([role='separator'][aria-orientation='horizontal']) .en-split-grip { inline-size: 100%; block-size: ${M(`--en-border-width`)}; }
  ${Bn}
  @media (forced-colors: active) { .en-split-grip { background: ButtonText; } }
`),Wr=`data-en-optional-slots`;function Gr(e,t){let n=e.getAttribute(Wr);if(n===null)return;let r;try{r=JSON.parse(n)}catch{throw TypeError(`Invalid optional-slot SSR metadata.`)}if(!r||typeof r!=`object`)throw TypeError(`Invalid optional-slot SSR metadata.`);let i=r;if(i.version!==1||!i.slots||typeof i.slots!=`object`||Array.isArray(i.slots)||Object.keys(i.slots).length!==t.length||t.some(e=>typeof i.slots?.[e]!=`boolean`))throw TypeError(`Invalid optional-slot SSR metadata.`);return Object.freeze(Object.fromEntries(t.map(e=>[e,i.slots[e]])))}var Kr=e=>S`
  <div class="en-card" part="base">
    <div class="en-card__header" part="header" ?hidden=${!e.hasHeader}>
      <slot name="header" @slotchange=${e.onSlotChange}></slot>
    </div>
    <div class="en-card__body" part="content"><slot></slot></div>
    <div class="en-card__footer" part="footer" ?hidden=${!e.hasFooter}>
      <slot name="footer" @slotchange=${e.onSlotChange}></slot>
    </div>
  </div>
`;n(customElements,{tagName:`en-card`,elementClass:class extends E{static properties={hasHeader:{state:!0},hasFooter:{state:!0}};static styles=[B,z,Hr];constructor(){super(),this.hasHeader=!0,this.hasFooter=!0}willUpdate(){if(this.hasUpdated)return;let e=Gr(this,[`header`,`footer`]);e&&(this.hasHeader=e.header,this.hasFooter=e.footer)}firstUpdated(){this.removeAttribute(Wr);for(let e of this.renderRoot.querySelectorAll(`slot[name]`))this.syncSlotPresence(e)}syncSlotPresence(e){let t=e.assignedNodes({flatten:!0}).some(e=>e.nodeType===1||!!e.textContent?.trim());e.name===`header`&&(this.hasHeader=t),e.name===`footer`&&(this.hasFooter=t)}onSlotChange=e=>{this.syncSlotPresence(e.currentTarget)};render(){return Kr({hasHeader:this.hasHeader,hasFooter:this.hasFooter,onSlotChange:this.onSlotChange})}}});function qr(e,t){return t?{...e,flags:{...e.flags,customError:!0},message:t}:e}var Jr=class{host;sync;constraintMessage;message=``;shown=!1;constructor(e,t,n){this.host=e,this.sync=t,this.constraintMessage=n,e.addEventListener(`invalid`,t=>{t.target===e&&(this.shown=!0,e.requestUpdate())})}get error(){return this.message}set error(e){let t=this.message;this.message=String(e??``),this.sync(),this.host.requestUpdate(`error`,t)}get visible(){return this.message||(this.shown?this.constraintMessage():``)}reset(){this.shown=!1,this.host.requestUpdate()}},Yr=class{host;attribute;read;serialize;write;dirty=!1;applying=!1;reflecting=!1;constructor(e,t,n,r,i){this.host=e,this.attribute=t,this.read=n,this.serialize=r,this.write=i}get value(){return this.read(this.host.getAttribute(this.attribute))}set value(e){let t=this.serialize(e);this.reflecting=!0;try{t===null?this.host.removeAttribute(this.attribute):this.host.setAttribute(this.attribute,t)}finally{this.reflecting=!1}this.attributeChanged()}get isDirty(){return this.dirty}markDirty(){this.applying||(this.dirty=!0)}attributeChanged(){this.reflecting||(this.dirty||this.apply(),this.host.requestUpdate())}reset(){this.dirty=!1,this.apply()}apply(e=this.value){let t=this.applying;this.applying=!0;try{this.write(e)}finally{this.applying=t}}},Xr=[`badInput`,`customError`,`patternMismatch`,`rangeOverflow`,`rangeUnderflow`,`stepMismatch`,`tooLong`,`tooShort`,`typeMismatch`,`valueMissing`],Zr=class{#e;#t;#n=!1;constructor(e,t){this.#e=e,this.#t=t,e.addController(this)}get disabled(){return this.#n||(this.#t.disabled?.()??!1)}hostUpdated(){this.sync()}sync(){let{internals:e}=this.#t;if(typeof e.setFormValue!=`function`)return;let t=this.disabled?null:this.#t.value();e.setFormValue(t,this.#t.state?this.#t.state():t);let n=this.#t.control?.()??null;if(n&&(n.disabled=this.disabled),typeof e.setValidity!=`function`)return;if(this.disabled){e.setValidity({});return}let r=this.#t.validate?.();if(r){let t=Object.values(r.flags).some(Boolean);if(t&&!r.message)throw TypeError(`Invalid form state requires a localized validation message.`);e.setValidity(r.flags,t?r.message:``,r.anchor)}else if(n){let t={};for(let e of Xr)n.validity[e]&&(t[e]=!0);e.setValidity(t,n.validationMessage,n)}else e.setValidity({})}formDisabled(e){this.#n=e,this.sync(),this.#e.requestUpdate()}formReset(){this.#t.onReset(),this.sync(),this.#e.requestUpdate()}formStateRestore(e,t){this.#t.onRestore?.(e,t),this.sync(),this.#e.requestUpdate()}},K=N(`--en-input-border-width`,M(`--en-border-width`)),Qr=N(`--en-input-invalid-border-width`,M(`--en-border-invalid-width`)),$r=N(`--en-input-radius`,N(`--en-control-radius`,M(`--en-radius-control`)));function ei(e,t){return _`
    ${e} { border-radius: ${$r}; border-width: ${K}; border-color: ${N(`--en-input-border-color`,N(`--en-control-border-color`,M(`--en-color-boundary`)))}; }
    @media (hover: hover) {
      ${e}:hover:where(:not(:disabled):not([aria-disabled='true']):not(:has(:disabled))) { border-color: var(--en-input-hover-border-color, var(--en-input-border-color, var(--en-control-border-color, ${M(`--en-color-boundary`)}))); }
    }
    ${t} { border-color: ${N(`--en-input-invalid-border-color`,M(`--en-color-danger-text`))}; }
  `}var ti=_`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='black' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E")`,ni=_`clamp(0ms, var(--en-dialog-enter-duration, ${M(`--en-duration-enter`)}), 500ms)`,ri=_`clamp(0ms, var(--en-dialog-exit-duration, ${M(`--en-duration-exit`)}), 500ms)`,ii=_`clamp(0px, ${M(`--en-motion-surface-offset`)}, 8px)`,ai=_`clamp(.95, ${M(`--en-motion-surface-scale`)}, 1)`,oi=_`var(--_en-surface-duration, 0ms) var(--_en-surface-ease, linear)`,si=_`opacity var(--_en-surface-opacity-duration, 0ms) var(--_en-surface-ease, linear), translate ${oi}, scale ${oi}, display ${oi} allow-discrete, overlay ${oi} allow-discrete`;function ci(e,t,n,r,i=_``,a=`popup`){let o=a===`dialog`?_`clamp(0ms, var(--en-dialog-enter-duration, ${M(`--en-duration-enter`)}), 500ms)`:_`clamp(0ms, var(--en-popup-enter-duration, ${M(`--en-duration-enter`)}), 500ms)`,s=a===`dialog`?_`clamp(0ms, var(--en-dialog-exit-duration, ${M(`--en-duration-exit`)}), 500ms)`:_`clamp(0ms, var(--en-popup-exit-duration, ${M(`--en-duration-exit`)}), 500ms)`,c=a===`dialog`?_`var(--en-dialog-enter-ease, ${M(`--en-ease-enter`)})`:_`var(--en-popup-enter-ease, ${M(`--en-ease-enter`)})`,l=a===`dialog`?_`var(--en-dialog-exit-ease, ${M(`--en-ease-exit`)})`:_`var(--en-popup-exit-ease, ${M(`--en-ease-exit`)})`,u=_`:where(${e})${i}`,d=_`${t}${i}`,f=_`${n}${i}`;return _`
    @supports (transition-behavior: allow-discrete) and (overlay: auto) {
      ${u} {
        --_en-surface-duration: ${s};
        --_en-surface-opacity-duration: ${s};
        --_en-surface-ease: ${l};
        opacity: 0;
        transition: ${si};
      }
      ${d} {
        --_en-surface-duration: ${o};
        /* Modal and menu entry keep content opaque. Fade surfaces reverse
           from their current opacity when reopened during exit. */
        --_en-surface-opacity-duration: ${r===`fade`?o:_`0ms`};
        --_en-surface-ease: ${c};
        opacity: 1;
      }
      ${f} { pointer-events: none; }
      ${r===`elevation`?_`
        /* Opaque command content and its primary focus contour are immediate.
           Elevation adds entry paint without corrupting measured iPhone geometry. */
        @keyframes en-surface-elevation { from { box-shadow: none; } }
        ${d} { animation: en-surface-elevation ${o} ${c}; }
      `:_``}
      @starting-style { ${d} { opacity: ${r===`fade`?0:1}; } }
    }
    @media (prefers-reduced-motion: reduce) {
      ${u} { transition: none !important; animation: none !important; }
    }
    @media (forced-colors: active) {
      ${u} { animation: none; }
    }
  `}var li=_`
  ${ci(_`dialog:is(.en-dialog, .en-drawer)`,_`dialog:is(.en-dialog, .en-drawer)[open]`,_`dialog:is(.en-dialog, .en-drawer):not([open])`,`move`,_``,`dialog`)}
  @supports (transition-behavior: allow-discrete) and (overlay: auto) {
    dialog:is(.en-dialog, .en-drawer) {
      --_en-surface-x: 0px;
      --_en-surface-y: ${ii};
      translate: var(--_en-surface-x) var(--_en-surface-y);
      scale: ${ai};
    }
    /* Share modal travel distance; attachment selects its axis and sign.
       Keep the drawer unscaled so its attached edge stays flush. */
    dialog.en-drawer { --_en-surface-x: ${ii}; --_en-surface-y: 0px; scale: 1; }
    dialog.en-drawer:is([data-placement='start'], [data-placement='left']) { --_en-surface-x: calc(-1 * ${ii}); }
    dialog.en-drawer[data-placement='end']:dir(rtl) { --_en-surface-x: calc(-1 * ${ii}); }
    dialog.en-drawer[data-placement='start']:dir(rtl) { --_en-surface-x: ${ii}; }
    dialog.en-drawer:is([data-placement='top'], [data-placement='bottom']) { --_en-surface-x: 0px; --_en-surface-y: ${ii}; }
    dialog.en-drawer[data-placement='top'] { --_en-surface-y: calc(-1 * ${ii}); }
    dialog:is(.en-dialog, .en-drawer)[open] { translate: 0px 0px; scale: 1; }
    @starting-style {
      dialog:is(.en-dialog, .en-drawer)[open] {
        translate: var(--_en-surface-x) var(--_en-surface-y);
        scale: ${ai};
      }
      dialog.en-drawer[open] { scale: 1; }
    }
    dialog:is(.en-dialog, .en-drawer)::backdrop {
      opacity: 0;
      transition: opacity ${ri} var(--en-dialog-exit-ease, ${M(`--en-ease-exit`)}), display ${ri} allow-discrete, overlay ${ri} allow-discrete;
    }
    dialog:is(.en-dialog, .en-drawer)[open]::backdrop {
      opacity: 1;
      transition: opacity ${ni} var(--en-dialog-enter-ease, ${M(`--en-ease-enter`)}), display ${ni} allow-discrete, overlay ${ni} allow-discrete;
    }
    dialog:is(.en-dialog, .en-drawer):not([open])::backdrop { pointer-events: none; }
    @starting-style { dialog:is(.en-dialog, .en-drawer)[open]::backdrop { opacity: 0; } }
  }
  @media (prefers-reduced-motion: reduce) {
    dialog:is(.en-dialog, .en-drawer) { translate: none !important; scale: none !important; }
    dialog:is(.en-dialog, .en-drawer)::backdrop { transition: none !important; }
  }
`,ui=_`
  .en-radio {
    flex: none;
    inline-size: ${N(`--en-choice-size`,M(`--en-size-icon`))};
    block-size: ${N(`--en-choice-size`,M(`--en-size-icon`))};
    margin: 0;
    accent-color: ${M(`--en-color-action`)};
    appearance: none;
    display: inline-grid;
    /* Keep the inline baseline independent of the checked-state grid dot. */
    vertical-align: middle;
    place-items: center;
    box-sizing: border-box;
    border: ${M(`--en-border-width`)} solid ${M(`--en-color-boundary`)};
    border-radius: ${M(`--en-radius-pill`)};
    background: ${M(`--en-color-surface`)};
    cursor: pointer;
  }
  .en-radio:checked { border-color: ${N(`--en-radio-selected-color`,M(`--en-color-action`))}; }
  .en-radio:checked::before { content: ''; inline-size: ${M(`--en-size-choice-dot`)}; block-size: ${M(`--en-size-choice-dot`)}; border-radius: ${M(`--en-radius-pill`)}; background: ${N(`--en-radio-selected-color`,M(`--en-color-action`))}; }
  .en-radio:not(:disabled):active { border-color: ${M(`--en-color-action-pressed`)}; }
  .en-radio:disabled { cursor: default; background: ${M(`--en-color-surface-subtle`)}; border-color: ${M(`--en-color-boundary`)}; }
  .en-radio:disabled::before { background: ${M(`--en-color-text-muted`)}; }
  ${P(_`.en-radio`,_`.en-radio:not(:disabled):not([data-press='none']):is(:active, .en-choice:active > .en-radio)`,V.radio)}
  @media (forced-colors: active) {
    .en-radio { accent-color: auto; background: Canvas; border-color: CanvasText; }
    .en-radio:checked { background: Canvas; border-color: CanvasText; }
    .en-radio:checked::before { background: CanvasText; }
    .en-radio:not(:disabled):active { border-color: Highlight; box-shadow: none; }
    .en-radio:disabled { background: Canvas; border-color: GrayText; }
    .en-radio:disabled::before { background: GrayText; }
    .en-radio:focus-visible { outline-color: CanvasText; }
  }
`,di=_`
  block-size: ${M(`--en-size-range-track`)};
  border: 0;
  border-radius: ${M(`--en-radius-pill`)};
  background: ${M(`--en-color-boundary`)};
`,fi=_`
  box-sizing: border-box;
  inline-size: ${M(`--en-size-icon`)};
  block-size: ${M(`--en-size-icon`)};
  border: ${M(`--en-border-width`)} solid ${M(`--en-color-action`)};
  border-radius: ${M(`--en-radius-pill`)};
  background: ${M(`--en-color-action`)};
`,pi=_`outline: ${M(`--en-focus-width`)} solid ${M(`--en-color-focus`)}; outline-offset: ${M(`--en-focus-offset`)};`,mi=_`
  @supports selector(input::-webkit-slider-thumb) {
    .en-range { appearance: none; background: none; cursor: pointer; }
    .en-range::-webkit-slider-runnable-track { ${di} }
    .en-range::-webkit-slider-thumb { appearance: none; ${fi} margin-block-start: calc((${M(`--en-size-range-track`)} - ${M(`--en-size-icon`)}) / 2); }
    /* Exposed native thumbs own focus. A global halo must not reintroduce a
       rectangular range-host ring; native unsupported fallbacks keep that route. */
    .en-range, .en-range:focus-visible { box-shadow: none; }
    .en-range:focus-visible { outline: none; }
    .en-range:focus-visible::-webkit-slider-thumb { ${pi} }
    .en-range:disabled::-webkit-slider-thumb { background: ${M(`--en-color-text-muted`)}; border-color: ${M(`--en-color-text-muted`)}; }
    @media (forced-colors: active) {
      .en-range::-webkit-slider-runnable-track { background: ButtonText; }
      .en-range::-webkit-slider-thumb { background: Highlight; border-color: Highlight; }
      .en-range:disabled::-webkit-slider-thumb { background: GrayText; border-color: GrayText; }
      .en-range:focus-visible::-webkit-slider-thumb { outline-color: CanvasText; }
    }
  }
  @supports selector(input::-moz-range-thumb) {
    .en-range { appearance: none; background: none; cursor: pointer; }
    .en-range::-moz-range-track { ${di} }
    .en-range::-moz-range-thumb { ${fi} }
    /* Exposed native thumbs own focus. A global halo must not reintroduce a
       rectangular range-host ring; native unsupported fallbacks keep that route. */
    .en-range, .en-range:focus-visible { box-shadow: none; }
    .en-range:focus-visible { outline: none; }
    .en-range:focus-visible::-moz-range-thumb { ${pi} }
    .en-range:disabled::-moz-range-thumb { background: ${M(`--en-color-text-muted`)}; border-color: ${M(`--en-color-text-muted`)}; }
    @media (forced-colors: active) {
      .en-range::-moz-range-track { background: ButtonText; }
      .en-range::-moz-range-thumb { background: Highlight; border-color: Highlight; }
      .en-range:disabled::-moz-range-thumb { background: GrayText; border-color: GrayText; }
      .en-range:focus-visible::-moz-range-thumb { outline-color: CanvasText; }
    }
  }
  .en-range:disabled { cursor: default; }
   .en-range::-webkit-slider-thumb { transition: scale clamp(0ms, var(--en-slider-thumb-release-duration, 80ms), 200ms) ${M(`--en-ease-standard`)}; }
   .en-range:not(:disabled):active::-webkit-slider-thumb { scale: clamp(.9, var(--en-slider-thumb-pressed-scale, 1), 1.25); transition-duration: clamp(0ms, var(--en-slider-thumb-press-duration, 80ms), 200ms); }
  @media (prefers-reduced-motion: reduce) {  .en-range::-webkit-slider-thumb { scale: none !important; transition: none !important; } }
  :host([data-press=none])  .en-range::-webkit-slider-thumb { scale: none !important; }

   .en-range::-moz-range-thumb { transition: scale clamp(0ms, var(--en-slider-thumb-release-duration, 80ms), 200ms) ${M(`--en-ease-standard`)}; }
   .en-range:not(:disabled):active::-moz-range-thumb { scale: clamp(.9, var(--en-slider-thumb-pressed-scale, 1), 1.25); transition-duration: clamp(0ms, var(--en-slider-thumb-press-duration, 80ms), 200ms); }
  @media (prefers-reduced-motion: reduce) {  .en-range::-moz-range-thumb { scale: none !important; transition: none !important; } }
  :host([data-press=none])  .en-range::-moz-range-thumb { scale: none !important; }

`,hi=_`
  .en-link {
    color: ${M(`--en-color-link`)};
    text-decoration: underline;
    text-underline-offset: ${M(`--en-space-0-5`)};
    overflow-wrap: break-word;
  }
  .en-link:not([aria-disabled='true']):active { text-decoration-thickness: .2em; }
  .en-link:visited { color: ${M(`--en-color-link`)}; }
`,gi=_`.en-link[aria-disabled='true'] { color: ${M(`--en-color-text-muted`)}; cursor: default; }`,_i=_`.en-link, .en-link:visited { color: LinkText; }`,vi=N(`--en-input-inline-padding`,N(`--en-control-inline-padding`,M(`--en-space-control-inline`))),yi=$r,bi=_`max(0px, ${yi} - ${K})`,xi=_`max(
  ${M(`--en-space-control-block`)},
  calc((var(--_en-text-control-block-size) - ${M(`--en-font-input-size`)} * ${M(`--en-font-input-line-height`)}) / 2 - ${K})
)`,Si=R(_`
  /* Compute on each consumer so local token/part overrides retain their scope. */
  ${Er(_`.en-button:not(.en-icon-button), .en-button[data-icon-only], .en-input, .en-textarea, .en-select, .en-number-input, .en-number-step, .en-color-control`)}
  ${Dr(_`.en-control, .en-button, .en-input, .en-textarea, .en-select`)}
  ${Or(_`.en-button:not(.en-icon-button), .en-input, .en-textarea, .en-select`)}
  /* Field tokens customize inputs without changing action and choice surfaces.
     Family refinements take precedence over shared control defaults. */
  .en-input, .en-textarea, .en-select {
    padding-inline: ${vi};
    background: ${N(`--en-input-background`,N(`--en-control-background`,M(`--en-color-surface`)))};
    color: ${N(`--en-input-color`,N(`--en-control-color`,M(`--en-color-text`)))};
  }
  ${In}
  ${hi}
  ${kr(_`:is(.en-button, .en-input, .en-textarea, .en-select, .en-control):is(:disabled, [aria-disabled='true'])`)}
  ${gi}
  .en-input, .en-textarea, .en-select {
    inline-size: 100%;
    font: ${M(`--en-font-input-weight`)} ${M(`--en-font-input-size`)} / ${M(`--en-font-input-line-height`)} ${M(`--en-font-input-family`)}; font-style: ${M(`--en-font-input-style`)}; letter-spacing: ${M(`--en-font-input-tracking`)};
  }
  /* Apply after the font shorthand so editable numeric content retains equal
     digit widths. Input modes also cover text-based numeric editors. */
  .en-input:is(.en-time-input, [type='number'], [type='date'], [type='time'], [type='datetime-local'], [type='month'], [type='week'], [type='tel']),
  :is(.en-input, .en-textarea):is([inputmode='numeric'], [inputmode='decimal'], [inputmode='tel']) {
    font-variant-numeric: tabular-nums;
  }
  /* Use the shared text-field surface and target envelope around the native
     date editor. Keep its fields, separators and calendar-picker activation. */
  .en-input[type='date'] {
    -webkit-appearance: none;
    appearance: none;
    padding-block: ${xi};
  }
  .en-input[type='date']::-webkit-datetime-edit { padding: 0; }
  .en-input[type='date']::-webkit-datetime-edit-fields-wrapper { padding-block: 0; }
  .en-input[type='date']::-webkit-datetime-edit-year-field,
  .en-input[type='date']::-webkit-datetime-edit-month-field,
  .en-input[type='date']::-webkit-datetime-edit-day-field { padding-block: 0; }
  .en-input[type='date']::-webkit-date-and-time-value {
    margin-block: 0;
    text-align: inherit;
  }
  .en-input::placeholder, .en-textarea::placeholder { color: ${M(`--en-color-text-muted`)}; opacity: 1; }
  .en-text-input, .en-textarea { padding-block: ${xi}; }
  .en-textarea { resize: block; }
  .en-input[aria-invalid='true'], .en-textarea[aria-invalid='true'], .en-select[aria-invalid='true'], .en-control[data-invalid] {
    border-color: ${M(`--en-color-danger-text`)};
  }
  .en-input:user-invalid, .en-textarea:user-invalid, .en-select:user-invalid { border-color: ${M(`--en-color-danger-text`)}; }
  /* The text-field marker keeps stronger invalid geometry out of other native controls.
     Preserve border + padding on each edge, including scoped padding/base-border tokens. */
  .en-text-input:is([aria-invalid='true'], :user-invalid) {
    border-width: ${Qr};
    padding-block: max(0px, calc(${xi} + ${K} - ${Qr}));
    padding-inline: max(0px, calc(${vi} + ${K} - ${Qr}));
  }
  ${ei(_`:is(.en-input, .en-textarea, .en-select, .en-number-group)`,_`:is(.en-input, .en-textarea, .en-select)[aria-invalid='true'], :is(.en-input, .en-textarea, .en-select):user-invalid, .en-number-group[data-invalid]`)}
  .en-input-group { display: flex; align-items: stretch; gap: ${M(`--en-space-1`)}; min-inline-size: 0; }
  .en-input-group > .en-input { flex: 1 1 auto; inline-size: 0; min-inline-size: 0; }
  .en-number-group {
    gap: 0;
    padding: 0;
    border: ${K} solid ${N(`--en-input-border-color`,N(`--en-control-border-color`,M(`--en-color-boundary`)))};
    border-radius: ${yi};
    background: ${N(`--en-input-background`,N(`--en-control-background`,M(`--en-color-surface`)))};
  }
  .en-number-group[data-invalid] { border-color: ${N(`--en-input-invalid-border-color`,M(`--en-color-danger-text`))}; }
  .en-number-group > :is(.en-number-input, .en-number-step, button.en-button.en-number-step) { min-block-size: max(calc(var(--_en-text-control-block-size) - 2 * ${K}), ${M(`--en-size-target-min`)}); }
  .en-number-group > .en-number-input { border: 0; border-radius: 0; background: none; appearance: textfield; }
  .en-number-input::-webkit-inner-spin-button, .en-number-input::-webkit-outer-spin-button { appearance: none; margin: 0; }
  .en-number-step {
    flex: none;
    min-inline-size: ${U()};
    padding-inline: ${M(`--en-space-control-block`)};
    border: 0;
    border-inline-start: ${M(`--en-border-width`)} solid ${M(`--en-color-line`)};
    border-radius: 0;
    background: ${M(`--en-color-surface-subtle`)};
    color: ${M(`--en-color-text`)};
  }
  /* Match the frame's override as well as its token. Keep overflow visible so
     consumer-defined outward focus contours remain intact. */
  .en-number-step:not(:disabled):not([aria-disabled='true']):active { background: var(--en-button-pressed-background, ${M(`--en-color-accent-subtle`)}); }
  .en-number-step:last-child { border-start-end-radius: ${bi}; border-end-end-radius: ${bi}; }
  .en-number-step:first-child { border-inline-start: 0; border-inline-end: ${M(`--en-border-width`)} solid ${M(`--en-color-line`)}; border-start-start-radius: ${bi}; border-end-start-radius: ${bi}; }

  .en-color-control { cursor: pointer; padding: ${M(`--en-space-control-block`)}; block-size: var(--_en-text-control-block-size); }
  .en-color-control::-webkit-color-swatch-wrapper { padding: 0; }
  .en-color-control::-webkit-color-swatch { border: ${M(`--en-border-width`)} solid ${M(`--en-color-boundary`)}; border-radius: max(0px, ${M(`--en-radius-control`)} - ${M(`--en-space-control-block`)}); }
  .en-color-control::-moz-color-swatch { border: ${M(`--en-border-width`)} solid ${M(`--en-color-boundary`)}; border-radius: max(0px, ${M(`--en-radius-control`)} - ${M(`--en-space-control-block`)}); }
  ${ui}
  .en-checkbox, .en-switch {
    flex: none;
    inline-size: ${N(`--en-choice-size`,M(`--en-size-icon`))};
    block-size: ${N(`--en-choice-size`,M(`--en-size-icon`))};
    margin: 0;
    accent-color: ${M(`--en-color-action`)};
  }
  .en-checkbox {
    appearance: none;
    display: inline-grid;
    place-items: center;
    box-sizing: border-box;
    border: ${M(`--en-border-width`)} solid ${M(`--en-color-boundary`)};
    background: ${M(`--en-color-surface`)};
    cursor: pointer;
  }
  .en-checkbox { border-radius: ${M(`--en-radius-choice`)}; }
  .en-checkbox:checked, .en-checkbox:indeterminate { background: ${M(`--en-color-action`)}; border-color: ${M(`--en-color-action`)}; }
  .en-checkbox:checked::before {
    content: '';
    box-sizing: border-box;
    inline-size: ${M(`--en-size-choice-mark-inline`)};
    block-size: ${M(`--en-size-choice-mark-block`)};
    /* The check is directional artwork, not an inline-layout edge; never mirror it in RTL. */
    border-right: ${M(`--en-size-choice-mark-stroke`)} solid ${M(`--en-color-on-action`)};
    border-bottom: ${M(`--en-size-choice-mark-stroke`)} solid ${M(`--en-color-on-action`)};
    transform: rotate(45deg);
  }
  .en-checkbox:indeterminate::before { content: ''; inline-size: ${M(`--en-size-choice-mark-block`)}; block-size: 0; border: 0; border-block-end: ${M(`--en-size-choice-mark-stroke`)} solid ${M(`--en-color-on-action`)}; transform: none; }
  .en-checkbox:disabled { cursor: default; background: ${M(`--en-color-surface-subtle`)}; border-color: ${M(`--en-color-boundary`)}; }
  .en-checkbox:disabled::before { border-color: ${M(`--en-color-text-muted`)}; }
  .en-switch {
    position: relative;
    appearance: none;
    box-sizing: border-box;
    inline-size: ${N(`--en-switch-inline-size`,M(`--en-size-switch-inline`))};
    block-size: ${N(`--en-switch-block-size`,M(`--en-size-switch-block`))};
    border: ${M(`--en-border-width`)} solid ${M(`--en-color-boundary`)};
    border-radius: ${M(`--en-radius-pill`)};
    background: ${M(`--en-color-surface-subtle`)};
    cursor: pointer;
  }
  .en-switch::before {
    content: '';
    pointer-events: none;
    position: absolute;
    inset-block-start: ${M(`--en-space-switch-inset`)};
    inset-inline-start: ${M(`--en-space-switch-inset`)};
    --_en-switch-thumb-inline: ${N(`--en-switch-thumb-size`,M(`--en-size-switch-thumb`))};
    inline-size: var(--_en-switch-thumb-inline);
    block-size: ${N(`--en-switch-thumb-size`,M(`--en-size-switch-thumb`))};
    border-radius: ${M(`--en-radius-pill`)};
    background: ${M(`--en-color-text-muted`)};
    transition: inset-inline-start var(--_en-press-duration, ${M(`--en-duration-fast`)}) ${M(`--en-ease-standard`)}, inline-size var(--_en-press-duration, ${M(`--en-duration-fast`)}) ${M(`--en-ease-standard`)};
  }
  .en-switch:checked { background: ${M(`--en-color-action`)}; border-color: ${M(`--en-color-action`)}; }
  .en-switch:checked::before { inset-inline-start: calc(100% - var(--_en-switch-thumb-inline) - ${M(`--en-space-switch-inset`)}); background: ${M(`--en-color-on-action`)}; }
  .en-switch:not(:disabled):is(:active, .en-choice:active > .en-switch)::before { --_en-switch-thumb-inline: clamp(0px, var(--en-switch-thumb-pressed-size, var(--en-switch-thumb-size, ${M(`--en-size-switch-thumb`)})), calc(100% - 2 * ${M(`--en-space-switch-inset`)})); }
  @media (prefers-reduced-motion: reduce) { .en-switch:is(:active, .en-choice:active > .en-switch)::before { --_en-switch-thumb-inline: var(--en-switch-thumb-size, ${M(`--en-size-switch-thumb`)}); transition: none; } }
  :host([data-press=none]) .en-switch:is(:active, .en-choice:active > .en-switch)::before { --_en-switch-thumb-inline: var(--en-switch-thumb-size, ${M(`--en-size-switch-thumb`)}); }
  .en-switch:disabled { cursor: default; border-color: ${M(`--en-color-boundary`)}; background: ${M(`--en-color-surface-subtle`)}; }
  :is(.en-checkbox, .en-switch):not(:disabled):active { border-color: ${M(`--en-color-action-pressed`)}; }
  .en-switch:disabled::before { background: ${M(`--en-color-text-muted`)}; }
  .en-range { inline-size: 100%; min-inline-size: ${M(`--en-size-target-min`)}; min-block-size: ${U()}; margin: 0; accent-color: ${M(`--en-color-action`)}; }
  .en-range-row { display: flex; align-items: center; gap: ${M(`--en-space-3`)}; min-inline-size: 0; }
  .en-range-row > .en-range { flex: 1 1 auto; inline-size: 0; }
  .en-range-row[data-editable] { flex-wrap: wrap; }
  .en-range-row > .en-range-editor {
    flex: 0 1 calc(3 * ${M(`--en-size-control-min`)});
    inline-size: calc(3 * ${M(`--en-size-control-min`)});
    min-inline-size: min(100%, ${M(`--en-size-target-min`)});
    font-variant-numeric: tabular-nums;
  }
  /* The value axis alone becomes vertical. Labels, output and number editing
     retain the surrounding writing direction and normal text layout. */
  .en-range-row[data-orientation='vertical'] { flex-direction: column; flex-wrap: nowrap; }
  .en-range-row[data-orientation='vertical'] > .en-range {
    writing-mode: vertical-lr;
    direction: rtl;
    flex: none;
    inline-size: ${N(`--en-slider-length`,M(`--en-size-range-length`))};
    min-inline-size: ${U()};
    block-size: ${U()};
  }
  .en-range-row[data-orientation='vertical'] > .en-range-editor {
    flex: none;
    inline-size: min(100%, calc(3 * ${M(`--en-size-control-min`)}));
  }
  .en-range-error[data-pending] { visibility: hidden; }
  .en-range-row > output { flex: none; font-variant-numeric: tabular-nums; color: ${M(`--en-color-text`)}; }
  ${P(_`.en-checkbox`,_`.en-checkbox:not(:disabled):not([data-press='none']):is(:active, .en-choice:active > .en-checkbox)`,V.checkbox)}
  ${P(_`.en-switch`,_`.en-switch:not(:disabled):not([data-press='none']):is(:active, .en-choice:active > .en-switch)`,V.switch)}
  ${P(_`.en-select`,_`.en-select:not(:disabled):not([data-press='none']):active`,V.select)}
  ${P(_`.en-number-step`,_`.en-number-step:not(:disabled):not([aria-disabled='true']):not([data-press='none']):active`,V[`number-step`])}
  ${Bn}
  ${Hn}
  ${I(_`.en-number-group > .en-number-input`,{family:`input`,inset:!0,halo:!1})}
  ${I(_`.en-number-group > .en-number-step`,{family:`button`,inset:!0,halo:!1})}
  ${mi}
  @media (any-pointer: coarse) {
    ${Er(_`.en-button:not(.en-icon-button), .en-button[data-icon-only], .en-input, .en-textarea, .en-select, .en-number-input, .en-number-step, .en-color-control`,!0)}
    ${Ar(_`.en-button, .en-control, .en-input, .en-textarea, .en-select, .en-range`)}
    .en-range-row[data-orientation='vertical'] > .en-range { min-inline-size: ${U(!0)}; }
    ${Or(_`.en-button:not(.en-icon-button), .en-input, .en-textarea, .en-select`)}
    .en-color-control { block-size: var(--_en-text-control-block-size); }
    ${jr(_`.en-icon-button, .en-number-step`)}
    .en-number-group > :is(.en-number-input, .en-number-step, button.en-button.en-number-step) { min-block-size: max(calc(var(--_en-text-control-block-size) - 2 * ${K}), ${H(!0)}); }
  }
  @media (prefers-reduced-motion: reduce) { ${Mr(_`.en-button, .en-switch::before`)} }
  @media (forced-colors: active) {
    ${Nr(_`.en-button, .en-control, .en-input, .en-textarea, .en-select, .en-number-group`)}
    ${_i}
    ${Pr(_`:is(.en-button, .en-control, .en-input, .en-textarea, .en-select):is(:disabled, [aria-disabled='true']), .en-link[aria-disabled='true']`)}
    ${zn}
    .en-checkbox, .en-switch, .en-range { accent-color: auto; }
    .en-checkbox { background: Canvas; border-color: CanvasText; }
    .en-checkbox:checked, .en-checkbox:indeterminate { background: Canvas; border-color: CanvasText; }
    .en-checkbox::before { border-color: CanvasText; }
    .en-checkbox:disabled { background: Canvas; border-color: GrayText; }
    .en-checkbox:disabled::before { border-color: GrayText; }
    .en-checkbox:focus-visible, .en-switch:focus-visible { outline-color: CanvasText; }
    .en-switch { background: Canvas; border-color: ButtonText; }
    .en-switch::before { background: ButtonText; }
    .en-switch:checked { background: Highlight; border-color: Highlight; }
    .en-switch:checked::before { background: HighlightText; }
  .en-switch:disabled { background: Canvas; border-color: GrayText; }
    :is(.en-checkbox, .en-switch):not(:disabled):active { border-color: Highlight; box-shadow: none; }
  .en-switch:disabled::before { background: GrayText; }
  }
  ${Tr}
`),Ci=N(`--en-option-list-radius`,N(`--en-overlay-radius`,M(`--en-radius-container`))),wi=_`max(${N(`--en-option-list-padding`,N(`--en-overlay-padding`,M(`--en-space-1`)))}, ${F({family:`option`,inset:!0})})`,Ti=R(_`
  .en-select { min-inline-size: 0; max-inline-size: 100%; white-space: nowrap; text-overflow: ellipsis; }
  .en-select > button { display: none; }
  /* Styling the closed control does not replace its OS picker. Keep this
     fallback outside base-select; ordinary select pseudos are not portable. */
  @supports selector(:has(> .en-select)) {
    @supports not ((appearance: base-select) and selector(::picker(select))) {
      .en-select {
        -webkit-appearance: none;
        appearance: none;
        padding-inline-end: calc(${vi} + ${M(`--en-size-icon`)} + ${M(`--en-space-icon-label`)});
        min-block-size: max(var(--_en-text-control-block-size), calc(${M(`--en-size-icon`)} + 2 * ${M(`--en-space-control-block`)} + 2 * ${M(`--en-border-width`)}));
      }
      .en-field-focus-frame:has(> .en-select)::before {
        content: '';
        position: absolute;
        z-index: 1;
        inset-inline-end: calc(${vi} + ${M(`--en-border-width`)});
        inset-block-start: 50%;
        translate: 0 -50%;
        inline-size: ${M(`--en-size-icon`)};
        block-size: ${M(`--en-size-icon`)};
        color: ${M(`--en-color-text-muted`)};
        background-color: currentColor;
        mask: ${ti} center / contain no-repeat;
        pointer-events: none;
      }
      @media (forced-colors: active) {
        .en-field-focus-frame:has(> .en-select)::before { forced-color-adjust: none; color: ButtonText; }
        .en-field-focus-frame:has(> .en-select:disabled)::before { color: GrayText; }
      }
    }
  }
  @supports (appearance: base-select) and selector(::picker(select)) {
    .en-select, .en-select::picker(select) { appearance: ${N(`--en-select-appearance`,_`base-select`)}; }
    .en-select { align-items: center; gap: ${M(`--en-space-icon-label`)}; }
    /* Give the browser-owned label a shrinkable box separate from the caret.
       The implicit select button's anonymous text cannot be truncated reliably. */
    .en-select > button { all: unset; display: block; flex: 1; min-inline-size: 0; }
    .en-select selectedcontent { display: block; min-inline-size: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .en-select::picker(select) {
      padding: ${wi};
      border: ${M(`--en-border-width`)} solid ${N(`--en-option-list-border-color`,N(`--en-overlay-border-color`,M(`--en-color-boundary`)))};
      border-radius: ${Ci};
      background: ${N(`--en-option-list-background`,N(`--en-overlay-background`,M(`--en-color-surface-raised`)))};
      color: ${N(`--en-option-list-color`,N(`--en-overlay-color`,M(`--en-color-text`)))};
      box-shadow: ${N(`--en-option-list-shadow`,M(`--en-shadow-overlay`))};
      max-block-size: min(${N(`--en-option-list-max-block-size`,N(`--en-overlay-max-block-size`,M(`--en-layout-panel-preferred`)))}, calc(100dvh - ${M(`--en-space-8`)}));
      overflow: auto;
    }
    ${ci(_`.en-select`,_`.en-select:open`,_`.en-select:not(:open)`,`fade`,_`::picker(select)`)}
    .en-select option {
      white-space: normal; overflow-wrap: anywhere;
      position: relative;
      min-block-size: ${U()};
      padding: ${N(`--en-option-block-padding`,M(`--en-space-control-block`))} ${N(`--en-option-inline-padding`,M(`--en-space-control-inline`))};
      border-radius: ${N(`--en-option-radius`,_`max(0px, ${Ci} - ${wi} - ${M(`--en-border-width`)})`)};
    }
    .en-select option + option { margin-block-start: ${N(`--en-option-list-gap`,_`0px`)}; }
    ${Pn({base:_`.en-select option`,selected:_`.en-select option:checked`,hover:_`.en-select option:not(:disabled):hover`,focus:_`.en-select option:not(:disabled):focus-visible`,pressed:_`.en-select option:not(:disabled):active`,disabled:_`.en-select option:disabled`,restBackground:_`transparent`,restColor:N(`--en-option-list-color`,N(`--en-overlay-color`,_`inherit`)),selectedColor:N(`--en-option-list-color`,N(`--en-overlay-color`,M(`--en-color-action-text`))),hoverBackground:M(`--en-color-selected`)})}
    .en-select option:not(:disabled):focus-visible { z-index: 1; }
    @media (hover: hover) { .en-select option:not(:disabled):hover { z-index: 1; } }
    /* Native :active is pressed activation, not the combobox's keyboard candidate. */
    ${L(_`.en-select option:not(:disabled):focus-visible`,{family:`option`,inset:!0,restSelector:_`.en-select option`})}
    @media (hover: hover) { ${L(_`.en-select option:not(:disabled):hover`,{family:`option`,inset:!0,restSelector:_`.en-select option`})} }
    .en-select::picker-icon {
      content: '';
      inline-size: ${M(`--en-size-icon`)};
      block-size: ${M(`--en-size-icon`)};
      flex: none;
      color: ${M(`--en-color-text-muted`)};
      background-color: currentColor;
      mask: ${ti} center / contain no-repeat;
    }
    @media (any-pointer: coarse) { .en-select option { min-block-size: ${U(!0)}; } }
    @media (forced-colors: active) {
      .en-select::picker(select) { background: Canvas; color: CanvasText; border-color: ButtonText; box-shadow: none; }
      .en-select option { background: Canvas; color: CanvasText; }
      .en-select option:checked, .en-select option:not(:disabled):focus-visible { background: Highlight; color: HighlightText; outline-color: HighlightText; }
      @media (hover: hover) { .en-select option:not(:disabled):hover { background: Highlight; color: HighlightText; outline-color: HighlightText; } }
      .en-select option:disabled { color: GrayText; }
      /* Keep the decorative mask visible while using the user's system colors. */
      .en-select::picker-icon { forced-color-adjust: none; color: ButtonText; }
      .en-select:disabled::picker-icon { color: GrayText; }
    }
  }
`),Ei=R(_`
  .en-field, .en-rating-field { --_en-field-gap: ${N(`--en-field-gap`,M(`--en-space-label-control`))}; }
  .en-field { display: flex; flex-direction: column; min-inline-size: 0; gap: 0; }
  .en-field > :not(:first-child):not(.en-description),
  .en-choice-content > :not(:first-child):not(.en-description) { margin-block-start: var(--_en-field-gap); }
  /* A fieldset legend already separates its first content through its margin. */
  .en-field > .en-legend + :not(.en-description) { margin-block-start: 0; }
  .en-label { display: block; color: ${M(`--en-color-text`)}; font-weight: ${M(`--en-font-label-strong-weight`)}; overflow-wrap: break-word; }
  .en-description, .en-error { margin: 0; font-size: ${M(`--en-font-ui-size`)}; line-height: ${M(`--en-font-body-line-height`)}; overflow-wrap: break-word; }
  /* No box or gap is created by the empty fallback. An assigned root remains
     present even when its light DOM is empty: it may render its own shadow. */
  .en-description { display: flow-root; color: ${M(`--en-color-text-muted`)}; }
  .en-description-fallback,
  .en-description > slot::slotted(:not([hidden])) { display: block; margin-block-start: var(--_en-field-gap); }
  .en-description-fallback:empty { display: none; }
  .en-error { color: ${M(`--en-color-danger-text`)}; }
  .en-choice { display: flex; align-items: center; gap: ${M(`--en-space-icon-label`)}; min-block-size: ${U()}; min-inline-size: ${M(`--en-size-target-min`)}; cursor: pointer; }
  .en-choice > :where(.en-label, .en-choice-content) { min-inline-size: 0; }
  .en-choice-content { --_en-field-gap: ${N(`--en-field-gap`,M(`--en-space-control-description`))}; display: flex; flex-direction: column; gap: 0; }
  .en-fieldset { margin: 0; padding: 0; min-inline-size: 0; border: 0; }
  .en-legend { padding: 0; margin-block-end: ${M(`--en-space-label-control`)}; font-weight: ${M(`--en-font-label-strong-weight`)}; }
  .en-form-stack { display: flex; flex-direction: column; gap: ${M(`--en-space-fields`)}; }
  .en-validation-summary { padding: ${M(`--en-space-panel`)}; border: ${M(`--en-border-width`)} solid ${M(`--en-color-danger-text`)}; border-radius: ${M(`--en-radius-container`)}; }
  .en-validation-summary :where(ul, ol) { padding-inline-start: ${M(`--en-space-6`)}; }
  @media (any-pointer: coarse) { .en-choice { min-block-size: ${U(!0)}; min-inline-size: ${H(!0)}; } }
  @media (forced-colors: active) { .en-label, .en-description, .en-error { color: CanvasText; } .en-validation-summary { border-color: CanvasText; } }
`),Di=R(_`
  .en-adorned { display:flex !important; align-items:center; border:${K} solid ${N(`--en-input-border-color`,M(`--en-color-boundary`))}; border-radius:${$r}; background:${N(`--en-input-background`,M(`--en-color-surface`))}; }
  .en-adorned > input { flex:1; min-inline-size:0; border:0; background:transparent; }
  .en-adorned:has(:focus-visible) { outline:var(--en-input-focus-width, ${M(`--en-focus-width`)}) solid var(--en-input-focus-color, ${M(`--en-color-focus`)}); outline-offset:var(--en-input-focus-offset, ${M(`--en-focus-offset`)}); }
  .en-adorned > input:focus-visible { outline:none; box-shadow:none; }
  .en-adorned[data-invalid] { border-color:var(--en-input-invalid-border-color, ${M(`--en-color-danger-text`)}); }
  .en-adorned slot::slotted(*) { margin-inline:${M(`--en-space-2`)}; }
  ${wr(_`.en-adorned`,_`.en-adorned slot[name='help-action']::slotted(*)`,$r,K)}
`);function Oi(e,t=`description`){return S`<div id="description" part=${t} class="en-description"><slot name="description"><span class="en-description-fallback">${e||T}</span></slot></div>`}function ki(e,t){return S`<div part="field" class="en-field">
    <label class="en-choice" part="label">
      <input part="control" class=${`en-${e.kind}`} type=${e.kind===`radio`?`radio`:`checkbox`}
        role=${e.kind===`switch`?`switch`:T}
        ?checked=${e.checked} aria-checked=${e.kind===`checkbox`&&e.indeterminate?`mixed`:T}
        .value=${e.value} ?disabled=${e.disabled} ?required=${e.required}
        tabindex=${e.tabIndex} aria-labelledby="label-text" aria-describedby=${e.error?`description error`:`description`} aria-invalid=${e.error?`true`:T}
        @change=${t}>
      <span class="en-label" id="label-text" part="label-text"><slot name="label"><slot>${e.label}</slot></slot></span>
    </label>
    ${Oi(e.description)}
    ${e.error?S`<div id="error" part="error" class="en-error">${e.error}</div>`:T}
  </div>`}var Ai=class extends E{static properties={error:{noAccessor:!0},validationText:{attribute:`validation-text`},checked:{type:Boolean,noAccessor:!0,attribute:!1},defaultChecked:{type:Boolean,attribute:`checked`,noAccessor:!0},disabled:{type:Boolean,reflect:!0},required:{type:Boolean,reflect:!0},name:{reflect:!0},value:{},label:{},description:{}};static styles=[B,z,Si,Ei,W];static formAssociated=!0;checkedDefaults=new Yr(this,`checked`,e=>e!==null,e=>e?``:null,e=>{this.checked=e});feedback=new Jr(this,()=>{this.syncForm()},()=>this.validationMessage);get error(){return this.feedback.error}set error(e){this.feedback.error=e}get visibleError(){return this.feedback.visible}get defaultChecked(){return this.checkedDefaults.value}set defaultChecked(e){this.checkedDefaults.value=!!e}attributeChangedCallback(e,t,n){if(e===`checked`){this.checkedDefaults.attributeChanged();return}super.attributeChangedCallback(e,t,n)}checkedModel=on(!1);signalController=new j(this,()=>this.checkedModel.view.get());authorRevision=0;formDisabled=!1;internals=typeof this.attachInternals==`function`?this.attachInternals():void 0;formController=this.internals?new Zr(this,{internals:this.internals,control:()=>this.nativeControl,value:()=>this.formValue,state:()=>this.checked?`checked`:`unchecked`,disabled:()=>this.effectiveDisabled,onReset:()=>{this.feedback.reset(),this.checkedDefaults.reset(),this.syncControl()},onRestore:e=>{typeof e==`string`&&(this.checked=e===`checked`),this.syncControl()},validate:()=>this.formValidation()}):void 0;constructor(){super(),this.disabled=!1,this.required=!1,this.name=``,this.value=`on`,this.validationText=``,this.label=``,this.description=``}get checked(){return this.checkedModel.value.get()}set checked(e){this.checkedDefaults.markDirty(),++this.authorRevision,this.setChecked(!!e)}setChecked(e){let t=this.checked;this.checkedModel.set(e),this.requestUpdate(`checked`,t),this.syncForm()}get mixed(){return!1}get effectiveDisabled(){return this.disabled||this.formDisabled}get controlTabIndex(){return 0}get nativeControl(){return this.renderRoot?.querySelector(`input`)??null}get formValue(){return this.checked?this.value:null}focus(e){this.nativeControl?.focus(e)}get form(){return this.internals?.form??null}get labels(){return this.internals?.labels}get willValidate(){return this.internals?.willValidate??!1}get validity(){return this.internals?.validity}get validationMessage(){return this.internals?.validationMessage??``}checkValidity(){return this.syncForm(),this.internals?.checkValidity?.()??!0}reportValidity(){return this.syncForm(),this.internals?.reportValidity?.()??!0}formDisabledCallback(e){this.formDisabled=e,this.requestUpdate(),this.formController?.formDisabled(e)}formResetCallback(){this.formController?.formReset()}formStateRestoreCallback(e,t=`restore`){this.formController?.formStateRestore(e,t)}formValidation(){let e=this.required&&!this.checked&&!this.effectiveDisabled;return qr({flags:e?{valueMissing:!0}:{},message:e?this.validationText||this.nativeControl?.validationMessage||`Please select this option.`:``,anchor:this.nativeControl??void 0},this.error)}syncForm(){this.formController?.sync()}syncControl(){this.nativeControl&&(this.nativeControl.checked=this.checked,this.nativeControl.indeterminate=this.mixed)}handleChange(e){if(this.effectiveDisabled){this.syncControl();return}this.checkedDefaults.markDirty();let t=this.nativeControl?.checked??!this.checked,n=this.isConnected;A(this,{previous:this.checked,proposed:t,reason:`toggle`,getRevision:()=>this.authorRevision,canCommit:()=>!this.effectiveDisabled&&(!n||this.isConnected),stage:e=>{this.setChecked(e),this.syncControl()},rollback:e=>{this.setChecked(e),this.syncControl()},commit:()=>{this.didCommit(),this.syncForm()}}),this.syncControl()}didCommit(){}updated(e){this.syncForm(),this.syncControl()}render(){return ki({kind:this.kind,checked:this.checked,indeterminate:this.mixed,disabled:this.effectiveDisabled,required:this.required,value:this.value,label:this.label,description:this.description,error:this.visibleError,tabIndex:this.controlTabIndex},e=>this.handleChange(e))}},ji={tagName:`en-checkbox`,elementClass:class extends Ai{static properties={...Ai.properties,indeterminate:{type:Boolean,noAccessor:!0}};mixedState=!1;get indeterminate(){return this.mixedState}set indeterminate(e){++this.authorRevision,this.setIndeterminate(!!e)}setIndeterminate(e){let t=this.mixedState;this.mixedState=e,this.requestUpdate(`indeterminate`,t),this.syncControl()}get kind(){return`checkbox`}get mixed(){return this.indeterminate}didCommit(){this.setIndeterminate(!1)}formResetCallback(){this.indeterminate=!1,super.formResetCallback()}}};n(customElements,ji);var Mi=class{#e;#t;#n=null;#r;#i=!1;#a;#o=new WeakSet;constructor(e,t){this.#e=e,this.#t=t,e.addController(this)}hostConnected(){this.#i=!0}hostUpdated(){this.#c(),this.sync()}hostDisconnected(){this.#i=!1,this.#l(),this.#r?.abort(),this.#r=void 0,this.#n=null}sync(){let e=this.#n;if(!e||this.#t.model.isComposing.get())return;let t=this.#t.model.draft.get();e.value!==t&&(this.#a=void 0,e.value=t)}#s(e,t,n){let r=this.#t.model.view.get().revision,i=Object.freeze({value:e,isComposing:t,inputType:n});return dn(this.#e,i),this.#t.onInput?.(i),this.#t.model.view.get().revision===r}#c(){if(!this.#i)return;let e=this.#t.control();if(e===this.#n||(this.#l(),this.#r?.abort(),this.#n=e,!e))return;let t=e.ownerDocument.defaultView?.AbortController??globalThis.AbortController;this.#r=new t;let n={signal:this.#r.signal},r=this.#t.model;if(e.addEventListener(`compositionstart`,()=>{this.#a=void 0,r.startComposition(),r.setDraft(e.value),this.#e.requestUpdate()},n),e.addEventListener(`compositionend`,()=>{let t=e.value,n=r.hasDeferredValue.get();r.endComposition(t),this.#a=t,this.#s(t,!1,`insertCompositionText`)&&!n&&t!==r.value.get()&&this.#t.onCommit?.(t,`compositionend`),this.sync(),this.#e.requestUpdate()},n),e.addEventListener(`input`,t=>{let n=t;n.isComposing&&!r.isComposing.get()&&r.startComposition();let i=e.value;r.setDraft(i);let a=r.isComposing.get(),o=this.#s(i,a,n.inputType??``),s=!a&&i===this.#a;a||(this.#a=void 0),o&&!a&&!s&&i!==r.value.get()&&this.#t.onCommit?.(i,`input`),this.sync(),this.#e.requestUpdate()},n),e.addEventListener(`change`,()=>{r.isComposing.get()||(r.setDraft(e.value),e.value!==r.value.get()&&this.#t.onCommit?.(e.value,`change`),this.sync(),this.#e.requestUpdate())},n),!this.#o.has(e)&&(this.#o.add(e),(this.#t.adoptInitialValue?.(e)??e.value!==e.defaultValue)&&e.value!==r.draft.get())){let t=e.value;r.setDraft(t),this.#s(t,!1,`hydrate`)&&t!==r.value.get()&&this.#t.onCommit?.(t,`hydrate`)}}#l(){this.#t.model.isComposing.get()&&this.#t.model.endComposition(this.#n?.value),this.#a=void 0}};function Ni(e=``){let t=new k.State(Object.freeze({value:e,draft:e,isComposing:!1,dirty:!1,revision:0,deferredAuthorWrite:!1})),n=e=>{let n=t.get(),r={...n,...e};return r.value===n.value&&r.draft===n.draft&&r.isComposing===n.isComposing&&r.deferredAuthorWrite===n.deferredAuthorWrite?!1:(t.set(Object.freeze({...r,dirty:r.value!==r.draft,revision:n.revision+1})),!0)},r=e=>t.get().isComposing?n({value:e,deferredAuthorWrite:!0}):n({value:e,draft:e,deferredAuthorWrite:!1});return{value:new k.Computed(()=>t.get().value),draft:new k.Computed(()=>t.get().draft),isComposing:new k.Computed(()=>t.get().isComposing),hasDeferredValue:new k.Computed(()=>t.get().deferredAuthorWrite),view:new k.Computed(()=>{let{deferredAuthorWrite:e,...n}=t.get();return Object.freeze(n)}),setValue:r,stageValue:e=>n({value:e}),setDraft:e=>n({draft:e}),startComposition:()=>n({isComposing:!0}),endComposition:e=>{let r=t.get();return n({draft:r.deferredAuthorWrite?r.value:e??r.draft,isComposing:!1,deferredAuthorWrite:!1})},acceptDraft:()=>!t.get().isComposing&&r(t.get().draft),reset:()=>r(e)}}var q=class extends E{static formAssociated=!0;valueDefaults=new Yr(this,`value`,e=>e??``,e=>String(e),e=>{this.value=e});get defaultValue(){return this.valueDefaults.value}set defaultValue(e){this.valueDefaults.value=String(e??``)}attributeChangedCallback(e,t,n){if(e===`value`){this.valueDefaults.attributeChanged();return}super.attributeChangedCallback(e,t,n)}static styles=[B,Ei,Si,_`:host { display: block; }`];static properties={label:{type:String},description:{type:String},validationText:{attribute:`validation-text`},error:{type:String,noAccessor:!0},value:{type:String,noAccessor:!0,attribute:!1},defaultValue:{attribute:`value`,noAccessor:!0},name:{type:String,reflect:!0},disabled:{type:Boolean,reflect:!0},required:{type:Boolean,reflect:!0},placeholder:{type:String}};applicationError=``;get error(){return this.applicationError}set error(e){let t=this.applicationError;this.applicationError=String(e??``),this.syncForm(),this.requestUpdate(`error`,t)}model=Ni();signal=new j(this,()=>this.model.view.get());internals;formAdapter;authorRevision=0;showNativeError=!1;nativeErrorMessage=``;constructor(){super(),this.label=``,this.description=``,this.error=``,this.validationText=``,this.name=``,this.disabled=!1,this.required=!1,this.placeholder=``,this.internals=typeof this.attachInternals==`function`?this.attachInternals():void 0,this.internals&&(this.formAdapter=new Zr(this,{internals:this.internals,control:()=>this.controlNode,value:()=>this.submissionValue,state:()=>this.submissionState,disabled:()=>this.disabled,validate:()=>this.validateAcceptedValue(),onReset:()=>{this.showNativeError=!1,this.valueDefaults.reset()},onRestore:e=>{typeof e==`string`&&(this.value=e)}})),this.addEventListener(`en-input`,()=>this.valueDefaults.markDirty(),{capture:!0}),this.addEventListener(`invalid`,()=>{this.showNativeError=!0,this.requestUpdate()})}get value(){return this.model.value.get()}set value(e){this.valueDefaults.markDirty();let t=this.value;this.authorRevision++,this.model.setValue(String(e??``)),this.reconcile(),this.syncForm(),this.requestUpdate(`value`,t)}get form(){return this.internals?.form??null}get labels(){return this.internals?.labels}get validity(){return this.internals?.validity??this.controlNode?.validity}get validationMessage(){return this.internals?.validationMessage??``}get willValidate(){return this.internals?.willValidate??!1}focus(e){this.controlNode?.focus(e)}blur(){this.controlNode?.blur()}checkValidity(){return this.syncForm(),this.internals?.checkValidity?.()??this.controlNode?.checkValidity()??!0}reportValidity(){return this.syncForm(),this.internals?.reportValidity?.()??this.controlNode?.reportValidity()??!0}formResetCallback(){this.formAdapter?.formReset()}formDisabledCallback(e){this.formAdapter?.formDisabled(e)}formStateRestoreCallback(e,t){this.formAdapter?.formStateRestore(e,t)}get submissionValue(){return this.value}get submissionState(){return this.value}get isDisabled(){return this.formAdapter?.disabled??this.disabled}get defaultControlValue(){return this.hasUpdated?this.defaultValue:this.value}get controlNode(){return this.shadowRoot?.querySelector(`#control`)??null}get describedBy(){return this.visibleError?`description error`:`description`}get visibleError(){return this.error||(this.showNativeError?this.nativeErrorMessage:``)}get controlAriaInvalid(){return this.visibleError?`true`:T}renderControlFrame(){return S`<div class="en-field-focus-frame" part="focus-frame">${this.renderControl()}</div>`}get valueRevision(){return this.authorRevision}canCommitValue(e){return!0}stageValue(e){let t=this.value;this.model.stageValue(e),this.syncForm(),this.requestUpdate(`value`,t)}requestValue(e,t){if(this.isDisabled)return;this.valueDefaults.markDirty();let n=this.isConnected;A(this,{previous:this.value,proposed:e,reason:t,getRevision:()=>this.authorRevision,canCommit:e=>!this.isDisabled&&(!n||this.isConnected)&&this.canCommitValue(e),stage:e=>this.stageValue(e),rollback:e=>this.stageValue(e),commit:e=>{this.model.setValue(e),this.reconcile(),this.syncForm(),this.requestUpdate()}})}updated(e){super.updated(e);let t=this.controlNode;t&&`defaultValue`in t&&t.defaultValue!==this.defaultValue&&(t.defaultValue=this.defaultValue),this.reconcile(),this.syncForm()}syncForm(){let e=this.nativeErrorMessage;this.formAdapter?.sync(),this.nativeErrorMessage=this.validationMessage,this.showNativeError&&e!==this.nativeErrorMessage&&this.requestUpdate()}validateAcceptedValue(){let e=this.controlNode;if(!e)return{flags:this.error?{customError:!0}:{},message:this.error};let t=e.value===this.value?e:e.cloneNode(!0);t!==e&&(t.value=this.value),t.setCustomValidity(this.error);let n=t.validity;return{flags:{badInput:n.badInput,customError:n.customError,patternMismatch:n.patternMismatch,rangeOverflow:n.rangeOverflow,rangeUnderflow:n.rangeUnderflow,stepMismatch:n.stepMismatch,tooLong:n.tooLong,tooShort:n.tooShort,typeMismatch:n.typeMismatch,valueMissing:n.valueMissing},message:n.valid?``:this.error||this.validationText||t.validationMessage,anchor:e}}descriptionPart=`description`;errorPart=`error`;render(){return S`<div class="en-field" part="field" data-invalid=${this.visibleError?``:T}>
      <label class="en-label" part="label" for="control"><slot name="label">${this.label}</slot></label>
      ${this.renderControlFrame()}
      ${Oi(this.description,this.descriptionPart)}
      ${this.visibleError?S`<div class="en-error" part=${this.errorPart} id="error">${this.visibleError}</div>`:T}
    </div>`}};function J(e){let t=e.getRootNode();return(t.nodeType===9||t.nodeType===11&&`host`in t)&&`getElementById`in t?t:null}var Pi=new WeakMap,Fi=class{root;subscribers=new Map;resolved=new Map;observer;constructor(e){this.root=e;let t=(e.nodeType===9?e:e.ownerDocument)?.defaultView?.MutationObserver;this.observer=t?new t(e=>{let t=new Set;for(let n of e){if(n.type===`childList`){if(![...n.addedNodes,...n.removedNodes].some(e=>e.nodeType===1))continue;for(let e of this.subscribers.keys())t.add(e);break}n.oldValue&&t.add(n.oldValue);let e=n.target.id;e&&t.add(e)}for(let e of t)this.notify(e)}):void 0,this.observer?.observe(e,{childList:!0,subtree:!0,attributes:!0,attributeFilter:[`id`],attributeOldValue:!0})}notify(e){let t=this.subscribers.get(e);if(!t)return;let n=this.root.getElementById(e);if(!(this.resolved.has(e)&&this.resolved.get(e)===n)){this.resolved.set(e,n);for(let r of[...t])this.subscribers.get(e)===t&&t.has(r)&&r(n)}}subscribe(e,t){let n=this.subscribers.get(e);n||this.subscribers.set(e,n=new Set),n.add(t);let r=this.root.getElementById(e);if(!this.resolved.has(e)||this.resolved.get(e)!==r){this.resolved.set(e,r);for(let t of[...n])this.subscribers.get(e)===n&&n.has(t)&&t(r)}else t(r);let i=!1;return()=>{i||(i=!0,n.delete(t),!n.size&&this.subscribers.get(e)===n&&(this.subscribers.delete(e),this.resolved.delete(e)),this.subscribers.size||(this.observer?.disconnect(),Pi.get(this.root)===this&&Pi.delete(this.root)))}}};function Ii(e,t,n){if(!e||!t)return n(null),()=>{};if(!(e.nodeType===9?e:e.ownerDocument)?.defaultView?.MutationObserver)return n(e.getElementById(t)),()=>{};let r=Pi.get(e);return r||Pi.set(e,r=new Fi(e)),r.subscribe(t,n)}var Li=class{#e;#t;#n=null;#r=``;#i=null;#a=null;constructor(e,t){this.#e=e,this.#t=t,e.addController(this)}hostConnected(){this.#o()}hostUpdated(){this.#o()}hostDisconnected(){this.#i?.(),this.#i=null,this.#n=null,this.#r=``,this.#s(null)}#o(){if(!this.#e.isConnected)return;let e=J(this.#e),t=typeof this.#e.for==`string`?this.#e.for:``;if(this.#i&&e===this.#n&&t===this.#r)return;this.#i?.(),this.#i=null,this.#n=e,this.#r=t;let n=Ii(e,t,this.#s);!this.#e.isConnected||J(this.#e)!==e||this.#e.for!==t?n():this.#i=n}#s=e=>{let t=this.#e.isConnected&&e?.namespaceURI===`http://www.w3.org/1999/xhtml`&&[`button`,`en-button`,`en-swatch`].includes(e.localName)?e:null;t!==this.#a&&(this.#a?.removeEventListener(`click`,this.#c),this.#a=t,t?.addEventListener(`click`,this.#c))};#c=e=>{let t=this.#a,n=J(this.#e);!e.defaultPrevented&&this.#e.isConnected&&t?.isConnected&&this.#e.for===this.#r&&n===this.#n&&n?.getElementById(this.#r)===t&&(e.preventDefault(),!(t.disabled||t.loading||t.matches(`:disabled, [aria-disabled="true"]`)||this.#t.disabled())&&this.#t.activate())}};function Ri(e){let t=String(e??``).trim();return/^#[\da-f]{6}$/i.test(t)?t.toLowerCase():`#000000`}var zi={tagName:`en-color-field`,elementClass:class extends q{static properties={...q.properties,for:{type:String,reflect:!0}};picker=new Li(this,{disabled:()=>this.isDisabled,activate:()=>this.showPicker()});requestingPicker=!1;editing=new Mi(this,{model:this.model,control:()=>this.controlNode,onCommit:(e,t)=>this.requestValue(Ri(e),t)});constructor(){super(),this.for=``,this.valueDefaults.apply(`#000000`)}get value(){return super.value}set value(e){super.value=Ri(e)}showPicker(){if(!this.isConnected||this.isDisabled||this.requestingPicker)return;let e=this.controlNode;if(e?.isConnected&&(this.syncForm(),!e.disabled)){this.requestingPicker=!0;try{if(typeof e.showPicker==`function`)try{e.showPicker();return}catch{}e.focus(),e.click()}finally{this.requestingPicker=!1}}}reconcile(){this.editing?.sync()}renderControl(){return S`<input id="control" class="en-input en-color-control" part="control" type="color"
      name=${this.name} value=${this.defaultControlValue} ?disabled=${this.isDisabled}
      aria-describedby=${this.describedBy} aria-invalid=${this.controlAriaInvalid}>`}}};n(customElements,zi);function Y(e,t){e.inert===t&&(e.inert=!t)}function Bi(e){let t=e.currentTarget;e.target===t&&(e.newState===`open`&&Y(t,!0),queueMicrotask(()=>{if(!t.isConnected)return;let e=t.localName===`dialog`?t.open:t.matches(`:popover-open`);Y(t,e)}))}var Vi=N(`--en-option-list-radius`,N(`--en-overlay-radius`,M(`--en-radius-container`))),Hi=_`max(${N(`--en-option-list-padding`,N(`--en-overlay-padding`,M(`--en-space-1`)))}, ${F({family:`option`,inset:!0})})`,Ui=N(`--en-input-inline-padding`,N(`--en-control-inline-padding`,M(`--en-space-control-inline`))),Wi=R(_`
	.en-combobox {
		--_en-combobox-trigger-size: ${U()};
		position: relative;
		min-inline-size: 0;
	}
	.en-combobox-input {
		padding-inline-end: calc(${Ui} + var(--_en-combobox-trigger-size));
	}
	.en-combobox-anchor { position: relative; min-inline-size: 0; }
	.en-combobox-input:is([aria-invalid='true'], :user-invalid) {
		padding-inline-end: max(0px, calc(${Ui} + var(--_en-combobox-trigger-size) + ${K} - ${Qr}));
	}
	/* A query is unfinished selection, not an announced error. Keep native
	   submission validity while aligning its paint with explicit field feedback. */
	.en-combobox-input:user-invalid:not([aria-invalid='true']) {
		border-color: ${N(`--en-control-border-color`,M(`--en-color-boundary`))};
		border-width: ${K};
		padding-block: ${M(`--en-space-control-block`)};
		padding-inline: ${Ui};
		padding-inline-end: calc(${Ui} + var(--_en-combobox-trigger-size));
	}
	.en-combobox-trigger {
		position: absolute;
		inset-block: ${K};
		inset-inline-end: ${K};
		display: grid;
		place-items: center;
		inline-size: var(--_en-combobox-trigger-size);
		padding: 0;
		border: 0;
		border-radius: max(0px, ${$r} - ${M(`--en-border-width`)});
		background: transparent;
		color: ${M(`--en-color-text-muted`)};
		cursor: pointer;
	}
	@media (hover: hover) { .en-combobox-trigger:not(:disabled):hover { color: ${M(`--en-color-text`)}; background: ${M(`--en-color-selected`)}; } }
	.en-combobox-trigger:not(:disabled):active { color: ${M(`--en-color-text`)}; background: ${M(`--en-color-accent-subtle`)}; }
	.en-combobox-trigger:disabled { cursor: default; }
	.en-combobox-trigger svg, .en-combobox-check { inline-size: ${M(`--en-size-icon`)}; block-size: ${M(`--en-size-icon`)}; flex: none; }
	${I(_`.en-combobox-trigger`,{family:`button`,inset:!0,halo:!1})}
	.en-combobox-popup {
		position: fixed;
		visibility: var(--_en-combobox-visibility, hidden);
		inset: auto;
		left: var(--_en-combobox-x, 0px);
		top: var(--_en-combobox-y, 0px);
		inline-size: var(--_en-combobox-width, auto);
		margin: 0;
		box-sizing: border-box;
		min-inline-size: 0;
		max-inline-size: calc(100vw - ${M(`--en-space-4`)});
		max-block-size: min(var(--_en-combobox-max-height, 100dvh), ${N(`--en-option-list-max-block-size`,N(`--en-overlay-max-block-size`,_`min(${M(`--en-layout-panel-preferred`)}, calc(100dvh - ${M(`--en-space-8`)}))`))});
		row-gap: ${M(`--en-space-1`)};
		padding: ${Hi};
		border: ${M(`--en-border-width`)} solid ${N(`--en-option-list-border-color`,N(`--en-overlay-border-color`,M(`--en-color-boundary`)))};
		border-radius: ${Vi};
		background: ${N(`--en-option-list-background`,N(`--en-overlay-background`,M(`--en-color-surface-raised`)))};
		color: ${N(`--en-option-list-color`,N(`--en-overlay-color`,M(`--en-color-text`)))};
		box-shadow: ${N(`--en-option-list-shadow`,M(`--en-shadow-overlay`))};
		font: ${M(`--en-font-input-weight`)} ${M(`--en-font-input-size`)}/${M(`--en-font-input-line-height`)} ${M(`--en-font-input-family`)}; font-style: ${M(`--en-font-input-style`)}; letter-spacing: ${M(`--en-font-input-tracking`)};
		text-align: start;
		overflow: auto;
		overscroll-behavior: contain;
	}
  .en-combobox-popup[hidden], .en-combobox-popup[popover]:not(:popover-open) { display: none; }
  ${ci(_`.en-combobox-popup[popover]`,_`.en-combobox-popup:popover-open`,_`.en-combobox-popup[popover]:not(:popover-open)`,`fade`)}
	.en-combobox-popup[data-fallback] { visibility: visible; position: static; inline-size: 100%; }
	.en-combobox-listbox { margin: 0; padding: 0; list-style: none; }
	/* Adjacent spacing leaves native list flow and popup display ownership intact. */
	.en-combobox-option + .en-combobox-option { margin-block-start: ${N(`--en-option-list-gap`,_`0px`)}; }
	.en-combobox-option {
		position: relative;
		display: flex;
		align-items: center;
		gap: ${M(`--en-space-icon-label`)};
		box-sizing: border-box;
		min-inline-size: 0;
		min-block-size: ${U()};
		padding: ${N(`--en-option-block-padding`,M(`--en-space-control-block`))} ${N(`--en-option-inline-padding`,Ui)};
		border-radius: ${N(`--en-option-radius`,_`max(0px, ${Vi} - ${Hi} - ${M(`--en-border-width`)})`)};
		overflow-wrap: anywhere;
		cursor: pointer;
	}
	${Pn({base:_`.en-combobox-option`,selected:_`.en-combobox-option[aria-selected='true']`,hover:_`.en-combobox-option:not([aria-disabled='true']):hover`,active:_`.en-combobox-option:not([aria-disabled='true'])[data-active]`,pressed:_`.en-combobox-option:not([aria-disabled='true']):active`,disabled:_`.en-combobox-option[aria-disabled='true']`,restBackground:_`transparent`,restColor:N(`--en-option-list-color`,N(`--en-overlay-color`,M(`--en-color-text`))),selectedColor:N(`--en-option-list-color`,N(`--en-overlay-color`,M(`--en-color-text`))),hoverBackground:M(`--en-color-surface-subtle`)})}
	.en-combobox-option[data-active] { z-index: 1; }
	${L(_`.en-combobox-option[data-active]`,{family:`option`,inset:!0,restSelector:_`.en-combobox-option`})}
	.en-combobox-check { margin-inline-start: auto; visibility: hidden; }
	.en-combobox-option[aria-selected='true'] .en-combobox-check { visibility: inherit; }
	.en-combobox-option[aria-disabled='true'] { cursor: default; }
	.en-combobox-status { margin: 0; padding: ${M(`--en-space-control-block`)} ${Ui}; color: ${M(`--en-color-text-muted`)}; overflow-wrap: anywhere; }
	.en-combobox-status:empty { display: none; }
	/* An always-present, empty live region has no initial footprint. Once used,
	   retain its measured minimum through this open session to avoid layout loops. */
	.en-field > .en-combobox-space-status:not(:first-child) { margin: 0; }
	.en-combobox-space-status {
		min-block-size: var(--_en-combobox-space-reserve, 0px);
		padding: 0; font-size: ${M(`--en-font-ui-size`)}; line-height: ${M(`--en-font-body-line-height`)};
		color: ${M(`--en-color-text-muted`)}; overflow-wrap: anywhere;
	}
	.en-combobox-space-status:not(:empty) { padding-block-start: var(--_en-field-gap); }
	@media (any-pointer: coarse) {
		.en-combobox { --_en-combobox-trigger-size: ${U(!0)}; }
		.en-combobox-option { min-block-size: ${U(!0)}; }
	}
	@media (forced-colors: active) {
		.en-combobox-popup { color: CanvasText; background: Canvas; border-color: CanvasText; box-shadow: none; }
		.en-combobox-trigger { color: ButtonText; }
		.en-combobox-option { color: CanvasText; background: Canvas; }
		.en-combobox-option[aria-selected='true'] { color: HighlightText; background: Highlight; }
		.en-combobox-option[data-active] { outline-color: Highlight; }
		.en-combobox-option[aria-selected='true'][data-active] { outline-color: HighlightText; }
		.en-combobox-option[aria-disabled='true'], .en-combobox-trigger:disabled { color: GrayText; }
		.en-combobox-status, .en-combobox-space-status { color: CanvasText; }
	}
  ${P(_`.en-combobox-trigger`,_`.en-combobox-trigger:not(:disabled):not([data-press='none']):active`,V[`combobox-trigger`])}
`);function Gi(){let e=new k.State([]),t=new k.State(``),n=new k.State(!1),r=new k.State(void 0),i=new k.Computed(()=>e.get().map((e,t)=>({...e,id:`option-${t}`}))),a=new k.Computed(()=>{let e=t.get().toLowerCase();return i.get().filter(t=>t.label.toLowerCase().includes(e))}),o=new k.Computed(()=>a.get().find(e=>e.value===r.get()&&!e.disabled));return{items:new k.Computed(()=>e.get()),filtered:a,activeOption:o,open:new k.Computed(()=>n.get()),view:new k.Computed(()=>({options:a.get(),active:o.get(),open:n.get()})),setItems(t){e.set(t),o.get()||r.set(void 0)},setQuery(e){t.get()!==e&&(t.set(e),r.set(void 0))},show(){n.set(!0)},close(){n.set(!1),r.set(void 0)},activate(e){a.get().some(t=>t.value===e&&!t.disabled)&&r.set(e)},move(e){let t=a.get().filter(e=>!e.disabled);if(!t.length){r.set(void 0);return}let n=t.findIndex(e=>e.value===r.get()),i=n<0?e===1?0:t.length-1:Math.max(0,Math.min(t.length-1,n+e));r.set(t[i].value)}}}var Ki=class{host;options;abort;constructor(e,t){this.host=e,this.options=t,e.addController(this)}hostUpdated(){this.sync()}hostDisconnected(){this.abort?.abort(),this.abort=void 0}sync(){if(!this.options.open()||!this.host.isConnected){this.hostDisconnected();return}if(this.abort)return;let e=this.host.ownerDocument.defaultView?.AbortController??globalThis.AbortController;this.abort=new e;let t=[],n=this.host.getRootNode();for(;`host`in n;)t.push(n),n=n.host.getRootNode();[...t,this.host.ownerDocument].forEach((e,n)=>e.addEventListener(`pointerdown`,(e=>{let r=e.composedPath();r.includes(this.host)||t.slice(0,n).some(e=>r.includes(e.host))||this.options.exit()}),{signal:this.abort.signal,capture:!0}))}keydown=e=>{if(!(e.defaultPrevented||this.options.disabled()||e.isComposing||this.options.composing()||e.keyCode===229||e.altKey||e.ctrlKey||e.metaKey)){if(e.key===`ArrowDown`||e.key===`ArrowUp`)e.preventDefault(),this.options.open()||this.options.show(),this.options.move(e.key===`ArrowDown`?1:-1);else if(e.key===`Enter`&&(this.options.open()||this.options.dirty())){e.preventDefault();let t=this.options.active();this.options.open()&&t!==void 0&&!e.repeat&&this.options.choose(t)}else e.key===`Escape`&&(this.options.open()||this.options.dirty())?(e.preventDefault(),this.options.exit()):e.key===`Tab`&&this.options.exit()}};keepInputFocus=e=>{e.button===0&&e.preventDefault()};trigger=()=>{this.options.disabled()||this.options.composing()||(this.options.input()?.focus(),this.options.expanded()?this.options.exit():this.options.show())};optionClick=e=>{if(e.defaultPrevented||this.options.disabled()||this.options.composing())return;let t=e.currentTarget;if(t.getAttribute(`aria-disabled`)===`true`)return;let n=t.dataset.value;n!==void 0&&this.options.choose(n)};focusout=()=>{queueMicrotask(()=>{this.host.isConnected&&(this.host.shadowRoot?.activeElement||this.options.exit())})}},qi=class{view;abort;observer;frame=0;stopped=!1;active;measure;constructor(e,t,n,r){this.active=n,this.measure=r,this.view=e.ownerDocument.defaultView,this.abort=new this.view.AbortController;let i={signal:this.abort.signal,passive:!0};this.view.addEventListener(`resize`,this.schedule,i),this.view.addEventListener(`scroll`,this.schedule,{...i,capture:!0});let a=e.getRootNode();for(;`host`in a;)a.addEventListener(`scroll`,this.schedule,{...i,capture:!0}),a=a.host.getRootNode();this.view.visualViewport?.addEventListener(`resize`,this.schedule,i),this.view.visualViewport?.addEventListener(`scroll`,this.schedule,i),this.view.ResizeObserver&&(this.observer=new this.view.ResizeObserver(this.schedule),this.observer.observe(e),this.observer.observe(t))}schedule=()=>{this.frame||this.stopped||(this.frame=this.view.requestAnimationFrame(()=>{this.frame=0,!this.stopped&&this.active()&&this.measure()}))};stop(){this.stopped=!0,this.abort.abort(),this.observer?.disconnect(),this.frame&&this.view.cancelAnimationFrame(this.frame),this.frame=0}};function Ji(e,t,n){let r=parseFloat(e),i=Number.isFinite(r)?r-t:0;return n===void 0||Math.abs(i-n)>.5?i:n}function Yi(e,t,n){return{x:e.x+t,y:e.y+n,left:e.left+t,right:e.right+t,top:e.top+n,bottom:e.bottom+n,width:e.width,height:e.height}}function Xi(e){let t=e.visualViewport;return{top:t?.offsetTop??0,left:t?.offsetLeft??0,width:t?.width??e.innerWidth,height:t?.height??e.innerHeight}}function Zi(e,t,n,r){let i=Math.max(0,Math.min(t.height,t.top+t.height-e.bottom-n)),a=Math.max(0,Math.min(t.height,e.top-t.top-n));return{below:i,above:a,useAbove:r>i&&a>i}}function Qi({widthChanged:e,heightChanged:t,intersects:n,width:r,height:i,rowHeight:a,available:o,minimumHeight:s,popupHeight:c}){let l=!e&&!t&&n&&r>0&&i>0&&a>0&&o+.5>=s&&c+.5>=s,u=n&&r>0&&i>0&&(e||t&&o+.5>=s),d=l?`visible`:u?`pending`:`suspended`;return{presented:l,pending:u,state:d,reason:d===`suspended`?n?r<=0||i<=0||a<=0?`unmeasured`:`no-room`:`offscreen`:void 0}}var $i=class{host;options;connected=!1;anchor=null;popup=null;measurement;view;geometry=``;originX;originY;presented;reason;constructor(e,t){this.host=e,this.options=t,e.addController(this)}hostConnected(){this.connected=!0}hostDisconnected(){this.connected=!1,this.stop()}hostUpdated(){this.sync()}sync(){let e=this.options.anchor(),t=this.options.popup();if(!this.connected||!this.options.open()||!e||!t||typeof t.showPopover!=`function`||!t.matches(`:popover-open`)){this.stop(this.connected&&!this.options.open());return}if(e!==this.anchor||t!==this.popup){this.stop(),this.anchor=e,this.popup=t,t.style.setProperty(`--_en-combobox-visibility`,`hidden`);let n=e.ownerDocument.defaultView;if(!n)return;this.view=n,this.measurement=new qi(e,t,()=>this.connected&&this.options.open(),()=>this.position())}this.schedule()}schedule=()=>{this.measurement?.schedule()};position(){let e=this.anchor,t=this.popup,n=this.view;if(!e?.isConnected||!t?.isConnected||!n||typeof t.showPopover!=`function`||!t.matches(`:popover-open`))return;let r=e.getBoundingClientRect(),i=t.getBoundingClientRect(),a=i.height,o=t.scrollHeight+t.offsetHeight-t.clientHeight,s=n.getComputedStyle(t);this.originX=Ji(s.left,i.left,this.originX),this.originY=Ji(s.top,i.top,this.originY);let c=Yi(r,this.originX,this.originY),l=parseFloat(s.rowGap)||0,u=(t.querySelector(`[role="option"][data-active]`)??t.querySelector(`[role="option"]`)??t.querySelector(`[role="status"]`))?.getBoundingClientRect().height??0,d=u+[s.paddingTop,s.paddingBottom,s.borderTopWidth,s.borderBottomWidth].reduce((e,t)=>e+(parseFloat(t)||0),0),{top:f,left:p,width:m,height:h}=Xi(n),{below:ee,above:g,useAbove:_}=Zi(c,{top:f,height:h},l,o),v=_?g:ee,te=c.width>0&&c.height>0&&c.right>p&&c.left<p+m&&c.bottom>f&&c.top<f+h,y=`${Math.min(c.width,m)}px`,ne=t.style.getPropertyValue(`--_en-combobox-width`)!==y,re=t.style.getPropertyValue(`--_en-combobox-max-height`)!==`${v}px`,{presented:ie,state:ae,reason:oe}=Qi({widthChanged:ne,heightChanged:re,intersects:te,width:m,height:h,rowHeight:u,available:v,minimumHeight:d,popupHeight:a}),se=ae,ce={"--_en-combobox-x":`${Math.max(p,Math.min(c.left,p+m-Math.min(c.width,m)))}px`,"--_en-combobox-y":`${_?c.top-l-Math.min(a,v):c.bottom+l}px`,"--_en-combobox-width":y,"--_en-combobox-max-height":`${v}px`,"--_en-combobox-visibility":ie?`visible`:`hidden`};for(let[e,n]of Object.entries(ce))t.style.getPropertyValue(e)!==n&&t.style.setProperty(e,n);(ne||re)&&this.schedule(),this.setPresented(se,oe);let le=[c.x,c.y,c.width,c.height,a,...Object.values(ce)].join(`/`);le!==this.geometry&&(this.geometry=le,ie&&this.options.resized())}setPresented(e,t){(e!==this.presented||t!==this.reason)&&(this.presented=e,this.reason=t,this.options.presented(e,t))}stop(e=!1){e||this.popup?.style.setProperty(`--_en-combobox-visibility`,`hidden`),this.setPresented(`pending`),this.presented=void 0,this.reason=void 0,this.measurement?.stop(),this.measurement=void 0,this.view=void 0,this.anchor=null,this.popup=null,this.geometry=``,this.originX=void 0,this.originY=void 0}},ea=class{host;options;connected=!1;state=`clear`;shown=!1;timer;timerView;generation=0;reserved=0;region=null;constructor(e,t){this.host=e,this.options=t,e.addController(this)}get visible(){return this.shown}hostConnected(){this.connected=!0}hostDisconnected(){this.connected=!1,this.reset()}hostUpdated(){this.sync()}update(e){this.state=e,this.sync()}sync(){if(!this.connected||!this.options.enabled()){this.reset();return}let e=this.options.region();if(e!==this.region&&(this.region?.style.removeProperty(`--_en-combobox-space-reserve`),this.region=e),e&&this.shown){let t=e.getBoundingClientRect().height;t>this.reserved&&(this.reserved=t)}if(e&&this.reserved>0){let t=`${this.reserved}px`;e.style.getPropertyValue(`--_en-combobox-space-reserve`)!==t&&e.style.setProperty(`--_en-combobox-space-reserve`,t)}if(this.state===`clear`){this.cancelTimer(),this.show(!1);return}if(this.state===`pending`){this.cancelTimer();return}if(this.shown)return;if(this.options.composing()){this.cancelTimer();return}if(this.timer!==void 0)return;let t=this.host.ownerDocument.defaultView;if(!t)return;let n=this.generation;this.timerView=t,this.timer=t.setTimeout(()=>{this.timer=void 0,this.timerView=void 0,n===this.generation&&this.connected&&this.options.enabled()&&this.state===`no-room`&&!this.options.composing()&&this.show(!0)},700)}reset(){this.state=`clear`,this.cancelTimer(),this.show(!1),this.region?.style.removeProperty(`--_en-combobox-space-reserve`),this.region=null,this.reserved=0}show(e){this.shown!==e&&(this.shown=e,this.host.requestUpdate())}cancelTimer(){++this.generation,this.timer!==void 0&&this.timerView?.clearTimeout(this.timer),this.timer=void 0,this.timerView=void 0}};function ta(e,t){return S`<div class="en-field" part="field" ?data-invalid=${!!e.error}>
    <label id="control-label" class="en-label" part="label" for="control"><slot name="label">${e.label||T}</slot></label>
    <div class="en-combobox" @focusout=${t.focusout}>
    <div class="en-combobox-anchor en-field-focus-frame" part="focus-frame">
    <input id="control" class="en-input en-text-input en-combobox-input" part="control" type="text"
      role="combobox" aria-autocomplete="list" aria-haspopup="listbox" aria-expanded=${String(e.expanded)}
      aria-controls="listbox" aria-activedescendant=${e.expanded&&!e.blocked?e.active?.id??T:T}
      aria-describedby=${e.describedBy} aria-invalid=${e.invalid} aria-required=${String(e.required)}
      autocomplete=${e.autocomplete} value=${e.defaultValue} placeholder=${e.placeholder||T}
      ?disabled=${e.disabled} ?readonly=${e.readOnly}
      @keydown=${t.keydown} @input=${t.input}>
    <button class="en-combobox-trigger" part="trigger" type="button" tabindex="-1" aria-label=${e.toggleLabel}
      aria-haspopup="listbox" aria-expanded=${String(e.expanded)} aria-controls="listbox"
      ?disabled=${e.disabled||e.readOnly} @mousedown=${t.keepInputFocus} @click=${t.trigger}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m6 9 6 6 6-6"></path></svg>
    </button>
    </div>
    <div class="en-combobox-popup" part="popup" inert @beforetoggle=${Bi} popover=${e.fallback?T:`manual`} ?data-fallback=${e.fallback} ?hidden=${e.fallback&&!e.open}>
      <div id="listbox" class="en-combobox-listbox" part="listbox" role="listbox" aria-labelledby="control-label" aria-busy=${String(e.loading)}>
        ${_r(e.options,e=>e.value,n=>S`<div id=${n.id} class="en-combobox-option"
          part=${`option${n.value===e.selectedValue?` option-selected`:``}${!e.blocked&&n.value===e.active?.value?` option-active`:``}${n.disabled||e.blocked?` option-disabled`:``}`}
          role="option" aria-selected=${String(n.value===e.selectedValue)} aria-disabled=${String(!!(n.disabled||e.blocked))}
          ?data-active=${!e.blocked&&n.value===e.active?.value} data-value=${n.value}
          @mousedown=${t.keepInputFocus} @click=${t.optionClick}>
          <span part="option-label">${n.label}</span>
          <svg class="en-combobox-check" part="option-indicator" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m5 12 4 4L19 6"></path></svg>
        </div>`)}
      </div>
      <p class="en-combobox-status" part="status" role="status" aria-live="polite" aria-atomic="true">${e.status||T}</p>
    </div>
    </div>
    <p class="en-combobox-space-status" part="space-status" role="status" aria-live="polite" aria-atomic="true">${e.spaceStatus||T}</p>
    ${Oi(e.description)}
    ${e.error?S`<div class="en-error" part="error" id="error">${e.error}</div>`:T}
  </div>`}var na={tagName:`en-combobox`,elementClass:class extends q{static styles=[...q.styles,Wi];static properties={...q.properties,items:{attribute:!1,noAccessor:!0},readOnly:{type:Boolean,attribute:`readonly`,reflect:!0},autocomplete:{},loading:{type:Boolean},loadError:{attribute:`load-error`},toggleLabel:{attribute:`toggle-label`},emptyText:{attribute:`empty-text`},loadingText:{attribute:`loading-text`},validationText:{attribute:`validation-text`},noRoomText:{attribute:`no-room-text`}};query=Ni();optionsModel=Gi();observer=new j(this,()=>[this.query.view.get(),this.optionsModel.view.get()]);editing=new Mi(this,{model:this.query,control:()=>this.input,onInput:e=>this.onQueryInput(e)});interaction=new Ki(this,{input:()=>this.input,disabled:()=>this.isDisabled||this.readOnly,composing:()=>this.query.isComposing.get(),dirty:()=>this.query.draft.get()!==this.acceptedLabel,open:()=>this.optionsModel.open.get(),active:()=>this.suggestionsBlocked||!this.fallback&&!this.popupPresented?void 0:this.optionsModel.activeOption.get()?.value,expanded:()=>this.optionsModel.open.get()&&(this.fallback||this.popupPresented),show:()=>this.showOptions(),exit:()=>this.restoreLabel(),move:e=>{!this.suggestionsBlocked&&!this.popupSuspended&&this.optionsModel.move(e)},choose:e=>this.chooseOption(e)});spaceFeedback=new ea(this,{enabled:()=>this.optionsModel.open.get()&&!this.fallback&&!this.isDisabled&&!this.readOnly,composing:()=>this.query.isComposing.get(),region:()=>this.renderRoot?.querySelector(`[part="space-status"]`)??null});positioning=new $i(this,{anchor:()=>this.input,popup:()=>this.popup,open:()=>this.optionsModel.open.get()&&!this.fallback,resized:()=>this.revealActiveOption(),presented:(e,t)=>{this.spaceFeedback.update(e===`pending`?`pending`:t===`no-room`?`no-room`:`clear`);let n=e===`visible`,r=e===`suspended`;(n!==this.popupPresented||r!==this.popupSuspended)&&(this.popupPresented=n,this.popupSuspended=r,this.requestUpdate())}});revision=0;selectionDepth=0;queryValue=``;initialLabel;knownLabel=``;knownValue=``;fallback=!1;popupPresented=!1;popupSuspended=!1;activeId;constructor(){super(),this.readOnly=!1,this.autocomplete=`off`,this.loading=!1,this.loadError=``,this.toggleLabel=`Show options`,this.emptyText=`No matching options.`,this.loadingText=`Loading options.`,this.validationText=`Choose an option from the list.`,this.noRoomText=`Suggestions cannot be shown in the available space.`}get items(){return this.optionsModel?.items.get()??[]}set items(e){let t=this.items,n=this.selectionDepth>0&&this.value!==this.queryValue||(this.query?this.query.draft.get()!==this.acceptedLabel:!1);this.optionsModel?.setItems(e),this.rememberLabel(),n||this.query?.setValue(this.acceptedLabel),this.editing?.sync(),this.syncForm(),this.requestUpdate(`items`,t)}get value(){return super.value}set value(e){++this.revision,super.value=e,this.rememberLabel(),this.restoreLabel()}get input(){return this.controlNode}get popup(){return this.renderRoot?.querySelector(`[part="popup"]`)??null}get suggestionsBlocked(){return this.loading||!!this.loadError}get acceptedLabel(){return this.items.find(e=>e.value===this.value)?.label??(this.knownValue===this.value?this.knownLabel:``)}rememberLabel(){let e=this.items.find(e=>e.value===this.value);e?(this.knownLabel=e.label,this.knownValue=e.value):this.knownValue!==this.value&&(this.knownValue=this.value,this.knownLabel=``)}get defaultControlValue(){return this.initialLabel??this.acceptedLabel}reconcile(){this.editing?.sync()}select(){this.input?.select()}willUpdate(e){super.willUpdate(e),this.initialLabel===void 0&&(this.rememberLabel(),this.initialLabel=this.acceptedLabel,this.query.setValue(this.acceptedLabel),this.queryValue=this.value),(e.has(`disabled`)||e.has(`readOnly`))&&(this.isDisabled||this.readOnly)&&this.restoreLabel()}onQueryInput(e){this.isDisabled||this.readOnly||this.query.hasDeferredValue.get()||(this.query.isComposing.get()||(this.optionsModel.setQuery(this.query.view.get().dirty?this.query.draft.get():``),e.inputType!==`hydrate`&&this.query.view.get().dirty&&this.shadowRoot?.activeElement===this.input&&this.optionsModel.show()),this.syncForm())}captureQuery=e=>{e.isComposing&&!this.query.isComposing.get()&&this.query.startComposition(),this.query.setDraft(e.currentTarget.value),this.syncForm()};showOptions(){this.isDisabled||this.readOnly||this.query.isComposing.get()||(this.optionsModel.open.get()||(this.popupSuspended=!1),this.optionsModel.setQuery(this.query.draft.get()===this.acceptedLabel?``:this.query.draft.get()),this.optionsModel.show(),this.requestUpdate())}restoreLabel(){this.spaceFeedback?.reset(),this.popupPresented=!1,this.popupSuspended=!1,this.optionsModel?.close(),this.query?.setValue(this.acceptedLabel),this.queryValue=this.value,this.optionsModel?.setQuery(``),this.editing?.sync(),this.syncForm(),this.requestUpdate()}chooseOption(e){if(this.isDisabled||this.readOnly||this.suggestionsBlocked||this.query.isComposing.get()||!this.fallback&&!this.popupPresented||!this.optionsModel.filtered.get().find(t=>t.value===e&&!t.disabled))return;this.optionsModel.activate(e);let t=this.knownLabel,n=this.knownValue;++this.selectionDepth;try{A(this,{previous:this.value,proposed:e,reason:`select`,getRevision:()=>this.revision,stage:e=>this.stageValue(e),rollback:e=>{this.knownLabel=t,this.knownValue=n,this.stageValue(e),this.rememberLabel()},canCommit:e=>!this.isDisabled&&!this.readOnly&&!this.suggestionsBlocked&&!this.query.isComposing.get()&&this.items.some(t=>t.value===e&&!t.disabled),commit:()=>{this.rememberLabel(),this.restoreLabel()}})===`unchanged`&&this.selectionDepth===1&&this.restoreLabel()}finally{--this.selectionDepth,this.syncForm()}}validateAcceptedValue(){let e=this.input;if(!e)return{flags:{}};let t=this.items.find(e=>e.value===this.value),n=this.required&&this.value===``,r=this.value!==``&&!t||!!t?.disabled,i=this.selectionDepth===0&&this.query.draft.get()!==this.acceptedLabel,a=this.error||(n||r||i?this.validationText||`Choose an option from the list.`:``),o={valueMissing:n,customError:!!(this.error||r||i)};return e.setCustomValidity(a),{flags:o,message:a,anchor:e}}formResetCallback(){super.formResetCallback(),this.restoreLabel()}formStateRestoreCallback(e,t){super.formStateRestoreCallback(e,t),typeof e==`string`&&this.restoreLabel()}formDisabledCallback(e){super.formDisabledCallback(e),this.isDisabled&&this.restoreLabel()}disconnectedCallback(){this.restoreLabel(),super.disconnectedCallback()}syncPopup(){let e=this.popup;if(e&&this.isConnected){if(this.fallback){Y(e,this.optionsModel.open.get());return}if(typeof e.showPopover!=`function`){this.fallback=!0,this.requestUpdate();return}try{this.optionsModel.open.get()?(Y(e,!0),e.matches(`:popover-open`)||e.showPopover()):(e.matches(`:popover-open`)&&e.hidePopover(),Y(e,!1))}catch{this.fallback=!0,this.requestUpdate()}}}updated(e){super.updated(e),this.syncPopup(),this.interaction.sync(),this.positioning.sync();let t=this.optionsModel.open.get()&&!this.suggestionsBlocked?this.optionsModel.activeOption.get():void 0;t?.id!==this.activeId&&(this.activeId=t?.id,this.revealActiveOption())}revealActiveOption(){let e=this.optionsModel.open.get()&&!this.suggestionsBlocked?this.optionsModel.activeOption.get():void 0,t=e?this.renderRoot.querySelector(`#${e.id}`):null,n=this.popup;if(t&&n&&(this.fallback||this.popupPresented)){let e=t.getBoundingClientRect(),r=n.getBoundingClientRect().top+n.clientTop,i=r+n.clientHeight;e.top<r?n.scrollTop-=r-e.top:e.bottom>i&&(n.scrollTop+=e.bottom-i)}}renderControl(){let e=this.optionsModel.view.get();return ta({label:this.label,description:this.description,error:this.visibleError,defaultValue:this.defaultControlValue,placeholder:this.placeholder,autocomplete:this.autocomplete,disabled:this.isDisabled,readOnly:this.readOnly,required:this.required,describedBy:this.describedBy,invalid:this.controlAriaInvalid,open:e.open,expanded:e.open&&(this.fallback||this.popupPresented),fallback:this.fallback,loading:this.loading,blocked:this.suggestionsBlocked,selectedValue:this.value,active:e.active,options:this.suggestionsBlocked?[]:e.options,toggleLabel:this.toggleLabel,spaceStatus:this.spaceFeedback.visible?this.noRoomText:``,status:this.loading?this.loadingText:this.loadError||(e.options.length?``:this.emptyText)},{keydown:this.interaction.keydown,keepInputFocus:this.interaction.keepInputFocus,trigger:this.interaction.trigger,optionClick:this.interaction.optionClick,focusout:this.interaction.focusout,input:this.captureQuery})}render(){return this.renderControl()}}};n(customElements,na);var ra=N(`--en-option-list-radius`,N(`--en-overlay-radius`,M(`--en-radius-container`))),ia=_`max(${N(`--en-option-list-padding`,N(`--en-overlay-padding`,M(`--en-space-1`)))}, ${F({family:`option`,inset:!0})})`,aa=N(`--en-option-list-color`,N(`--en-overlay-color`,M(`--en-color-text`))),oa=N(`--en-option-list-background`,N(`--en-overlay-background`,M(`--en-color-surface-raised`))),sa=N(`--en-option-list-gap`,_`0px`),ca=N(`--en-option-radius`,_`max(0px, ${ra} - ${ia} - ${M(`--en-border-width`)})`);function la(e,t=ca){return _`
    ${e} {
      position: relative;
      display: flex;
      align-items: center;
      gap: ${M(`--en-space-icon-label`)};
      box-sizing: border-box;
      min-inline-size: ${M(`--en-size-target-min`)};
      min-block-size: ${U()};
      max-inline-size: 100%;
      inline-size: 100%;
      margin: 0;
      padding: ${N(`--en-option-block-padding`,M(`--en-space-control-block`))} ${N(`--en-option-inline-padding`,M(`--en-space-control-inline`))};
      border: 0;
      border-radius: ${t};
      font: inherit;
      text-align: start;
      white-space: normal;
      overflow-wrap: anywhere;
      cursor: pointer;
    }
    @media (any-pointer: coarse) {
      ${e} { min-block-size: ${U(!0)}; }
    }
  `}function ua(e,t){return Pn({base:e,hover:_`${e}:not([aria-disabled='true']):hover`,active:t,pressed:_`${e}:not([aria-disabled='true']):active`,disabled:_`${e}[aria-disabled='true']`,restBackground:_`transparent`,restColor:aa,hoverBackground:M(`--en-color-surface-subtle`)})}function da(e,t){return _`
    ${e} { z-index: 1; }
    ${L(e,{family:`option`,inset:!0,restSelector:t})}
    @media (forced-colors: active) {
      ${e} { outline-color: HighlightText; background: Highlight; color: HighlightText; }
    }
  `}var fa=R(_`
  .en-menu {
    position: fixed;
    inset: auto;
    left: var(--_en-menu-x, 0px);
    top: var(--_en-menu-y, 0px);
    visibility: var(--_en-menu-visibility, hidden);
    display: flex;
    flex-direction: column;
    gap: ${sa};
    box-sizing: border-box;
    margin: 0;
    inline-size: max-content;
    min-inline-size: min(${M(`--en-layout-panel-preferred`)}, ${N(`--en-overlay-max-inline-size`,M(`--en-layout-form-max`))}, var(--_en-menu-viewport-width, calc(100dvw - ${M(`--en-space-4`)})));
    max-inline-size: min(${N(`--en-overlay-max-inline-size`,M(`--en-layout-form-max`))}, var(--_en-menu-viewport-width, calc(100dvw - ${M(`--en-space-4`)})));
    max-block-size: min(var(--_en-menu-max-height, calc(100dvh - ${M(`--en-space-8`)})), ${N(`--en-option-list-max-block-size`,N(`--en-overlay-max-block-size`,M(`--en-layout-panel-preferred`)))});
    padding: ${ia};
    border: ${M(`--en-border-width`)} solid ${N(`--en-option-list-border-color`,N(`--en-overlay-border-color`,M(`--en-color-boundary`)))};
    border-radius: ${ra};
    background: ${oa};
    color: ${aa};
    box-shadow: ${N(`--en-option-list-shadow`,M(`--en-shadow-overlay`))};
    font: inherit;
    text-align: start;
    overflow: auto;
    overscroll-behavior: contain;
    scroll-behavior: auto;
  }
  ${ci(_`.en-menu[popover]`,_`.en-menu:popover-open`,_`.en-menu[popover]:not(:popover-open)`,`elevation`)}
  .en-menu > slot { display: contents; }
  ::slotted(hr[role='separator']) { inline-size: 100%; box-sizing: border-box; border: 0; border-block-start: ${M(`--en-border-width`)} solid ${M(`--en-color-line`)}; margin-block: ${M(`--en-space-1`)}; margin-inline: 0; }
  .en-menu[data-replaced] { background: transparent; border-color: transparent; box-shadow: none; pointer-events: none; }
  .en-menu[data-replaced] > .en-menu-back,
  .en-menu[data-replaced] > slot::slotted(:not(en-menu)) { visibility: hidden; }
  .en-menu[data-replaced] > slot::slotted(en-menu) { pointer-events: auto; }
  .en-menu[data-replacement] { inline-size: var(--_en-menu-replacement-width); min-inline-size: 0; pointer-events: auto; }
  ${la(_`.en-menu-back`)}
  ${ua(_`.en-menu-back`,_`.en-menu-back:focus`)}
  .en-menu-back { appearance: none; text-align: start; }
  .en-menu-back-icon { inline-size: 1em; block-size: 1em; flex: 0 0 auto; transform: rotate(90deg); }
  :host(:dir(rtl)) .en-menu-back-icon { transform: rotate(-90deg); }
  ${da(_`.en-menu-back:focus`,_`.en-menu-back`)}
  .en-menu[popover]:not(:popover-open), .en-menu[hidden] { display: none; }
  ${L(_`.en-menu:focus`,{family:`overlay`,inset:!0,restSelector:_`.en-menu`,baseShadow:N(`--en-option-list-shadow`,M(`--en-shadow-overlay`)),baseTransitions:si})}
  @media (forced-colors: active) {
    .en-menu { color: CanvasText; background: Canvas; border-color: CanvasText; box-shadow: none; }
    .en-menu:focus { outline-color: Highlight; }
  }
`),pa=R(_`
  :host(:focus-within) { position: relative; z-index: 1; }
  ${la(_`.en-menu-item`)}
  ${ua(_`.en-menu-item`,_`.en-menu-item:not([aria-disabled='true']):focus`)}
  .en-menu-item { appearance: none; }
  .en-menu-item-check, .en-menu-item-submenu { display: inline-flex; flex: 0 0 auto; inline-size: 1em; block-size: 1em; }
  .en-menu-item-check svg, .en-menu-item-submenu svg { inline-size: 100%; block-size: 100%; }
  .en-menu-item-submenu { transform: rotate(-90deg); }
  :host(:dir(rtl)) .en-menu-item-submenu { transform: rotate(90deg); }
  .en-menu-item-label { flex: 1 1 auto; min-inline-size: 0; }
  .en-menu-item-prefix, .en-menu-item-suffix, .en-menu-item-shortcut { display: contents; }
  .en-menu-item-shortcut { font-family: ${M(`--en-font-code-family`)}; }
  ::slotted([slot='shortcut']) { margin-inline-start: auto; }
  .en-menu-item[aria-disabled='true'] { cursor: default; }
  @media (forced-colors: active) {
    .en-menu-item { color: CanvasText; background: Canvas; }
    .en-menu-item[aria-disabled='true'] { color: GrayText; }
  }
  ${da(_`.en-menu-item:focus`,_`.en-menu-item`)}
  @media (forced-colors: active) {
    .en-menu-item[aria-disabled='true']:focus { color: GrayText; background: Canvas; outline-color: CanvasText; }
  }
`),ma=R(_`
  .en-toolbar {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: ${M(`--en-space-actions`)};
    min-inline-size: 0;
    max-inline-size: 100%;
  }
  .en-toolbar > slot { display: contents; }
  .en-toolbar[aria-orientation='vertical'], .en-toolbar[data-orientation='vertical'] {
    flex-direction: column;
    align-items: stretch;
  }
  .en-toolbar > :not(slot) { min-inline-size: 0; max-inline-size: 100%; }
  .en-toolbar > slot::slotted(*) { min-inline-size: 0; max-inline-size: 100%; }
`),ha=R(_`
  .en-command-palette {
    position: fixed;
    inset: auto;
    left: calc(var(--_en-command-viewport-left, 0px) + var(--_en-command-viewport-width, 100dvw) / 2);
    top: calc(var(--_en-command-viewport-top, 0px) + var(--_en-command-viewport-height, 100dvh) / 2);
    transform: translate(-50%, -50%);
    /* Individual scale composes outside the centering transform. The layout
       origin is already the viewport center; scaling around it avoids drift. */
    transform-origin: 0 0;
    margin: 0;
    inline-size: min(${N(`--en-overlay-max-inline-size`,M(`--en-layout-form-max`))}, max(0px, calc(var(--_en-command-viewport-width, 100dvw) - ${M(`--en-space-8`)})));
    max-inline-size: max(0px, calc(var(--_en-command-viewport-width, 100dvw) - ${M(`--en-space-8`)}));
    max-block-size: min(${N(`--en-overlay-max-block-size`,_`100dvh`)}, max(0px, calc(var(--_en-command-viewport-height, 100dvh) - ${M(`--en-space-8`)})));
    /* At exceptionally short viewports, retain outer scroll reachability rather
       than clipping the query/close controls to preserve a fixed composition. */
    overflow: auto;
    scroll-behavior: auto;
  }
  .en-command-palette > .en-overlay-header, .en-command-palette > .en-overlay-footer { flex: none; }
  .en-command-palette > .en-overlay-body { display: flex; min-block-size: 0; overflow: visible; }
  .en-command-palette-content {
    display: flex;
    flex-direction: column;
    flex: 1 1 auto;
    min-inline-size: 0;
    min-block-size: 0;
    gap: ${M(`--en-space-label-control`)};
  }
  .en-command-palette-content > slot { display: contents; }
  .en-command-palette-content > .en-label {
    flex: none;
    color: ${M(`--en-color-text`)};
    font-weight: ${M(`--en-font-label-strong-weight`)};
    overflow-wrap: anywhere;
  }
  .en-command-palette-content > .en-field-focus-frame { flex: none; }
  .en-command-palette-input { flex: none; inline-size: 100%; }
  .en-command-list {
    display: flex;
    flex-direction: column;
    flex: 1 1 auto;
    gap: ${sa};
    box-sizing: border-box;
    min-inline-size: 0;
    min-block-size: 0;
    max-block-size: ${N(`--en-option-list-max-block-size`,M(`--en-layout-panel-preferred`))};
    margin: 0;
    padding: ${ia};
    border: 0;
    border-radius: ${ra};
    background: ${oa};
    color: ${aa};
    overflow: auto;
    overscroll-behavior: contain;
    scroll-behavior: auto;
  }
  .en-command-list:empty { display: none; }
  ${la(_`.en-command-option`,N(`--en-option-radius`,_`max(0px, ${ra} - ${ia})`))}
  .en-command-option { flex: none; }
  ${ua(_`.en-command-option`,_`.en-command-option:not([aria-disabled='true'])[data-active]`)}
  .en-command-label { flex: 1 1 auto; min-inline-size: 0; }
  .en-command-shortcut { flex: 0 1 auto; min-inline-size: 0; margin-inline-start: auto; font-family: ${M(`--en-font-code-family`)}; }
  .en-command-shortcut:empty { display: none; }
  .en-command-option[aria-disabled='true'] { cursor: default; }
  .en-command-status { flex: none; margin: 0; color: ${M(`--en-color-text-muted`)}; line-height: ${M(`--en-font-body-line-height`)}; overflow-wrap: anywhere; }
  .en-command-status:empty { display: none; }
  @media (forced-colors: active) {
    .en-command-list, .en-command-option { color: CanvasText; background: Canvas; }
    .en-command-status { color: CanvasText; }
    .en-command-option[aria-disabled='true'] { color: GrayText; }
  }
  ${da(_`.en-command-option:not([aria-disabled='true'])[data-active]`,_`.en-command-option`)}
`),ga=`(width < ${_n(`--en-layout-dialog-collapse`)})`,_a=R(_`
  .en-dialog, .en-drawer, .en-popover, .en-tooltip {
    box-sizing: border-box;
    min-inline-size: 0;
    max-inline-size: min(${N(`--en-overlay-max-inline-size`,M(`--en-layout-form-max`))}, calc(100% - ${M(`--en-space-8`)}));
    max-block-size: ${N(`--en-overlay-max-block-size`,_`calc(100dvh - ${M(`--en-space-8`)})`)};
    padding: ${N(`--en-overlay-padding`,M(`--en-space-panel`))};
    border: ${M(`--en-border-width`)} solid ${N(`--en-overlay-border-color`,M(`--en-color-boundary`))};
    border-radius: ${N(`--en-overlay-radius`,M(`--en-radius-dialog`))};
    background: ${N(`--en-overlay-background`,M(`--en-color-surface-raised`))};
    color: ${N(`--en-overlay-color`,M(`--en-color-text`))};
    font: inherit;
    text-align: start;
    overflow: auto;
    box-shadow: ${M(`--en-shadow-overlay`)};
  }
  ${ci(_`.en-popover[popover]`,_`.en-popover:popover-open`,_`.en-popover[popover]:not(:popover-open)`,`fade`)}
  ${ci(_`.en-tooltip[popover]`,_`.en-tooltip:popover-open`,_`.en-tooltip[popover]:not(:popover-open)`,`fade`)}
  ${li}
  .en-dialog { position: fixed; inset: 0; margin: auto; box-shadow: ${M(`--en-shadow-dialog`)}; }
  dialog.en-dialog, dialog.en-drawer { flex-direction: column; gap: ${M(`--en-space-4`)}; }
  dialog.en-dialog[open], dialog.en-drawer[open] { display: flex; }
  dialog.en-dialog:not([open]), dialog.en-drawer:not([open]) { display: none; }
  .en-dialog::backdrop, .en-drawer::backdrop { background: ${M(`--en-color-scrim`)}; }
  .en-overlay-header, .en-overlay-footer { display: flex; align-items: center; flex-wrap: wrap; gap: ${M(`--en-space-3`)}; min-inline-size: 0; }
  .en-overlay-header { justify-content: space-between; }
  .en-overlay-footer { justify-content: flex-end; gap: ${M(`--en-space-actions`)}; }
  .en-overlay-header > slot, .en-overlay-footer > slot { display: contents; }
  .en-overlay-body {
    --_en-overlay-focus-clearance: ${kn};
    min-inline-size: 0;
    min-block-size: 0;
    /* Expand the scrollport without moving content or changing the surrounding gaps. */
    margin: calc(0px - var(--_en-overlay-focus-clearance));
    padding: var(--_en-overlay-focus-clearance);
    scroll-padding: var(--_en-overlay-focus-clearance);
    overflow: auto;
  }
  .en-overlay-close { margin-inline-start: auto; }
  .en-popover { position: fixed; display: flex; flex-direction: column; margin: 0; row-gap: ${M(`--en-space-4`)}; border-radius: ${N(`--en-overlay-radius`,M(`--en-radius-container`))}; }
  [popover].en-popover:not(:popover-open), [popover].en-tooltip:not(:popover-open) { display: none; }
  .en-tooltip { position: fixed; inline-size: max-content; margin: 0; row-gap: ${M(`--en-space-2`)}; padding: ${N(`--en-overlay-padding`,M(`--en-space-2`))}; border-radius: ${N(`--en-overlay-radius`,M(`--en-radius-control`))}; overflow-wrap: break-word; }
  .en-overlay-content { display:contents; }
  [data-arrow].en-popover, [data-arrow].en-tooltip { overflow:visible; padding:0; }
  [data-arrow] > .en-overlay-content {
    display:flex; flex-direction:column; gap:inherit; min-block-size:0; min-inline-size:0;
    max-block-size:inherit; box-sizing:border-box; overflow:auto; border-radius:inherit;
    padding:${N(`--en-overlay-padding`,M(`--en-space-panel`))};
  }
  .en-tooltip[data-arrow] > .en-overlay-content { display:block; padding:${N(`--en-overlay-padding`,M(`--en-space-2`))}; }
  .en-overlay-arrow {
    position:absolute; width:calc(2 * ${N(`--en-overlay-arrow-size`,M(`--en-space-2`))});
    height:${N(`--en-overlay-arrow-size`,M(`--en-space-2`))};
    overflow:visible; pointer-events:none; visibility:hidden; transform-origin:50% 0;
    fill:${N(`--en-overlay-background`,M(`--en-color-surface-raised`))};
    stroke:${N(`--en-overlay-border-color`,M(`--en-color-boundary`))}; stroke-width:${M(`--en-border-width`)};
  }
  @media (forced-colors:active) { .en-overlay-arrow { fill:Canvas; stroke:CanvasText; } }
  /* An outside separator is clipped at viewport-flush edges, even for a drawer
     that fills the whole viewport. Keep it separate from the immediate focus cue. */
  :where(.en-drawer) { outline: ${M(`--en-border-width`)} solid ${N(`--en-overlay-border-color`,M(`--en-color-boundary`))}; outline-offset: 0; }
  ${I(_`:where(.en-dialog, .en-drawer)`,{family:`overlay`,baseShadow:M(`--en-shadow-dialog`),baseTransitions:si})}
  ${I(_`.en-popover`,{family:`overlay`,baseShadow:M(`--en-shadow-overlay`),baseTransitions:si})}
  .en-drawer {
    position: fixed;
    margin: 0;
    inset: auto;
    inset-block: 0;
    inset-inline-end: 0;
    inline-size: min(${N(`--en-overlay-max-inline-size`,M(`--en-layout-form-max`))}, 100%);
    max-inline-size: 100%;
    block-size: 100%;
    max-block-size: 100%;
    border-radius: 0;
    border-width: 0;
    box-shadow: ${M(`--en-shadow-dialog`)};
  }
  .en-drawer[data-placement='start'] { inset-inline-end: auto; inset-inline-start: 0; }
  .en-drawer[data-placement='left'] { inset-inline: auto; left: 0; right: auto; }
  .en-drawer[data-placement='right'] { inset-inline: auto; left: auto; right: 0; }
  .en-drawer[data-placement='top'], .en-drawer[data-placement='bottom'] { inset-inline: 0; inline-size: 100%; block-size: auto; max-block-size: ${N(`--en-overlay-max-block-size`,_`calc(100dvh - ${M(`--en-space-8`)})`)}; }
  .en-drawer[data-placement='top'] { inset-block-start: 0; inset-block-end: auto; }
  .en-drawer[data-placement='bottom'] { inset-block-start: auto; inset-block-end: 0; }
  @media (forced-colors: active) {
    .en-dialog, .en-drawer, .en-popover, .en-tooltip { color: CanvasText; background: Canvas; border-color: CanvasText; box-shadow: none; }
    :where(.en-drawer) { outline-color: CanvasText; }
    :where(.en-dialog, .en-drawer, .en-popover):focus-visible { outline-color: Highlight; }
  }
`);function va(e){return S`
    <dialog class=${e.surfaceClass} part=${e.surfacePart??`surface`} data-placement=${e.placement}
      role=${e.kind??`dialog`} aria-describedby=${e.description?`en-overlay-description`:T}
      aria-labelledby="en-overlay-heading" closedby=${e.closedBy}
      inert @beforetoggle=${Bi} @cancel=${e.cancel} @close=${e.close}
      @pointerdown=${e.pointerDown} @pointerup=${e.pointerUp}
      @pointercancel=${e.pointerCancel} @keydown=${e.keyDown}>
      <div class="en-overlay-header" part="header">
        <h2 class="en-heading-small" id="en-overlay-heading" part="heading"><slot name="label">${e.label}</slot></h2>
        ${e.dismissible?S`
          <en-button class="en-overlay-close" variant="ghost" icon-only size="inherit"
            exportparts="control:close" @click=${e.dismiss}>
            <en-icon slot="prefix" name="close" size="inherit"></en-icon>
            <span slot="label">${e.closeLabel}</span>
          </en-button>
        `:null}
      </div>
      ${e.description?S`<p id="en-overlay-description" part="description">${e.description}</p>`:T}
      <div class="en-overlay-body" part="body">${e.body??S`<slot></slot>`}</div>
      ${e.footer===T?T:S`<div class="en-overlay-footer" part="footer">${e.footer??S`<slot name="footer"></slot>`}</div>`}
    </dialog>`}function ya(e,t,n){return!(!e.isConnected||!n?.isConnected||J(e)?.getElementById(t)!==n||n.disabled||n.loading||n.matches(`:disabled,[aria-disabled="true"]`))}function ba(e,t){return e?.defaultPrevented||!t?!1:(e?.preventDefault(),!0)}var xa=class{host;options;#e=null;#t=``;#n;#r=null;#i={};#a={};constructor(e,t){this.host=e,this.options=t,e.addController(this)}hostConnected(){this.hostUpdated()}hostUpdated(){if(!this.host.isConnected)return;let e=J(this.host),t=typeof this.options.id()==`string`?this.options.id():``;(!this.#n||e!==this.#e||t!==this.#t)&&(this.#n?.(),this.#n=void 0,this.#e=e,this.#t=t,this.#n=Ii(e,t,this.accept)),this.sync()}hostDisconnected(){this.#n?.(),this.#n=void 0,this.#e=null,this.#t=``,this.detach()}accept=e=>{let t=this.host.isConnected&&e?.namespaceURI===`http://www.w3.org/1999/xhtml`&&(e.localName===`button`||e.localName===`en-button`)?e:null;t!==this.#r&&(this.detach(),this.#r=t,t&&(this.#i=Object.fromEntries([`aria-haspopup`,`aria-expanded`].map(e=>[e,t.getAttribute(e)])),t.addEventListener(`click`,this.click),this.sync()))};click=e=>{let t=this.#r,n=()=>!!(this.host.isConnected&&t?.isConnected&&t===this.#r&&this.options.id()===this.#t&&J(this.host)===this.#e&&this.#e?.getElementById(this.#t)===t&&ya(this.host,this.#t,t));t&&ba(e,n())&&this.options.activate(t,n)};sync(){if(this.#r)for(let[e,t]of Object.entries({"aria-haspopup":`dialog`,"aria-expanded":String(this.options.open())}))this.#r.getAttribute(e)!==t&&this.#r.setAttribute(e,t),this.#a[e]=t}detach(){let e=this.#r;if(e){e.removeEventListener(`click`,this.click);for(let[t,n]of Object.entries(this.#i))e.getAttribute(t)===this.#a[t]&&(n===null?e.removeAttribute(t):e.setAttribute(t,n))}this.#r=null,this.#i={},this.#a={}}};function Sa(e){let t=e.activeElement;for(;t?.shadowRoot?.activeElement;)t=t.shadowRoot.activeElement;return t}function Ca(e){if(!e?.isConnected||e.matches(`:disabled, [hidden], [aria-disabled="true"]`))return;let t=e;for(;t;){if(`inert`in t&&(t.inert||t.hidden))return;t=t.parentNode??(`host`in t?t.host:null)}e.getClientRects().length&&e.focus({preventScroll:!0})}function wa(e,t){for(;t;){if(t===e)return!0;t=`assignedSlot`in t&&t.assignedSlot||t.parentNode||(`host`in t?t.host:null)}return!1}var Ta=class extends E{static properties={for:{type:String,reflect:!0},kind:{reflect:!0},description:{},initialFocus:{attribute:`initial-focus`},open:{type:Boolean,reflect:!0,noAccessor:!0},label:{type:String,useDefault:!0},closeLabel:{type:String,attribute:`close-label`,useDefault:!0},closedBy:{type:String,attribute:`closedby`,reflect:!0,noAccessor:!0},dismissible:{type:Boolean},backdropDismiss:{type:Boolean,attribute:`backdrop-dismiss`,noAccessor:!0},presentation:{type:String,reflect:!0},responsiveQuery:{type:String,attribute:`responsive-query`}};static styles=[B,jn,Si,_a];#e=!1;#t=0;#n=0;#r=0;#i=!1;#a=null;#o=null;#s=null;#c=new xa(this,{id:()=>this.for,open:()=>this.#r?this.#i:this.open,activate:(e,t)=>{let n=!this.triggerToggles||!this.open;this.requestOpen(n,`trigger`,t)===`committed`&&n&&this.open&&t()&&(this.#s={element:e,revision:this.#n})}});#l=null;#u=`close-request`;#d=`closerequest`;#f=null;#p=``;#m=!1;get open(){return this.#e}set open(e){let t=this.#e;this.#s=null,this.#e=!!e,this.#t++,this.#n++,this.#e&&!this.dialog?.open&&(this.#i=!1),this.requestUpdate(`open`,t)}get closedBy(){return this.#d}set closedBy(e){let t=this.#d;this.#d=e===`any`||e===`none`?e:`closerequest`,this.requestUpdate(`closedBy`,t),this.requestUpdate(`backdropDismiss`,t===`any`)}get backdropDismiss(){return this.closedBy===`any`}set backdropDismiss(e){this.closedBy=e?`any`:`closerequest`}constructor(){super(),this.for=``,this.kind=`dialog`,this.description=``,this.initialFocus=``,this.label=``,this.closeLabel=`Close`,this.dismissible=!0,this.presentation=`dialog`,this.responsiveQuery=ga}show(e=`programmatic`){return this.requestOpen(!0,e)}hide(e=`programmatic`){return this.requestOpen(!1,e)}requestOpen(e,t,n){if(e===this.open)return`unchanged`;let r=this.open,i=this.#i;this.#r++;try{return A(this,{previous:r,proposed:e,reason:t,canCommit:n,getRevision:()=>this.#t,stage:e=>{this.#e=e,e&&!this.dialog?.open&&(this.#i=!1)},rollback:t=>{this.#e=t,this.#i=i,this.requestUpdate(`open`,e)},commit:()=>{this.#s=null,this.#n++,this.requestUpdate(`open`,r)}})}finally{this.#r--,this.#r||this.requestUpdate(`open`,r)}}get triggerToggles(){return!1}get openRevision(){return this.#n}get surfaceClass(){return this.#m?`en-drawer`:`en-dialog`}get placement(){return this.#m?`bottom`:``}get dialog(){return this.renderRoot?.querySelector(`dialog`)??null}get effectiveClosedBy(){return this.dismissible?this.closedBy:`none`}get supportsNativeClosedBy(){let e=this.ownerDocument?.defaultView?.HTMLDialogElement?.prototype;return e!==void 0&&`closedBy`in e}connectedCallback(){super.connectedCallback(),this.hasUpdated&&this.observePresentation(),this.updateComplete.then(()=>{this.isConnected&&this.syncDialog()})}disconnectedCallback(){this.#i=!1,this.dialog?.close(),this.#a=null,this.#o=null,this.#s=null,this.#l=null,this.stopObservingPresentation(),super.disconnectedCallback()}updated(e){this.observePresentation(),this.syncDialog()}observePresentation(){let e=this.ownerDocument?.defaultView;if(!this.isConnected||!e?.matchMedia)return;if(this.presentation!==`responsive`){this.stopObservingPresentation(),this.setCompactPresentation(!1);return}let t=this.responsiveQuery.trim()||ga;this.#f&&this.#p===t||(this.stopObservingPresentation(),this.#p=t,this.#f=e.matchMedia(t),this.#f.addEventListener(`change`,this.#h),this.setCompactPresentation(this.#f.matches))}stopObservingPresentation(){this.#f?.removeEventListener(`change`,this.#h),this.#f=null,this.#p=``}setCompactPresentation(e){let t=this.#m;t!==e&&(this.#m=e,this.requestUpdate(`compactPresentation`,t))}#h=e=>{this.setCompactPresentation(e.matches)};syncDialog(){let e=this.dialog;if(!(!e||!this.isConnected||this.#r)){if(this.#i&&!e.open){this.reconcileNativeClose();return}if(this.open&&!e.open){let t=Sa(this.ownerDocument);this.#o=t&&`focus`in t?t:null;let n=this.#s;this.#s=null,this.#a=n?.revision===this.#n&&n.element.isConnected?n.element:this.#o,Y(e,!0),e.showModal();let r=this.initialFocus?[...this.querySelectorAll(`[id]`)].find(e=>e.id===this.initialFocus):null;r&&!r.matches(`[disabled], [hidden], [inert]`)&&!r.closest(`[hidden], [inert]`)&&r.focus({preventScroll:!0}),this.#i=!0}else if(!this.open&&e.open){let t=Sa(this.ownerDocument),n=t===this||wa(e,t);this.#i=!1,e.close(),Y(e,!1),n&&Ca(this.#a),this.#a=null,this.#o=null}}}#g=e=>{e.preventDefault();let t=this.#u;this.#u=`close-request`,this.effectiveClosedBy!==`none`&&(t!==`backdrop`||this.effectiveClosedBy===`any`)&&this.hide(t)};#_=()=>{this.isConnected&&this.#i&&!this.dialog?.open&&this.reconcileNativeClose()};reconcileNativeClose(){this.#i=!1,this.dialog&&Y(this.dialog,!1),this.open=!1;let e=Sa(this.ownerDocument);(e===this.#o||e===this.ownerDocument.body||e===this.dialog)&&Ca(this.#a),this.#a=null,this.#o=null}#v(e){let t=this.dialog;if(!t||e.target!==t)return!1;let n=t.getBoundingClientRect();return e.clientX<n.left||e.clientX>n.right||e.clientY<n.top||e.clientY>n.bottom}#y=e=>{let t=this.#v(e);this.#l=t&&e.isPrimary&&e.button===0?e.pointerId:null,this.#u=t?`backdrop`:`close-request`};#b=e=>{let t=this.#l===e.pointerId&&this.#v(e);this.#l=null,this.#u=t?`backdrop`:`close-request`,t&&this.effectiveClosedBy===`any`&&!this.supportsNativeClosedBy&&this.hide(`backdrop`),queueMicrotask(()=>{this.#u=`close-request`})};#x=()=>{this.#l=null,this.#u=`close-request`};#S=e=>{e.key===`Escape`&&!e.defaultPrevented&&(this.#u=`escape`)};get dialogView(){return{kind:this.kind===`alertdialog`?`alertdialog`:`dialog`,description:this.description,surfaceClass:this.surfaceClass,placement:this.#m?`bottom`:this.placement,label:this.label,closeLabel:this.closeLabel,dismissible:this.dismissible,closedBy:this.supportsNativeClosedBy?this.effectiveClosedBy:`closerequest`,cancel:this.#g,close:this.#_,dismiss:()=>this.hide(`close-button`),pointerDown:this.#y,pointerUp:this.#b,pointerCancel:this.#x,keyDown:this.#S}}render(){return va(this.dialogView)}};function Ea(e){if(!Array.isArray(e))throw TypeError(`commands must be an array.`);let t=new Set;return Object.freeze(e.map(e=>{if(!e||typeof e.action!=`string`||!e.action.trim()||typeof e.label!=`string`||!e.label.trim()||t.has(e.action)||e.disabled!==void 0&&typeof e.disabled!=`boolean`||e.shortcut!==void 0&&typeof e.shortcut!=`string`||e.keywords!==void 0&&(!Array.isArray(e.keywords)||e.keywords.some(e=>typeof e!=`string`)))throw TypeError(`Commands require unique nonempty actions, nonempty labels, and typed optional fields.`);return t.add(e.action),Object.freeze({action:e.action,label:e.label,...e.keywords===void 0?{}:{keywords:Object.freeze([...e.keywords])},...e.disabled===void 0?{}:{disabled:e.disabled},...e.shortcut===void 0?{}:{shortcut:e.shortcut}})}))}function Da(){let e=new k.State([]),t=new k.State(``),n=new k.State(void 0),r=new k.Computed(()=>{let n=t.get().trim().toLowerCase().split(/\s+/).filter(Boolean);return e.get().filter(e=>{let t=[e.label,...e.keywords??[]].join(` `).toLowerCase();return n.every(e=>t.includes(e))}).map(e=>({...e,id:`en-command-${Array.from(e.action).map(e=>e.codePointAt(0).toString(16)).join(`-`)}`}))}),i=new k.Computed(()=>r.get().find(e=>e.action===n.get()&&!e.disabled)),a=()=>{n.set(r.get().find(e=>!e.disabled)?.action)};return{commands:new k.Computed(()=>e.get()),query:new k.Computed(()=>t.get()),view:new k.Computed(()=>({commands:r.get(),active:i.get()})),setCommands(t){e.set(Ea(t)),i.get()||a()},setQuery(e){t.get()!==e&&(t.set(e),a())},reset(){t.set(``),a()},activate(e){r.get().some(t=>t.action===e&&!t.disabled)&&n.set(e)},move(e){let t=r.get().filter(e=>!e.disabled),i=t.findIndex(e=>e.action===n.get()),a=i<0?e===1?0:t.length-1:Math.max(0,Math.min(t.length-1,i+e));n.set(t[a]?.action)}}}function Oa(e,t){return S`<div class="en-command-palette-content">
		<label class="en-label" for="en-command-search" id="en-command-search-label">${e.searchLabel}</label>
		<div class="en-field-focus-frame" part="focus-frame">
			<input class="en-input en-text-input en-command-palette-input" part="control" id="en-command-search"
				type="text" role="combobox" autocomplete="off" spellcheck="false" autofocus
				aria-autocomplete="list" aria-haspopup="listbox" aria-expanded=${String(e.open)}
				aria-controls="en-command-list" aria-activedescendant=${e.open?e.active?.id??T:T}
				placeholder=${e.placeholder||T} value=""
				@input=${t.input} @compositionstart=${t.compositionStart} @compositionend=${t.compositionEnd} @keydown=${t.keydown}>
		</div>
		<div class="en-command-list" part="listbox" role="listbox" tabindex="-1" id="en-command-list" aria-labelledby="en-command-search-label"
			@pointerdown=${t.pointerDown} @pointermove=${t.pointerMove} @pointercancel=${t.pointerCancel} @scroll=${t.scroll}>
			${_r(e.commands,e=>e.action,n=>S`<div class="en-command-option" part="option" role="option"
				id=${n.id} data-action=${n.action} ?data-active=${n.action===e.active?.action}
				aria-selected=${String(n.action===e.active?.action)} aria-disabled=${String(!!n.disabled)}
				@mousedown=${t.mousedown} @click=${t.click}>
				<span class="en-command-label">${n.label}</span>
				${n.shortcut?S`<span class="en-command-shortcut">${n.shortcut}</span>`:T}
			</div>`)}
		</div>
		<p class="en-command-status" part="status" role="status" aria-live="polite" aria-atomic="true">${e.commands.length?T:e.emptyText}</p>
		<slot></slot>
	</div>`}function ka(e){return!!e&&typeof e==`object`&&typeof e.nodeType==`number`&&typeof e.getRootNode==`function`}function Aa(e){return ka(e)&&e.nodeType===1}var ja=class{options;#e=!1;#t=!1;#n;constructor(e){this.options=e}get composing(){return this.#e}reset(){if(this.#n=void 0,this.#e){this.#t=!0;return}let e=this.options.input();e&&(e.value=``),this.options.query(``)}disconnect(){let e=this.#e;this.#e=!1,this.#t?(this.#t=!1,this.reset()):e&&this.options.query(this.options.input()?.value??``),this.#n=void 0}input=e=>{e.isComposing&&(this.#e=!0),this.#e||this.options.query(this.options.input()?.value??``)};compositionStart=()=>{this.#e=!0};compositionEnd=()=>{this.#e=!1,this.#t?(this.#t=!1,this.reset()):this.options.query(this.options.input()?.value??``)};keydown=e=>{if(!(e.defaultPrevented||!this.options.open()||e.isComposing||this.#e||e.keyCode===229||e.altKey||e.ctrlKey||e.metaKey)){if(e.key===`ArrowDown`||e.key===`ArrowUp`)e.preventDefault(),this.options.move(e.key===`ArrowDown`?1:-1);else if(e.key===`Enter`){e.preventDefault();let t=this.options.active();t!==void 0&&!e.repeat&&this.options.execute(t)}}};mousedown=e=>{e.button===0&&e.preventDefault()};pointerDown=e=>{if(!e.isPrimary||e.button!==0){this.#n=void 0;return}let t=e.composedPath().find(e=>Aa(e)&&e.hasAttribute(`data-action`));this.#n={id:e.pointerId,x:e.clientX,y:e.clientY,action:t?.dataset.action,moved:!1}};pointerMove=e=>{let t=this.#n;t?.id===e.pointerId&&Math.hypot(e.clientX-t.x,e.clientY-t.y)>8&&(t.moved=!0)};pointerCancel=()=>{this.#n&&(this.#n.moved=!0)};scroll=()=>{this.#n&&(this.#n.moved=!0)};click=e=>{if(e.defaultPrevented||!this.options.open()||this.#e)return;let t=e.currentTarget,n=t.dataset.action,r=this.#n;this.#n=void 0,!(t.getAttribute(`aria-disabled`)===`true`||n===void 0||e.detail!==0&&r&&(r.moved||r.action!==n))&&this.options.execute(n)}},Ma=class{host;surface;#e;#t=0;#n=null;#r=null;#i=``;constructor(e,t){this.host=e,this.surface=t,e.addController(this)}hostUpdated(){this.sync()}hostDisconnected(){this.stop()}sync(){let e=this.surface();if(!this.host.isConnected||!e?.open){this.stop();return}if(e!==this.#r){this.stop(),this.#r=e,this.#n=this.host.ownerDocument.defaultView;let t=this.#n;if(!t)return;let n=new((this.host.ownerDocument.defaultView?.AbortController)??globalThis.AbortController);this.#e=n;let r={signal:n.signal,passive:!0};t.addEventListener(`resize`,this.schedule,r),t.visualViewport?.addEventListener(`resize`,this.schedule,r),t.visualViewport?.addEventListener(`scroll`,this.schedule,r),this.position()}}schedule=()=>{!this.#n||this.#t||(this.#t=this.#n.requestAnimationFrame(()=>{this.#t=0,this.position()}))};position(){let e=this.#n,t=this.#r;if(!e||!t?.open||!this.host.isConnected)return;let n=e.visualViewport,r=[n?.width??e.innerWidth,n?.height??e.innerHeight,n?.offsetTop??0,n?.offsetLeft??0],i=r.join(`:`);i!==this.#i&&(this.#i=i,[`width`,`height`,`top`,`left`].forEach((e,n)=>t.style.setProperty(`--_en-command-viewport-${e}`,`${r[n]}px`)))}stop(){this.#e?.abort(),this.#e=void 0,this.#t&&this.#n?.cancelAnimationFrame(this.#t),this.#t=0,this.#n=null,this.#r=null,this.#i=``}},Na=class extends Ta{static properties={...Ta.properties,commands:{attribute:!1,noAccessor:!0},searchLabel:{type:String,attribute:`search-label`,useDefault:!0},placeholder:{type:String,useDefault:!0},emptyText:{type:String,attribute:`empty-text`}};static styles=[...Ta.styles,ha];#e=Da();#t=new j(this,()=>this.#e.view.get());#n=new ja({input:()=>this.input,open:()=>this.open&&!!this.dialog?.open,query:e=>{this.#e.setQuery(e),this.scrollCandidate()},move:e=>{this.#e.move(e),this.scrollCandidate()},active:()=>this.#e.view.get().active?.action,execute:e=>this.execute(e)});#r=new Ma(this,()=>this.dialog);#i=!1;#a=!1;get commands(){return this.#e.commands.get()}set commands(e){let t=this.commands;this.#e.setCommands(e),this.requestUpdate(`commands`,t),this.isConnected&&this.open&&this.scrollCandidate()}constructor(){super(),this.label=`Commands`,this.searchLabel=`Search commands`,this.placeholder=``,this.emptyText=`No matching commands.`}get input(){return this.renderRoot?.querySelector(`#en-command-search`)??null}get triggerToggles(){return!0}willUpdate(e){super.willUpdate(e),!this.open&&this.dialog?.open&&this.syncDialog()}syncDialog(){super.syncDialog();let e=!!this.dialog?.open;this.#i&&!e&&(this.#e.reset(),this.#n.reset()),this.#i=e,this.#r.sync()}updated(e){super.updated(e),!this.#a&&this.input&&(this.#a=!0,this.input.value&&this.#e.setQuery(this.input.value))}disconnectedCallback(){this.#n.disconnect(),this.#i=!1,super.disconnectedCallback()}execute(e){if(!this.open||!this.dialog?.open||this.#n.composing||!this.isConnected||!this.#e.view.get().commands.find(t=>t.action===e&&!t.disabled))return;this.#e.activate(e);let t=this.openRevision;un(this,{action:e,data:void 0},{cancelable:!0})&&this.isConnected&&this.open&&t===this.openRevision&&this.commands.some(t=>t.action===e&&!t.disabled)&&this.hide(`action`)}scrollCandidate(){let e=this.#e.view.get().active?.action;this.updateComplete.then(()=>{if(!this.isConnected||!this.open||e!==this.#e.view.get().active?.action)return;let t=this.#e.view.get().active?.id,n=t?this.renderRoot.querySelector(`[id="${t}"]`):null,r=this.renderRoot.querySelector(`#en-command-list`);if(!n||!r)return;let i=n.getBoundingClientRect(),a=r.getBoundingClientRect();i.top<a.top?r.scrollTop-=a.top-i.top:i.bottom>a.bottom&&(r.scrollTop+=i.bottom-a.bottom)})}render(){let e=this.#e.view.get(),t=this.dialogView;return va({...t,surfaceClass:`${t.surfaceClass} en-command-palette`,surfacePart:`surface`,cancel:e=>{this.#n.composing?e.preventDefault():t.cancel(e)},keyDown:e=>{this.#n.composing||t.keyDown(e)},body:Oa({searchLabel:this.searchLabel,placeholder:this.placeholder,emptyText:this.emptyText,open:this.open,commands:e.commands,active:e.active},this.#n)})}},Pa={bold:C`<path d="M7 4h6a4 4 0 0 1 0 8H7V4Zm0 8h7a4 4 0 0 1 0 8H7v-8Z" />`,italic:C`<path d="M10 4h9M5 20h9M15 4 9 20" />`,underline:C`<path d="M6 3v8a6 6 0 0 0 12 0V3M4 21h16" />`,"align-start":C`<path d="M4 5h16M4 10h10M4 15h16M4 20h10" />`,"align-center":C`<path d="M4 5h16M7 10h10M4 15h16M7 20h10" />`,"align-end":C`<path d="M4 5h16M10 10h10M4 15h16M10 20h10" />`,heading:C`<path d="M5 4v16M19 4v16M5 12h14" />`,paragraph:C`<path d="M13 4H9a5 5 0 0 0 0 10h4M13 4v16M18 4v16M9 4h12" />`,"bullet-list":C`<circle cx="4" cy="6" r="1" /><circle cx="4" cy="12" r="1" /><circle cx="4" cy="18" r="1" /><path d="M9 6h12M9 12h12M9 18h12" />`,"ordered-list":C`<path d="m3 4 1-1v6M3 9h3M3 15a1.5 1.5 0 0 1 3 0c0 1-3 3-3 4h3M10 6h11M10 12h11M10 18h11" />`,link:C`<path d="M10 13a4 4 0 0 0 6 0l4-4a4 4 0 0 0-6-6l-2 2M14 11a4 4 0 0 0-6 0l-4 4a4 4 0 0 0 6 6l2-2" />`,unlink:C`<path d="m12 5 2-2a4 4 0 0 1 6 6l-2 2M6 13l-2 2a4 4 0 0 0 6 6l2-2M3 3l18 18" />`,undo:C`<path d="M9 4 3 10l6 6M3 10h11a6 6 0 0 1 0 12" transform="translate(0 -2)" />`,redo:C`<path d="m15 4 6 6-6 6M21 10H10a6 6 0 0 0 0 12" transform="translate(0 -2)" />`,file:C`<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z" /><path d="M14 2v6h6M8 13h8M8 17h5" />`,calendar:C`<rect x="3" y="5" width="18" height="16" rx="2"></rect><path d="M7 3v4m10-4v4M3 11h18"></path>`,check:C`<path d="m5 12 4 4L19 6" />`,plus:C`<path d="M12 5v14M5 12h14" />`,close:C`<path d="m6 6 12 12M18 6 6 18" />`,"chevron-left":C`<path d="m15 6-6 6 6 6" />`,"chevron-right":C`<path d="m9 6 6 6-6 6" />`,"chevron-down":C`<path d="m6 9 6 6 6-6" />`,"arrow-right":C`<path d="M4 12h16m-6-6 6 6-6 6" />`,search:C`<circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 4 4" />`,info:C`<circle cx="12" cy="12" r="9" /><path d="M12 11v6m0-10v1" />`,warning:C`<path d="m12 3 10 18H2L12 3Zm0 6v5m0 3v1" />`,sparkles:C`<path d="m12 3 2.6 6.4L21 12l-6.4 2.6L12 21l-2.6-6.4L3 12l6.4-2.6L12 3ZM20 2v4m-2-2h4" />`},Fa=(e,t)=>S`
  <svg
    class="en-icon"
    ?data-logical=${e===`align-start`||e===`align-end`}
    part="base"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-linecap="round"
    stroke-linejoin="round"
    focusable="false"
    role=${t?`img`:T}
    aria-label=${t||T}
    aria-hidden=${t?T:`true`}
  >${Pa[e]??T}</svg>
`,Ia={tagName:`en-icon`,elementClass:class extends E{static properties={name:{type:String},label:{type:String}};static styles=[B,Nn,Xn];constructor(){super(),this.name=`info`,this.label=``}render(){return Fa(this.name,this.label)}}};n(customElements,{tagName:`en-command-palette`,elementClass:Na,dependencies:[Vr,Ia]});var La=`modulepreload`,Ra=function(e){return`/`+e},za={},Ba=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=Ra(t,n),t=s(t),t in za)return;za[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:La,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},Va,Ha=!1;async function Ua({retry:e=!1}={}){return(!Va||e&&Ha)&&(Ha=!1,Va=Ba(()=>import(`./calendar-Bnw96Yao.js`).then(e=>e.calendarDefinition),[]).catch(e=>{throw Ha=!0,e})),[await Va]}var Wa=864e5;function Ga(e,t){if(!Number.isInteger(e)||e<1||e>9999||!Number.isInteger(t)||t<1||t>12)throw RangeError(`Calendar dates require a year from 1 to 9999 and a month from 1 to 12.`);return t===2?e%4==0&&(e%100!=0||e%400==0)?29:28:[4,6,9,11].includes(t)?30:31}function X(e){if(!/^\d{4}-\d{2}-\d{2}$/.test(e))return;let t=Number(e.slice(0,4)),n=Number(e.slice(5,7)),r=Number(e.slice(8,10));if(!(t<1||n<1||n>12||r<1||r>Ga(t,n)))return{year:t,month:n,day:r}}function Ka(e){if(!Number.isInteger(e.day)||e.day<1||e.day>Ga(e.year,e.month))throw RangeError(`Calendar dates require a valid day in the selected month.`);return`${String(e.year).padStart(4,`0`)}-${String(e.month).padStart(2,`0`)}-${String(e.day).padStart(2,`0`)}`}function Z(e){Ka(e);let t=new Date(0);return t.setUTCFullYear(e.year,e.month-1,e.day),t}function qa(e){let t=new Date(e);return{year:t.getUTCFullYear(),month:t.getUTCMonth()+1,day:t.getUTCDate()}}var Ja={year:1,month:1,day:1},Ya={year:9999,month:12,day:31},Xa=Z(Ja).getTime(),Za=Z(Ya).getTime();function Qa(e){if(!Number.isSafeInteger(e))throw RangeError(`Calendar increments must be safe integers.`)}function $a(e,t){Qa(t);let n=Z(e).getTime()+t*Wa;return qa(Math.max(Xa,Math.min(Za,n)))}function eo(e,t){Ka(e),Qa(t);let n=Math.max(0,Math.min(119987,(e.year-1)*12+e.month-1+t)),r=Math.floor(n/12)+1,i=n%12+1;return{year:r,month:i,day:Math.min(e.day,Ga(r,i))}}function to(e,t){return Math.sign(Z(e).getTime()-Z(t).getTime())}function no(e,t,n=`1970-01-01`){let r=Number.isFinite(t)&&t>0?t:1,i=X(n)??{year:1970,month:1,day:1},a=(Z(e).getTime()-Z(i).getTime())/Wa/r;return!Number.isFinite(a)||Math.abs(a-Math.round(a))<=2**-52*Math.max(1,Math.abs(a))*8}function ro(e,t,n){let r=t?X(t):void 0,i=n?X(n):void 0;return(!r||to(e,r)>=0)&&(!i||to(e,i)<=0)}function io(e,t,n){let r=t?X(t):void 0,i=n?X(n):void 0;if(r&&i&&to(r,i)>0)return!1;let a={...e,day:1},o={...e,day:Ga(e.year,e.month)};return(!r||to(o,r)>=0)&&(!i||to(a,i)<=0)}function ao(e,t,n){let r=t?X(t):void 0,i=n?X(n):void 0;if(!(r&&i&&to(r,i)>0))return r&&to(e,r)<0?r:i&&to(e,i)>0?i:{...e}}function oo(e){if(!Number.isInteger(e)||e<0||e>6)throw RangeError(`The first weekday must be an integer from 0 (Sunday) to 6 (Saturday).`);return e}function so(e,t={}){let n=oo(t.firstDayOfWeek??0),r=Z({...e,day:1}),i=(r.getUTCDay()-n+7)%7;return Array.from({length:42},(n,a)=>{let o=r.getTime()+(a-i)*Wa;if(o<Xa||o>Za)return{date:void 0,value:``,inMonth:!1,disabled:!0};let s=qa(o);return{date:s,value:Ka(s),inMonth:s.month===e.month&&s.year===e.year,disabled:!ro(s,t.min,t.max)}})}function co(e,t=0){let n=oo(t),r=new Intl.DateTimeFormat(e,{weekday:`short`,calendar:`gregory`,timeZone:`UTC`}),i=new Intl.DateTimeFormat(e,{weekday:`long`,calendar:`gregory`,timeZone:`UTC`});return Array.from({length:7},(e,t)=>{let a=Z({year:2024,month:1,day:7+(n+t)%7});return{short:r.format(a),long:i.format(a)}})}function lo(e,t=`en`){if(e!==`gregory`&&e!==`buddhist`)throw RangeError(`Unsupported calendar: ${e}.`);let n=new Map,r=r=>{let i=JSON.stringify(r),a=n.get(i);if(a)return a;let o=new Intl.DateTimeFormat(t,{...r,calendar:e,timeZone:`UTC`});if(o.resolvedOptions().calendar!==e)throw RangeError(`Calendar data unavailable: ${e}.`);return n.set(i,o),o};r({year:`numeric`});let i=e===`buddhist`?`1941-01-01`:`0001-01-01`,a=`9999-12-31`,o=e===`buddhist`?543:0,s=e===`buddhist`?`be`:`ce`;function c(e){f(e);let t=new Date(0);return t.setUTCFullYear(e.year,e.month-1,e.day),t.getTime()/864e5}function l(e,t){let n=f($a(f(e),t));if(c(n)-c(e)!==t)throw RangeError(`Day navigation exceeds the supported calendar interval.`);return n}function u(e,t){let n=f(eo(f(e),t));if((n.year-e.year)*12+n.month-e.month!==t)throw RangeError(`Month navigation exceeds the supported calendar interval.`);return n}function d(e){let t=Ka(e);return t>=i&&t<=a}function f(t){if(!d(t))throw RangeError(`${e} supports ISO ${i} through ${a}.`);return t}function p(t){return f(t),{calendar:e,era:s,year:t.year+o,monthCode:`M${String(t.month).padStart(2,`0`)}`,day:t.day}}function m(t){if(t.calendar!==e||t.era!==s||!/^M(0[1-9]|1[0-2])$/.test(t.monthCode))throw RangeError(`Invalid calendar fields.`);return f({year:t.year-o,month:Number(t.monthCode.slice(1)),day:t.day})}return{id:e,minimum:i,maximum:a,supported:d,toFields:p,fromFields:m,dayIdentity:c,daysInMonth:e=>{let t=m({...e,day:1});return Ga(t.year,t.month)},addDays:l,addMonths:u,grid:(e,t)=>so(f(e),t).map(e=>e.date&&!d(e.date)?{date:void 0,value:``,inMonth:!1,disabled:!0}:e),format:(e,t)=>{f(e);let n=new Date(0);return n.setUTCFullYear(e.year,e.month-1,e.day),r(t).format(n)}}}function uo(e,t,n){try{let r=lo(e,t),i=n?X(n):void 0;return i&&!r.supported(i)?{error:`${e} supports ISO ${r.minimum} through ${r.maximum}.`}:{adapter:r}}catch{return{error:`Calendar “${e}” is unsupported or its locale data is unavailable.`}}}function fo(e){if(e&&typeof e.start==`string`&&typeof e.end==`string`&&!(e.start&&!X(e.start)||e.end&&!X(e.end)))return Object.freeze(e.start&&e.end&&e.end<e.start?{start:e.end,end:e.start}:{start:e.start,end:e.end})}var po=()=>Object.freeze({start:``,end:``});function mo(e,t){if(!e.start||!e.end)return`Choose both a start date and an end date.`;let n=X(e.start),r=X(e.end),i=uo(t.calendar,t.locale,e.start);if(!n||!r||!i.adapter||!i.adapter.supported(r))return i.error||`The range is outside the supported calendar.`;if(!ro(n,t.min,t.max)||!ro(r,t.min,t.max))return`The range must stay within the available dates.`;if(!no(n,t.step,t.min||t.stepBase)||!no(r,t.step,t.min||t.stepBase)||e.start!==e.end&&t.step>1)return`Every date in the range must match the allowed date step.`;if(t.unavailableDate){if(i.adapter.dayIdentity(r)-i.adapter.dayIdentity(n)>=36600)return`Availability checks support ranges of at most 36,600 days. Choose a shorter range.`;for(let r=n;;r=i.adapter.addDays(r,1)){let n=Ka(r);if(t.unavailableDate(n))return`The range includes an unavailable date: ${n}.`;if(n===e.end)break}}return``}var ho={},go=ar(class extends or{constructor(){super(...arguments),this.ot=ho}render(e,t){return t()}update(e,[t,n]){if(Array.isArray(t)){if(Array.isArray(this.ot)&&this.ot.length===t.length&&t.every((e,t)=>e===this.ot[t]))return w}else if(this.ot===t)return w;return this.ot=Array.isArray(t)?Array.from(t):t,this.render(t,n)}}),Q=class extends q{static properties={...q.properties,readOnly:{type:Boolean,attribute:`readonly`,reflect:!0},autocomplete:{type:String},inputMode:{type:String,attribute:`inputmode`}};editing=new Mi(this,{model:this.model,control:()=>this.controlNode,onCommit:(e,t)=>{this.readOnly||this.requestValue(e,t)}});constructor(){super(),this.readOnly=!1,this.autocomplete=``,this.inputMode=``}canCommitValue(e){return!this.readOnly&&super.canCommitValue(e)}reconcile(){this.editing?.sync()}select(){this.controlNode?.select()}},_o=class extends Q{static properties={...Q.properties,min:{type:String},max:{type:String},step:{type:Number}};constructor(){super(),this.min=``,this.max=``,this.step=1}renderControl(){return S`<input id="control" class="en-input" part="control" type="date"
      name=${this.name} value=${this.defaultControlValue} min=${this.min||T} max=${this.max||T} step=${this.step}
      autocomplete=${this.autocomplete||T} ?disabled=${this.isDisabled} ?readonly=${this.readOnly} ?required=${this.required}
      aria-describedby=${this.describedBy} aria-invalid=${this.controlAriaInvalid}>`}},vo=class extends _o{static properties={..._o.properties,selection:{reflect:!0,noAccessor:!0},calendarLoading:{attribute:`calendar-loading`,reflect:!0,noAccessor:!0},loadingLabel:{attribute:`loading-label`},loadErrorLabel:{attribute:`load-error-label`},loadRetryErrorLabel:{attribute:`load-retry-error-label`},rangeValue:{attribute:!1,noAccessor:!0},defaultRangeValue:{attribute:!1,noAccessor:!0},startName:{attribute:`start-name`},endName:{attribute:`end-name`},unavailableDate:{attribute:!1,noAccessor:!0},applyLabel:{attribute:`apply-label`,useDefault:!0},cancelLabel:{attribute:`cancel-label`,useDefault:!0},clearLabel:{attribute:`clear-label`,useDefault:!0},startLabel:{attribute:`start-label`,useDefault:!0},endLabel:{attribute:`end-label`,useDefault:!0},calendar:{},calendarLabel:{attribute:`calendar-label`,useDefault:!0},unsupportedLabel:{attribute:`unsupported-label`,useDefault:!0},editLabel:{attribute:`edit-label`,useDefault:!0},locale:{},today:{},firstDayOfWeek:{type:Number,attribute:`first-day-of-week`},pickerLabel:{attribute:`picker-label`,useDefault:!0},closeLabel:{attribute:`close-label`,useDefault:!0},previousLabel:{attribute:`previous-label`,useDefault:!0},nextLabel:{attribute:`next-label`,useDefault:!0}};static styles=[..._o.styles,_`
    .en-date-picker-layout { display:grid;grid-template-columns:minmax(0,1fr) auto;gap:var(--en-space-2);align-items:center;min-inline-size:0; }
    .en-field-focus-frame { min-inline-size:0; }
    input::-webkit-calendar-picker-indicator { display:none; }
    en-dialog { --en-overlay-max-inline-size:26rem; }
    en-calendar { inline-size:100%; }
    .range-fields {display:grid;grid-template-columns:1fr 1fr;gap:var(--en-space-2);margin-block-end:var(--en-space-3)} .range-fields label {display:grid;gap:var(--en-space-1);min-inline-size:0} .range-fields input {inline-size:100%;min-inline-size:0;box-sizing:border-box} .range-actions {display:flex;justify-content:flex-end;gap:var(--en-space-2);margin-block-start:var(--en-space-3)}
    en-calendar::part(base) { inline-size:100%; }
    .en-picker-status { min-block-size:1.5em;margin:0; }
  `];#e=`single`;get selection(){return this.#e}set selection(e){if(e===`range`&&this.calendarLoading===`deferred`)throw RangeError(`Deferred calendar supports single selection only.`);let t=this.#e;this.#e=e,this.requestUpdate(`selection`,t)}#t=`eager`;get calendarLoading(){return this.#t}set calendarLoading(e){let t=e===`deferred`?`deferred`:`eager`;if(t===this.#t)return;if(this.hasUpdated)throw Error(`Set calendarLoading before the first update.`);if(t===`deferred`&&this.selection===`range`)throw RangeError(`Deferred calendar supports single selection only.`);let n=this.#t;this.#t=t,this.requestUpdate(`calendarLoading`,n),this.isConnected&&(this.removeEventListener(`keydown`,this.pendingKeydown),t===`deferred`&&this.addEventListener(`keydown`,this.pendingKeydown))}calendarLoadFailures=0;get calendarErrorMessage(){return this.calendarLoadFailures>1?this.loadRetryErrorLabel.replaceAll(`{attempt}`,String(this.calendarLoadFailures-1)):this.loadErrorLabel}calendarMounted=!1;featureRegistrationError;pickerStatus=`idle`;pendingOpen;pickerRegistry(){let e=this.renderRoot,t=e&&`customElementRegistry`in e?e.customElementRegistry:this.ownerDocument.defaultView?.customElements;if(!t)throw Error(`Missing picker render registry.`);return t}async preparePicker(e={}){this.calendarLoading===`deferred`&&(await this.updateComplete,await Ua(e))}cancelOpen(){this.pendingOpen?.abort.abort(),this.pendingOpen=void 0,this.pickerStatus===`loading`&&(this.pickerStatus=`idle`,this.requestUpdate())}connectedCallback(){super.connectedCallback(),this.calendarLoading===`deferred`&&this.addEventListener(`keydown`,this.pendingKeydown)}disconnectedCallback(){this.cancelOpen(),this.removeEventListener(`keydown`,this.pendingKeydown),super.disconnectedCallback()}adoptedCallback(){this.cancelOpen(),super.adoptedCallback()}formDisabledCallback(e){e&&this.cancelOpen(),super.formDisabledCallback(e),e||queueMicrotask(()=>this.requestUpdate())}async openFromTrigger(){try{await this.showPicker()}catch{}}pendingKeydown(e){e.key===`Escape`&&this.pendingOpen&&(this.hidePicker(),e.preventDefault())}unavailable;get unavailableDate(){return this.unavailable}set unavailableDate(e){let t=this.unavailable;t!==e&&(this.unavailable=e,this.availabilityCache?.clear(),this.requestUpdate(`unavailableDate`,t))}acceptedRange=po();pickerDraft=po();defaultRange=po();rangeDirty=!1;get defaultRangeValue(){return this.defaultRange}set defaultRangeValue(e){let t=fo(e);if(!t)return;let n=this.defaultRange;this.defaultRange=t,this.rangeDirty||=(this.rangeValue=t,!1),this.requestUpdate(`defaultRangeValue`,n)}rangeRevision=0;rangeError=``;availabilityCache=new Map;get rangeValue(){return this.acceptedRange}set rangeValue(e){let t=fo(e);if(!t)return;this.rangeDirty=!0;let n=this.acceptedRange;this.acceptedRange=t,this.pickerDraft=t,++this.rangeRevision,this.rangeError=``,this.syncForm(),this.requestUpdate(`rangeValue`,n),this.calendarElement&&(this.calendarElement.rangeValue=t)}invalidateAvailability(){this.availabilityCache.clear(),this.calendarElement?.invalidateAvailability(),this.syncForm(),this.requestUpdate()}validateRange(e){let t=JSON.stringify([e,this.calendar,this.locale,this.min,this.max,this.step,this.defaultValue]);return this.availabilityCache.has(t)||this.availabilityCache.set(t,mo(e,{...this.rangeOptions,unavailableDate:this.unavailableDate})),this.availabilityCache.get(t)}get rangeOptions(){return{calendar:this.calendar,locale:this.locale,min:this.min,max:this.max,step:this.step,stepBase:this.min||this.defaultValue||`1970-01-01`}}get submissionValue(){if(this.selection!==`range`)return super.submissionValue;if(!this.rangeValue.start||!this.rangeValue.end||this.validateRange(this.rangeValue))return null;let e=new FormData;return this.startName&&e.append(this.startName,this.rangeValue.start),this.endName&&e.append(this.endName,this.rangeValue.end),e}get submissionState(){return this.selection===`range`?JSON.stringify(this.rangeValue):super.submissionState}formResetCallback(){this.cancelOpen(),super.formResetCallback(),this.selection===`range`&&(this.rangeValue=this.defaultRangeValue,this.rangeDirty=!1,this.hidePicker())}formStateRestoreCallback(e,t){if(this.selection!==`range`){super.formStateRestoreCallback(e,t);return}if(typeof e==`string`)try{this.rangeValue=JSON.parse(e)}catch{}}validateAcceptedValue(){if(this.selection!==`range`)return super.validateAcceptedValue();let e=!this.rangeValue.start&&!this.rangeValue.end,t=this.error||(e&&!this.required?``:this.validateRange(this.rangeValue));return{anchor:this.renderRoot?.querySelector(`en-button#picker-trigger`)?.shadowRoot?.querySelector(`button`)??void 0,flags:t?this.required&&(!this.rangeValue.start||!this.rangeValue.end)&&!this.error?{valueMissing:!0}:{customError:!0}:{},message:t}}applyRange(){let e=this.calendarElement?.draftRange;if(!e||this.isDisabled||this.readOnly)return;let t=this.validateRange(e);if(t){this.rangeError=t,this.requestUpdate();return}this.rangeDirty=!0;let n=A(this,{previous:this.rangeValue,proposed:e,reason:`range`,getRevision:()=>this.rangeRevision,stage:e=>{this.acceptedRange=e,this.pickerDraft=e,this.syncForm(),this.requestUpdate()},rollback:e=>{this.acceptedRange=e,this.pickerDraft=e,this.syncForm(),this.requestUpdate()},canCommit:e=>!this.isDisabled&&!this.readOnly&&!this.validateRange(e)});n===`committed`||n===`unchanged`?this.hidePicker():(this.calendarElement&&(this.calendarElement.rangeValue=this.rangeValue),this.rangeError=`Range change canceled.`,this.requestUpdate())}editRange(e,t){this.rangeDirty=!0;let n=this.calendarElement;if(!n)return;let r=e.target.value,i={...n.draftRange,[t]:r};t===`start`&&i.end&&i.start>i.end&&(i.end=``),n.setRangeDraft(i),this.pickerDraft=n.draftRange,this.rangeError=``,this.requestUpdate()}clearRange(){if(this.isDisabled||this.readOnly)return;this.rangeDirty=!0;let e=po();A(this,{previous:this.rangeValue,proposed:e,reason:`clear`,getRevision:()=>this.rangeRevision,stage:e=>{this.acceptedRange=e,this.pickerDraft=e,this.syncForm(),this.requestUpdate()},rollback:e=>{this.acceptedRange=e,this.pickerDraft=e,this.syncForm(),this.requestUpdate()},canCommit:()=>!this.isDisabled&&!this.readOnly}),this.calendarElement&&(this.calendarElement.rangeValue=this.rangeValue),this.hidePicker()}get rangeSummary(){let e=uo(this.calendar,this.locale,this.rangeValue.start);if(e.error)return this.unsupportedLabel||e.error;let t=t=>{let n=X(t);return n&&e.adapter?e.adapter.format(n,{year:`numeric`,month:`short`,day:`numeric`,era:this.calendar===`buddhist`?`short`:void 0}):`…`};return this.rangeValue.start||this.rangeValue.end?`${t(this.rangeValue.start)} – ${t(this.rangeValue.end)}`:`No range selected`}willUpdate(e){super.willUpdate(e),e.has(`unavailableDate`)&&this.availabilityCache.clear(),(this.isDisabled||this.readOnly)&&this.cancelOpen()}constructor(){super(),this.loadingLabel=`Loading calendar…`,this.loadErrorLabel=`Calendar could not load. Try again, reload the page, or enter a date directly.`,this.loadRetryErrorLabel=`Calendar retry {attempt} failed. Reload the page or enter a date directly.`,this.selection=`single`,this.startName=``,this.endName=``,this.applyLabel=`Apply range`,this.cancelLabel=`Cancel`,this.clearLabel=`Clear range`,this.startLabel=`Start date`,this.endLabel=`End date`,this.calendar=`gregory`,this.calendarLabel=``,this.unsupportedLabel=``,this.editLabel=`Edit Gregorian date (ISO YYYY-MM-DD value; input layout follows your browser).`,this.locale=`en`,this.today=``,this.firstDayOfWeek=0,this.pickerLabel=`Choose date`,this.closeLabel=`Close calendar`,this.previousLabel=`Previous month`,this.nextLabel=`Next month`}focus(e){this.selection===`range`?this.renderRoot?.querySelector(`#picker-trigger`)?.focus(e):super.focus(e)}get dialog(){return this.renderRoot?.querySelector(`en-dialog`)}get calendarElement(){return this.renderRoot?.querySelector(`en-calendar`)}syncCalendar(e){e.value=this.value,e.rangeValue=this.rangeValue,this.pickerDraft=this.rangeValue,this.rangeError=``,e.month=(this.selection===`range`?this.rangeValue.start:this.value)||this.today||this.min}async showEagerPicker(){if(await this.updateComplete,this.isDisabled||this.readOnly)return;let e=this.dialog,t=this.calendarElement;e&&t&&(this.syncCalendar(t),this.requestUpdate(),e.show(),await e.updateComplete,await t.updateComplete,e.open&&t.focus())}showPicker(){if(this.calendarLoading===`eager`)return this.showEagerPicker();if(this.pendingOpen)return this.pendingOpen.promise;let e=new AbortController,n=this.ownerDocument,r=()=>{let e=n.activeElement;for(;e?.shadowRoot?.activeElement;)e=e.shadowRoot.activeElement;return e},i=r(),a=()=>!e.signal.aborted&&this.isConnected&&this.ownerDocument===n&&!this.isDisabled&&!this.readOnly,o=t=>new Promise((n,r)=>{let i=()=>r(new DOMException(`Opening canceled`,`AbortError`));if(e.signal.aborted){i();return}e.signal.addEventListener(`abort`,i,{once:!0}),t.then(n,r).finally(()=>e.signal.removeEventListener(`abort`,i))}),s={abort:e,promise:void 0};return this.pendingOpen=s,s.promise=(async()=>{try{if(await o(this.updateComplete),!a())return;if(!this.calendarMounted){let e=this.pickerRegistry();if(this.featureRegistrationError)throw this.featureRegistrationError;let n=this.pickerStatus===`error`;this.pickerStatus=`loading`,this.requestUpdate();let s=await o(Ua({retry:n}));if(!a()||r()!==i)return;try{t(e,s)}catch(e){throw this.featureRegistrationError=e,e}this.calendarMounted=!0,this.requestUpdate(),await o(this.updateComplete)}if(!a()||r()!==i)return;let e=this.dialog,n=this.calendarElement;if(!e||!n||(this.syncCalendar(n),this.calendarLoadFailures=0,this.pickerStatus=`idle`,this.requestUpdate(),await o(this.updateComplete),await o(n.updateComplete),!a()||r()!==i))return;e.show(),await o(e.updateComplete),await o(n.updateComplete),a()&&e.open&&n.focus()}catch(t){if(e.signal.aborted)return;throw++this.calendarLoadFailures,this.pickerStatus=`error`,this.requestUpdate(),t}finally{this.pendingOpen===s&&(this.pendingOpen=void 0,this.pickerStatus===`loading`&&(this.pickerStatus=`idle`,this.requestUpdate()))}})(),s.promise}hidePicker(){this.cancelOpen();let e=this.calendarElement;e&&this.selection===`range`&&(e.rangeValue=this.rangeValue),e?.cancelRange(),this.dialog?.hide()}dialogChanged(e){if(e.stopPropagation(),e.detail.proposed&&this.calendarLoading===`deferred`&&!this.calendarMounted){e.preventDefault(),this.openFromTrigger();return}if(!e.detail.proposed){this.calendarElement?.cancelRange();return}let t=this.calendarElement;t&&this.syncCalendar(t),this.requestUpdate(),queueMicrotask(async()=>{await this.dialog?.updateComplete,await t?.updateComplete,this.dialog?.open&&t?.focus()})}calendarTransaction=!1;confirm(e){if(e.stopPropagation(),e.detail.action!==`confirm`||this.isDisabled||this.readOnly)return;let t=e.detail.data;this.calendarTransaction=!0;try{this.requestValue(t,`calendar`)}finally{this.calendarTransaction=!1}this.calendarElement&&(this.calendarElement.value=this.value),this.value===t&&this.canCommitValue(t)&&this.hidePicker()}canCommitValue(e){if(this.isDisabled||this.readOnly)return!1;if(!this.calendarTransaction)return!0;let t=X(e);if(this.isDisabled||this.readOnly||!t||!ro(t,this.min,this.max))return!1;let n=this.controlNode?.cloneNode(!0);return!n||(n.min=this.min,n.max=this.max,n.step=String(this.step),n.required=this.required,n.value=e,n.setCustomValidity(``),n.validity.valid)}updated(e){super.updated(e),(this.isDisabled||this.readOnly)&&this.dialog?.open&&(this.dialog.open=!1)}get describedBy(){return`${super.describedBy}${this.calendar===`gregory`?``:` calendar-edit-hint`}`}renderControlFrame(){return this.selection===`range`?S`<div class="en-date-picker-layout" part="picker-layout"><div part="range-summary">${this.rangeSummary}</div><en-button id="picker-trigger" variant="secondary" aria-label=${`${this.querySelector?.(`[slot=label]`)?.textContent?.trim()||this.label||this.pickerLabel}: ${this.rangeSummary}`} aria-describedby=${this.describedBy} ?disabled=${this.isDisabled||this.readOnly} exportparts="control:trigger">${this.pickerLabel}</en-button></div>`:S`<div class="en-date-picker-layout" part="picker-layout">${super.renderControlFrame()}
      <en-button size="inherit" id="picker-trigger" variant="secondary" icon-only ?disabled=${this.isDisabled||this.readOnly} exportparts="control:trigger"><en-icon slot="prefix" size="inherit" name="calendar"></en-icon><span class="en-sr-only">${this.pickerLabel}${this.value?`, ${this.value}`:``}</span></en-button>
    </div>${this.calendar===`gregory`?T:S`<p part="edit-hint" id="calendar-edit-hint">${this.editLabel}</p>`}`}render(){let e=uo(this.calendar,this.locale,this.selection===`range`?this.rangeValue.start:this.value),t=X(this.value),n=this.selection===`range`?this.rangeSummary:t&&e.adapter?e.adapter.format(t,{year:`numeric`,month:`long`,day:`numeric`,era:`short`}):``;return S`${super.render()}${this.calendar===`gregory`?T:S`<p part="calendar-summary">${this.calendarLabel||(this.calendar===`buddhist`?`Buddhist calendar · BE`:this.calendar)}: ${e.error?this.unsupportedLabel||e.error:n||`No date selected`}</p>`}<en-dialog for="picker-trigger" label=${this.pickerLabel} close-label=${this.closeLabel} presentation="responsive" exportparts="surface,close" @en-change=${this.dialogChanged}>
      ${this.selection===`range`?S`<div class="range-fields" part="range-fields"><label>${this.startLabel}<span class="en-field-focus-frame"><input class="en-input" type="date" aria-label=${this.startLabel} .value=${this.pickerDraft.start} min=${this.min||T} max=${this.max||T} step=${this.step} ?disabled=${this.isDisabled||this.readOnly} @change=${e=>this.editRange(e,`start`)}></span></label><label>${this.endLabel}<span class="en-field-focus-frame"><input class="en-input" type="date" aria-label=${this.endLabel} .value=${this.pickerDraft.end} min=${this.min||T} max=${this.max||T} step=${this.step} ?disabled=${this.isDisabled||this.readOnly} @change=${e=>this.editRange(e,`end`)}></span></label></div><p part="edit-hint">${this.editLabel}</p>`:T}
      ${this.calendarLoading===`eager`||this.calendarMounted?S`<en-calendar .selection=${this.selection} .rangeValue=${go([this.rangeValue],()=>this.rangeValue)} .unavailableDate=${this.unavailableDate} .deferRangeCommit=${this.selection===`range`} size="inherit" part="calendar" exportparts="day:calendar-day,selected:calendar-selected,range-start:calendar-range-start,range-end:calendar-range-end,in-range:calendar-in-range,preview:calendar-preview,range-band:calendar-range-band,range-band-start:calendar-range-band-start,range-band-end:calendar-range-band-end,range-band-preview:calendar-range-band-preview" .calendar=${this.calendar} .calendarLabel=${this.calendarLabel} .unsupportedLabel=${this.unsupportedLabel} .value=${this.value} .step=${this.step} .stepBase=${this.min||this.defaultValue||`1970-01-01`} .min=${this.min} .max=${this.max} .today=${this.today} .locale=${this.locale} .firstDayOfWeek=${this.firstDayOfWeek} .label=${this.pickerLabel} .previousLabel=${this.previousLabel} .nextLabel=${this.nextLabel} @en-change=${e=>e.stopPropagation()} @en-action=${e=>{this.selection===`range`?(e.stopPropagation(),this.pickerDraft=this.calendarElement?.draftRange??this.rangeValue,(this.pickerDraft.start!==this.rangeValue.start||this.pickerDraft.end!==this.rangeValue.end)&&(this.rangeDirty=!0),this.requestUpdate()):this.confirm(e)}}></en-calendar>`:T}
      ${this.selection===`range`?S`<div role="status" part="range-error">${this.rangeError}</div><div class="range-actions" part="range-actions"><en-button variant="secondary" ?disabled=${this.isDisabled||this.readOnly} @click=${this.clearRange}>${this.clearLabel}</en-button><en-button variant="secondary" @click=${()=>this.hidePicker()}>${this.cancelLabel}</en-button><en-button ?disabled=${!this.pickerDraft.start||!this.pickerDraft.end||this.isDisabled||this.readOnly} @click=${this.applyRange}>${this.applyLabel}</en-button></div>`:T}
    </en-dialog>${this.calendarLoading===`deferred`?S`<p class="en-picker-status" role="status" aria-live="polite" part="calendar-status">${this.pickerStatus===`loading`?this.loadingLabel:this.pickerStatus===`error`?this.calendarErrorMessage:T}</p>`:T}`}},yo={tagName:`en-dialog`,elementClass:Ta,dependencies:[Vr,Ia]},bo={tagName:`en-date-picker`,elementClass:vo,dependencies:[yo,Vr,Ia]};n(customElements,yo);var xo={tagName:`en-drawer`,elementClass:class extends Ta{static properties={...Ta.properties,placement:{type:String,reflect:!0,noAccessor:!0}};#e=`end`;get placement(){return this.#e}set placement(e){let t=this.#e;this.#e=[`start`,`end`,`left`,`right`,`top`,`bottom`].includes(e)?e:`end`,this.requestUpdate(`placement`,t)}get surfaceClass(){return`en-drawer`}},dependencies:[Vr,Ia]};n(customElements,xo),n(customElements,Ia);function So(e,t=`M0 0 L8 8 L16 0`){return e?S`<svg class="en-overlay-arrow" part="arrow" viewBox="0 0 16 8" preserveAspectRatio="none" aria-hidden="true" focusable="false"><path part="arrow-shape" d=${t} vector-effect="non-scaling-stroke"></path></svg>`:T}function Co(e){let t=e.querySelector(`.en-overlay-arrow`);return t&&parseFloat(e.ownerDocument.defaultView.getComputedStyle(t).height)||0}function wo(e,t){let n=e.querySelector(`.en-overlay-arrow`);if(!n)return;let r=e.ownerDocument.defaultView,i=e.getBoundingClientRect(),a=t.getBoundingClientRect(),o=r.getComputedStyle(e),s=r.getComputedStyle(n),c=parseFloat(s.height)||0,l=(parseFloat(s.width)||c*2)/2,u=parseFloat(o.borderTopWidth)||0,d=i.bottom<=a.top+1?`bottom`:i.top>=a.bottom-1?`top`:i.right<=a.left+1?`right`:i.left>=a.right-1?`left`:``;if(n.style.visibility=`hidden`,!d||!c)return;let f=d===`top`||d===`bottom`,p=Math.max(...[o.borderTopLeftRadius,o.borderTopRightRadius,o.borderBottomLeftRadius,o.borderBottomRightRadius].map(e=>parseFloat(e)||0)),m=f?i.width:i.height,h=p+l+u;if(m<h*2)return;let ee=f?i.left:i.top,g=f?a.left:a.top,_=f?a.right:a.bottom,v=Math.max(h,Math.min((g+_)/2-ee,m-h));if(v+ee<g||v+ee>_)return;n.dataset.side=d;let te=f?v-u:d===`left`?-u/2:i.width-u*1.5,y=f?d===`top`?-u/2:i.height-u*1.5:v-u;n.style.left=`${te}px`,n.style.top=`${y}px`,n.style.transform=`translateX(-50%) rotate(${d===`top`?180:d===`left`?90:d===`right`?-90:0}deg)`,n.style.visibility=`visible`}var To=new WeakMap;function Eo(e,t){for(;t;){if(t===e)return!0;t=`assignedSlot`in t&&t.assignedSlot||t.parentNode||(`host`in t?t.host:null)}return!1}var Do=class extends E{static properties={open:{type:Boolean,reflect:!0,noAccessor:!0},for:{type:String,reflect:!0}};static styles=[B,_a];#e=!1;#t=0;#n=0;#r=0;#i=!1;#a=null;#o={};#s={};#c=null;#l=``;#u=null;#d=null;#f=null;#p=`programmatic`;#m=0;#h=null;#g=!1;get open(){return this.#e}set open(e){let t=this.#e;this.#e=!!e,this.#t++,this.#n++,this.#e?(this.#p=`programmatic`,this.surface?.matches(`:popover-open`)||(this.#i=!1)):this.#g=!1,this.requestUpdate(`open`,t)}constructor(){super(),this.for=``}show(e=`programmatic`){return this.requestOpen(!0,e)}hide(e=`programmatic`){return this.requestOpen(!1,e)}requestOpen(e,t){if(e===this.open)return`unchanged`;let n=this.trigger,r=this.for,i=this.open,a=this.#i,o=this.#p,s=this.#g;this.#r++;try{return A(this,{previous:i,proposed:e,reason:t,getRevision:()=>this.#t,canCommit:()=>t!==`trigger`||this.for===r&&ya(this,r,n),stage:e=>{this.#e=e,e?(this.#g=t===`trigger`,this.surface?.matches(`:popover-open`)||(this.#i=!1)):this.#p=t},rollback:t=>{this.#e=t,this.#i=a,this.#p=o,this.#g=s,this.requestUpdate(`open`,e)},commit:()=>{this.#n++,this.requestUpdate(`open`,i)}})}finally{this.#r--,this.#r||this.requestUpdate(`open`,i)}}get surface(){return this.renderRoot?.querySelector(`[popover]`)??null}get trigger(){return this.#a}get movesFocus(){return!0}get openRevision(){return this.#n}get changingOpen(){return this.#r>0}get presentedOpen(){return this.#r?this.#i:this.open}get managesOwnPosition(){return!1}focusSurface(){this.surface?.focus({preventScroll:!0})}returnsFocus(e){return e!==`outside`}openerFor(e,t){return t?this.trigger:e&&`focus`in e?e:null}get activeElement(){let e=J(this)?.activeElement??Sa(this.ownerDocument);for(;e?.shadowRoot?.activeElement;)e=e.shadowRoot.activeElement;return e}get hasOpenPopoverForTrigger(){let e=this.trigger&&To.get(this.trigger);return!!(e&&[...e].some(e=>e!==this&&e.movesFocus&&e.open&&e.surface?.matches(`:popover-open`)))}triggerChanged(){}get triggerAttributes(){return{"aria-haspopup":`dialog`,"aria-expanded":String(this.open)}}connectedCallback(){super.connectedCallback(),this.updateComplete.then(()=>{this.isConnected&&(this.observeTrigger(),this.syncPopover())})}disconnectedCallback(){this.#u?.(),this.#u=null,this.#c=null,this.#l=``,this.stopListening(),this.detachTrigger();let e=this.surface;this.#i=!1,e?.matches(`:popover-open`)&&e.hidePopover(),this.#f=null,this.#g=!1,super.disconnectedCallback()}updated(e){this.observeTrigger(),this.syncTriggerAttributes(),this.syncPopover(),e.has(`arrow`)&&this.open&&(this.position(),this.startListening())}triggerClick=e=>{ba(e,ya(this,this.for,this.trigger))&&(this.open?this.hide(`trigger`):this.show(`trigger`))};connectTrigger(e){e.addEventListener(`click`,this.triggerClick)}disconnectTrigger(e){e.removeEventListener(`click`,this.triggerClick)}observeTrigger(){if(!this.isConnected)return;let e=J(this),t=typeof this.for==`string`?this.for:``;if(this.#u&&e===this.#c&&t===this.#l)return;this.#u?.(),this.#u=null,this.#c=e,this.#l=t;let n=Ii(e,t,this.acceptTrigger);!this.isConnected||J(this)!==e||this.for!==t?n():this.#u=n}acceptsTrigger(e){return e.namespaceURI===`http://www.w3.org/1999/xhtml`&&(e.localName===`button`||e.localName===`en-button`)}acceptTrigger=e=>{if(!this.isConnected)return;let t=e&&this.acceptsTrigger(e)?e:null;if(t!==this.#a){if(this.stopListening(),this.detachTrigger(),this.#a=t,t){this.#o=Object.fromEntries(Object.keys(this.triggerAttributes).map(e=>[e,t.getAttribute(e)]));let e=To.get(t);e||To.set(t,e=new Set),e.add(this),this.connectTrigger(t),this.syncTriggerAttributes()}this.surface?.matches(`:popover-open`)&&(this.position(),this.startListening()),this.syncPopover(),this.triggerChanged()}};detachTrigger(){let e=this.#a;if(!e)return;this.disconnectTrigger(e);let t=To.get(e);t?.delete(this),t?.size||To.delete(e);for(let[t,n]of Object.entries(this.#o))e.getAttribute(t)===this.#s[t]&&(n===null?e.removeAttribute(t):e.setAttribute(t,n));this.#o={},this.#s={},this.#a=null}syncTriggerAttributes(){let e=this.#a;if(!(!e||this.#r))for(let[t,n]of Object.entries(this.triggerAttributes))e.getAttribute(t)!==n&&e.setAttribute(t,n),this.#s[t]=n}syncPopover(){let e=this.surface;if(!e||!this.isConnected||this.#r)return;let t=e.matches(`:popover-open`);if(this.#i&&!t){this.reconcileNativeHide();return}if(this.open&&!t&&this.trigger?.isConnected){let t=this.activeElement;this.#f=this.openerFor(t,this.#g),this.#g=!1,this.movesFocus&&Y(e,!0),e.showPopover(),this.#i=!0,this.position(),this.startListening(),this.movesFocus&&this.focusSurface()}else if(!this.open&&t){let t=this.activeElement,n=Eo(e,t);this.#i=!1,e.hidePopover(),this.movesFocus&&Y(e,!1),this.stopListening(),this.movesFocus&&n&&this.returnsFocus(this.#p)&&Ca(this.#f),this.#f=null,this.#p=`programmatic`}this.open||(this.#g=!1)}nativeToggle=e=>{e.newState===`closed`&&this.isConnected&&this.#i&&!this.surface?.matches(`:popover-open`)&&this.reconcileNativeHide()};reconcileNativeHide(){this.#i=!1,this.movesFocus&&this.surface&&Y(this.surface,!1),this.open=!1,this.stopListening(),this.#f=null,this.#p=`programmatic`}position=()=>{let e=this.surface,t=this.trigger,n=this.ownerDocument.defaultView;if(!e||!t?.isConnected||!n||!this.open)return;let r=t.getBoundingClientRect(),i=this.ownerDocument.documentElement.clientWidth,a=this.ownerDocument.documentElement.clientHeight,o=e.getBoundingClientRect(),s=(parseFloat(n.getComputedStyle(e).rowGap)||0)+Co(e),c=n.getComputedStyle(this).direction===`rtl`?r.right-o.width:r.left,l=Math.max(s,Math.min(c,i-o.width-s)),u=r.bottom+s,d=u+o.height<=a-s?u:Math.max(s,r.top-o.height-s);e.style.left=`${l}px`,e.style.top=`${d}px`,e.style.right=`auto`,e.style.bottom=`auto`,wo(e,t)};#_=()=>{let e=this.ownerDocument.defaultView;!e||this.#m||(this.#m=e.requestAnimationFrame(()=>{this.#m=0,this.position()}))};#v=e=>{e.key!==`Escape`||e.defaultPrevented||!this.open||!this.movesFocus&&this.hasOpenPopoverForTrigger||(e.preventDefault(),this.hide(`escape`))};#y=e=>{let t=e.composedPath();!t.includes(this)&&(!this.trigger||!t.includes(this.trigger))&&this.hide(`outside`)};#b=e=>{let t=J(this);t&&t!==this.ownerDocument&&e.composedPath().includes(t.host)||this.#y(e)};startListening(){this.stopListening(),this.#d=new AbortController;let e={signal:this.#d.signal};this.addEventListener(`keydown`,this.#v,e),this.trigger?.addEventListener(`keydown`,this.#v,e);let t=J(this);if(t&&t!==this.ownerDocument&&t.addEventListener(`pointerdown`,this.#y,{...e,capture:!0}),this.ownerDocument.addEventListener(`pointerdown`,this.#b,{...e,capture:!0}),!this.managesOwnPosition){this.ownerDocument.addEventListener(`scroll`,this.#_,{...e,capture:!0,passive:!0}),this.ownerDocument.defaultView?.addEventListener(`resize`,this.#_,e),this.ownerDocument.defaultView?.visualViewport?.addEventListener(`resize`,this.#_,e),this.ownerDocument.defaultView?.visualViewport?.addEventListener(`scroll`,this.#_,e);let t=this.ownerDocument.defaultView?.ResizeObserver;if(t){if(this.#h=new t(this.#_),this.surface){this.#h.observe(this.surface);let e=this.surface.querySelector(`.en-overlay-arrow`);e&&this.#h.observe(e)}this.trigger&&this.#h.observe(this.trigger)}}}stopListening(){this.#d?.abort(),this.#d=null,this.#h?.disconnect(),this.#h=null,this.#m&&this.ownerDocument.defaultView?.cancelAnimationFrame(this.#m),this.#m=0}},Oo=class{#e;#t;#n=new Map;#r=new Map;#i=null;#a;#o=!1;#s=[];#c;constructor(e,t){this.#e=e,this.#t=t,e.addController(this)}get current(){return this.#i}hostConnected(){this.#o=!0,this.#a?.abort();let e=this.#e.ownerDocument.defaultView?.AbortController??globalThis.AbortController;this.#a=new e,this.#e.addEventListener(`keydown`,this.#h,{signal:this.#a.signal,capture:this.#t.keydownCapture}),this.#e.addEventListener(`focusin`,this.#p,{signal:this.#a.signal}),this.#t.recoverFocus&&this.#e.addEventListener(`focusout`,this.#m,{signal:this.#a.signal}),this.refresh()}hostUpdated(){this.#o&&this.refresh()}hostDisconnected(){this.#o=!1,this.#c=void 0,this.#s=[],this.#a?.abort(),this.#a=void 0;for(let[e,t]of this.#n)this.#f(e,t);this.#n.clear();for(let e of this.#r.values())e.release();this.#r.clear()}refresh(){let e=this.#t.items(),t=new Set(e);for(let[e,n]of this.#r)t.has(e)||(n.release(),this.#r.delete(e));for(let[e,n]of this.#n)t.has(e)||(this.#f(e,n),this.#n.delete(e));let n=this.#d(e);if(this.#t.recoverFocus){let e=n.find(e=>e.matches(`:focus-within`));e&&(this.#i=e,this.#c={item:e,root:this.#e.getRootNode()})}let r=this.#c,i=r&&!n.includes(r.item),a=i&&this.#u(r)?this.#l(n,r.item):null;a?this.#i=a:(!this.#i||!n.includes(this.#i))&&(this.#i=this.#l(n,this.#i)),this.#s=[...e];for(let t of e){let e=t===this.#i?0:-1;if(this.#t.claimTabStop){let n=this.#r.get(t);n||this.#r.set(t,n=this.#t.claimTabStop(t)),n.set(e)}else this.#n.has(t)||this.#n.set(t,t.getAttribute(`tabindex`)),t.tabIndex=e}i&&(this.#c=void 0),a&&r&&this.#u(r)?a.focus():i&&!n.length&&r&&this.#u(r)&&this.#t.focusEmpty?.()}#l(e,t){if(this.#t.recoverFocus&&t){let n=this.#s.indexOf(t);if(n!==-1){for(let t of this.#s.slice(n+1))if(e.includes(t))return t;for(let t of this.#s.slice(0,n).reverse())if(e.includes(t))return t}}return e[0]??null}#u(e){let t=this.#e.ownerDocument;if(!this.#t.recoverFocus||!this.#o||!this.#e.isConnected||this.#e.getRootNode()!==e.root||!t.hasFocus())return!1;let n=e.root.activeElement;if(n===e.item)return!0;let r=(e,n)=>n===null||e===t&&(n===t.body||n===t.documentElement);if(!r(e.root,n))return!1;let i=e.root;for(;i!==t;){let e=i,t=e.host.getRootNode();if(t.activeElement!==e.host&&!r(t,t.activeElement))return!1;i=t}return!0}setCurrent(e,{focus:t=!1}={}){return this.#d(this.#t.items()).includes(e)?(this.#i=e,this.refresh(),t&&e.focus(),!0):!1}#d(e){return e.filter(e=>!(this.#t.isDisabled?.(e)??e.matches(`[disabled], [aria-disabled="true"], [hidden], [inert]`)))}#f(e,t){t===null?e.removeAttribute(`tabindex`):e.setAttribute(`tabindex`,t)}#p=e=>{let t=this.#d(this.#t.items()),n=e.composedPath().find(e=>t.includes(e));this.#t.recoverFocus&&(this.#c=n?{item:n,root:this.#e.getRootNode()}:void 0),n&&(this.setCurrent(n),this.#t.onFocus?.(n))};#m=e=>{let t=this.#c;if(t&&e.composedPath().includes(t.item)){if(e.relatedTarget){this.#c=void 0;return}queueMicrotask(()=>{this.#c===t&&this.#d(this.#t.items()).includes(t.item)&&(this.#c=void 0)})}};#h=e=>{if(e.defaultPrevented||e.isComposing||e.altKey||e.ctrlKey||e.metaKey)return;let t=e.composedPath();if(t[0]?.matches?.(`input, textarea, select, [contenteditable]:not([contenteditable="false"])`))return;let n=this.#d(this.#t.items()),r=t.find(e=>n.includes(e));if(!r||!n.length)return;let i=this.#t.orientation??`horizontal`,a=this.#t.direction?.()??this.#e.ownerDocument.defaultView?.getComputedStyle(this.#e).direction??`ltr`,o=0,s=n.indexOf(r);if(e.key===`Home`)s=0;else if(e.key===`End`)s=n.length-1;else{if(i!==`vertical`&&e.key===`ArrowRight`&&(o=a===`rtl`?-1:1),i!==`vertical`&&e.key===`ArrowLeft`&&(o=a===`rtl`?1:-1),i!==`horizontal`&&e.key===`ArrowDown`&&(o=1),i!==`horizontal`&&e.key===`ArrowUp`&&(o=-1),!o)return;s=this.#t.wrap===!1?Math.max(0,Math.min(n.length-1,s+o)):(s+o+n.length)%n.length}e.preventDefault(),this.setCurrent(n[s],{focus:!0})}},ko=new WeakMap;function Ao(e,t){return ko.set(e,t),()=>{ko.get(e)===t&&ko.delete(e)}}function jo(e){return ko.get(e)}var Mo=new WeakMap;function No(e,t){Mo.set(e,t)}function Po(e){return Mo.get(e)}var Fo=class{host;options;abort;search=``;lastKey=0;constructor(e,t){this.host=e,this.options=t,e.addController(this)}hostConnected(){let e=this.host.ownerDocument.defaultView?.AbortController??globalThis.AbortController;this.abort=new e,this.host.addEventListener(`keydown`,this.keyDown,{signal:this.abort.signal})}hostDisconnected(){this.abort?.abort(),this.abort=void 0,this.search=``,this.lastKey=0}keyDown=e=>{if(e.defaultPrevented||e.isComposing||!this.options.open()||e.composedPath().find(e=>[`en-menu`,`en-context-menu`].includes(e.localName))!==this.host)return;if(e.key===`Tab`){this.options.closeForTab(e);return}if(e.altKey||e.ctrlKey||e.metaKey||!this.options.presented()||e.key.length!==1||e.key===` `)return;let t=this.options.items(),n=t.find(t=>e.composedPath().includes(t));if(!n||!t.length)return;let r=e.key.toLocaleLowerCase();this.search=e.timeStamp-this.lastKey>700?r:this.search+r,this.lastKey=e.timeStamp;let i=[...this.search].every(e=>e===r)?r:this.search,a=t.indexOf(n),o=[...t.slice(a+1),...t.slice(0,a+1)].find(e=>[...e.childNodes].filter(e=>e.nodeType!==1||!e.hasAttribute(`slot`)).map(e=>e.textContent??``).join(``).trim().toLocaleLowerCase().startsWith(i));o&&(e.preventDefault(),this.options.focus(o))}},Io=class{host;options;connected=!1;anchor=null;popup=null;measurement;view;geometry=``;originX;originY;presented;reason;constructor(e,t){this.host=e,this.options=t,e.addController(this)}hostConnected(){this.connected=!0}hostDisconnected(){this.connected=!1,this.stop()}hostUpdated(){this.sync()}sync(){let e=this.options.anchor(),t=this.options.popup();if(!this.connected||!this.options.open()||!t||typeof t.showPopover!=`function`||!t.matches(`:popover-open`)){this.stop();return}if(!e){this.stop(this.presented===`visible`);return}if(e!==this.anchor||t!==this.popup){let n=this.presented===`visible`;this.stop(n),n||t.style.setProperty(`--_en-menu-visibility`,`hidden`),this.anchor=e,this.popup=t;let r=e.ownerDocument.defaultView;if(!r)return;this.view=r,this.measurement=new qi(e,t,()=>this.connected&&this.options.open(),()=>this.position())}this.schedule()}schedule=()=>{this.measurement?.schedule()};position(){let e=this.anchor,t=this.popup,n=this.view;if(!e?.isConnected||!t?.isConnected||!n||typeof t.showPopover!=`function`||!t.matches(`:popover-open`))return;let r=n.getComputedStyle(t),i=parseFloat(r.rowGap)||0;if(this.options.adaptPresentation(n.visualViewport?.width??n.innerWidth,i))return;let a=e.getBoundingClientRect(),o=t.getBoundingClientRect(),s=o.height,c=t.scrollHeight+t.offsetHeight-t.clientHeight;this.originX=Ji(r.left,o.left,this.originX),this.originY=Ji(r.top,o.top,this.originY);let l=Yi(a,this.originX,this.originY),u=this.options.row()?.getBoundingClientRect().height??0,d=u+[r.paddingTop,r.paddingBottom,r.borderTopWidth,r.borderBottomWidth].reduce((e,t)=>e+(parseFloat(t)||0),0),{top:f,left:p,width:m,height:h}=Xi(n),{below:ee,above:g,useAbove:_}=Zi(l,{top:f,height:h},i,c),v=this.options.submenu(),te=this.options.replacement(),y=te?Math.max(0,f+h-l.top):v?h:_?g:ee,ne=l.width>0&&l.height>0&&l.right>p&&l.left<p+m&&l.bottom>f&&l.top<f+h,re=`${m}px`,ie=t.style.getPropertyValue(`--_en-menu-viewport-width`)!==re,ae=t.style.getPropertyValue(`--_en-menu-max-height`)!==`${y}px`,{presented:oe,state:se,reason:ce}=Qi({widthChanged:ie,heightChanged:ae,intersects:ne,width:m,height:h,rowHeight:u,available:y,minimumHeight:d,popupHeight:s}),le=se,ue=le===`pending`&&this.presented===`visible`,de=le===`suspended`&&this.options.unfit(ce);(de||ue)&&(le=`visible`);let fe=!this.options.open(),pe=Math.min(te?l.width:o.width,m),me=r.direction===`rtl`,b=me?l.left-i-pe:l.right+i,he=me?l.right+i:l.left-i-pe,ge=te?l.left:v?b>=p&&b+pe<=p+m?b:he:me?l.right-pe:l.left,_e={"--_en-menu-replacement-width":`${pe}px`,"--_en-menu-x":`${Math.max(p,Math.min(ge,p+m-pe))}px`,"--_en-menu-y":`${te?l.top:v?Math.max(f,Math.min(l.top,f+h-Math.min(s,y))):_?l.top-i-Math.min(s,y):l.bottom+i}px`,"--_en-menu-viewport-width":re,"--_en-menu-max-height":`${y}px`,"--_en-menu-visibility":fe?r.visibility:oe||de||ue?`visible`:`hidden`};for(let[e,n]of Object.entries(_e))t.style.getPropertyValue(e)!==n&&t.style.setProperty(e,n);(ie||ae)&&this.schedule(),this.setPresented(le,ce);let ve=[l.x,l.y,l.width,l.height,s,...Object.values(_e)].join(`/`);ve!==this.geometry&&(this.geometry=ve,(oe||de)&&this.options.resized())}setPresented(e,t){(e!==this.presented||t!==this.reason)&&(this.presented=e,this.reason=t,this.options.presented(e,t))}stop(e=!1){e||(this.setPresented(`pending`),this.presented=void 0,this.reason=void 0),this.measurement?.stop(),this.measurement=void 0,this.view=void 0,this.anchor=null,this.popup=null,this.geometry=``,this.originX=void 0,this.originY=void 0}},Lo=e=>S`
  <div class="en-menu" ?data-replaced=${e.replaced} ?data-replacement=${e.replacement} part="surface" popover="manual" role=${e.replaced?`presentation`:`menu`} aria-label=${e.replaced?T:e.label} tabindex="-1"
    inert @beforetoggle=${Bi} @toggle=${e.nativeToggle}>
    ${e.replacement?S`<button type="button" class="en-menu-back" part="back" role="menuitem" tabindex="-1" @click=${e.back}><svg class="en-menu-back-icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${Pa[`chevron-down`]}</svg><span>${e.backLabel}</span></button>`:T}
    <slot @slotchange=${e.childrenChanged}></slot>
  </div>`,Ro=class extends Do{static properties={...Do.properties,label:{type:String,useDefault:!0},backLabel:{type:String,attribute:`back-label`,useDefault:!0}};static styles=[B,fa];replacementMode=!1;touchPresentation=!1;lastPointerType;presentationOpen=!1;presentationParent=null;presentationTrigger=null;openingFromHover=!1;hoverTimer;pointerOrigin;pointerPoint;pendingHover;items=[];itemTriggerState;releases=new Map;mutation;shown=!1;entry=`first`;needsFocus=!1;entryFocus=null;layoutVetoRevision;upgrades=new d(this,()=>{this.readChildren(),this.syncTriggerAttributes()});triggerUpgrades=new d(this,()=>this.syncTriggerAttributes());roving=new Oo(this,{items:()=>this.focusItems,orientation:`vertical`,isDisabled:e=>!this.available(e),claimTabStop:Br,recoverFocus:!0,focusEmpty:()=>{this.open&&this.shown&&this.surface?.focus({preventScroll:!0})}});keys=new Fo(this,{open:()=>this.open,presented:()=>this.shown,items:()=>this.focusItems.filter(e=>this.available(e)),focus:e=>{this.roving.setCurrent(e,{focus:!0})},closeForTab:e=>this.closeForTab(e)});placementController=new Io(this,{anchor:()=>this.replacementMode&&this.parentMenu?this.parentMenu.surface:this.positionAnchor,popup:()=>this.surface,open:()=>this.presentedOpen,submenu:()=>this.parentMenu!==null,adaptPresentation:(e,t)=>this.adaptPresentation(e,t),replacement:()=>this.replacementMode&&this.parentMenu!==null,row:()=>this.focusItems.find(e=>!e.hidden&&!e.inert&&e.getClientRects().length>0)??null,resized:()=>this.revealCurrent(),unfit:()=>this.layoutVetoRevision===this.openRevision?this.open:(this.hide(`layout`),this.open?(this.layoutVetoRevision=this.openRevision,!0):!1),presented:e=>{if(this.shown=e===`visible`,this.parentMenu?.requestUpdate(),this.shown&&(this.roving.refresh(),this.needsFocus&&this.open)){let e=this.focusItems.filter(e=>this.available(e)),t=this.entry===`last`?e.at(-1):e[0],n=this.activeElement===this.entryFocus;this.needsFocus=!1,this.entryFocus=null,n&&(t?this.roving.setCurrent(t,{focus:!0}):this.surface?.focus({preventScroll:!0}))}}});owner={ready:()=>this.open&&this.shown&&!this.changingOpen,owns:e=>e.parentElement===this&&!e.slot&&this.items.includes(e),capture:()=>{let e=[],t=this;for(;t;)e.push({menu:t,revision:t.openRevision,parent:t.parentMenu,trigger:t.trigger,forId:t.for}),t=t.parentMenu;return()=>{e.every(({menu:e,revision:t,parent:n,trigger:r,forId:i})=>e.isConnected&&e.open&&e.openRevision===t&&e.parentMenu===n&&e.trigger===r&&e.for===i)&&e.at(-1).menu.hide(`action`)}},accepted:e=>e(),radioPeers:e=>this.items.filter(t=>t!==e&&this.owner.owns(t)&&t.type===`radio`&&t.name===e.name).flatMap(e=>{let t=Po(e);return t?[t]:[]}),radioSelected:e=>{if(this.owner.owns(e))for(let t of this.owner.radioPeers(e))t.write(!1)}};get parentMenu(){let e=this.parentElement;return(e?.localName===`en-menu`||e?.localName===`en-context-menu`)&&`show`in e&&this.trigger?.parentElement===e?e:null}get childMenus(){return[...this.children??[]].filter(e=>e.localName===`en-menu`&&`hide`in e)}get positionAnchor(){return this.trigger}acceptsTrigger(e){return super.acceptsTrigger(e)||e.localName===`en-menu-item`&&e.parentElement===this.parentElement&&(this.parentElement?.localName===`en-menu`||this.parentElement?.localName===`en-context-menu`)}requestOpen(e,t){if(e&&!this.open&&this.readPresentationMode(),e&&this.parentMenu&&(!this.parentMenu.open||!this.parentMenu.shown))return`unchanged`;let n=super.requestOpen(e,t);if(n===`committed`){if(!this.open)for(let e of this.childMenus)e.open=!1;else if(this.parentMenu)for(let e of this.parentMenu.childMenus)e!==this&&e.open&&(e.open=!1,e.syncPopover())}return this.open||this.parentMenu?.surface?.removeAttribute(`data-replaced`),this.parentMenu?.requestUpdate(),n}submenuKeyDown=e=>{if(e.defaultPrevented||e.isComposing||e.altKey||e.ctrlKey||e.metaKey||!this.open||e.composedPath().find(e=>[`en-menu`,`en-context-menu`].includes(e.localName))!==this)return;let t=this.ownerDocument.defaultView?.getComputedStyle(this).direction===`rtl`?`ArrowRight`:`ArrowLeft`;this.parentMenu&&e.key===t&&(e.preventDefault(),this.hide(`back`))};constructor(){super(),this.label=``,this.backLabel=`Back`}get managesOwnPosition(){return!0}get triggerAttributes(){return zo(this.trigger)?{}:{"aria-haspopup":`menu`,"aria-expanded":String(this.open)}}syncTriggerAttributes(){if(this.triggerUpgrades.watch(this.trigger?[this.trigger]:[]),!zo(this.trigger)){super.syncTriggerAttributes();return}if(this.changingOpen)return;let e=this.trigger;if(`updateComplete`in e){if(!e.hasUpdated){e.updateComplete.then(()=>{this.isConnected&&this.trigger===e&&this.syncTriggerAttributes()});return}e.menuHasPopup=`menu`,e.menuExpanded=String(this.open),this.itemTriggerState&&(this.itemTriggerState.writtenExpanded=e.menuExpanded)}}returnsFocus(e){return e!==`outside`&&e!==`tab`&&e!==`hover`}openerFor(e,t){return this.parentMenu?this.trigger:super.openerFor(e,t)}focusSurface(){this.openingFromHover||(this.needsFocus=!0,this.entryFocus=this.activeElement)}position=()=>{this.placementController.sync()};triggerClick=e=>{if(ba(e,ya(this,this.for,this.trigger))&&(this.entry=`first`,this.open||(this.layoutVetoRevision=void 0),!(!this.trigger?.isConnected||this.trigger.disabled||this.trigger.loading||this.trigger.matches(`:disabled,[aria-disabled="true"]`)))){if(this.open&&zo(this.trigger)){if(this.shown){let e=this.focusItems.find(e=>this.available(e));e&&this.roving.setCurrent(e,{focus:!0})}else this.needsFocus=!0,this.entryFocus=this.activeElement}else this.open?this.hide(`trigger`):this.show(`trigger`)}};connectTrigger(e){if(zo(e)){let t=e;this.itemTriggerState={item:t,popup:t.menuHasPopup,expanded:t.menuExpanded,writtenExpanded:String(this.open)}}super.connectTrigger(e),e.addEventListener(`keydown`,this.triggerKeyDown)}disconnectTrigger(e){super.disconnectTrigger(e),e.removeEventListener(`keydown`,this.triggerKeyDown);let t=this.itemTriggerState;t?.item===e&&(t.item.menuHasPopup===`menu`&&(t.item.menuHasPopup=t.popup),t.item.menuExpanded===t.writtenExpanded&&(t.item.menuExpanded=t.expanded),this.itemTriggerState=void 0)}triggerKeyDown=e=>{if(!(e.defaultPrevented||e.isComposing)){if(e.key===`Tab`&&this.open){this.closeForTab(e);return}if(zo(this.trigger)){let t=this.ownerDocument.defaultView?.getComputedStyle(this).direction===`rtl`?`ArrowLeft`:`ArrowRight`;if(e.key!==t||e.altKey||e.ctrlKey||e.metaKey||this.trigger?.disabled)return;if(e.preventDefault(),this.entry=`first`,this.open&&this.shown){let e=this.items.find(e=>this.available(e));e&&this.roving.setCurrent(e,{focus:!0})}else this.show(`trigger`);return}if(!(e.altKey||e.ctrlKey||e.metaKey||![`ArrowDown`,`ArrowUp`].includes(e.key))&&!(this.trigger?.disabled||this.trigger?.loading||this.trigger?.matches(`:disabled,[aria-disabled="true"]`))){if(e.preventDefault(),this.entry=e.key===`ArrowUp`?`last`:`first`,this.open&&this.shown){let e=this.items.filter(e=>this.available(e)),t=this.entry===`last`?e.at(-1):e[0];t&&this.roving.setCurrent(t,{focus:!0})}else this.layoutVetoRevision=void 0,this.show(`trigger`)}}};closeForTab(e){if(this.parentMenu){let t=this.parentMenu;for(;t.parentMenu;)t=t.parentMenu;t.closeForTab(e),e.stopPropagation();return}let t=this.activeElement,n=this.trigger,r=t!==null&&e.composedPath().includes(t);this.hide(`tab`)===`committed`&&!this.open&&r&&this.activeElement===t&&this.trigger===n&&(this.syncPopover(),Ca(n),e.shiftKey&&n&&(this.activeElement===n||this.activeElement===n.shadowRoot?.activeElement)&&e.preventDefault())}connectedCallback(){super.connectedCallback(),this.addEventListener(`keydown`,this.submenuKeyDown),this.addEventListener(`pointermove`,this.pointerMove),this.addEventListener(`pointerover`,this.pointerOver),this.addEventListener(`pointerdown`,this.pointerDown),this.addEventListener(`pointerout`,this.pointerOut);let e=this.ownerDocument.defaultView?.MutationObserver;e&&(this.mutation=new e(()=>this.readChildren()),this.mutation.observe(this,{childList:!0,subtree:!0,attributes:!0,attributeFilter:[`slot`,`hidden`,`inert`,`disabled`,`action`,`type`,`name`,`checked`,`for`,`id`]}))}disconnectedCallback(){let e=this.presentationParent,t=this.presentationTrigger,n=this.open&&this.replacementMode&&this.ownerDocument.activeElement===this.ownerDocument.body;e?.surface?.removeAttribute(`data-replaced`),e?.requestUpdate(),n&&e?.open&&Ca(t),this.presentationParent=null,this.presentationTrigger=null,this.removeEventListener(`keydown`,this.submenuKeyDown),this.removeEventListener(`pointermove`,this.pointerMove),this.removeEventListener(`pointerover`,this.pointerOver),this.removeEventListener(`pointerdown`,this.pointerDown),this.removeEventListener(`pointerout`,this.pointerOut),this.clearHover(),this.mutation?.disconnect(),this.mutation=void 0;for(let e of this.releases.values())e();this.releases.clear(),this.items=[],this.needsFocus=!1,this.entryFocus=null,this.shown=!1,this.layoutVetoRevision=void 0,super.disconnectedCallback()}updated(e){if(this.open&&!this.presentationOpen&&(this.readPresentationMode(),this.requestUpdate()),this.presentationOpen=this.open,this.readChildren(),super.updated(e),!this.open){for(let e of this.childMenus)e.open&&(e.open=!1,e.syncPopover());this.shown=!1,this.needsFocus=!1,this.entryFocus=null,this.layoutVetoRevision=void 0}this.parentMenu?.requestUpdate(),this.placementController.sync()}available(e){if(!e.isConnected||!e.getClientRects().length)return!1;let t=e;for(;t;){if(t instanceof this.ownerDocument.defaultView.HTMLElement&&(t.hidden||t.inert))return!1;t=`assignedSlot`in t&&t.assignedSlot||t.parentNode||(`host`in t?t.host:null)}return this.ownerDocument.defaultView?.getComputedStyle(e).visibility!==`hidden`}readChildren=()=>{let e=this.renderRoot?.querySelector(`slot:not([name])`);this.upgrades.watch(e?.assignedElements()??[]);let t=(e?.assignedElements()??[]).filter(e=>e.localName===`en-menu-item`&&`action`in e);for(let[e,n]of this.releases)t.includes(e)||(n(),this.releases.delete(e));let n=t.filter(e=>!this.releases.has(e));this.items=t;for(let e of t)this.releases.has(e)||this.releases.set(e,Ao(e,this.owner));for(let e of n)e.type===`radio`&&e.checked&&this.owner.radioSelected(e);for(let e of this.childMenus)e.open&&(!e.trigger?.isConnected||!t.includes(e.trigger)||e.trigger.disabled||e.trigger.hidden||e.trigger.inert)&&(e.open=!1,e.syncPopover());this.surface?.toggleAttribute(`data-replaced`,this.childMenus.some(e=>e.open&&e.replacementMode&&e.shown)),this.roving.refresh(),this.placementController.sync()};revealCurrent(){let e=this.roving.current,t=this.surface;if(!this.shown||!e||!t)return;let n=t.getBoundingClientRect(),r=e.getBoundingClientRect();r.top<n.top?t.scrollTop-=n.top-r.top:r.bottom>n.bottom&&(t.scrollTop+=r.bottom-n.bottom)}readPresentationMode(){let e=this.parentMenu;this.presentationParent=e,this.presentationTrigger=this.trigger,this.touchPresentation=!!(e&&(e.lastPointerType?e.lastPointerType===`touch`:e.touchPresentation||this.ownerDocument.defaultView?.matchMedia(`(hover: none), (pointer: coarse)`).matches));let t=this.ownerDocument.defaultView,n=e?.surface&&t&&parseFloat(t.getComputedStyle(e.surface).rowGap)||0;this.adaptPresentation(t?.visualViewport?.width??t?.innerWidth??0,n)}adaptPresentation(e,t){let n=this.parentMenu,r=n?.surface?.getBoundingClientRect().width??0,i=!!(n&&(this.touchPresentation||e+.5<r*2+t));if(i===this.replacementMode)return!1;let a=this.renderRoot?.querySelector(`.en-menu-back`),o=!i&&a===this.activeElement,s=i&&n?.focusItems.some(e=>e.matches(`:focus-within`));if(this.replacementMode=i,this.open&&this.shown&&(o||s)){let e=this.items.find(e=>this.available(e));e?this.roving.setCurrent(e,{focus:!0}):this.surface?.focus({preventScroll:!0})}return this.requestUpdate(),n?.requestUpdate(),!0}get focusItems(){let e=this.renderRoot?.querySelector(`.en-menu-back`);return e&&this.replacementMode&&this.parentMenu?[e,...this.items]:this.items}back=()=>{this.hide(`back`)};pointerDown=e=>{e.composedPath().find(e=>[`en-menu`,`en-context-menu`].includes(e.localName))===this&&(this.lastPointerType=e.pointerType)};clearHover(){this.hoverTimer&&clearTimeout(this.hoverTimer),this.hoverTimer=void 0,this.pendingHover=void 0}pointerMove=e=>{if(e.pointerType!==`mouse`)return;this.lastPointerType=`mouse`,this.pointerPoint={x:e.clientX,y:e.clientY};let t=e.composedPath().find(e=>this.items.includes(e)),n=this.childMenus.find(e=>e.open);t&&n?.trigger===t&&(this.pointerOrigin=this.pointerPoint),this.pendingHover&&!this.inSafeTriangle()&&this.activateHover(this.pendingHover)};inSafeTriangle(){let e=this.childMenus.find(e=>e.open),t=this.pointerOrigin,n=this.pointerPoint,r=e?.surface?.getBoundingClientRect();if(!r||!t||!n)return!1;if(n.x>=r.left&&n.x<=r.right&&n.y>=r.top&&n.y<=r.bottom)return!0;let i=Math.abs(t.x-r.left)<Math.abs(t.x-r.right)?r.left:r.right,a={x:i,y:r.top-8},o={x:i,y:r.bottom+8},s=(e,t,n)=>(e.x-n.x)*(t.y-n.y)-(t.x-n.x)*(e.y-n.y),c=s(n,t,a),l=s(n,a,o),u=s(n,o,t);return!((c<0||l<0||u<0)&&(c>0||l>0||u>0))}pointerOut=e=>{let t=e.relatedTarget;(!ka(t)||!this.contains(t))&&this.clearHover()};pointerOver=e=>{if(e.pointerType!==`mouse`||!this.open||!this.shown)return;if(e.composedPath().find(e=>[`en-menu`,`en-context-menu`].includes(e.localName))!==this){this.clearHover();return}let t=e.composedPath().find(e=>this.items.includes(e));if(!t||ka(e.relatedTarget)&&(t===e.relatedTarget||t.contains(e.relatedTarget)))return;this.pointerPoint={x:e.clientX,y:e.clientY};let n=this.childMenus.find(e=>e.open);if(n?.trigger===t){this.clearHover(),this.pointerOrigin=this.pointerPoint;return}this.clearHover(),n&&this.inSafeTriangle()?(this.pendingHover=t,this.hoverTimer=setTimeout(()=>{this.pendingHover&&this.activateHover(this.pendingHover)},350)):this.activateHover(t)};activateHover(e){if(this.clearHover(),!this.open||!this.shown||!this.items.includes(e))return;let t=this.childMenus.find(t=>t.trigger===e);for(let e of this.childMenus)if(e!==t&&e.open&&(e.hide(`hover`),e.open))return;if(t&&!e.disabled){if(t.readPresentationMode(),t.replacementMode)return;t.openingFromHover=!0,t.show(`hover`),t.updateComplete.then(()=>{t.openingFromHover=!1}),this.pointerOrigin=this.pointerPoint}}render(){return Lo({label:this.label,backLabel:this.backLabel,back:this.back,replacement:this.replacementMode&&this.parentMenu!==null,replaced:this.childMenus.some(e=>e.open&&e.replacementMode&&e.shown),nativeToggle:this.nativeToggle,childrenChanged:this.readChildren})}};function zo(e){return e?.localName===`en-menu-item`}n(customElements,{tagName:`en-menu`,elementClass:Ro});var Bo=e=>S`
  <button class="en-menu-item" part=${e.disabled?`control option option-disabled`:`control option`}
    type="button" role=${e.type===`checkbox`?`menuitemcheckbox`:e.type===`radio`?`menuitemradio`:`menuitem`}
    aria-checked=${G(e.type===`checkbox`||e.type===`radio`?String(e.checked):void 0)}
    aria-haspopup=${G(e.hasPopup)} aria-expanded=${G(e.hasPopup?e.expanded:void 0)} aria-disabled=${String(e.disabled)} tabindex=${e.tabStop}
    @click=${e.activate}>
    ${e.type===`checkbox`||e.type===`radio`?S`<span class="en-menu-item-check" part="checkmark" aria-hidden="true">${e.checked?e.type===`radio`?S`<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="4" /></svg>`:S`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${Pa.check}</svg>`:T}</span>`:T}
    <slot class="en-menu-item-prefix" name="prefix" aria-hidden="true"></slot>
    <span class="en-menu-item-label" part="label"><slot></slot></span>
    <slot class="en-menu-item-suffix" name="suffix" aria-hidden="true"></slot>
    ${e.hasPopup===`menu`?S`<span class="en-menu-item-submenu" part="submenu-indicator" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${Pa[`chevron-down`]}</svg></span>`:T}
    <slot class="en-menu-item-shortcut" part="shortcut" name="shortcut"></slot>
  </button>`;n(customElements,{tagName:`en-menu-item`,elementClass:class extends E{static properties={action:{type:String},type:{type:String,reflect:!0},name:{type:String},checked:{type:Boolean,reflect:!0,noAccessor:!0},menuHasPopup:{type:String,attribute:`aria-haspopup`},menuExpanded:{type:String,attribute:`aria-expanded`},disabled:{type:Boolean,reflect:!0}};static styles=[B,z,pa];#e=!1;#t=0;#n=0;get checked(){return this.#e}set checked(e){let t=this.#e;this.#e=!!e,this.#t++,this.#n++,this.requestUpdate(`checked`,t),this.#e&&this.type===`radio`&&jo(this)?.radioSelected(this)}tabStop=0;constructor(){super(),this.action=``,this.disabled=!1,this.type=`command`,this.name=``,No(this,{element:this,checked:()=>this.#e,revision:()=>this.#n,stage:e=>{let t=this.#e;this.#e=e,this.requestUpdate(`checked`,t)},write:e=>{this.checked=e}}),zr(this,e=>{if(this.tabStop===e)return;this.tabStop=e;let t=this.renderRoot?.querySelector(`button`);t&&(t.tabIndex=e),this.requestUpdate()})}updated(e){(e.has(`type`)||e.has(`name`))&&this.checked&&this.type===`radio`&&jo(this)?.radioSelected(this)}focus(e){this.renderRoot?.querySelector(`button`)?.focus(e)}activate=e=>{if(e.defaultPrevented||this.disabled||!this.isConnected||this.menuHasPopup===`menu`)return;let t=jo(this);if(t&&(!t.ready()||!t.owns(this)))return;let n=this.parentElement;if(this.type===`checkbox`||this.type===`radio`){let r=this.#e,i=this.type===`radio`||!r;if(r===i)return;let a=this.type,o=this.name,s=(a===`radio`?t?.radioPeers(this)??[]:[]).map(e=>({state:e,checked:e.checked(),revision:e.revision()})),c=()=>{for(let e of s)e.state.revision()===e.revision&&e.state.stage(e.checked)},l=A(this,{previous:r,proposed:i,reason:`checked`,getRevision:()=>this.#t,stage:e=>{this.#e=e;for(let e of s)e.state.stage(!1)},rollback:e=>{this.#e=e,c()},canCommit:()=>!this.disabled&&this.isConnected&&this.type===a&&this.name===o&&this.parentElement===n&&jo(this)===t&&(!t||t.owns(this))&&s.every(e=>e.state.revision()===e.revision&&e.state.element.isConnected)&&(a!==`radio`||(t?.radioPeers(this)??[]).length===s.length&&(t?.radioPeers(this)??[]).every(e=>s.some(t=>t.state===e))),commit:()=>{this.#n++,a===`radio`&&t?.radioSelected(this)}});l===`superseded`&&c(),l===`canceled`&&e.preventDefault(),this.requestUpdate(`checked`,r);return}if(!this.action)return;let r=t?.capture(),i=this.action,a=un(this,{action:i,data:void 0},{cancelable:!0});a||e.preventDefault(),a&&!this.disabled&&this.action===i&&t&&r!==void 0&&jo(this)===t&&t.owns(this)&&this.parentElement===n&&this.isConnected&&t.accepted(r)};render(){return Bo({disabled:this.disabled||this.type!==`checkbox`&&this.type!==`radio`&&!this.action&&this.menuHasPopup!==`menu`,type:this.type,checked:this.checked,hasPopup:this.menuHasPopup,expanded:this.menuExpanded,tabStop:this.tabStop,activate:this.activate})}}});var Vo=class{host;value=!1;revision=0;constructor(e){this.host=e}write(e){let t=this.value;this.value=e,this.revision++,this.host.requestUpdate(`open`,t)}propose(e,t){let n=this.value;return A(this.host,{previous:n,proposed:e,reason:t,getRevision:()=>this.revision,stage:e=>{this.value=e},rollback:e=>{this.value=e},commit:()=>{this.host.requestUpdate(`open`,n),this.notify()}})}notify(){fn(this.host,`en-toggle`,{open:this.value})}};function Ho({label:e}){return S`
		<nav class="en-section-nav" part="base" aria-label=${e}>
			<slot></slot>
		</nav>
	`}n(customElements,{tagName:`en-navigation`,elementClass:class extends E{static properties={label:{type:String,useDefault:!0},sticky:{type:Boolean,reflect:!0,useDefault:!0},layout:{type:String,reflect:!0},collapseAt:{type:String,attribute:`collapse-at`},open:{type:Boolean,reflect:!0,noAccessor:!0},compact:{state:!0},ready:{state:!0}};static styles=[B,z,br,xr,Sr];get open(){return this.disclosure.value}set open(e){this.disclosure.write(e)}requestOpen(e){return this.disclosure.propose(!!e,`api`)}disclosure=new Vo(this);media;observer;lastCurrent;constructor(){super(),this.label=`Navigation`,this.sticky=!1,this.layout=`inline`,this.collapseAt=``,this.open=!1,this.compact=!1,this.ready=!1}connectedCallback(){super.connectedCallback(),this.observer=new MutationObserver(()=>this.syncCurrent()),this.observer.observe(this,{subtree:!0,childList:!0,attributes:!0,attributeFilter:[`aria-current`,`hidden`]}),this.hasUpdated&&(this.configureMedia(),this.syncCurrent())}disconnectedCallback(){this.observer?.disconnect(),this.media?.removeEventListener(`change`,this.resize),super.disconnectedCallback()}firstUpdated(){this.configureMedia(),this.syncCurrent()}updated(e){e.has(`collapseAt`)&&this.ready&&this.configureMedia()}willUpdate(e){e.has(`open`)&&!this.open&&this.compact&&this.contains(this.ownerDocument.activeElement)&&this.summary()?.focus()}summary(){return this.renderRoot.querySelector(`summary`)}current(){return[...this.querySelectorAll(`a[aria-current]:not([aria-current="false"])`)].find(e=>e.closest(`en-navigation`)===this&&!e.closest(`[hidden]`))}syncCurrent(){let e=this.current();e!==this.lastCurrent&&(this.lastCurrent=e,this.revealCurrent())}revealCurrent(){let e=this.current();for(let t=e?.parentElement;t&&t!==this;t=t.parentElement)t.localName===`en-navigation-group`&&(t.setAttribute(`open`,``),t.open=!0)}configureMedia(){this.media?.removeEventListener(`change`,this.resize),this.media=this.collapseAt?this.ownerDocument.defaultView?.matchMedia(`(max-width: ${this.collapseAt})`):void 0,this.media?.addEventListener(`change`,this.resize),this.resize(),this.ready=!0}resize=()=>{let e=this.media?.matches??!1,t=this.summary(),n=!!t&&this.shadowRoot?.activeElement===t;e&&!this.compact&&this.contains(this.ownerDocument.activeElement)&&(this.open=!0),this.compact=e,!e&&n&&this.updateComplete.then(()=>{this.revealCurrent(),requestAnimationFrame(()=>{let e=[this.current(),...this.querySelectorAll(`a[href], en-navigation-group`)];for(let t of e){let e=t?.localName===`en-navigation-group`?t.shadowRoot?.querySelector(`summary`):t;if(e?.getClientRects().length){e.focus();break}}})})};activateSummary=e=>{if(!this.ready||!this.compact||e.defaultPrevented)return;e.preventDefault(),this.disclosure.propose(!this.open,`toggle`);let t=this.renderRoot.querySelector(`details`);t&&(t.open=this.open)};toggled=e=>{if(!this.ready||!this.compact)return;let t=e.currentTarget.open;t!==this.open&&(this.open=t,this.disclosure.notify())};keydown=e=>{let t=this.renderRoot.querySelector(`details`);e.key===`Escape`&&!e.defaultPrevented&&this.compact&&t?.open&&(e.preventDefault(),e.stopPropagation(),this.disclosure.propose(!1,`escape`),t.open=this.open,this.open||this.summary()?.focus())};render(){return this.collapseAt?S`<details part="disclosure" ?open=${!this.ready||!this.compact||this.open} @toggle=${this.toggled} @keydown=${this.keydown}>
      <summary @click=${this.activateSummary} part="control" ?hidden=${this.ready&&!this.compact}>${this.label}</summary>
      ${Ho({label:this.label})}
    </details>`:Ho({label:this.label})}}});var Uo={tagName:`en-number-field`,elementClass:class extends Q{static properties={...Q.properties,min:{type:Number},max:{type:Number},step:{type:Number},decrementLabel:{type:String,attribute:`decrement-label`},incrementLabel:{type:String,attribute:`increment-label`}};constructor(){super(),this.min=void 0,this.max=void 0,this.step=1,this.decrementLabel=`Decrease value`,this.incrementLabel=`Increase value`}stepValue(e){let t=this.controlNode;if(!t||this.isDisabled||this.readOnly||this.model.isComposing.get())return;let n=t.cloneNode();n.value=t.value,e<0?n.stepDown():n.stepUp(),this.requestValue(n.value,e<0?`decrement`:`increment`)}renderControlFrame(){return this.renderControl()}renderControl(){let e=this.model.draft.get(),t=e===``?void 0:Number(e),n=this.isDisabled||this.readOnly||t!==void 0&&this.min!==void 0&&t<=this.min,r=this.isDisabled||this.readOnly||t!==void 0&&this.max!==void 0&&t>=this.max;return S`<div class="en-input-group en-number-group en-field-focus-frame" part="stepper focus-frame" data-invalid=${this.visibleError?``:T}>
      <button class="en-button en-button--quiet en-icon-button en-number-step en-number-decrement" part="decrement" type="button"
        ?disabled=${n} @click=${()=>this.stepValue(-1)}><span class="en-sr-only"><slot name="decrement-label">${this.decrementLabel}</slot></span><span aria-hidden="true">−</span></button>
      <input id="control" class="en-input en-number-input" part="control" type="number" name=${this.name}
        value=${this.defaultControlValue} min=${this.min??T} max=${this.max??T} step=${this.step}
        placeholder=${this.placeholder||T} autocomplete=${this.autocomplete||T}
        inputmode=${this.inputMode||T} ?disabled=${this.isDisabled} ?readonly=${this.readOnly} ?required=${this.required}
        aria-describedby=${this.describedBy} aria-invalid=${this.controlAriaInvalid}>
      <button class="en-button en-button--quiet en-icon-button en-number-step en-number-increment" part="increment" type="button"
        ?disabled=${r} @click=${()=>this.stepValue(1)}><span class="en-sr-only"><slot name="increment-label">${this.incrementLabel}</slot></span><span aria-hidden="true">+</span></button>
    </div>`}}};n(customElements,Uo);function Wo(e){return S`
    <div class="en-popover" part="surface" ?data-arrow=${e.arrow} popover="manual" role="dialog" aria-labelledby="en-popover-heading" tabindex="-1" inert @beforetoggle=${Bi} @toggle=${e.nativeToggle}>
      ${So(!!e.arrow,e.arrowPath)}
      <div class="en-overlay-content" part="content">
      <h2 id="en-popover-heading" class="en-heading-small" part="heading"><slot name="label">${e.label}</slot></h2>
      <div class="en-overlay-body" part="body"><slot></slot></div>
      <button class="en-button en-button--quiet en-overlay-close" part="close" type="button" @click=${e.dismiss}>${e.closeLabel}</button>
      </div>
    </div>`}var Go={tagName:`en-popover`,elementClass:class extends Do{static styles=[...Do.styles,jn,Si];static properties={...Do.properties,arrow:{type:Boolean,reflect:!0},arrowPath:{type:String,attribute:`arrow-path`},label:{type:String,useDefault:!0},closeLabel:{type:String,attribute:`close-label`,useDefault:!0}};constructor(){super(),this.arrow=!1,this.arrowPath=`M0 0 L8 8 L16 0`,this.label=``,this.closeLabel=`Close`}render(){return Wo({arrow:this.arrow,arrowPath:this.arrowPath,label:this.label,closeLabel:this.closeLabel,dismiss:()=>this.hide(`close-button`),nativeToggle:this.nativeToggle})}}};n(customElements,Go);var Ko=e=>S`
  <progress
    class="en-progress"
    part="track"
    max=${e.max}
    value=${G(e.value)}
    aria-label=${G(e.label||void 0)}
  ></progress>
`,qo={tagName:`en-progress-bar`,elementClass:class extends E{static properties={value:{type:Number},shape:{reflect:!0},max:{type:Number},label:{type:String}};static styles=[B,z,Yn,_`
    .circle { display:inline-grid; place-items:center; inline-size:var(--en-size-control-min); block-size:var(--en-size-control-min); position:relative; color:var(--en-progress-color,var(--en-color-action)); }
    .circle progress { position:absolute; inline-size:1px; block-size:1px; clip-path:inset(50%); overflow:hidden; }
    svg { inline-size:100%; block-size:100%; rotate:-90deg; }
    circle { fill:none; stroke-width:4; }
    .track { stroke:var(--en-progress-track-color,var(--en-color-boundary)); }
    .value { stroke:currentColor; stroke-linecap:round; }
    .indeterminate { animation:progress-turn 1s linear infinite; }
    @keyframes progress-turn { to { transform:rotate(360deg); } }
    @media(prefers-reduced-motion:reduce) { .indeterminate { animation:none; } }
    @media(forced-colors:active) { .track { stroke:CanvasText; } .value { stroke:Highlight; } }
  `];constructor(){super(),this.value=void 0,this.shape=`bar`,this.max=100,this.label=``}render(){let e=Number.isFinite(this.max)&&this.max>0?this.max:100,t=this.value===void 0||!Number.isFinite(this.value)?void 0:Math.max(0,Math.min(e,this.value)),n=Ko({value:t,max:e,label:this.label});return this.shape===`circle`?S`<span class="circle" part="circle">${n}<svg viewBox="0 0 40 40" aria-hidden="true" class=${t===void 0?`indeterminate`:T}><circle class="track" cx="20" cy="20" r="16"></circle><circle class="value" cx="20" cy="20" r="16" pathLength="100" stroke-dasharray=${`${t===void 0?25:t/e*100} 100`}></circle></svg></span>`:n}}};n(customElements,qo),n(customElements,{tagName:`en-radio`,elementClass:class extends Ai{owner;groupDisabled=!1;groupTabIndex=0;get kind(){return`radio`}get effectiveDisabled(){return super.effectiveDisabled||this.groupDisabled}get controlTabIndex(){return this.groupTabIndex}get radioValidationAnchor(){return this.nativeControl??void 0}setRadioOwner(e,t,n,r){let i=this.owner!==e||this.groupDisabled!==n||this.groupTabIndex!==r;this.owner=e,this.groupDisabled=n,this.groupTabIndex=r,this.checked!==t&&this.setChecked(t),i&&this.requestUpdate(),this.syncControl(),this.syncForm()}handleChange(e){if(!this.owner){super.handleChange(e);return}e.preventDefault(),e.stopPropagation(),this.effectiveDisabled||this.owner.requestRadioSelection(this),this.syncControl()}get formValue(){return this.owner?null:super.formValue}formValidation(){return this.owner?{flags:{}}:super.formValidation()}formResetCallback(){this.owner||super.formResetCallback()}formStateRestoreCallback(e,t=`restore`){this.owner||super.formStateRestoreCallback(e,t)}updated(e){super.updated(e),(e.has(`disabled`)||e.has(`value`)||e.has(`checked`))&&this.owner?.radioConfigurationChanged()}}});function Jo(e,t,n){return S`<div part="field" class="en-field">
    <div id="label" part="label" class="en-label"><slot name="label">${e.label}</slot></div>
    <div part="options" class="en-choice-group" data-orientation=${e.orientation} role="radiogroup"
      aria-labelledby="label" aria-describedby=${e.error?`description error`:`description`} aria-invalid=${e.error?`true`:T}
      aria-orientation=${e.orientation} aria-disabled=${e.disabled?`true`:T}
      aria-required=${e.required?`true`:T} @keydown=${n}>
      <slot @slotchange=${t}></slot>
    </div>
    ${Oi(e.description)}
    ${e.error?S`<div id="error" part="error" class="en-error">${e.error}</div>`:T}
  </div>`}function Yo(e,t,n,r){if(n===0||t<0)return;let i;switch(e){case`ArrowDown`:i=t+1;break;case`ArrowUp`:i=t-1;break;case`ArrowRight`:i=t+(r?-1:1);break;case`ArrowLeft`:i=t+(r?1:-1);break;case`Home`:i=0;break;case`End`:i=n-1;break;default:return}return(i+n)%n}n(customElements,{tagName:`en-radio-group`,elementClass:class extends E{static properties={error:{noAccessor:!0},value:{noAccessor:!0,attribute:!1},defaultValue:{attribute:`value`,noAccessor:!0},disabled:{type:Boolean,reflect:!0},required:{type:Boolean,reflect:!0},name:{reflect:!0},label:{},description:{},orientation:{},validationText:{attribute:`validation-text`}};static styles=[B,z,Si,Ei,W];static formAssociated=!0;valueDefaults=new Yr(this,`value`,e=>e??``,e=>String(e),e=>{this.value=e});feedback=new Jr(this,()=>{this.syncForm()},()=>this.validationMessage);get error(){return this.feedback.error}set error(e){this.feedback.error=e}get visibleError(){return this.feedback.visible}get defaultValue(){return this.valueDefaults.value}set defaultValue(e){this.valueDefaults.value=String(e??``)}attributeChangedCallback(e,t,n){if(e===`value`){this.valueDefaults.attributeChanged();return}super.attributeChangedCallback(e,t,n)}model=on(``);signals=new j(this,()=>this.model.view.get());internals=typeof this.attachInternals==`function`?this.attachInternals():void 0;formController=this.internals?new Zr(this,{internals:this.internals,value:()=>this.radios.some(e=>e.value===this.value)?this.value:null,state:()=>this.value,disabled:()=>this.effectiveDisabled,onReset:()=>{this.feedback.reset(),this.valueDefaults.reset(),this.focusedValue=void 0,this.syncRadios()},onRestore:e=>{typeof e==`string`&&(this.value=e)},validate:()=>{let e=this.required&&!this.radios.some(e=>e.value===this.value);return qr({flags:e?{valueMissing:!0}:{},message:e?this.validationText||`Please select an option.`:``,anchor:this.radios.find(e=>!e.disabled)?.radioValidationAnchor},this.error)}}):void 0;revision=0;formDisabled=!1;radios=[];upgrades=new d(this,()=>this.collectRadios());focusedValue;constructor(){super(),this.disabled=!1,this.required=!1,this.name=``,this.label=``,this.description=``,this.orientation=`vertical`,this.validationText=`Please select an option.`}get value(){return this.model.value.get()}set value(e){this.valueDefaults.markDirty(),++this.revision,this.setValue(String(e??``))}setValue(e){let t=this.value;this.model.set(e),this.requestUpdate(`value`,t),this.syncRadios(),this.syncForm()}get effectiveDisabled(){return this.disabled||this.formDisabled}get form(){return this.internals?.form??null}get labels(){return this.internals?.labels}get willValidate(){return this.internals?.willValidate??!1}get validity(){return this.internals?.validity}get validationMessage(){return this.internals?.validationMessage??``}checkValidity(){return this.syncForm(),this.internals?.checkValidity?.()??!0}reportValidity(){return this.syncForm(),this.internals?.reportValidity?.()??!0}focus(e){let t=this.radios.filter(e=>!e.disabled);(t.find(e=>e.value===this.value)??t[0])?.focus(e)}disconnectedCallback(){super.disconnectedCallback();for(let e of this.radios)e.setRadioOwner(void 0,e.checked,!1,0);this.radios=[]}formDisabledCallback(e){this.formDisabled=e,this.requestUpdate(),this.syncRadios(),this.formController?.formDisabled(e)}formResetCallback(){this.formController?.formReset()}formStateRestoreCallback(e,t=`restore`){this.formController?.formStateRestore(e,t)}radioConfigurationChanged(){this.requestUpdate()}requestRadioSelection(e){this.effectiveDisabled||e.disabled||!this.radios.includes(e)||(this.focusedValue=e.value,this.propose(e,`select`))}propose(e,t){this.valueDefaults.markDirty();let n=e.value;A(this,{previous:this.value,proposed:n,reason:t,getRevision:()=>this.revision,canCommit:t=>this.isConnected&&!this.effectiveDisabled&&(this.renderRoot.querySelector(`slot:not([name])`)?.assignedElements({flatten:!0})??[]).some(n=>n===e&&e.value===t&&!e.disabled),stage:e=>this.setValue(e),rollback:e=>this.setValue(e)}),this.syncRadios()}collectRadios=()=>{let e=this.renderRoot.querySelector(`slot:not([name])`)?.assignedElements({flatten:!0})??[];this.upgrades.watch(e);let t=e.filter(e=>e.localName===`en-radio`&&e.matches(`:defined`)&&typeof e.setRadioOwner==`function`);for(let e of this.radios)t.includes(e)||e.setRadioOwner(void 0,e.checked,!1,0);this.radios=t,this.syncRadios(),this.syncForm()};syncRadios(){let e=this.radios.filter(e=>!e.disabled),t=e.find(e=>e.value===this.focusedValue)??e.find(e=>e.value===this.value)??e[0];for(let e of this.radios)e.setRadioOwner(this,e.value===this.value,this.effectiveDisabled,e===t&&!this.effectiveDisabled?0:-1)}syncForm(){this.formController?.sync()}handleKeyDown=e=>{if(this.effectiveDisabled||e.altKey||e.ctrlKey||e.metaKey)return;let t=e.composedPath().find(e=>this.radios.includes(e));if(!t)return;let n=this.radios.filter(e=>!e.disabled),r=n.indexOf(t);if(r<0)return;let i=getComputedStyle(this).direction===`rtl`,a=Yo(e.key,r,n.length,i);if(a===void 0)return;e.preventDefault();let o=n[a];o&&(this.focusedValue=o.value,this.propose(o,`keyboard`),o.focus())};updated(){this.collectRadios()}render(){return Jo({label:this.label,description:this.description,orientation:this.orientation,disabled:this.effectiveDisabled,required:this.required,error:this.visibleError},this.collectRadios,this.handleKeyDown)}}});var Xo=class extends E{static properties={error:{noAccessor:!0},value:{type:Number,noAccessor:!0,attribute:!1},defaultValue:{attribute:`value`,noAccessor:!0},disabled:{type:Boolean,reflect:!0},name:{reflect:!0},label:{},description:{}};static styles=[B,z,Si,Ei,W];static formAssociated=!0;valueDefaults=new Yr(this,`value`,e=>Number(e??0),e=>String(e),e=>{this.value=e});feedback=new Jr(this,()=>{this.formController?.sync()},()=>this.validationMessage);get error(){return this.feedback.error}set error(e){this.feedback.error=e}get visibleError(){return this.feedback.visible}get defaultValue(){return this.valueDefaults.value}set defaultValue(e){this.valueDefaults.value=Number(e)}attributeChangedCallback(e,t,n){if(e===`value`){this.valueDefaults.attributeChanged();return}super.attributeChangedCallback(e,t,n)}model=on(0);signals=new j(this,()=>this.model.view.get());internals=typeof this.attachInternals==`function`?this.attachInternals():void 0;authorRevision=0;formDisabled=!1;formController=this.internals?new Zr(this,{internals:this.internals,value:()=>String(this.value),disabled:()=>this.effectiveDisabled,control:()=>this.validationControl,validate:()=>qr({anchor:this.validationAnchor??void 0,...this.validateForm()},this.error),onReset:()=>{this.feedback.reset(),this.valueDefaults.reset(),this.syncControl()},onRestore:e=>{typeof e==`string`&&(this.value=Number(e)),this.syncControl()}}):void 0;constructor(){super(),this.disabled=!1,this.name=``,this.label=``,this.description=``,this.addEventListener(`en-input`,()=>this.valueDefaults.markDirty(),{capture:!0})}get value(){return this.model.value.get()}set value(e){this.valueDefaults.markDirty(),++this.authorRevision,this.setValue(this.normalizeValue(Number(e))),this.onValueWrite(),this.formController?.sync()}setValue(e){let t=this.value;this.model.set(e),this.requestUpdate(`value`,t),this.formController?.sync()}get effectiveDisabled(){return this.disabled||this.formDisabled}onValueWrite(){}validateForm(){return{flags:{}}}get validationControl(){return null}get validationAnchor(){return this.validationControl}get form(){return this.internals?.form??null}get labels(){return this.internals?.labels}get willValidate(){return this.internals?.willValidate??!1}get validity(){return this.internals?.validity}get validationMessage(){return this.internals?.validationMessage??``}checkValidity(){return this.formController?.sync(),this.internals?.checkValidity?.()??!0}reportValidity(){return this.formController?.sync(),this.internals?.reportValidity?.()??!0}formDisabledCallback(e){this.formDisabled=e,this.formController?.formDisabled(e),this.requestUpdate(),queueMicrotask(()=>this.requestUpdate())}formResetCallback(){this.formController?.formReset()}formStateRestoreCallback(e,t=`restore`){this.formController?.formStateRestore(e,t)}propose(e,t){let n=this.normalizeValue(e);if(this.effectiveDisabled)return;this.valueDefaults.markDirty();let r=this.isConnected;A(this,{previous:this.value,proposed:n,reason:t,getRevision:()=>this.authorRevision,stage:e=>{this.setValue(e),this.syncControl()},rollback:e=>{this.setValue(e),this.syncControl()},canCommit:e=>!this.effectiveDisabled&&(!r||this.isConnected)&&this.normalizeValue(e)===e,commit:()=>{this.onValueWrite(),this.formController?.sync()}}),this.syncControl()}updated(e){this.syncControl(),this.formController?.sync()}};function Zo(e,t){let n=n=>S`
    <label class=${n===0?`en-rating-clear`:`en-rating-item`} part=${n===0?`option clear-option`:`option star-option`}
      data-selected=${e.value===n?``:T}>
      <input part="control" class="en-rating-input en-sr-only" type="radio" name="rating" value=${n}
        ?checked=${e.value===n} aria-label=${e.optionLabel(n,e.max)} @change=${t}>
      ${n===0?S`<span>${e.optionLabel(0,e.max)}</span>`:S`<span class="en-rating-star" part="star" data-filled=${n<=e.value?``:T}
            aria-hidden="true">${n<=e.value?`★`:`☆`}</span>`}
    </label>`;return S`<fieldset part="field" class="en-fieldset en-rating-field" ?disabled=${e.disabled}
      aria-describedby=${e.error?`description error`:`description`} aria-invalid=${e.error?`true`:T}>
    <legend part="label" class="en-label en-legend"><slot name="label"><slot>${e.label}</slot></slot></legend>
    <div class="en-rating" part="options">
      ${n(0)}
      <div class="en-rating-values" part="star-options">
        ${Array.from({length:e.max},(e,t)=>n(t+1))}
      </div>
    </div>
    ${Oi(e.description)}
    ${e.error?S`<div id="error" part="error" class="en-error">${e.error}</div>`:T}
  </fieldset>`}var Qo={tagName:`en-rating`,elementClass:class extends Xo{static properties={...Xo.properties,max:{type:Number},optionLabel:{attribute:!1}};constructor(){super(),this.max=5,this.optionLabel=(e,t)=>e===0?`No rating`:`${e} of ${t} stars`}get maximum(){return Math.max(1,Math.min(10,Math.round(Number.isFinite(this.max)?this.max:5)))}normalizeValue(e){return Math.max(0,Math.min(this.maximum,Math.round(Number.isFinite(e)?e:0)))}willUpdate(e){if(e.has(`max`)){let e=this.normalizeValue(this.value);e!==this.value&&this.valueDefaults.apply(e)}}syncControl(){for(let e of this.renderRoot?.querySelectorAll(`input`)??[])e.checked=Number(e.value)===this.value}get validationAnchor(){return this.renderRoot?.querySelector(`input:checked`)??null}focus(e){this.renderRoot?.querySelector(`input[value="${this.value}"]`)?.focus(e)}render(){return Zo({value:this.value,max:this.maximum,disabled:this.effectiveDisabled,label:this.label,description:this.description,error:this.visibleError,optionLabel:this.optionLabel},e=>this.propose(Number(e.target.value),`select`))}}};n(customElements,Qo);var $o=`data-en-selection-children`,es=`en-selection-`,ts={select:`en-select-option`,segmented:`en-segmented-item`,choice:`en-choice-option`,checkbox:`en-choice-option`},ns=e=>e.replace(/[\t\n\f\r ]+/g,` `).replace(/^ | $/g,``);function rs(e){return/^en-selection-(?:ssr|client)-(?:0|[1-9]\d*)$/.test(e)}function is(e,t){let n=e===`segmented`||e===`checkbox`,r=new Set,i=new Set;return Object.freeze(t.map(t=>{let a=t.attributes,o=e=>Object.prototype.hasOwnProperty.call(a,e);if(t.tagName!==ts[e])throw TypeError(`Expected direct ${ts[e]} children.`);if(!t.key||i.has(t.key))throw TypeError(`Repeated or missing selection child key.`);if(i.add(t.key),!o(`value`)||n&&a.value===``)throw TypeError(`${ts[e]} requires an explicit ${n?`nonempty `:``}value.`);if(r.has(a.value))throw TypeError(`Selection child values must be unique.`);if(r.add(a.value),o(`selected`)||o(`checked`))throw TypeError(`Selection children do not own selected or checked state; set the parent value instead.`);if(o(`slot`)&&!(n&&rs(a.slot)))throw TypeError(`Selection child slot attributes are reserved for internal label projection.`);if(a.hidden?.toLowerCase()===`until-found`)throw TypeError(`Selection children do not support hidden=until-found.`);if(n&&(t.interactive||as(t.tagName,a)))throw TypeError(`Projected choice labels must contain noninteractive content only.`);if(n&&(o(`inert`)||a[`aria-hidden`]?.toLowerCase()===`true`))throw TypeError(`Projected choice roots must not be inert or aria-hidden; use hidden to make a choice unavailable.`);return Object.freeze({key:t.key,value:a.value,label:e===`segmented`?``:ns(t.text)||ns(a.label??``),...e===`checkbox`?{description:ns(t.description??``)||ns(a.description??``)}:{},disabled:o(`disabled`),hidden:o(`hidden`)})}))}function as(e,t){let n=e=>Object.prototype.hasOwnProperty.call(t,e);return[`button`,`input`,`select`,`textarea`,`summary`,`iframe`,`embed`,`object`,`en-button`,`en-checkbox`,`en-switch`,`en-select`,`en-text-field`,`en-toggle-button`].includes(e)||[`button`,`link`,`checkbox`,`radio`,`switch`,`textbox`,`combobox`,`slider`,`spinbutton`].includes(t.role??``)||(e===`a`||e===`area`)&&n(`href`)||(e===`audio`||e===`video`)&&n(`controls`)||n(`tabindex`)||n(`contenteditable`)&&t.contenteditable!==`false`}var os=new WeakMap,ss=new WeakMap,cs=class{#e;#t;get projectsContent(){return this.#t===`segmented`||this.#t===`checkbox`}#n=new WeakMap;#r=new Map;#i=0;#a;#o={active:!1,items:[],error:``};#s=!1;#c=!1;#l;constructor(e,t){if(this.#e=e,this.#t=t,os.has(e))throw TypeError(`Only one selection child controller can own a host.`);os.set(e,this),e.addController(this)}get view(){return this.#o}get initialValue(){return this.#l}prepare(e){if(e.version!==1||e.kind!==this.#t||typeof e.value!=`string`||!Array.isArray(e.items))throw TypeError(`Invalid selection child SSR snapshot.`);let t=new Set,n=new Set;for(let r of e.items){if(!r||typeof r.key!=`string`||!r.key||t.has(r.key)||typeof r.value!=`string`||n.has(r.value)||this.projectsContent&&!r.value||typeof r.label!=`string`||r.description!==void 0&&typeof r.description!=`string`||typeof r.disabled!=`boolean`||typeof r.hidden!=`boolean`)throw TypeError(`Invalid selection child SSR record.`);t.add(r.key),n.add(r.value)}this.#o={active:e.items.length>0,items:e.items.map(e=>Object.freeze({...e})),error:``},this.#s=!0,this.#c=!0,this.#l=e.value,this.#e.requestUpdate()}hostConnected(){let e=this.#e.getAttribute($o);if(e!==null&&!this.#s){this.prepare(JSON.parse(e)),this.#c=!1;let t=this.#f();this.#o.items.forEach(e=>{let n=t.find(t=>this.projectsContent?t.getAttribute(`slot`)===`en-selection-${e.key}`&&t.getAttribute(`value`)===e.value:t.getAttribute(`value`)===e.value);if(!n)return;this.#n.set(n,e.key);let r=n.getAttribute(`slot`);this.projectsContent&&r===`en-selection-${e.key}`&&this.#u(n,r)})}this.#s||this.refresh();let t=this.#e.ownerDocument.defaultView?.MutationObserver;t&&(this.#a??=new t(()=>this.refresh()),this.#a.observe(this.#e,{subtree:!0,childList:!0,characterData:!0,attributes:!0,attributeFilter:[`value`,`label`,`description`,`role`,`alt`,`aria-label`,`disabled`,`hidden`,`selected`,`checked`,`slot`,`tabindex`,`contenteditable`,`href`,`controls`,`inert`,`aria-hidden`]}))}hostUpdated(){this.#s&&(this.#s=!1,this.#e.removeAttribute($o)),this.refresh()}hostDisconnected(){this.#a?.disconnect();for(let[e,t]of this.#r)this.#d(e,t)}#u(e,t){ss.set(e,this),this.#r.set(e,t),e.getAttribute(`slot`)!==t&&e.setAttribute(`slot`,t)}#d(e,t){ss.get(e)===this&&(e.getAttribute(`slot`)===t&&e.removeAttribute(`slot`),ss.delete(e)),this.#r.delete(e)}#f(){return[...this.#e.children??[]].filter(e=>e.localName===ts[this.#t])}current(){if(this.#c)return this.#o;let e=this.#f();if(!e.length)return{active:!1,items:[],error:``};try{let t=e.map(e=>{let t=this.#n.get(e);t||(t=`client-${++this.#i}`,this.#n.set(e,t));let n=Object.fromEntries([...e.attributes].map(e=>[e.name,e.value])),r=this.#r.get(e);if(r!==void 0&&ss.get(e)===this){if(n.slot!==r)throw TypeError(`Do not replace or remove an internally owned selection child slot.`);delete n.slot}let i=this.projectsContent&&[...e.querySelectorAll(`*`)].some(e=>as(e.localName,Object.fromEntries([...e.attributes].map(e=>[e.name,e.value])))),a=this.#t===`checkbox`?ls([...e.childNodes].map(us)):void 0;return{key:t,tagName:e.localName,attributes:n,text:a?.label??e.textContent??``,description:a?.description,interactive:i}});return{active:!0,items:is(this.#t,t),error:``}}catch(e){return{active:!0,items:[],error:e instanceof Error?e.message:String(e)}}}refresh(){if(this.#s)return;let e=this.current(),t=this.#f();for(let[e,n]of this.#r)t.includes(e)||this.#d(e,n);!e.error&&this.projectsContent&&t.forEach((t,n)=>{let r=`${es}${e.items[n].key}`;this.#u(t,r)}),JSON.stringify(e)!==JSON.stringify(this.#o)&&(this.#o=e,this.#e.requestUpdate())}};function ls(e){let t=e=>{let n=e.attributes??{};return`hidden`in n||`inert`in n||n[`aria-hidden`]===`true`?``:n[`aria-label`]??n.alt??e.text??(e.children??[]).map(t).join(``)};for(let t of e){if(t.attributes?.slot&&t.attributes.slot!==`description`)throw TypeError(`Checkbox content supports the default label and description slot only.`);let e=t=>!!t.attributes?.slot||(t.children??[]).some(e);if((t.children??[]).some(e))throw TypeError(`Place checkbox description slots directly inside en-choice-option.`)}return{label:e.filter(e=>e.attributes?.slot!==`description`).map(t).join(``),description:e.filter(e=>e.attributes?.slot===`description`).map(t).join(` `)}}function us(e){return e.nodeType===3?{text:e.textContent??``}:e.nodeType===1?{attributes:Object.fromEntries([...e.attributes].map(e=>[e.name,e.value])),children:[...e.childNodes].map(us)}:{}}function ds(e,t,n,r,i,a){return S`<fieldset class="en-fieldset en-field" part="field" ?disabled=${e.disabled}
      aria-describedby=${e.error?`description child-error`:`description`} aria-invalid=${e.error?`true`:T}>
    <legend class="en-legend en-label" part="label"><slot name="label">${e.label}</slot></legend>
    <div class="en-segmented-control" part="options" @click=${a} @keydown=${n} @focusin=${r} @focusout=${i}>
      ${_r(e.items,e=>e.key??e.value,n=>S`
        <label class="en-segmented-item" part="option" data-selected=${n.value===e.value?``:T}
          data-disabled=${e.disabled||n.disabled?``:T} ?hidden=${n.hidden}>
          <input class="en-segmented-input en-sr-only" part="control" type="radio" name=${n.disabled||n.hidden?T:`choice`}
            value=${n.value} ?checked=${n.value===e.value} ?disabled=${e.disabled||n.disabled||n.hidden}
            ?required=${e.required} tabindex=${!e.disabled&&!n.disabled&&!n.hidden&&n.value===e.tabValue?0:-1}
            aria-describedby=${e.error?`description child-error`:`description`} aria-invalid=${e.error?`true`:T} @change=${t}>
          <span class="en-segmented-label" part="option-label" ?data-rich=${n.projected}>${n.projected?S`<slot name=${`${es}${n.key}`}></slot>`:n.label||T}</span>
        </label>`)}
    </div>
    ${Oi(e.description)}
    ${e.error?S`<p id="child-error" class="en-error" part="error" role="status">${e.error}</p>`:T}
  </fieldset>`}function fs(e,t,n){let r,i=1/0;for(let a=0;a<n.length;a++){let o=n[a],s=Math.max(o.left-e,0,e-o.right),c=Math.max(o.top-t,0,t-o.bottom),l=s*s+c*c;l<i&&(i=l,r=a)}return r}var ps=class extends E{static properties={error:{noAccessor:!0},value:{noAccessor:!0,attribute:!1},defaultValue:{attribute:`value`,noAccessor:!0},items:{attribute:!1},disabled:{type:Boolean,reflect:!0},required:{type:Boolean,reflect:!0},name:{reflect:!0},label:{},description:{},validationText:{attribute:`validation-text`}};static styles=[B,z,Ei,W];static formAssociated=!0;valueDefaults=new Yr(this,`value`,e=>e??``,e=>String(e),e=>{this.value=e});feedback=new Jr(this,()=>{this.formController?.sync()},()=>this.validationMessage);get error(){return this.feedback.error}set error(e){this.feedback.error=e}get visibleError(){return this.feedback.visible}get defaultValue(){return this.valueDefaults.value}set defaultValue(e){this.valueDefaults.value=String(e??``)}attributeChangedCallback(e,t,n){if(e===`value`){this.valueDefaults.attributeChanged();return}super.attributeChangedCallback(e,t,n)}model=on(``);childOptions=new cs(this,`segmented`);hydrationChoice=this.captureHydrationChoice();hydrationRevision=0;removedFocus;signals=new j(this,()=>this.model.view.get());internals=typeof this.attachInternals==`function`?this.attachInternals():void 0;revision=0;fieldsetDisabled=!1;focusedValue;formController=this.internals?new Zr(this,{internals:this.internals,value:()=>this.selectedItem&&!this.selectedItem.disabled&&!this.selectedItem.hidden?this.value:null,state:()=>this.value,disabled:()=>this.effectiveDisabled,onReset:()=>{this.feedback.reset(),this.valueDefaults.reset(),this.focusedValue=void 0,this.syncControls()},onRestore:e=>{typeof e==`string`&&(this.value=e),this.syncControls()},validate:()=>qr({flags:this.childOptions.current().error?{customError:!0}:this.required&&(!this.selectedItem||this.selectedItem.disabled||this.selectedItem.hidden)?{valueMissing:!0}:{},message:this.childOptions.current().error||this.validationText||`Please select an option.`,anchor:this.controls.find(e=>!e.disabled)},this.error)}):void 0;constructor(){super(),this.items=[],this.disabled=!1,this.required=!1,this.name=``,this.label=``,this.description=``,this.validationText=`Please select an option.`}connectedCallback(){this.hydrationRevision=this.revision,super.connectedCallback()}captureHydrationChoice(){if(!this.hasAttribute(`data-en-selection-children`)||!this.shadowRoot)return;let e=[...this.shadowRoot.querySelectorAll(`input[type="radio"]`)];return{value:e.find(e=>e.checked)?.value??``,baseline:e.find(e=>e.defaultChecked)?.value??``}}get effectiveItems(){return this.childOptions.view.active?this.childOptions.view.items.map(e=>({...e,projected:!0})):this.items}currentItems(){let e=this.childOptions.current();return e.active?e.items:this.items}get value(){return this.model.value.get()}set value(e){this.valueDefaults.markDirty(),++this.revision,this.setValue(String(e??``))}setValue(e){let t=this.value;this.model.set(e),this.requestUpdate(`value`,t),this.syncControls(),this.formController?.sync()}get selectedItem(){return this.currentItems()?.find(e=>e.value===this.value)}get effectiveDisabled(){return this.disabled||this.fieldsetDisabled}get controls(){return[...this.renderRoot?.querySelectorAll(`input[type="radio"]`)??[]]}get tabValue(){let e=this.effectiveItems?.filter(e=>!e.disabled&&!e.hidden)??[];return e.find(e=>e.value===this.focusedValue)?.value??e.find(e=>e.value===this.value)?.value??e[0]?.value}get form(){return this.internals?.form??null}get labels(){return this.internals?.labels}get willValidate(){return this.internals?.willValidate??!1}get validity(){return this.internals?.validity}get validationMessage(){return this.internals?.validationMessage??``}checkValidity(){return this.formController?.sync(),this.internals?.checkValidity?.()??!0}reportValidity(){return this.formController?.sync(),this.internals?.reportValidity?.()??!0}focus(e){this.controls.find(e=>e.value===this.tabValue&&!e.disabled)?.focus(e)}formDisabledCallback(e){this.fieldsetDisabled=e,this.formController?.formDisabled(e),this.requestUpdate()}formResetCallback(){this.formController?.formReset()}formStateRestoreCallback(e,t=`restore`){this.formController?.formStateRestore(e,t)}syncControls(){if(this.hydrationChoice&&!this.hasUpdated)return;let e=this.tabValue;for(let t of this.controls)t.checked=t.value===this.value,t.tabIndex=!this.effectiveDisabled&&!t.disabled&&t.value===e?0:-1}propose(e,t){let n=this.currentItems().find(t=>t.value===e);this.effectiveDisabled||!n||n.disabled||n.hidden||(this.valueDefaults.markDirty(),!this.effectiveDisabled&&n&&!n.disabled&&!n.hidden&&A(this,{previous:this.value,proposed:e,reason:t,getRevision:()=>this.revision,stage:e=>this.setValue(e),rollback:e=>this.setValue(e),canCommit:e=>!this.effectiveDisabled&&this.currentItems().some(t=>t.value===e&&!t.disabled&&!t.hidden)}),this.syncControls(),this.requestUpdate())}handleClick=e=>{if(e.defaultPrevented||e.button!==0||e.detail<=0||e.target!==e.currentTarget||this.effectiveDisabled)return;let t=this.controls.flatMap(e=>{let t=e.closest(`label`);if(!t)return[];let n=t.getBoundingClientRect();return n.width>0&&n.height>0?[{control:e,rect:n}]:[]}),n=fs(e.clientX,e.clientY,t.map(({rect:e})=>e)),r=n===void 0?void 0:t[n]?.control;r&&!r.disabled&&(r.focus(),r.click())};handleChange=e=>{let t=e.target;this.focusedValue=t.value,this.propose(t.value,`select`)};handleFocusIn=e=>{let t=e.target;t.type===`radio`&&(this.focusedValue=t.value,this.syncControls())};handleFocusOut=e=>{let t=e.relatedTarget;t&&this.renderRoot.contains(t)||(this.focusedValue=void 0,this.syncControls())};handleKeyDown=e=>{if(e.defaultPrevented||e.isComposing||e.altKey||e.ctrlKey||e.metaKey||this.effectiveDisabled)return;let t=this.controls.filter(e=>!e.disabled),n=t.indexOf(e.target),r=this.ownerDocument.defaultView?.getComputedStyle(this).direction===`rtl`,i=Yo(e.key,n,t.length,r);if(i===void 0)return;e.preventDefault();let a=t[i];a&&(this.focusedValue=a.value,this.propose(a.value,`keyboard`),a.focus())};willUpdate(e){super.willUpdate(e);let t=this.hydrationChoice;t&&(this.hydrationChoice=void 0,this.revision===this.hydrationRevision&&this.value===this.childOptions.initialValue&&t.value!==t.baseline&&this.propose(t.value,`hydrate`));let n=this.shadowRoot?.activeElement;n&&this.controls.includes(n)&&(this.removedFocus={control:n,index:this.controls.indexOf(n),root:this.getRootNode()})}updated(e){this.syncControls(),this.formController?.sync();let t=this.removedFocus;if(this.removedFocus=void 0,t&&(!t.control.isConnected||t.control.disabled)&&this.canRecoverFocus(t)){let e=this.controls.filter(e=>!e.disabled&&e.closest(`label`)?.getClientRects().length);e[Math.min(t.index,e.length-1)]?.focus()}}canRecoverFocus(e){let t=this.ownerDocument;if(!this.isConnected||this.effectiveDisabled||this.getRootNode()!==e.root||!t.hasFocus())return!1;let n=this.shadowRoot?.activeElement;if(n&&n!==e.control)return!1;let r=this,i=this.getRootNode();for(;;){let e=i.activeElement,n=e===null||i===t&&(e===t.body||e===t.documentElement);if(e!==r&&!n)return!1;if(i===t)return!0;r=i.host,i=r.getRootNode()}}render(){return ds({items:this.effectiveItems,value:this.value,tabValue:this.tabValue,label:this.label,description:this.description,disabled:this.effectiveDisabled,required:this.required,error:this.visibleError||this.childOptions.view.error},this.handleChange,this.handleKeyDown,this.handleFocusIn,this.handleFocusOut,this.handleClick)}},ms=class extends $e{staticStyles=new mt(this);static properties={value:{noAccessor:!0,reflect:!0,useDefault:!0},disabled:{type:Boolean,noAccessor:!0,reflect:!0,useDefault:!0},label:{type:String,noAccessor:!0,reflect:!0,useDefault:!0}};#e=``;get value(){return this.#e}set value(e){let t=this.#e;this.#e=String(e??``),this.getAttribute(`value`)!==this.#e&&this.setAttribute(`value`,this.#e);let n=this.getAttribute(`value`)===this.#e?void 0:Object.assign(Object.create(this.constructor.getPropertyOptions(`value`)),{hasChanged:()=>!0});this.requestUpdate(`value`,t,n)}#t=!1;get disabled(){return this.#t}set disabled(e){let t=this.#t;this.#t=!!e,this.hasAttribute(`disabled`)!==this.#t&&this.toggleAttribute(`disabled`,this.#t),this.requestUpdate(`disabled`,t)}#n=``;get label(){return this.#n}set label(e){let t=this.#n;this.#n=String(e??``),this.getAttribute(`label`)!==this.#n&&this.setAttribute(`label`,this.#n),this.requestUpdate(`label`,t)}},hs={tagName:`en-segmented-item`,elementClass:class extends ms{static styles=_`:host { display: contents; } :host([hidden]) { display: none !important; }`;render(){return S`<slot>${this.label||T}</slot>`}}};n(customElements,{tagName:`en-segmented-control`,elementClass:ps,dependencies:[hs]}),n(customElements,hs);var gs=Symbol.for(``),_s=e=>{if(e?.r===gs)return e?._$litStatic$},vs=e=>({_$litStatic$:e,r:gs}),ys=new Map,bs=(e=>(t,...n)=>{let r=n.length,i,a,o=[],s=[],c,l=0,u=!1;for(;l<r;){for(c=t[l];l<r&&(a=n[l],(i=_s(a))!==void 0);)c+=i+t[++l],u=!0;l!==r&&s.push(a),o.push(c),l++}if(l===r&&o.push(t[r]),u){let e=o.join(`$$lit$$`);(t=ys.get(e))===void 0&&(o.raw=o,ys.set(e,t=o)),n=s}return e(t,...n)})(S),xs=class extends q{static styles=[...q.styles,Ti];static properties={...q.properties,items:{attribute:!1}};childOptions=new cs(this,`select`);hydrationChoice=this.captureHydrationChoice();hydrationRevision=0;constructor(){super(),this.items=[]}connectedCallback(){this.hydrationRevision=this.valueRevision,super.connectedCallback()}captureHydrationChoice(){let e=this.shadowRoot?.querySelector(`#control`);if(e&&this.hasAttribute(`data-en-selection-children`))return{value:e.value,baseline:[...e.options].find(e=>e.defaultSelected)?.value??[...e.options].find(e=>!e.disabled)?.value??``}}get effectiveItems(){return this.childOptions.view.active?this.childOptions.view.items:this.items}currentItems(){let e=this.childOptions.current();return e.active?e.items:this.items}get visibleError(){return this.childOptions?.view.error||super.visibleError}get submissionValue(){return this.value===``&&this.placeholder?``:this.currentItems().some(e=>e.value===this.value&&!e.disabled&&!e.hidden)?this.value:null}canCommitValue(e){return!this.isDisabled&&(e===``&&!!this.placeholder||this.currentItems().some(t=>t.value===e&&!t.disabled&&!t.hidden))}validateAcceptedValue(){let e=super.validateAcceptedValue(),t=this.childOptions?.current().error;if(t)return{...e,flags:{...e.flags,customError:!0},message:t};if(this.required&&this.submissionValue===null){let t=this.controlNode?.cloneNode(!0);return t&&(t.selectedIndex=-1,t.setCustomValidity(``)),{...e,flags:{...e.flags,valueMissing:!0},message:this.error||t?.validationMessage||`Please select an option.`}}return e}willUpdate(e){super.willUpdate(e);let t=this.hydrationChoice;t&&(this.hydrationChoice=void 0,this.valueRevision===this.hydrationRevision&&this.value===this.childOptions.initialValue&&t.value!==t.baseline&&this.requestValue(t.value,`hydrate`))}reconcile(){let e=this.controlNode;if(this.hydrationChoice&&!this.hasUpdated)return;let t=this.model.draft.get();e&&e.value!==t&&(e.value=t)}onInput(e){let t=e.target.value;this.model.setDraft(t),dn(this,{value:t,isComposing:!1,inputType:`insertReplacementText`})}onChange(e){let t=e.target.value;this.model.setDraft(t),this.requestValue(t,`change`),this.model.setValue(this.value),this.reconcile(),this.syncForm()}renderControl(){let e=this.effectiveItems,t=e=>vs(e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`)),n=!this.hasUpdated&&this.childOptions.initialValue!==void 0?this.childOptions.initialValue:this.defaultControlValue,r=!this.placeholder&&e.length>0&&!e.some(e=>e.value===n);return S`<select id="control" class="en-select" part="control" name=${this.name}
      ?disabled=${this.isDisabled} ?required=${this.required}
      aria-describedby=${this.describedBy} aria-invalid=${this.controlAriaInvalid}
      @input=${this.onInput} @change=${this.onChange}>
      <button type="button" part="selected-button"><selectedcontent part="selected-content"></selectedcontent></button>
      ${this.placeholder?bs`<option part="option" value="" ?selected=${n===``}>${t(this.placeholder)}</option>`:r?S`<option value="" selected disabled hidden></option>`:T}
      ${_r(e,e=>e.key??e.value,e=>bs`<option part="option" value=${e.value} ?selected=${e.value===n}
        ?disabled=${e.disabled} ?hidden=${e.hidden}>${t(e.label||``)}</option>`)}
    </select>`}},Ss={tagName:`en-select-option`,elementClass:class extends ms{render(){return T}}};n(customElements,{tagName:`en-select`,elementClass:xs,dependencies:[Ss]}),n(customElements,Ss);function Cs(e,t,n){let r=Number.isFinite(e)?e:0;return{min:r,max:Math.max(r,Number.isFinite(t)?t:100),step:Number.isFinite(n)&&n>0?n:1}}function ws(e){let[t=``,n=`0`]=Math.abs(e).toString().split(`e`);return Math.max(0,(t.split(`.`)[1]?.length??0)-Number(n))}function Ts(e,t){let n=Number.isFinite(e)?e:t.min,r=Math.min(t.max,Math.max(t.min,n)),i=Math.round((r-t.min)/t.step),a=Math.floor(Number(((t.max-t.min)/t.step).toFixed(12))),o=t.min+Math.min(i,a)*t.step,s=Math.max(ws(t.min),ws(t.step));return s<=100?Number(o.toFixed(s)):o}function Es(e,t,n){let r=e.editorError&&e.showEditorError?`description editor-error`:`description`;return S`<div part="field" class="en-field">
    <label id="label" part="label" class="en-label" for="control"><slot name="label"><slot>${e.label}</slot></slot></label>
    <div part="row" class="en-range-row" data-orientation=${e.orientation} data-editable=${e.editable?``:T}>
      <input id="control" part="control" class="en-range" type="range"
        value=${String(e.value)} min=${e.min} max=${e.max} step=${e.step}
        ?disabled=${e.disabled} aria-orientation=${e.orientation} aria-valuetext=${e.valueText||T}
        aria-describedby=${e.applicationError?`description editor-error`:`description`}
        aria-invalid=${e.applicationError?`true`:T} @input=${t.rangeInput}>
      ${e.editable?n??S`
        <span id="editor-label" part="editor-label" class="en-sr-only"><slot name="editor-label">${e.editorLabel}</slot></span>
        <input id="editor" part="editor" class="en-input en-range-editor" type="number"
          value=${e.defaultEditorValue} min=${e.min} max=${e.max} step=${e.step} required
          ?disabled=${e.disabled} aria-labelledby="label editor-label"
          aria-describedby=${r} aria-invalid=${e.editorError&&e.showEditorError?`true`:T}
          @input=${t.editorInput} @change=${t.editorChange} @blur=${t.editorBlur}
          @keydown=${t.editorKeyDown} @compositionend=${t.editorCompositionEnd}>`:T}
      ${e.showValue?S`<output part="output" for="control">${e.valueText||e.value}</output>`:T}
    </div>
    ${Oi(e.description)}
    ${e.editorError?S`<p id="editor-error" part="error" class="en-error en-range-error"
      data-pending=${e.showEditorError?T:``} aria-hidden=${e.showEditorError?T:`true`}>${e.editorError}</p>`:T}
  </div>`}var Ds={tagName:`en-slider`,elementClass:class extends Xo{static properties={...Xo.properties,min:{type:Number},max:{type:Number},step:{type:Number},orientation:{type:String,reflect:!0},showValue:{type:Boolean,attribute:`show-value`},valueText:{attribute:`value-text`},editable:{type:Boolean},editorLabel:{attribute:`editor-label`},validationText:{attribute:`validation-text`}};editorDraft=Ni(`0`);editing=new Mi(this,{model:this.editorDraft,control:()=>this.editorControl,onInput:()=>{++this.editGeneration,this.lastCompletion=void 0,this.syncEditorValidation()}});initialEditorValue;showEditorError=!1;editorError=``;editGeneration=0;pendingBlur=!1;lastCompletion;constructor(){super(),this.min=0,this.max=100,this.step=1,this.orientation=`horizontal`,this.showValue=!1,this.valueText=``,this.editable=!1,this.editorLabel=`Exact value`,this.validationText=``,this.addEventListener(`invalid`,()=>{this.showEditorError=!0,this.syncEditorValidation(),this.requestUpdate()})}get bounds(){return Cs(this.min,this.max,this.step)}get editorControl(){return this.editable?this.renderRoot?.querySelector(`#editor`)??null:null}get validationControl(){return this.editorControl??this.renderRoot?.querySelector(`#control`)??null}normalizeValue(e){return Ts(e,this.bounds)}onValueWrite(){this.reconcileEditor()}reconcileEditor(){this.editorDraft?.setValue(String(this.value));let e=this.showEditorError;this.showEditorError=!1,e&&this.requestUpdate(),this.pendingBlur=!1,this.lastCompletion=void 0,this.editing?.sync(),this.syncEditorValidation()}willUpdate(e){if(e.has(`min`)||e.has(`max`)||e.has(`step`)){let e=this.normalizeValue(this.value);e!==this.value&&this.valueDefaults.apply(e)}e.has(`editable`)&&!this.editable&&this.reconcileEditor(),this.initialEditorValue??=String(this.value)}syncControl(){let e=this.renderRoot?.querySelector(`#control`);e&&e.value!==String(this.value)&&(e.value=String(this.value)),this.editing?.sync()}validateForm(){let e=this.editorControl;if(!e)return{flags:{}};let t=this.bounds,n=e.min===String(t.min)&&e.max===String(t.max)&&e.step===String(t.step)&&e.required?e:e.cloneNode(!1);n!==e&&(n.min=String(t.min),n.max=String(t.max),n.step=String(t.step),n.required=!0,n.disabled=!1,n.value=e.value);let r=n.validity,i=e.validity.badInput,a={badInput:i,valueMissing:r.valueMissing,rangeUnderflow:r.rangeUnderflow,rangeOverflow:r.rangeOverflow,stepMismatch:r.stepMismatch};return{flags:a,message:Object.values(a).some(Boolean)?this.validationText||(i?e.validationMessage:n.validationMessage):``,anchor:e}}syncEditorValidation(){if(this.formController?.sync(),!this.hasUpdated)return;let e=!this.effectiveDisabled&&this.editable?this.validationMessage:``;e!==this.editorError&&(this.editorError=e,this.requestUpdate())}checkValidity(){return this.syncEditorValidation(),super.checkValidity()}reportValidity(){return this.syncEditorValidation(),super.reportValidity()}formResetCallback(){super.formResetCallback(),this.reconcileEditor(),this.syncControl()}formStateRestoreCallback(e,t=`restore`){super.formStateRestoreCallback(e,t),this.syncEditorValidation()}disconnectedCallback(){this.pendingBlur=!1,this.lastCompletion=void 0,super.disconnectedCallback()}focus(e){this.renderRoot?.querySelector(`#control`)?.focus(e)}finishEditor(e){let t=this.editorControl;if(!t||this.effectiveDisabled||this.editorDraft.isComposing.get())return;let n=this.lastCompletion;if(e!==`enter`&&n?.control===t&&n.generation===this.editGeneration&&n.authorRevision===this.authorRevision&&n.value===t.value&&n.badInput===t.validity.badInput)return;this.editorDraft.setDraft(t.value),this.showEditorError=!0,this.requestUpdate();let r=this.validateForm();!Object.values(r.flags).some(Boolean)&&Number.isFinite(t.valueAsNumber)&&(t.valueAsNumber===this.value?this.reconcileEditor():this.propose(t.valueAsNumber,`change`)),this.syncEditorValidation(),this.lastCompletion={control:t,generation:this.editGeneration,authorRevision:this.authorRevision,value:t.value,badInput:t.validity.badInput}}handleRangeInput=e=>{this.propose(Number(e.target.value),`input`),this.syncEditorValidation()};handleEditorInput=e=>{e.isComposing&&!this.editorDraft.isComposing.get()&&this.editorDraft.startComposition(),this.editorDraft.setDraft(e.currentTarget.value),this.syncEditorValidation()};handleEditorChange=()=>{this.finishEditor(`change`)};handleEditorBlur=()=>{if(this.editorDraft.isComposing.get()){this.pendingBlur=!0;return}this.finishEditor(`blur`)};handleEditorKeyDown=e=>{e.defaultPrevented||e.isComposing||this.editorDraft.isComposing.get()||e.altKey||e.ctrlKey||e.metaKey||this.effectiveDisabled||(e.key===`Enter`?(e.preventDefault(),this.finishEditor(`enter`)):e.key===`Escape`&&(e.preventDefault(),this.reconcileEditor()))};handleEditorCompositionEnd=e=>{let t=e.currentTarget;queueMicrotask(()=>{this.pendingBlur&&(this.pendingBlur=!1,this.isConnected&&this.editable&&!this.effectiveDisabled&&this.editorControl===t&&this.finishEditor(`blur`))})};updated(e){super.updated(e),this.syncEditorValidation()}renderExactEditor(){}render(){let e=this.editable?this.renderExactEditor():void 0;return Es({value:this.value,...this.bounds,disabled:this.effectiveDisabled,orientation:this.orientation===`vertical`?`vertical`:`horizontal`,label:this.label,description:this.description,showValue:this.showValue,valueText:this.valueText,editable:this.editable,editorLabel:this.editorLabel,defaultEditorValue:this.initialEditorValue??String(this.value),applicationError:this.error,editorError:this.error||(e?``:this.editorError),showEditorError:!!this.error||this.showEditorError},{rangeInput:this.handleRangeInput,editorInput:this.handleEditorInput,editorChange:this.handleEditorChange,editorBlur:this.handleEditorBlur,editorKeyDown:this.handleEditorKeyDown,editorCompositionEnd:this.handleEditorCompositionEnd},e)}}};n(customElements,Ds);var Os=e=>S`
  <div
    class="en-stack"
    part="base"
    data-direction=${e.direction}
    data-gap=${e.gap}
    data-align=${e.align}
    data-justify=${e.justify}
    ?data-wrap=${e.wrap}
  ><slot></slot></div>
`;n(customElements,{tagName:`en-stack`,elementClass:class extends E{static properties={direction:{reflect:!0},gap:{reflect:!0},align:{reflect:!0},justify:{reflect:!0},wrap:{type:Boolean,reflect:!0}};static styles=[B,z,Ur];constructor(){super(),this.direction=`vertical`,this.gap=`medium`,this.align=`stretch`,this.justify=`start`,this.wrap=!1}render(){return Os(this)}}});var ks=/^--en-[A-Za-z0-9_-]+$/u;function As(e){return typeof e==`string`&&ks.test(e)?`var(${e})`:void 0}function js(e,t){return e?As(e)??``:typeof t!=`string`||/[;{}\\!]/u.test(t)?``:t.trim()}var Ms=e=>S`
  <button class="en-control en-swatch__sample" part="control sample" type="button"
    ?disabled=${e.disabled} @click=${e.onActivate}>
    <span class="en-swatch__color" part="color" aria-hidden="true"
      style=${e.color?`background-color: ${e.color}`:T}></span>
    <span class="en-sr-only" part="label"><slot name="label">${e.label}</slot></span>
  </button>
`;n(customElements,{tagName:`en-swatch`,elementClass:class extends E{static properties={token:{type:String},color:{type:String},label:{type:String},disabled:{type:Boolean,reflect:!0}};static styles=[B,Mn,Zn];constructor(){super(),this.token=``,this.color=``,this.label=``,this.disabled=!1}focus(e){this.renderRoot.querySelector(`button`)?.focus(e)}onActivate=e=>{if(this.disabled){e.preventDefault();return}e.defaultPrevented||un(this,{action:`activate`,data:void 0},{cancelable:!0})||e.preventDefault()};render(){return Ms({color:js(this.token,this.color),label:this.label||``,disabled:this.disabled,onActivate:this.onActivate})}}}),n(customElements,{tagName:`en-switch`,elementClass:class extends Ai{get kind(){return`switch`}}});function Ns(){return S`<span class="en-tab" part="base"><slot></slot></span>`}var Ps={tagName:`en-tab`,elementClass:class extends E{static properties={value:{type:String,reflect:!0},disabled:{type:Boolean,reflect:!0}};static styles=[B,W,_`
    :host { display: inline-flex; cursor: pointer; }
    :host([disabled]) { cursor: default; }
  `];constructor(){super(),this.value=``,this.disabled=!1}connectedCallback(){super.connectedCallback(),this.setAttribute(`role`,`tab`),this.hasAttribute(`tabindex`)||(this.tabIndex=-1)}updated(e){e.has(`disabled`)&&(this.setAttribute(`aria-disabled`,String(this.disabled)),this.disabled&&(this.tabIndex=-1))}render(){return Ns()}}};n(customElements,Ps);function Fs(){return S`<div class="en-tab-panel" part="base"><slot></slot></div>`}var Is={tagName:`en-tab-panel`,elementClass:class extends E{static properties={value:{type:String,reflect:!0}};static styles=[B,z,W,_`
    :host { display: block; }
    :host([hidden]) { display: none !important; }
  `];constructor(){super(),this.value=``}connectedCallback(){super.connectedCallback(),this.setAttribute(`role`,`tabpanel`),this.hasAttribute(`tabindex`)||(this.tabIndex=0)}render(){return Fs()}}};n(customElements,Is);function Ls(e){if(!e.isConnected||!e.getClientRects().length)return!1;for(let t=e;t;){if(t.hasAttribute(`hidden`)||t.hasAttribute(`inert`))return!1;let e=t.ownerDocument.defaultView?.getComputedStyle(t);if(e?.visibility===`hidden`||e?.visibility===`collapse`||e?.display===`none`)return!1;t=t.assignedSlot||t.parentElement||t.getRootNode().host||null}return!0}function Rs(e,t){return S`<div class="en-tabs" part="base" data-orientation=${e.orientation}>
    <div class="en-tab-list" part="tab-list" role="tablist" aria-label=${e.label} aria-orientation=${e.orientation}>
      <slot name="tab" @slotchange=${t}></slot>
    </div>
    <div part="panels"><slot name="panel" @slotchange=${t}></slot></div>
  </div>`}n(customElements,{tagName:`en-tabs`,elementClass:class extends E{static properties={value:{type:String,reflect:!0,noAccessor:!0},label:{type:String},orientation:{type:String,reflect:!0},activation:{type:String,reflect:!0}};static styles=[B,z,W];model=on(``);authorRevision=0;presentedValue=``;tabs=[];panels=[];focusKey=``;idPrefix=``;observer;upgrades=new d(this,()=>this.readChildren());constructor(){super(),this.label=``,this.orientation=`horizontal`,this.activation=`automatic`,new j(this,()=>this.model.view.get())}get value(){return this.model.value.get()}set value(e){this.authorRevision+=1;let t=this.presentedValue;this.model.set(String(e??``)),this.presentedValue=this.value,this.requestUpdate(`value`,t)}connectedCallback(){super.connectedCallback(),this.addEventListener(`keydown`,this.onKeyDown),this.addEventListener(`click`,this.onClick);let e=this.ownerDocument.defaultView?.MutationObserver;e&&(this.observer=new e(()=>this.readChildren()),this.observer.observe(this,{childList:!0,subtree:!0,attributes:!0,attributeFilter:[`value`,`disabled`,`id`,`hidden`,`inert`,`style`,`class`,`slot`]}))}disconnectedCallback(){this.removeEventListener(`keydown`,this.onKeyDown),this.removeEventListener(`click`,this.onClick),this.observer?.disconnect(),this.observer=void 0,super.disconnectedCallback()}readChildren(){let e=this.renderRoot.querySelector(`slot[name="tab"]`),t=this.renderRoot.querySelector(`slot[name="panel"]`),n=e?.assignedElements({flatten:!0})??[],r=t?.assignedElements({flatten:!0})??[];if(this.upgrades.watch([...n,...r]),this.tabs=n.filter(e=>e.localName===`en-tab`&&e.matches(`:defined`)&&`disabled`in e&&`value`in e),this.panels=r.filter(e=>e.localName===`en-tab-panel`&&e.matches(`:defined`)&&`value`in e),!this.idPrefix&&this.tabs.length&&(this.idPrefix=this.id||`en-tabs-${this.ownerDocument.defaultView?.crypto.randomUUID()??Math.random().toString(36).slice(2)}`),this.tabs.forEach((e,t)=>{e.id||=`${this.idPrefix}-tab-${t+1}`}),this.panels.forEach((e,t)=>{e.id||=`${this.idPrefix}-panel-${t+1}`}),!this.value&&this.authorRevision===0){let e=this.presentedValue;this.model.set(this.tabs.find(e=>this.available(e)&&e.value)?.value??``),this.presentedValue=this.value,this.requestUpdate(`value`,e)}this.syncChildren()}syncChildren(){let e=this.tabs.filter(e=>this.available(e)),t=this.tabs.find(e=>e.value===this.presentedValue);e.some(e=>e.value===this.focusKey)||(this.focusKey=e.find(e=>e===t)?.value??e[0]?.value??``);for(let e of this.tabs){let n=this.panels.find(t=>t.value===e.value);e.setAttribute(`role`,`tab`),e.setAttribute(`aria-selected`,String(e===t)),e.setAttribute(`aria-disabled`,String(e.disabled)),n?e.setAttribute(`aria-controls`,n.id):e.removeAttribute(`aria-controls`),e.tabIndex=this.available(e)&&e.value===this.focusKey?0:-1}for(let e of this.panels){let n=this.tabs.find(t=>t.value===e.value);e.setAttribute(`role`,`tabpanel`),n?e.setAttribute(`aria-labelledby`,n.id):e.removeAttribute(`aria-labelledby`);let r=e.value!==this.presentedValue,i=this.ownerDocument.activeElement;r&&!e.hidden&&i&&(i===e||e.contains(i))&&t?.focus(),e.hidden!==r&&(e.hidden=r)}}available(e){return!e.disabled&&Ls(e)}owns(e){return!!this.renderRoot.querySelector(`slot[name="tab"]`)?.assignedElements({flatten:!0}).includes(e)}activate(e,t){this.available(e)&&e.value&&e.value!==this.value&&A(this,{previous:this.value,proposed:e.value,reason:t,getRevision:()=>this.authorRevision,canCommit:t=>this.owns(e)&&this.available(e)&&e.value===t,stage:e=>{this.model.set(e)},rollback:e=>{this.model.set(e)},commit:()=>{let e=this.presentedValue;this.presentedValue=this.value,this.requestUpdate(`value`,e),this.syncChildren()}})}eventTab(e){return this.tabs.find(t=>e.composedPath().includes(t))}onClick=e=>{let t=this.eventTab(e);t&&this.available(t)&&!e.defaultPrevented&&(this.focusKey=t.value,this.syncChildren(),t.focus(),this.activate(t,`pointer`))};onKeyDown=e=>{let t=this.eventTab(e);if(!t||!this.available(t)||e.defaultPrevented||e.altKey||e.ctrlKey||e.metaKey)return;if(e.key===`Enter`||e.key===` `){e.preventDefault(),this.activate(t,`keyboard`);return}let n=this.tabs.filter(e=>this.available(e)),r=n.indexOf(t),i=this.orientation!==`vertical`,a=i&&this.ownerDocument.defaultView?.getComputedStyle(this).direction===`rtl`;if(e.key===`Home`)r=0;else if(e.key===`End`)r=n.length-1;else if(i&&e.key===`ArrowRight`)r+=a?-1:1;else if(i&&e.key===`ArrowLeft`)r+=a?1:-1;else if(!i&&e.key===`ArrowDown`)r+=1;else if(!i&&e.key===`ArrowUp`)--r;else return;e.preventDefault();let o=n[(r+n.length)%n.length];o&&(this.focusKey=o.value,this.syncChildren(),o.focus(),this.activation!==`manual`&&this.activate(o,`keyboard`))};updated(e){e.has(`value`)&&(this.focusKey=this.tabs.find(e=>e.value===this.presentedValue&&this.available(e))?.value??this.focusKey,this.syncChildren())}render(){return Rs({label:this.label,orientation:this.orientation},()=>this.readChildren())}}});var zs={tagName:`en-text-field`,elementClass:class extends Q{static properties={...Q.properties,adorned:{type:Boolean,reflect:!0},type:{type:String},minLength:{type:Number,attribute:`minlength`},maxLength:{type:Number,attribute:`maxlength`},pattern:{type:String}};static styles=[...Q.styles,Di];constructor(){super(),this.type=`text`,this.adorned=!1,this.minLength=void 0,this.maxLength=void 0,this.pattern=``}renderControlFrame(){return this.adorned?S`<div class="en-field-focus-frame en-adorned" part="focus-frame" ?data-invalid=${!!this.visibleError}><slot name="prefix"></slot>${this.renderControl()}<slot name="suffix"></slot><slot name="help-action"></slot></div>`:super.renderControlFrame()}renderControl(){return S`<input id="control" class="en-input en-text-input" part="control"
      type=${[`text`,`email`,`password`,`url`,`tel`].includes(this.type)?this.type:`text`} name=${this.name} value=${this.defaultControlValue}
      placeholder=${this.placeholder||T} autocomplete=${this.autocomplete||T}
      inputmode=${this.inputMode||T} minlength=${this.minLength??T}
      maxlength=${this.maxLength??T} pattern=${this.pattern||T}
      ?disabled=${this.isDisabled} ?readonly=${this.readOnly} ?required=${this.required}
      aria-describedby=${this.describedBy} aria-invalid=${this.controlAriaInvalid}>`}}};n(customElements,zs);var Bs={tagName:`en-textarea`,elementClass:class extends Q{static properties={...Q.properties,rows:{type:Number},minLength:{type:Number,attribute:`minlength`},maxLength:{type:Number,attribute:`maxlength`}};constructor(){super(),this.rows=3,this.minLength=void 0,this.maxLength=void 0}renderControl(){return S`<textarea id="control" class="en-textarea" part="control" name=${this.name}
      rows=${this.rows} placeholder=${this.placeholder||T} autocomplete=${this.autocomplete||T}
      inputmode=${this.inputMode||T} minlength=${this.minLength??T} maxlength=${this.maxLength??T}
      ?disabled=${this.isDisabled} ?readonly=${this.readOnly} ?required=${this.required}
      aria-describedby=${this.describedBy} aria-invalid=${this.controlAriaInvalid}></textarea>`}}};n(customElements,Bs);var Vs=e=>S`
  <div class="en-toolbar" part="base" role=${e.nativeNavigation?`group`:`toolbar`} aria-label=${e.label}
    data-orientation=${e.orientation===`vertical`?`vertical`:`horizontal`}
    aria-orientation=${e.nativeNavigation?T:e.orientation===`vertical`?`vertical`:`horizontal`}>
    <slot @slotchange=${e.onSlotChange}></slot>
  </div>
`;n(customElements,{tagName:`en-toolbar`,elementClass:class extends E{static properties={label:{useDefault:!0},orientation:{reflect:!0},keyboardNavigation:{attribute:`keyboard-navigation`,reflect:!0}};static styles=[B,ma];nativeNavigation=!1;observer;roving;upgrades=new d(this,()=>this.refresh());initialized=!1;constructor(){super(),this.label=`Actions`,this.orientation=`horizontal`,this.keyboardNavigation=`auto`;let e=this;this.roving=new Oo(this,{items:()=>this.items(),get orientation(){return e.orientation===`vertical`?`vertical`:`horizontal`},isDisabled:e=>e.matches(`:disabled, [disabled], [loading], [aria-disabled="true"], [hidden], [inert]`)||!e.getClientRects().length||e.ownerDocument.defaultView?.getComputedStyle(e).visibility===`hidden`,claimTabStop:Br,keydownCapture:!0,recoverFocus:!0})}usesNativeNavigation(){return this.keyboardNavigation===`tab`?!0:this.children?Array.from(this.children).some(e=>e.getAttribute(`slot`)||e.localName===`button`||[`en-button`,`en-toggle-button`].includes(e.localName)?!1:[e,...e.querySelectorAll(`*`)].some(e=>e.localName.includes(`-`)||e.matches(`button, input:not([type="hidden"]), select, textarea, a[href], area[href], summary, iframe, audio[controls], video[controls], [tabindex], [contenteditable]:not([contenteditable="false"]), [role="button"], [role="checkbox"], [role="radio"], [role="switch"], [role="textbox"], [role="combobox"], [role="slider"], [role="spinbutton"], [role="tree"], [role="grid"], [role="listbox"], [role="tablist"]`))):!1}items(){let e=this.usesNativeNavigation();if(e!==this.nativeNavigation&&(this.nativeNavigation=e,this.requestUpdate()),e||!this.initialized&&Array.from(this.children).some(e=>!e.getAttribute(`slot`)&&[`en-button`,`en-toggle-button`].includes(e.localName)&&!(`updateComplete`in e)))return[];let t=Array.from(this.children).filter(e=>!e.getAttribute(`slot`)&&(e.localName===`button`||[`en-button`,`en-toggle-button`].includes(e.localName)&&`updateComplete`in e));return t.length&&(this.initialized=!0),t}connectedCallback(){super.connectedCallback();let e=this.ownerDocument.defaultView?.MutationObserver;e&&(this.observer=new e(()=>this.refresh()),this.observer.observe(this,{childList:!0,subtree:!0,attributes:!0,attributeFilter:[`disabled`,`loading`,`aria-disabled`,`hidden`,`inert`,`slot`,`style`,`class`,`type`,`href`,`controls`,`role`,`contenteditable`,`tabindex`]})),this.refresh()}observeButtonUpgrade(){this.upgrades.watch(Array.from(this.children).filter(e=>[`en-button`,`en-toggle-button`].includes(e.localName)))}disconnectedCallback(){this.observer?.disconnect(),this.observer=void 0,super.disconnectedCallback()}refresh=()=>{this.isConnected&&(this.roving.refresh(),this.observeButtonUpgrade())};render(){return Vs({label:this.label,orientation:this.orientation,nativeNavigation:this.usesNativeNavigation(),onSlotChange:this.refresh})}}});function Hs(e){if(e.type!==`en-change`||!e.cancelable)return;let t=e.currentTarget;return t&&e.composedPath()[0]===t?t:void 0}function Us(e,t,n){let r=Hs(e);if(!r||e.defaultPrevented)return;let i=e.detail.proposed;Object.is(t(r),i)&&queueMicrotask(()=>{!e.defaultPrevented&&r.isConnected&&Object.is(t(r),i)&&n(i,r)})}var Ws=[{value:`ada`,label:`Ada Lovelace`},{value:`rafael`,label:`Rafael Silva`},{value:`jun`,label:`Jun Park`}],Gs={week:[{label:`Mon`,value:12},{label:`Tue`,value:26},{label:`Wed`,value:19},{label:`Thu`,value:32},{label:`Fri`,value:23},{label:`Sat`,value:8}],month:[{label:`Apr`,value:78},{label:`May`,value:104},{label:`Jun`,value:86},{label:`Jul`,value:124},{label:`Aug`,value:96},{label:`Sep`,value:112}]},Ks=[{action:`portrait`,label:`Portrait canvas`,keywords:[`tall`,`layout`]},{action:`landscape`,label:`Landscape canvas`,keywords:[`wide`,`layout`]},{action:`reset-canvas`,label:`Reset canvas`,keywords:[`default`]}];function qs(){return{canvas:`portrait`,activityRange:`week`,ready:[!0,!0,!1,!1],project:``,projectStatus:``,opacity:82,scale:100,accent:`#6d5ce7`,members:[`Mira Chen`,`Omar Haddad`],invitationStatus:``,messages:[],chatStatus:``,feedback:``,accessStatus:``,notificationStatus:``,approved:!1,inserted:!1,shareStatus:``}}var Js=ar(class extends or{constructor(){super(...arguments),this.key=T}render(e,t){return this.key=e,t}update(e,[t,n]){return t!==this.key&&(pr(e),this.key=t),n}}),Ys=`important`,Xs=` !`+Ys,Zs=ar(class extends or{constructor(e){if(super(e),e.type!==ir.ATTRIBUTE||e.name!==`style`||e.strings?.length>2)throw Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.")}render(e){return Object.keys(e).reduce((t,n)=>{let r=e[n];return r==null?t:t+`${n=n.includes(`-`)?n:n.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g,`-$&`).toLowerCase()}:${r};`},``)}update(e,[t]){let{style:n}=e.element;if(this.ft===void 0)return this.ft=new Set(Object.keys(t)),this.render(t);for(let e of this.ft)t[e]??(this.ft.delete(e),e.includes(`-`)?n.removeProperty(e):n[e]=null);for(let e in t){let r=t[e];if(r!=null){this.ft.add(e);let t=typeof r==`string`&&r.endsWith(Xs);e.includes(`-`)||t?n.setProperty(e,t?r.slice(0,-11):r,t?Ys:``):n[e]=r}}return w}}),Qs=new WeakMap;function $s(e){if(e.defaultPrevented)return;let t=e.currentTarget,n=t.closest(`[data-token-sample]`),r=n?.querySelector(`[role="status"]`);if(!n||!r||!t.isConnected||t.disabled||!/^--en-[A-Za-z0-9_-]+$/u.test(t.token))return;let i=`var(${t.token})`;e.preventDefault();let a=Qs.get(n);if(a?.reference===i&&a.token===t.token&&a.swatch===t&&a.status===r)return;let o={token:t.token,reference:i,swatch:t,status:r};Qs.set(n,o),r.textContent=``,n.dataset.copyState=`copying`,n.setAttribute(`aria-busy`,`true`);let s=t.ownerDocument.defaultView,c;try{let e=s?.navigator.clipboard;c=e?.writeText?e.writeText(i).then(()=>!0,()=>!1):Promise.resolve(!1)}catch{c=Promise.resolve(!1)}l();async function l(){await new Promise(e=>s?.requestAnimationFrame?s.requestAnimationFrame(()=>s.requestAnimationFrame(()=>e())):setTimeout(e,0));let e=await c;if(Qs.get(n)===o){if(Qs.delete(n),n.removeAttribute(`aria-busy`),!t.isConnected||!n.contains(t)||!n.contains(r)||t.disabled||t.token!==o.token){n.dataset.copyState=`idle`;return}n.dataset.copyState=e?`success`:`failure`,r.textContent=e?`CSS reference copied.`:`Could not copy. Select and copy the CSS reference.`}}}var ec=e=>e!=null&&e!==T&&e!==``,tc=e=>ec(e)?e:T;function nc(e,t=`text`){return S`<div class="en-content-placeholder" data-shape=${t}>
		<div class="en-content-placeholder__content">${tc(e)}</div>
		<en-skeleton class="en-content-placeholder__skeleton" shape="rectangle" aria-hidden="true"></en-skeleton>
	</div>`}var rc=(e,t,n=`text`)=>t?nc(e,n):tc(e);function ic({items:e,placeholders:t=!1}){return S`<dl class="en-content-metadata">
		${e.map(e=>S`<div class="en-content-metadata__item"><dt>${rc(e.label,t)}</dt><dd>${rc(e.value,t)}</dd></div>`)}
	</dl>`}function ac({title:e,description:t,actions:n,media:r,kind:i=`empty`,placeholders:a=!1}){if(![`empty`,`no-results`,`unavailable`].includes(i))throw TypeError(`Empty state kind must be empty, no-results or unavailable.`);return S`<div class="en-content-empty" data-kind=${i}>
		${ec(r)?S`<div class="en-content-empty__media">${rc(r,a,`rectangle`)}</div>`:T}
		<div class="en-content-empty__title">${rc(e,a)}</div>
		${ec(t)?S`<div class="en-content-empty__description">${rc(t,a)}</div>`:T}
		${ec(n)?S`<div class="en-content-empty__actions">${rc(n,a,`rectangle`)}</div>`:T}
	</div>`}function $(e,t,n,r,i=!0){return S`<section
    id=${`showcase-${t}`}
    class="showcase-card"
    aria-labelledby=${`showcase-heading-${t}`}
  >
    <en-card>
      <div slot="header" class="showcase-card-heading">
        <h2 id=${`showcase-heading-${t}`}>${n}</h2>
        ${i?S`<en-button
                variant="ghost"
                size="small"
                @click=${()=>e.reset(t)}
                ><span class="showcase-reset-label"
                  >Reset<span class="showcase-sr-only"> ${n}</span></span
                ></en-button
              >`:T}
      </div>
      ${Js(e.resets.get(t)??0,S`<div class="showcase-card-body">${r}</div>`)}
    </en-card>
  </section>`}function oc(e,t=!1){return S`<div
    class=${`showcase-art${t?` showcase-art-large`:``}`}
    data-layout=${e.data.canvas}
    role="img"
    aria-label=${`${e.data.canvas} composition with overlapping shapes`}
  >
    <div
      class="showcase-artboard"
      style=${Zs({opacity:String(e.data.opacity/100)})}
    >
      <i></i><b></b><span>Make room<br />for a new idea.</span>
    </div>
  </div>`}function sc(e){return $(e,`actions`,`Make something.`,S`
      <div class="showcase-row">
        <en-button id="showcase-create-trigger"
          >Create <en-icon slot="suffix" name="arrow-right"></en-icon
        ></en-button>
        <en-button
          variant="secondary"
          @click=${()=>e.open(`showcase-preview-dialog`)}
          >Preview</en-button
        >
        <en-button
          variant="ghost"
          icon-only
          @click=${()=>e.setLayout(`reset-canvas`)}
          ><en-icon slot="prefix" name="sparkles"></en-icon
          ><span slot="label">Reset canvas</span></en-button
        >
      </div>
      <en-text-field
        label="Study name"
        class="showcase-visually-labeled"
        placeholder="Name your next idea"
      ></en-text-field>
      <en-textarea
        label="Quick note"
        class="showcase-visually-labeled"
        placeholder="Leave a note for your future self…"
        rows="2"
      ></en-textarea>
      <div class="showcase-row">
        <en-badge variant="accent">In progress</en-badge
        ><en-badge>Local draft</en-badge><en-switch checked>Sync</en-switch>
      </div>
      <en-toolbar label="Canvas orientation"
        ><en-button
          variant="secondary"
          @click=${()=>e.setLayout(`portrait`)}
          >Portrait</en-button
        ><en-button
          variant="secondary"
          @click=${()=>e.setLayout(`landscape`)}
          >Landscape</en-button
        ></en-toolbar
      >
      <div class="showcase-row">
        <en-button id="showcase-menu-trigger" variant="ghost"
          >Actions<en-icon
            slot="suffix"
            name="chevron-down"
            size="inherit"
          ></en-icon></en-button
        ><en-button id="showcase-palette-trigger" variant="ghost"
          >All commands</en-button
        >
      </div>
      <p class="showcase-status" role="status">Canvas: ${e.data.canvas}.</p>
      <en-menu
        for="showcase-menu-trigger"
        label="Canvas actions"
        @en-action=${t=>e.command(t)}
        >${Ks.map(e=>S`<en-menu-item action=${e.action}>${e.label}</en-menu-item>`)}</en-menu
      >
      <en-command-palette
        id="showcase-palette"
        for="showcase-palette-trigger"
        label="Studio commands"
        search-label="Find a layout command"
        .commands=${Ks}
        @en-action=${t=>e.command(t)}
      ></en-command-palette>
      <en-dialog
        for="showcase-create-trigger"
        id="showcase-create-dialog"
        label="Start with a direction"
        ><p>
          Choose a canvas for this local study. You can change it at any time.
        </p>
        <div slot="footer" class="showcase-row">
          <en-button
            variant="secondary"
            @click=${()=>{e.setLayout(`portrait`),e.close(`showcase-create-dialog`)}}
            >Portrait</en-button
          ><en-button
            @click=${()=>{e.setLayout(`landscape`),e.close(`showcase-create-dialog`)}}
            >Landscape</en-button
          >
        </div></en-dialog
      >
    `)}function cc(e){return $(e,`navigation`,`Around the studio`,S`
      <en-breadcrumbs label="Current study path"
        ><a href="#showcase-navigation">Studio</a
        ><a href="#showcase-project">Projects</a
        ><span aria-current="page">New study</span></en-breadcrumbs
      >
      <div class="showcase-nav-pair">
        <en-navigation label="Planning"
          ><a href="#showcase-project">Projects</a
          ><a href="#showcase-activity">Activity</a
          ><a href="#showcase-readiness">Reviews</a
          ><a href="#showcase-library">Library</a></en-navigation
        >
        <en-navigation label="Workspace"
          ><a href="#showcase-team">People</a
          ><a href="#showcase-brand">Brand kit</a
          ><a href="#showcase-access">Access</a
          ><a href="#showcase-notifications">Notifications</a></en-navigation
        >
      </div>
    `,!1)}function lc(e){return $(e,`brief`,`A little direction`,S`
      <en-tabs label="Creative brief" value="idea">
        <en-tab slot="tab" value="idea">The idea</en-tab
        ><en-tab slot="tab" value="delivery">Delivery</en-tab>
        <en-tab-panel slot="panel" value="idea"
          ><p>
            A quieter workspace for a brighter idea. Start with a strong shape,
            an honest headline, and room to breathe.
          </p>
          <en-checkbox checked
            >Keep the headline editable</en-checkbox
          ></en-tab-panel
        >
        <en-tab-panel slot="panel" value="delivery"
          ><en-radio-group label="Export quality" value="review"
            ><en-radio value="review">Review quality</en-radio
            ><en-radio value="final">Final artwork</en-radio></en-radio-group
          ></en-tab-panel
        >
      </en-tabs>
      <en-accordion
        ><en-accordion-item value="review-guidance"
          ><span slot="label">What makes a useful review?</span>
          <p>
            Try one task, note where you hesitate, and share the result with
            your team.
          </p></en-accordion-item
        ></en-accordion
      >
    `)}function uc(e){return $(e,`brand`,`Small palette. Big possibility.`,S`
      <div class="showcase-swatches">
        ${[[`Brand`,`--en-color-brand`],[`Action`,`--en-color-action`],[`Surface`,`--en-color-surface-subtle`]].map(([e,t])=>S`<div data-token-sample>
              <en-swatch
                label=${`Copy ${e.toLowerCase()} color CSS reference`}
                token=${t}
                @en-action=${$s}
              ></en-swatch
              ><span>${e}</span><small role="status"></small>
            </div>`)}
      </div>
      <p>These three swatches follow the page theme.</p>
      <div
        class="showcase-color-preview"
        style=${Zs({"--study-accent":e.data.accent})}
      >
        <span>Studio / 04</span
        ><strong>Color outside<br />the expected.</strong>
      </div>
      <en-color-field
        label="Study color"
        value="#6d5ce7"
        @en-change=${t=>e.change(t,e=>e.value,t=>e.patch({accent:t}))}
      ></en-color-field>
      <p class="showcase-caption">Study color changes this artwork only.</p>
    `)}function dc(e){let t=Gs[e.data.activityRange],n=Math.max(...t.map(e=>e.value));return $(e,`activity`,`Creative momentum`,S`
      <p>A few small steps, every day.</p>
      <en-segmented-control
        label="Activity period"
        value="week"
        @en-change=${t=>e.change(t,e=>e.value,t=>e.patch({activityRange:t===`month`?`month`:`week`}))}
        ><en-segmented-item value="week">This week</en-segmented-item
        ><en-segmented-item value="month"
          >Six months</en-segmented-item
        ></en-segmented-control
      >
      <figure class="showcase-chart">
        <div class="showcase-bars" aria-hidden="true">
          ${t.map(e=>S`<div>
                <div
                  class="showcase-bar"
                  style=${Zs({"--bar-size":`${e.value/n*100}%`})}
                ></div>
                <span>${e.label}</span>
              </div>`)}
        </div>
        <figcaption>Contributions to studio projects · sample data</figcaption>
      </figure>
      <details>
        <summary>View activity data</summary>
        <table>
          <caption>
            Contributions per period
          </caption>
          <thead>
            <tr>
              <th scope="col">Period</th>
              <th scope="col">Contributions</th>
            </tr>
          </thead>
          <tbody>
            ${t.map(e=>S`<tr>
                  <th scope="row">${e.label}</th>
                  <td>${e.value}</td>
                </tr>`)}
          </tbody>
        </table>
      </details>
      <div class="showcase-summary-pair">
        <div>
          <span>Total contributions</span
          ><strong>${t.reduce((e,t)=>e+t.value,0)}</strong>
        </div>
        <div><span>Next review</span><strong>Friday</strong></div>
      </div>
      <a href=${e.href(`/workflows/assets`)}
        >Explore the asset workflow <span aria-hidden="true">↗</span></a
      >
    `)}function fc(e){let t=e.data.ready.filter(Boolean).length;return $(e,`readiness`,`Ready for a first impression`,S`
      <div class="showcase-metric">
        <strong>${t}<span> / 4</span></strong
        ><en-badge variant=${e.data.approved?`success`:`accent`}
          >${e.data.approved?`Approved`:`In review`}</en-badge
        >
      </div>
      <en-progress-bar
        label="Review checklist"
        .value=${t}
        max="4"
      ></en-progress-bar>
      <div class="showcase-checklist">
        ${[`The story is clear`,`The layout responds`,`Keyboard review complete`,`Alternative text checked`].map((t,n)=>S`<en-checkbox
              .checked=${e.data.ready[n]}
              @en-change=${t=>e.change(t,e=>e.checked,t=>e.patch({ready:e.data.ready.map((e,r)=>r===n?t:e),approved:!1}))}
              >${t}</en-checkbox
            >`)}
      </div>
      <en-button
        id="showcase-approve-trigger"
        ?disabled=${t!==4||e.data.approved}
        >Approve study</en-button
      >
      <en-dialog
        for="showcase-approve-trigger"
        id="showcase-approve-dialog"
        label="Ready to approve?"
        ><p>This marks the sample study as approved in this page only.</p>
        <div slot="footer" class="showcase-row">
          <en-button
            variant="ghost"
            @click=${()=>e.close(`showcase-approve-dialog`)}
            >Keep reviewing</en-button
          ><en-button @click=${()=>e.approve()}>Confirm approval</en-button>
        </div></en-dialog
      >
    `)}function pc(e){return $(e,`asset`,`One idea, many possibilities`,S`
      ${oc(e)}
      ${ic({items:[{label:`Study`,value:`Shape & space`},{label:`Format`,value:`Editable composition`},{label:`Owner`,value:`Mira Chen`}]})}
      <div class="showcase-row">
        <en-button @click=${()=>e.open(`showcase-preview-dialog`)}
          >Preview study</en-button
        ><en-button id="showcase-asset-info" icon-only variant="ghost"
          ><en-icon slot="prefix" name="info"></en-icon
          ><span slot="label">About this study</span></en-button
        >
      </div>
      <en-popover for="showcase-asset-info" label="About this study"
        ><p>
          This editable composition uses the active theme’s colors. Change its
          orientation in “Make something” and its opacity in “Every little
          detail.”
        </p></en-popover
      >
      <en-dialog id="showcase-preview-dialog" label="Shape & space"
        >${oc(e,!0)}
        <p>Canvas: ${e.data.canvas}. Opacity: ${e.data.opacity}%.</p>
        <en-button
          slot="footer"
          @click=${()=>e.close(`showcase-preview-dialog`)}
          >Back to the studio</en-button
        ></en-dialog
      >
    `,!1)}function mc(e){return $(e,`feedback`,`What’s your first impression?`,S`
      <en-rating
        id="feedback-rating"
        label="Study rating"
        value="4"
        max="5"
      ></en-rating>
      <en-textarea
        id="feedback-note"
        label="Review note"
        placeholder="What’s working? What could be clearer?"
        rows="3"
        required
      ></en-textarea>
      <en-button
        variant="secondary"
        @click=${()=>{e.valid(`feedback-note`)&&e.patch({feedback:`${e.value(`feedback-rating`)} / 5 — ${e.value(`feedback-note`)}`})}}
        >Add review</en-button
      >
      <p class="showcase-status" role="status">${e.data.feedback}</p>
    `)}function hc(e){return $(e,`project`,`Set your next milestone`,S`
      <p>Give an idea a name, a team, and a little momentum.</p>
      <form
        @submit=${t=>{t.preventDefault(),e.createProject()}}
      >
        <en-text-field
          id="project-title"
          label="Project name"
          placeholder="A fresh perspective"
          required
        ></en-text-field>
        <div class="showcase-field-pair">
          <en-select id="project-kind" label="Project type" value="campaign"
            ><en-select-option value="campaign">Campaign</en-select-option
            ><en-select-option value="identity">Identity</en-select-option
            ><en-select-option value="product"
              >Product</en-select-option
            ></en-select
          ><en-date-picker calendar-loading="deferred"
            id="project-date"
            label="Review date"
            value="2026-09-18"
            today="2026-09-14"
            required
          ></en-date-picker>
        </div>
        <en-button @click=${()=>e.createProject()}
          >Create project</en-button
        >
      </form>
      <p class="showcase-status" role="status">${e.data.projectStatus}</p>
    `)}function gc(e){return $(e,`output`,`Every little detail`,S`
      <p>Shape the output to fit the idea.</p>
      <en-select label="Export format" value="png"
        ><en-select-option value="png">PNG · Raster image</en-select-option
        ><en-select-option value="svg">SVG · Vector image</en-select-option
        ><en-select-option value="pdf"
          >PDF · Document</en-select-option
        ></en-select
      >
      <en-slider
        label="Artwork opacity"
        .value=${e.data.opacity}
        min="0"
        max="100"
        step="1"
        editable
        @en-change=${t=>e.change(t,e=>Number(e.value),t=>e.patch({opacity:t}))}
      ></en-slider>
      <en-number-field
        label="Export scale"
        .value=${String(e.data.scale)}
        min="25"
        max="400"
        step="25"
        @en-change=${t=>e.change(t,e=>e.value,t=>e.patch({scale:Number(t)}))}
      ></en-number-field>
      <en-checkbox checked>Include transparent background</en-checkbox>
      <en-textarea
        label="Export notes"
        placeholder="Anything the next person should know?"
        rows="3"
      ></en-textarea>
      <en-button id="showcase-output-trigger" variant="ghost"
        >More export options<en-icon slot="suffix" name="chevron-down"></en-icon
      ></en-button>
      <en-drawer
        for="showcase-output-trigger"
        id="showcase-output-drawer"
        label="Export options"
        presentation="responsive"
        ><en-stack
          ><en-checkbox checked>Keep layer names</en-checkbox
          ><en-checkbox>Include review notes</en-checkbox
          ><en-textarea
            label="Handoff message"
            rows="3"
          ></en-textarea></en-stack
        ><en-button
          slot="footer"
          @click=${()=>e.close(`showcase-output-drawer`)}
          >Done</en-button
        ></en-drawer
      >
      <div class="showcase-summary-pair">
        <div><span>Opacity</span><strong>${e.data.opacity}%</strong></div>
        <div><span>Scale</span><strong>${e.data.scale}%</strong></div>
      </div>
    `)}function _c(e){return $(e,`access`,`Your own corner of the studio`,S`
      <en-text-field
        id="access-email"
        label="Work email"
        type="email"
        autocomplete="email"
        pattern="[^\\s@]+@[^\\s@]+\\.[^\\s@]+"
        placeholder="you@studio.com"
        required
      ></en-text-field>
      <en-text-field
        id="access-password"
        label="Password"
        type="password"
        autocomplete="new-password"
        minlength="8"
        description="At least 8 characters. Use a sample password here."
        required
      ></en-text-field>
      <en-switch>Remember this device</en-switch>
      <en-button variant="secondary" @click=${()=>e.saveAccess()}
        >Check details</en-button
      >
      <p class="showcase-status" role="status">${e.data.accessStatus}</p>
    `)}function vc(e){return $(e,`notifications`,`Keep the useful signals`,S`
      <en-switch id="notify-mentions" checked>Mentions and replies</en-switch
      ><en-switch id="notify-reviews" checked>New review requests</en-switch
      ><en-switch id="notify-digest">Weekly studio digest</en-switch>
      <en-button
        variant="secondary"
        @click=${()=>e.patch({notificationStatus:`Saved locally: ${[`mentions`,`reviews`,`digest`].filter(t=>e.field(`notify-${t}`).checked).join(`, `)||`all notifications off`}.`})}
        >Save preferences</en-button
      >
      <p class="showcase-status" role="status">
        ${e.data.notificationStatus}
      </p>
    `)}function yc(e){return $(e,`team`,`Better, together.`,S`
      <p>A small team with room for another perspective.</p>
      <ul class="showcase-people">
        ${_r(e.data.members,e=>e,(e,t)=>S`<li>
              <en-avatar name=${e}></en-avatar>
              <div>
                <strong>${e}</strong
                ><span
                  >${t===0?`Designer · Owner`:`Collaborator`}</span
                >
              </div>
              <en-badge>${t===0?`You`:`Member`}</en-badge>
            </li>`)}
      </ul>
      <en-combobox
        id="team-person"
        label="Add a teammate"
        placeholder="Search people…"
        .items=${Ws}
      ></en-combobox>
      <en-select id="team-role" label="Access level" value="editor"
        ><en-select-option value="editor">Editor</en-select-option
        ><en-select-option value="reviewer">Reviewer</en-select-option
        ><en-select-option value="viewer">Viewer</en-select-option></en-select
      >
      <en-button @click=${()=>e.invite()}
        >Add to demo team<en-icon slot="suffix" name="plus"></en-icon
      ></en-button>
      <p class="showcase-status" role="status">${e.data.invitationStatus}</p>
    `)}function bc(e){return $(e,`chat`,`A thought to get you started`,S`
      ${e.data.messages.length?S`<ol class="showcase-messages" aria-label="Sample conversation">
              ${_r(e.data.messages,e=>e.id,e=>S`<li data-who=${e.who}>
                    <strong>${e.who}</strong>
                    <p>${e.text}</p>
                  </li>`)}
            </ol>`:S`<div class="showcase-chat-welcome">
              <en-icon name="sparkles" size="large"></en-icon>
              <h3>What are we making today?</h3>
              <p>A rough idea is a good place to start.</p>
            </div>`}
      <en-textarea
        id="chat-message"
        label="Message"
        class="showcase-visually-labeled"
        placeholder="I’m exploring a new direction…"
        rows="3"
      ></en-textarea>
      <div class="showcase-row showcase-between">
        <span class="showcase-caption"
          >Local sample response · no AI connection</span
        ><en-button @click=${()=>e.sendMessage()}
          >Send<en-icon slot="suffix" name="arrow-right"></en-icon
        ></en-button>
      </div>
      <p class="showcase-status" role="status">${e.data.chatStatus}</p>
    `)}function xc(e){return $(e,`share`,`Bring another screen`,S`
      <div class="showcase-share-art" aria-hidden="true">
        <en-icon name="arrow-right" size="large"></en-icon>
      </div>
      <p>Open this showcase on another screen to compare the layout.</p>
      <a href=${e.href(`/showcase`)}>Open showcase</a>
      <en-button variant="secondary" @click=${()=>e.copyLink()}
        >Copy showcase link</en-button
      >
      <p class="showcase-caption">
        A localhost address opens only on the computer running this preview.
      </p>
      <p class="showcase-status" role="status">${e.data.shareStatus}</p>
    `)}function Sc(e){return $(e,`library`,`A place for what’s next`,S`
      ${e.data.inserted?S`<div class="showcase-row">
              <en-icon name="sparkles" size="large"></en-icon>
              <div>
                <h3>First spark</h3>
                <p>Your sample asset is in the collection.</p>
              </div>
              <en-badge variant="success">1 asset</en-badge>
            </div>`:ac({title:S`<h3>No assets yet</h3>`,description:`Every collection starts with one good find.`,actions:S`<en-button
                variant="secondary"
                @click=${()=>e.patch({inserted:!0})}
                >Add a sample asset</en-button
              >`})}
      <en-button id="showcase-library-help" variant="ghost"
        >How this collection works<en-icon
          slot="suffix"
          name="chevron-down"
        ></en-icon
      ></en-button>
      <en-popover for="showcase-library-help" label="About the collection"
        ><p>
          Add an authored sample asset to this page. Use Reset to empty the
          collection again.
        </p>
        <en-checkbox checked>Keep the source editable</en-checkbox></en-popover
      >
    `)}function Cc(e){return S`<div class="showcase-grid">
    <div class="showcase-column">
      ${sc(e)}${cc(e)}${lc(e)}${uc(e)}
    </div>
    <div class="showcase-column">
      ${dc(e)}${fc(e)}${pc(e)}${mc(e)}
    </div>
    <div class="showcase-column">
      ${hc(e)}${gc(e)}${_c(e)}${vc(e)}
    </div>
    <div class="showcase-column">
      ${yc(e)}${bc(e)}${xc(e)}${Sc(e)}
    </div>
  </div>`}var wc=class extends $e{state=new k.State(qs());revision=new k.State(0);observer=new j(this,()=>[this.state.get(),this.revision.get()]);resets=new Map;get data(){return this.state.get()}touch(){this.revision.set(this.revision.get()+1)}patch(e){this.state.set({...this.data,...e})}href(e){return e===`/showcase`?location.pathname:`https://en-reve-docs.reve-ai-0869.chatgpt.site`+e}createRenderRoot(){return this}field(e){return this.querySelector(`#${e}`)}value(e){return this.field(e).value}valid(...e){for(let t of e)if(!this.field(t).reportValidity())return this.field(t).focus(),!1;return!0}change(e,t,n){Us(e,t,n)}setLayout(e){[`portrait`,`landscape`,`reset-canvas`].includes(e)&&this.patch({canvas:e===`reset-canvas`?`portrait`:e})}command(e){let t=e.currentTarget,n=e.detail?.action;queueMicrotask(async()=>{await t.updateComplete,!e.defaultPrevented&&t.isConnected&&!t.open&&this.setLayout(n)})}open(e){this.querySelector(`#${e}`).open=!0}close(e){this.querySelector(`#${e}`).open=!1}async approve(){this.patch({approved:!0}),this.close(`showcase-approve-dialog`),await this.updateComplete,await this.querySelector(`#showcase-approve-dialog`).updateComplete;let e=this.querySelector(`#showcase-heading-readiness`);e.tabIndex=-1,e.focus({preventScroll:!0})}createProject(){if(!this.valid(`project-title`,`project-date`)){this.patch({projectStatus:`Add a project name and a valid review date.`});return}this.patch({project:this.value(`project-title`),projectStatus:`${this.value(`project-title`)} created locally. Review: ${this.value(`project-date`)}.`})}invite(){let e=Ws.find(e=>e.value===this.value(`team-person`));if(!e){this.patch({invitationStatus:`Choose a teammate from the list.`}),this.field(`team-person`).focus();return}if(this.data.members.includes(e.label)){this.patch({invitationStatus:`${e.label} is already on the team.`});return}this.patch({members:[...this.data.members,e.label],invitationStatus:`${e.label} added to this demo team as ${this.value(`team-role`)}.`})}sendMessage(){let e=this.value(`chat-message`).trim();if(!e){this.patch({chatStatus:`Write a message first.`}),this.field(`chat-message`).focus();return}let t=this.data.messages.length;this.patch({messages:[...this.data.messages,{id:t,who:`You`,text:e},{id:t+1,who:`Demo assistant`,text:`Try a portrait composition, compare two accent colors, and ask your team for a first impression.`}],chatStatus:`Message added. A sample response is shown below.`}),this.field(`chat-message`).value=``,this.field(`chat-message`).focus()}saveAccess(){this.valid(`access-email`,`access-password`)?this.patch({accessStatus:`Local form validated for ${this.value(`access-email`)}. No account was created.`}):this.patch({accessStatus:`Check the highlighted fields.`})}async copyLink(){try{await navigator.clipboard.writeText(location.href),this.patch({shareStatus:`Showcase link copied.`})}catch{this.patch({shareStatus:`Copy unavailable. Use the link above to copy the address.`})}}reset(e){let t=qs();this.patch(Object.fromEntries(({actions:[`canvas`],activity:[`activityRange`],readiness:[`ready`,`approved`],project:[`project`,`projectStatus`],output:[`opacity`,`scale`],brand:[`accent`],team:[`members`,`invitationStatus`],chat:[`messages`,`chatStatus`],feedback:[`feedback`],access:[`accessStatus`],notifications:[`notificationStatus`],share:[`shareStatus`],library:[`inserted`]}[e]??[]).map(e=>[e,t[e]]))),this.resets.set(e,(this.resets.get(e)??0)+1),this.touch()}render(){return S`<div class="showcase-page">
      <main id="showcase">
        <div class="showcase-heading">
          <div>
            <h1>Made of en-reve.</h1>
            <p>
              Creative work, in sixteen small spaces. Local demos; nothing is
              sent or saved after reload.
            </p>
          </div>
        </div>
        ${Cc(this)}
      </main>
    </div>`}};if(new URLSearchParams(location.search).has(`progress-report`)){let e=document.createElement(`a`);e.className=`progress-return`,e.href=`http://127.0.0.1:4177`,e.textContent=`Progress Report`,document.body.append(e)}lt({document,registry:`global`}).register([bo]),customElements.define(`en-showcase-app`,wc),document.getElementById(`root`).append(document.createElement(`en-showcase-app`));export{T as A,N as C,A as D,un as E,_ as M,on as O,P as S,j as T,z as _,ao as a,An as b,Ka as c,co as d,Ia as f,V as g,Pn as h,uo as i,S as j,E as k,io as l,U as m,po as n,ro as o,Vr as p,mo as r,no as s,fo as t,X as u,B as v,M as w,L as x,R as y};
//# sourceMappingURL=index-BuDGUI--.js.map