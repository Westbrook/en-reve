import{i as e}from"./Base-C029uGPE.js";function t(t){return e({...t,state:!0,attribute:!1})}export{t};
//# sourceMappingURL=state-CRZlQpoJ.js.map