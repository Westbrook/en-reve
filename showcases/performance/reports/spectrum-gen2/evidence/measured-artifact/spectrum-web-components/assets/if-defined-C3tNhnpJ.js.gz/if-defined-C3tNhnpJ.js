import{o as e}from"./Base-C029uGPE.js";var t=t=>t??e;export{t};
//# sourceMappingURL=if-defined-C3tNhnpJ.js.map