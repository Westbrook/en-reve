# spectrum-gen2-interactions-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 60/60 samples retained; 10 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| fluent-web-components | desktop/cold | on | 10 / 0 | 80.0 | 80.0 | 0.0001 | 72.1 | 40.0 |
| en-reve | desktop/cold | on | 10 / 0 | 94.0 | 94.0 | 0.0000 | 82.2 | 40.0 |
| fluent-web-components | mobile/cold | on | 10 / 0 | 506.0 | 506.0 | 0.0000 | 501.2 | 64.0 |
| spectrum-web-components | mobile/cold | on | 10 / 10 | — | — | — | — | — |
| spectrum-web-components | desktop/cold | on | 10 / 0 | 112.0 | 112.0 | 0.0000 | 102.0 | 40.0 |
| en-reve | mobile/cold | on | 10 / 0 | 598.0 | 598.0 | 0.0000 | 592.8 | 48.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
