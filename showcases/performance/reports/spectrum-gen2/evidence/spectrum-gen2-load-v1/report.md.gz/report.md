# spectrum-gen2-load-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 120/120 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| fluent-web-components | mobile/cold | on | 10 / 0 | 500.0 | 500.0 | 0.0000 | 495.3 | — |
| spectrum-web-components | mobile/warm | on | 10 / 0 | 288.0 | 288.0 | 0.0000 | 303.6 | — |
| fluent-web-components | desktop/cold | on | 10 / 0 | 78.0 | 78.0 | 0.0001 | 70.5 | — |
| en-reve | mobile/warm | on | 10 / 0 | 276.0 | 276.0 | 0.0000 | 284.1 | — |
| fluent-web-components | desktop/warm | on | 10 / 0 | 28.0 | 28.0 | 0.0001 | 26.5 | — |
| en-reve | desktop/warm | on | 10 / 0 | 44.0 | 44.0 | 0.0000 | 42.4 | — |
| spectrum-web-components | desktop/cold | on | 10 / 0 | 112.0 | 112.0 | 0.0000 | 100.5 | — |
| spectrum-web-components | desktop/warm | on | 10 / 0 | 48.0 | 48.0 | 0.0000 | 46.8 | — |
| fluent-web-components | mobile/warm | on | 10 / 0 | 206.0 | 206.0 | 0.0000 | 212.3 | — |
| en-reve | desktop/cold | on | 10 / 0 | 92.0 | 92.0 | 0.0000 | 80.3 | — |
| spectrum-web-components | mobile/cold | on | 10 / 0 | 776.0 | 776.0 | 0.0000 | 772.7 | — |
| en-reve | mobile/cold | on | 10 / 0 | 596.0 | 596.0 | 0.0000 | 592.2 | — |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
