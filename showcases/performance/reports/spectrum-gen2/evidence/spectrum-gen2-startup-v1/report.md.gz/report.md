# spectrum-gen2-startup-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 60/60 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| fluent-web-components | desktop/cold | on | 10 / 0 | 80.0 | — | 0.0001 | 70.2 | 32.0 |
| en-reve | desktop/cold | on | 10 / 0 | 96.0 | — | 0.0000 | 85.0 | 32.0 |
| fluent-web-components | mobile/cold | on | 10 / 0 | 512.0 | — | 0.0000 | 519.7 | 48.0 |
| spectrum-web-components | mobile/cold | on | 10 / 0 | 772.0 | — | 0.0000 | 770.8 | 48.0 |
| spectrum-web-components | desktop/cold | on | 10 / 0 | 112.0 | — | 0.0000 | 100.8 | 40.0 |
| en-reve | mobile/cold | on | 10 / 0 | 608.0 | — | 0.0000 | 603.3 | 44.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
