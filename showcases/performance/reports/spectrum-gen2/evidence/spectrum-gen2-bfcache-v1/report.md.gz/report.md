# spectrum-gen2-bfcache-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 15/15 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| fluent-web-components | desktop/cold | on | 5 / 0 | 24.6 | 24.6 | 0.0000 | 61.4 | 40.0 |
| spectrum-web-components | desktop/cold | on | 5 / 0 | 23.9 | 24.0 | 0.0000 | 92.3 | 48.0 |
| en-reve | desktop/cold | on | 5 / 0 | 33.9 | 34.0 | 0.0000 | 73.0 | 32.0 |

## Return navigation

Automation diagnostic, not field hit rate. Non-restoration is an explicit outcome; raw navigation entries retain available reasons.

| System | Attempts | Same document and persisted pageshow | Interactive after return |
| --- | ---: | ---: | ---: |
| fluent-web-components | 5 | 5 | 5 |
| spectrum-web-components | 5 | 5 | 5 |
| en-reve | 5 | 3 | 5 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
