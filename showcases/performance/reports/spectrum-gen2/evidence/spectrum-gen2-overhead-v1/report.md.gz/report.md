# spectrum-gen2-overhead-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 30/30 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| fluent-web-components | desktop/cold | off | 5 / 0 | 80.0 | — | — | — | — |
| en-reve | desktop/cold | off | 5 / 0 | 92.0 | — | — | — | — |
| fluent-web-components | desktop/cold | on | 5 / 0 | 80.0 | 80.0 | 0.0001 | 70.5 | — |
| spectrum-web-components | desktop/cold | on | 5 / 0 | 108.0 | 108.0 | 0.0000 | 99.0 | — |
| spectrum-web-components | desktop/cold | off | 5 / 0 | 108.0 | — | — | — | — |
| en-reve | desktop/cold | on | 5 / 0 | 92.0 | 92.0 | 0.0000 | 82.8 | — |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
