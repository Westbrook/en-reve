# spectrum-gen2-diagnostic-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 3/3 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| fluent-web-components | desktop/cold | on | 1 / 0 | 116.0 | 116.0 | 0.0001 | 105.0 | 48.0 |
| spectrum-web-components | desktop/cold | on | 1 / 0 | 168.0 | 168.0 | 0.0000 | 158.8 | 48.0 |
| en-reve | desktop/cold | on | 1 / 0 | 128.0 | 128.0 | 0.0000 | 116.6 | 48.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
