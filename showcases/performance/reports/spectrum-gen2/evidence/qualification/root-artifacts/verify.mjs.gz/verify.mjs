import {readFile,writeFile,mkdir,open} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {exclusiveBrowserWork} from '../../showcases/performance/src/lock.mjs';
await exclusiveBrowserWork(async()=>{
for(const engine of ['chromium','firefox','webkit']){
 await mkdir(`artifacts/spectrum-wc-migration/${engine}`,{recursive:true});
 for(const suite of ['smoke','secondary']){
  const source=(await readFile(`showcases/tools/${suite}.mjs`,'utf8')).replace('import { chromium, expect }',`import { ${engine} as chromium, expect }`);
  const file=`artifacts/spectrum-wc-migration/${engine}/${suite}.mjs`;await writeFile(file,source);
  const log=await open(`artifacts/spectrum-wc-migration/${engine}/${suite}.log`,'w');
  const exitCode=await new Promise((resolve,reject)=>{const c=spawn(process.execPath,[file],{stdio:['ignore',log.fd,log.fd],env:{...process.env,SHOWCASE_FILTER:'spectrum-web-components',SHOWCASE_ARTIFACTS:process.cwd()+`/artifacts/spectrum-wc-migration/${engine}/`}});c.on('error',reject);c.on('exit',resolve)});await log.close();console.log(engine,suite,exitCode);
 }
}
});
