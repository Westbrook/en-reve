import {spawn} from 'node:child_process';import {open} from 'node:fs/promises';import {exclusiveBrowserWork} from '../../showcases/performance/src/lock.mjs';
async function run(args,name,env={}){let f=await open(`artifacts/spectrum-wc-migration/${name}.log`,'w');try{let code=await new Promise((res,rej)=>{let c=spawn(args[0],args.slice(1),{stdio:['ignore',f.fd,f.fd],env:{...process.env,...env}});c.on('error',rej);c.on('exit',res)});if(code)throw Error(name+' exit '+code);}finally{await f.close()}}
await exclusiveBrowserWork(async()=>{
 await run(['npm','run','build','-w','@en-reve/docs'],'docs-build');
 await run(['node','--test','--test-name-pattern=spectrum-inspired','tooling/theme-candidates/catalogue.test.mjs'],'theme-unit-final');
 await run(['npx','playwright','test','--config','apps/docs/tests/theme-refresh.config.ts','--grep','spectrum-inspired'],'theme-browser',{EN_DOCS_ORIGIN:'http://127.0.0.1:4493',EN_THEME_REFRESH_OUTPUT_DIR:process.cwd()+'/artifacts/spectrum-wc-migration/theme-browser'});
});
