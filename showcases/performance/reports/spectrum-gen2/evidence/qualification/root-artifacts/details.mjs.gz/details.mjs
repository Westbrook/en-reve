import {chromium,firefox,webkit,expect} from '@playwright/test';
import {readFile,writeFile,open} from 'node:fs/promises';import {spawn} from 'node:child_process';
import {exclusiveBrowserWork} from '../../showcases/performance/src/lock.mjs';
import {installStartupProbe} from '../../showcases/performance/scenarios/startup.mjs';
await exclusiveBrowserWork(async()=>{
 const results=[];
 for(const [engine,type] of Object.entries({chromium,firefox,webkit})){
  const b=await type.launch();try{const page=await b.newPage({viewport:{width:1500,height:1100}});const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.addInitScript(installStartupProbe);await page.goto('http://127.0.0.1:4516/?progress-report');
   await page.waitForFunction(()=>window.__startupProbe?.found);expect(await page.evaluate(()=>window.__startupProbe.tag)).toBe('swc-button');
   const tags=await page.evaluate(()=>[...new Set([...document.querySelectorAll('*')].map(x=>x.localName).filter(n=>n.startsWith('swc-')))]);
   for(const tag of ['swc-button','swc-action-button','swc-badge','swc-avatar','swc-tabs','swc-tab','swc-tab-panel','swc-accordion','swc-accordion-item','swc-progress-bar','swc-popover'])expect(tags).toContain(tag);
   const brief=page.locator('#showcase-brief');await brief.getByRole('tab',{name:'The idea',exact:true}).press('ArrowRight');await expect(brief.getByRole('tab',{name:'Delivery',exact:true})).toHaveAttribute('aria-selected','true');await brief.getByRole('tab',{name:'Delivery',exact:true}).press('ArrowLeft');
   await brief.getByRole('button',{name:'What makes a useful review?',exact:true}).click();await expect(brief.locator('swc-accordion-item')).toHaveAttribute('open','');
   const readiness=page.locator('#showcase-readiness');await expect(readiness.getByRole('progressbar',{name:'Review checklist',exact:true})).toHaveAttribute('aria-valuenow','50');await readiness.getByRole('checkbox',{name:'Keyboard review complete',exact:true}).click();await expect(readiness.getByRole('progressbar',{name:'Review checklist',exact:true})).toHaveAttribute('aria-valuenow','75');
   await expect(page.locator('#showcase-team').getByRole('img',{name:'Mira Chen',exact:true})).toBeVisible();
   const library=page.locator('#showcase-library');const help=library.getByRole('button',{name:'How this collection works',exact:true});await help.click();await expect(library.getByRole('dialog',{name:'How this collection works',exact:true})).toBeVisible();await page.keyboard.press('Escape');await expect(library.getByRole('dialog',{name:'How this collection works',exact:true})).not.toBeVisible();await expect(help).toBeFocused();await library.getByRole('button',{name:/Reset/}).click();await help.click();await expect(library.getByRole('dialog',{name:'How this collection works',exact:true})).toBeVisible();await page.keyboard.press('Escape');
   expect(errors).toEqual([]);results.push({engine,browser:b.version(),passed:true,gen2Tags:tags,checks:['Gen2 startup target','individual components registered','automatic keyboard tabs','accordion label/open','progress label/value updates','avatar name','popover Escape/focus and reset reconnection']});
  }catch(e){results.push({engine,passed:false,error:String(e)});}finally{await b.close();}
 }
 await writeFile('artifacts/spectrum-wc-migration/detail-verification.json',JSON.stringify(results,null,2)+'\n');console.log(results);
 const f=await open('artifacts/spectrum-wc-migration/webkit/secondary-rerun.log','w');try{const code=await new Promise((res,rej)=>{const c=spawn(process.execPath,['artifacts/spectrum-wc-migration/webkit/secondary.mjs'],{stdio:['ignore',f.fd,f.fd],env:{...process.env,SHOWCASE_FILTER:'spectrum-web-components',SHOWCASE_ARTIFACTS:process.cwd()+'/artifacts/spectrum-wc-migration/webkit/recheck/'}});c.on('error',rej);c.on('exit',res)});console.log('WebKit secondary recheck',code)}finally{await f.close()}
});
