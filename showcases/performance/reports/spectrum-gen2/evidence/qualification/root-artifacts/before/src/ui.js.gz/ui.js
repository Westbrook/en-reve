import "@spectrum-web-components/theme/sp-theme.js";
import "@spectrum-web-components/theme/spectrum-two/theme-light.js";
import "@spectrum-web-components/theme/spectrum-two/scale-medium.js";
import "./style.css";
export const libraryName = "Spectrum Web Components";
export const provider = (s) =>
  `<sp-theme system="spectrum-two" color="light" scale="medium">${s}</sp-theme>`;
export const card = (s) => `<div class="native-card">${s}</div>`;
export const button = (label, action, secondary = false, attrs = "") =>
  `<sp-button variant="${secondary ? "secondary" : "accent"}" data-action="${action}" ${attrs}>${label}</sp-button>`;
export const input = (
  id,
  label,
  placeholder = "",
  type = "text",
  value = "",
) =>
  type === "date"
    ? `<label class="field">${label}<input id="${id}" aria-label="${label}" type="date" value="${value}"></label>`
    : `<div class="field"><sp-field-label for="${id}">${label}</sp-field-label><sp-textfield id="${id}" label="${label}" placeholder="${placeholder}" ${type === "textarea" ? 'multiline rows="3"' : `type="${type}"`} value="${value}"></sp-textfield></div>`;
export const check = (id, label, checked = false) =>
  `<sp-checkbox id="${id}" ${checked ? "checked" : ""}>${label}</sp-checkbox>`;
export const toggle = (id, label, checked = false) =>
  `<sp-switch id="${id}" ${checked ? "checked" : ""}>${label}</sp-switch>`;
export const badge = (s, id = "") =>
  `<sp-badge ${id ? `id="${id}"` : ""}>${s}</sp-badge>`;
export const avatar = (name) =>
  `<sp-avatar label="${name}" src="data:image/svg+xml,${encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='40' height='40'><rect width='40' height='40' fill='#ddd'/><text x='20' y='26' text-anchor='middle' font-family='sans-serif' font-size='14'>${name
      .split(" ")
      .map((x) => x[0])
      .join("")}</text></svg>`,
  )}"></sp-avatar>`;
export const select = (id, label, options, value = options[0]) =>
  `<div class="field"><sp-field-label for="${id}">${label}</sp-field-label><sp-picker id="${id}" label="${label}" value="${value}">${options.map((x) => `<sp-menu-item value="${x}" ${value === x ? "selected" : ""}>${x}</sp-menu-item>`).join("")}</sp-picker></div>`;
export const combo = (id, label, options) =>
  `<div class="field"><sp-field-label for="${id}">${label}</sp-field-label><sp-combobox id="${id}" label="${label}" placeholder="Search people…">${options.map((x) => `<sp-menu-item value="${x}">${x}</sp-menu-item>`).join("")}</sp-combobox></div>`;
export const segments = (id, label, options) =>
  `<sp-radio-group id="${id}" label="${label}" selected="${options[0]}" horizontal>${options.map((x, i) => `<sp-radio value="${x}" ${i ? "" : "checked"}>${x}</sp-radio>`).join("")}</sp-radio-group>`;
export const tabs = (items) =>
  `<sp-tabs selected="idea" label="Creative brief">${items.map((x) => `<sp-tab value="${x.id}" label="${x.label}"></sp-tab><sp-tab-panel value="${x.id}"><div class="stack">${x.content}</div></sp-tab-panel>`).join("")}</sp-tabs>`;
export const disclosure = (label, s) =>
  `<sp-accordion><sp-accordion-item label="${label}"><p>${s}</p></sp-accordion-item></sp-accordion>`;
export const radio = (label, options) =>
  `<sp-radio-group label="${label}" selected="${options[0]}">${options.map((x, i) => `<sp-radio value="${x}" ${i ? "" : "checked"}>${x}</sp-radio>`).join("")}</sp-radio-group>`;
export const slider = (id, label, value) =>
  `<sp-slider id="${id}" label="${label}" value="${value}" min="0" max="100" step="1"></sp-slider>`;
export const number = (id, label, value) =>
  `<div class="field"><sp-field-label for="${id}">${label}</sp-field-label><sp-number-field id="${id}" label="${label}" value="${value}" min="25" max="400" step="25"></sp-number-field></div>`;
export const color = (id, label, value) =>
  `<div class="field"><sp-field-label for="${id}">${label}</sp-field-label><sp-color-field id="${id}" label="${label}" value="${value}"></sp-color-field></div>`;
export const progress = (id, value, max) =>
  `<sp-progress-bar id="${id}" label="Review checklist" progress="${(value / max) * 100}"></sp-progress-bar>`;
export const dialog = (id, title, body) =>
  `<sp-overlay id="${id}-dialog" type="modal"><sp-dialog size="m"><h2 slot="heading">${title}</h2><div class="stack">${body}</div><sp-button slot="button" variant="secondary" data-action="close:${id}">Close</sp-button></sp-dialog></sp-overlay>`;
export const drawer = dialog;
export const menu = (label, items) =>
  `<overlay-trigger placement="bottom-start"><sp-action-button slot="trigger">${label} ▾</sp-action-button><sp-popover slot="click-content"><sp-menu>${items.map(([l, a]) => `<sp-menu-item data-action="${a}">${l}</sp-menu-item>`).join("")}</sp-menu></sp-popover></overlay-trigger>`;
export const popover = (label, body) =>
  `<overlay-trigger placement="bottom-start"><sp-action-button slot="trigger">${label}</sp-action-button><sp-popover slot="click-content"><div class="stack" style="padding:16px;max-width:320px">${body}</div></sp-popover></overlay-trigger>`;
export const open = (e) => {
  e.open = true;
};
export const close = (e) => {
  e.open = false;
};
export const value = (e) =>
  e.localName === "sp-radio-group" ? e.selected : (e.value ?? "");
export const setValue = (e, v) => {
  e.value = v;
};
export const checked = (e) => e.checked;
export const setProgress = (e, v, m) => {
  e.progress = (v / m) * 100;
};

export const link = (href, label) =>
  `<sp-link href="${href}">${label}</sp-link>`;
