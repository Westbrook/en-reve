import { chromium } from 'playwright';
import { writeFile } from 'node:fs/promises';
import { exclusiveBrowserWork } from '../../showcases/performance/src/lock.mjs';
const phase=process.argv[2]??'before';
await exclusiveBrowserWork(async()=>{
const browser=await chromium.launch();const page=await browser.newPage({viewport:{width:1440,height:1100}});const evidence={};
for (const [name,url] of Object.entries({native:'http://127.0.0.1:4516/?progress-report',inspired:'http://127.0.0.1:4493/showcase?theme=spectrum-inspired&appearance=light&progress-report'})) {
 await page.goto(url);await page.waitForTimeout(800); if(name==='inspired') await page.getByText('Applied Spectrum 2-inspired · Light and dark. Demo edits are preserved.',{exact:true}).waitFor();
 evidence[name]=await page.evaluate(()=>{
 const rows=[];function visit(root){for(const el of root.querySelectorAll('*')){if(el.shadowRoot)visit(el.shadowRoot);if(el.hasAttribute('part')||el.matches('h2,body')){let s=getComputedStyle(el),r=el.getBoundingClientRect();if(r.width&&r.height)rows.push({tag:el.tagName,host:el.getRootNode().host?.tagName,part:el.getAttribute('part'),text:el.textContent.trim().slice(0,50),card:(el.getRootNode().host??el).closest('[id^="showcase-"]')?.id,width:r.width,height:r.height,font:s.font,background:s.backgroundColor,color:s.color,border:s.border,borderRadius:s.borderRadius,padding:s.padding,shadow:s.boxShadow})}}}visit(document);return rows;});
 for(const id of ['actions','brief','readiness','team']){await page.locator('#showcase-'+id).scrollIntoViewIfNeeded();await page.locator('#showcase-'+id).screenshot({path:`artifacts/spectrum-wc-migration/${phase}-${name}-${id}.png`});}
}
await writeFile(`artifacts/spectrum-wc-migration/${phase}-computed.json`,JSON.stringify(evidence,null,2));await browser.close();
});
