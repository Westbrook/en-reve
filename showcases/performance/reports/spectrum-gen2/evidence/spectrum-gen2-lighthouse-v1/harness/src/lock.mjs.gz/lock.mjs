import { mkdir, writeFile, readFile, unlink } from "node:fs/promises";
import { resolve } from "node:path";
import { root, json } from "./config.mjs";
export async function exclusiveBrowserWork(work) {
  const path = resolve(root, ".cache/browser-run.lock");
  await mkdir(resolve(root, ".cache"), { recursive: true });
  try {
    await writeFile(
      path,
      json({ pid: process.pid, at: new Date().toISOString() }),
      { flag: "wx" },
    );
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
    const prior = JSON.parse(await readFile(path));
    let alive = true;
    try {
      process.kill(prior.pid, 0);
    } catch (error) {
      if (error.code === "ESRCH") alive = false;
      else throw error;
    }
    if (alive)
      throw new Error(
        `Another browser campaign is active (PID ${prior.pid}). Keep measurements serial.`,
      );
    await unlink(path);
    await writeFile(
      path,
      json({ pid: process.pid, at: new Date().toISOString() }),
      { flag: "wx" },
    );
  }
  try {
    return await work();
  } finally {
    await unlink(path);
  }
}
