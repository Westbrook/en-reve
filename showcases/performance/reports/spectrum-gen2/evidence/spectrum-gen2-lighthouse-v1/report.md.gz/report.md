# spectrum-gen2-lighthouse-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 15/15 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| fluent-web-components | mobile/cold | Lighthouse | 5 / 0 | 553.1 | 553.1 | 0.0000 | — | — |
| spectrum-web-components | mobile/cold | Lighthouse | 5 / 0 | 958.8 | 958.8 | 0.0000 | — | — |
| en-reve | mobile/cold | Lighthouse | 5 / 0 | 701.8 | 701.8 | 0.0000 | — | — |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
