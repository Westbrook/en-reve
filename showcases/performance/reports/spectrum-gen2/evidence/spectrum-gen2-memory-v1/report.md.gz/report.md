# spectrum-gen2-memory-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 3/3 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| fluent-web-components | desktop/cold | off | 1 / 0 | 98.0 | — | — | — | — |
| spectrum-web-components | desktop/cold | off | 1 / 0 | 136.2 | — | — | — | — |
| en-reve | desktop/cold | off | 1 / 0 | 122.9 | — | — | — | — |

## Separate memory diagnostics

Bytes; medians of available samples only. API statuses remain explicit. JS heap and browser-wide DOM counters are different scopes from API memory and connected DOM. A short lifecycle pilot does not establish a leak.

| System | Cycles | API statuses | API bytes | JS heap bytes | Browser DOM nodes |
| --- | ---: | --- | ---: | ---: | ---: |
| fluent-web-components | 0 | {"ok":1} | 3709204 | 3478340 | 3851 |
| fluent-web-components | 10 | {"ok":1} | 3977875 | 4597940 | 4617 |
| fluent-web-components | 50 | {"ok":1} | 4500312 | 5034196 | 7497 |
| spectrum-web-components | 0 | {"timeout":1} | — | 4315276 | 5604 |
| spectrum-web-components | 10 | {"ok":1} | 8511539 | 5992556 | 5055 |
| spectrum-web-components | 50 | {"ok":1} | 9377058 | 6237868 | 5095 |
| en-reve | 0 | {"timeout":1} | — | 5128092 | 7141 |
| en-reve | 10 | {"ok":1} | 5572330 | 5251656 | 6456 |
| en-reve | 50 | {"ok":1} | 5731248 | 5602060 | 6496 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
