# spectrum-gen2-qualification-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 6/6 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| spectrum-web-components | desktop/cold | on | 1 / 0 | 180.0 | 180.0 | 0.0000 | 168.2 | 40.0 |
| spectrum-web-components | mobile/cold | on | 1 / 0 | 756.0 | 756.0 | 0.0000 | 754.1 | 40.0 |
| en-reve | mobile/cold | on | 1 / 0 | 624.0 | 624.0 | 0.0000 | 620.3 | 48.0 |
| en-reve | desktop/cold | on | 1 / 0 | 92.0 | 92.0 | 0.0000 | 79.3 | 40.0 |
| fluent-web-components | mobile/cold | on | 1 / 0 | 512.0 | 512.0 | 0.0000 | 506.1 | 64.0 |
| fluent-web-components | desktop/cold | on | 1 / 0 | 76.0 | 76.0 | 0.0001 | 67.1 | 40.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
