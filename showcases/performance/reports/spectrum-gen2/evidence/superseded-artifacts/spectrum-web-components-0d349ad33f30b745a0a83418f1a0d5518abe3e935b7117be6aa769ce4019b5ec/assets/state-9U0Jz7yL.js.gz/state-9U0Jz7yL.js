import{l as e}from"./Base-ZN4Dbzq-.js";function t(t){return e({...t,state:!0,attribute:!1})}export{t};
//# sourceMappingURL=state-9U0Jz7yL.js.map