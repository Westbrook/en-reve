import{i as e}from"./Base-ZN4Dbzq-.js";var t=t=>t??e;export{t};
//# sourceMappingURL=if-defined-Vi_7t4rj.js.map