import{n as e}from"./focusable-selectors-CbRTteoW.js";var t=t=>t.querySelector(e),n=t=>t.assignedElements().find(t=>t.matches(e));export{n,t};
//# sourceMappingURL=first-focusable-in-HCIc6lth.js.map