function e(e,t){window.__swc,customElements.define(e,t)}export{e as t};
//# sourceMappingURL=define-element-BlONwTYC.js.map