# en-reve-main-startup-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 60/60 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| web-awesome | desktop/cold | on | 10 / 0 | 92.0 | — | 0.0000 | 81.4 | 32.0 |
| web-awesome | mobile/cold | on | 10 / 0 | 594.0 | — | 0.0000 | 592.7 | 40.0 |
| en-reve | mobile/cold | on | 10 / 0 | 630.0 | — | 0.0000 | 629.9 | 48.0 |
| en-reve | desktop/cold | on | 10 / 0 | 100.0 | — | 0.0000 | 89.4 | 40.0 |
| fluent-web-components | desktop/cold | on | 10 / 0 | 82.0 | — | 0.0001 | 70.8 | 40.0 |
| fluent-web-components | mobile/cold | on | 10 / 0 | 510.0 | — | 0.0000 | 507.8 | 44.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
