# en-reve-main-load-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 120/120 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| web-awesome | mobile/cold | on | 10 / 0 | 600.0 | 600.0 | 0.0000 | 596.9 | — |
| fluent-web-components | mobile/cold | on | 10 / 0 | 514.0 | 514.0 | 0.0000 | 508.3 | — |
| web-awesome | mobile/warm | on | 10 / 0 | 246.0 | 246.0 | 0.0000 | 256.9 | — |
| en-reve | desktop/cold | on | 10 / 0 | 100.0 | 100.0 | 0.0000 | 88.1 | — |
| fluent-web-components | desktop/warm | on | 10 / 0 | 28.0 | 28.0 | 0.0001 | 25.8 | — |
| en-reve | desktop/warm | on | 10 / 0 | 44.0 | 44.0 | 0.0000 | 42.5 | — |
| en-reve | mobile/cold | on | 10 / 0 | 644.0 | 644.0 | 0.0000 | 638.4 | — |
| web-awesome | desktop/cold | on | 10 / 0 | 94.0 | 94.0 | 0.0000 | 82.1 | — |
| web-awesome | desktop/warm | on | 10 / 0 | 36.0 | 36.0 | 0.0000 | 31.9 | — |
| en-reve | mobile/warm | on | 10 / 0 | 304.0 | 304.0 | 0.0000 | 313.5 | — |
| fluent-web-components | desktop/cold | on | 10 / 0 | 82.0 | 82.0 | 0.0001 | 74.5 | — |
| fluent-web-components | mobile/warm | on | 10 / 0 | 208.0 | 208.0 | 0.0000 | 215.0 | — |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
