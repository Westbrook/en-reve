# en-reve-main-interactions-v1

Protocol: c83da72ad9e252607a6ca2eda12621b084d01484ab30e639ffa82a259015a8db. 60/60 samples retained; 0 failures. Developer workstation measurements; see manifest for limitations.

Times in milliseconds. Every cell is a median of successful samples; failures remain explicit. No overall ranking.

| System | Profile/cache | Collector | n / failures | FCP | LCP | CLS | Card frame opportunity | Scripted INP |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| web-awesome | desktop/cold | on | 10 / 0 | 92.0 | 92.0 | 0.0000 | 81.6 | 40.0 |
| web-awesome | mobile/cold | on | 10 / 0 | 608.0 | 608.0 | 0.0000 | 607.8 | 48.0 |
| en-reve | mobile/cold | on | 10 / 0 | 644.0 | 644.0 | 0.0000 | 639.1 | 56.0 |
| en-reve | desktop/cold | on | 10 / 0 | 104.0 | 104.0 | 0.0000 | 90.7 | 48.0 |
| fluent-web-components | desktop/cold | on | 10 / 0 | 82.0 | 82.0 | 0.0001 | 73.8 | 44.0 |
| fluent-web-components | mobile/cold | on | 10 / 0 | 524.0 | 524.0 | 0.0000 | 518.5 | 64.0 |

Raw per-action timings, confidence intervals, native attribution, resources, failures and manifests accompany this report. Frame opportunity uses two requestAnimationFrame callbacks and does not prove pixels were presented. Scripted-session INP is not field INP. Resource transfer sizes of zero may mean cache or cross-origin restriction.
