(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=Object.freeze({prefix:`fluent`,shadowRootMode:`open`,registry:globalThis.customElements}),t={submit:`submit`,reset:`reset`,button:`button`},n=`${e.prefix}-button`,r={download:`download`,href:`href`,hreflang:`hreflang`,ping:`ping`,referrerpolicy:`referrerpolicy`,rel:`rel`,target:`target`,type:`type`};`${e.prefix}`;var i=`${e.prefix}-link`,a=class{constructor(e,t,n=!1){this.evaluate=e,this.policy=t,this.isVolatile=n}},o;(function(e){e[e.needsArrayObservation=1101]=`needsArrayObservation`,e[e.onlySetDOMPolicyOnce=1201]=`onlySetDOMPolicyOnce`,e[e.bindingInnerHTMLRequiresTrustedTypes=1202]=`bindingInnerHTMLRequiresTrustedTypes`,e[e.twoWayBindingRequiresObservables=1203]=`twoWayBindingRequiresObservables`,e[e.hostBindingWithoutHost=1204]=`hostBindingWithoutHost`,e[e.unsupportedBindingBehavior=1205]=`unsupportedBindingBehavior`,e[e.directCallToHTMLTagNotAllowed=1206]=`directCallToHTMLTagNotAllowed`,e[e.onlySetTemplatePolicyOnce=1207]=`onlySetTemplatePolicyOnce`,e[e.cannotSetTemplatePolicyAfterCompilation=1208]=`cannotSetTemplatePolicyAfterCompilation`,e[e.blockedByDOMPolicy=1209]=`blockedByDOMPolicy`,e[e.invalidHydrationAttributeMarker=1210]=`invalidHydrationAttributeMarker`,e[e.duplicateRenderInstruction=1211]=`duplicateRenderInstruction`,e[e.missingElementDefinition=1401]=`missingElementDefinition`,e[e.noRegistrationForContext=1501]=`noRegistrationForContext`,e[e.noFactoryForResolver=1502]=`noFactoryForResolver`,e[e.invalidResolverStrategy=1503]=`invalidResolverStrategy`,e[e.cannotAutoregisterDependency=1504]=`cannotAutoregisterDependency`,e[e.cannotResolveKey=1505]=`cannotResolveKey`,e[e.cannotConstructNativeFunction=1506]=`cannotConstructNativeFunction`,e[e.cannotJITRegisterNonConstructor=1507]=`cannotJITRegisterNonConstructor`,e[e.cannotJITRegisterIntrinsic=1508]=`cannotJITRegisterIntrinsic`,e[e.cannotJITRegisterInterface=1509]=`cannotJITRegisterInterface`,e[e.invalidResolver=1510]=`invalidResolver`,e[e.invalidKey=1511]=`invalidKey`,e[e.noDefaultResolver=1512]=`noDefaultResolver`,e[e.cyclicDependency=1513]=`cyclicDependency`,e[e.connectUpdateRequiresController=1514]=`connectUpdateRequiresController`})(o||={});var s=e=>typeof e==`function`,c=e=>typeof e==`string`,l=()=>void 0,u=Object.create(null),d={warn(e,t){},error(e,t){return Error(`Error ${e}`)},addMessages(e){Object.assign(u,e)}},ee=Object.freeze([]);function te(){let e=new Map;return Object.freeze({register(t){return!e.has(t.type)&&(e.set(t.type,t),!0)},getByType(t){return e.get(t)},getForInstance(t){if(t!=null)return e.get(t.constructor)}})}function ne(){let e=new WeakMap;return function(t){let n=e.get(t);if(n===void 0){let r=Reflect.getPrototypeOf(t);for(;n===void 0&&r!==null;)n=e.get(r),r=Reflect.getPrototypeOf(r);n=n===void 0?[]:n.slice(0),e.set(t,n)}return n}}function re(e){e.prototype.toJSON=l}var ie=class extends a{createObserver(){return this}bind(e){return this.evaluate(e.source,e.context)}};re(ie);function ae(e,t){return new ie(e,t)}var oe=class{constructor(e,t){this.sub1=void 0,this.sub2=void 0,this.spillover=void 0,this.subject=e,this.sub1=t}has(e){return this.spillover===void 0?this.sub1===e||this.sub2===e:this.spillover.indexOf(e)!==-1}subscribe(e){let t=this.spillover;if(t===void 0){if(this.has(e))return;if(this.sub1===void 0){this.sub1=e;return}if(this.sub2===void 0){this.sub2=e;return}this.spillover=[this.sub1,this.sub2,e],this.sub1=void 0,this.sub2=void 0}else t.indexOf(e)===-1&&t.push(e)}unsubscribe(e){let t=this.spillover;if(t===void 0)this.sub1===e?this.sub1=void 0:this.sub2===e&&(this.sub2=void 0);else{let n=t.indexOf(e);n!==-1&&t.splice(n,1)}}notify(e){let t=this.spillover,n=this.subject;if(t===void 0){let t=this.sub1,r=this.sub2;t!==void 0&&t.handleChange(n,e),r!==void 0&&r.handleChange(n,e)}else for(let r=0,i=t.length;r<i;++r)t[r].handleChange(n,e)}},se=class{constructor(e){this.subscribers={},this.subjectSubscribers=null,this.subject=e}notify(e){var t,n;(t=this.subscribers[e])==null||t.notify(e),(n=this.subjectSubscribers)==null||n.notify(e)}subscribe(e,t){let n;n=t?this.subscribers[t]??(this.subscribers[t]=new oe(this.subject)):this.subjectSubscribers??=new oe(this.subject),n.subscribe(e)}unsubscribe(e,t){var n,r;t?(n=this.subscribers[t])==null||n.unsubscribe(e):(r=this.subjectSubscribers)==null||r.unsubscribe(e)}},ce=[],le=[],ue=globalThis.requestAnimationFrame,de=!0;function fe(){if(le.length)throw le.shift()}function pe(e){try{e.call()}catch(e){if(de)le.push(e),setTimeout(fe,0);else throw ce.length=0,e}}function me(){let e=0;for(;e<ce.length;)if(pe(ce[e]),e++,e>1024){for(let t=0,n=ce.length-e;t<n;t++)ce[t]=ce[t+e];ce.length-=e,e=0}ce.length=0}function he(e){ce.push(e),ce.length<2&&(de?ue(me):me())}var f=Object.freeze({enqueue:he,next:()=>new Promise(he),process:me,setMode:e=>de=e}),ge=Object.freeze({unknown:void 0,coupled:1}),p=(()=>{let e=f.enqueue,t=/(:|&&|\|\||if|\?\.)/,n=new WeakMap,r,i=e=>{throw d.error(o.needsArrayObservation)};function a(e){let t=e.$fastController??n.get(e);return t===void 0&&(Array.isArray(e)?t=i(e):n.set(e,t=new se(e))),t}let l=ne();class u{constructor(e){this.name=e,this.field=`_${e}`,this.callback=`${e}Changed`}getValue(e){return r!==void 0&&r.watch(e,this.name),e[this.field]}setValue(e,t){let n=this.field,r=e[n];if(r!==t){e[n]=t;let i=e[this.callback];s(i)&&i.call(e,r,t),a(e).notify(this.name)}}}class ee extends oe{constructor(e,t,n=!1){super(e,t),this.expression=e,this.isVolatileBinding=n,this.needsRefresh=!0,this.needsQueue=!0,this.isAsync=!0,this.first=this,this.last=null,this.propertySource=void 0,this.propertyName=void 0,this.notifier=void 0,this.next=void 0}setMode(e){this.isAsync=this.needsQueue=e}bind(e){let t=this.observe(e.source,e.context);return!e.isBound&&this.requiresUnbind(e)&&e.onUnbind(this),t}requiresUnbind(e){return e.sourceLifetime!==ge.coupled||this.first!==this.last||this.first.propertySource!==e.source}unbind(e){this.dispose()}observe(e,t){this.needsRefresh&&this.last!==null&&this.dispose();let n=r;r=this.needsRefresh?this:void 0,this.needsRefresh=this.isVolatileBinding;let i;try{i=this.expression(e,t)}finally{r=n}return i}disconnect(){this.dispose()}dispose(){if(this.last!==null){let e=this.first;for(;e!==void 0;)e.notifier.unsubscribe(this,e.propertyName),e=e.next;this.last=null,this.needsRefresh=this.needsQueue=this.isAsync}}watch(e,t){let n=this.last,i=a(e),o=n===null?this.first:{};if(o.propertySource=e,o.propertyName=t,o.notifier=i,i.subscribe(this,t),n!==null){if(!this.needsRefresh){let t;r=void 0,t=n.propertySource[n.propertyName],r=this,e===t&&(this.needsRefresh=!0)}n.next=o}this.last=o}handleChange(){this.needsQueue?(this.needsQueue=!1,e(this)):this.isAsync||this.call()}call(){this.last!==null&&(this.needsQueue=this.isAsync,this.notify(this))}*records(){let e=this.first;for(;e!==void 0;)yield e,e=e.next}}return re(ee),Object.freeze({setArrayObserverFactory(e){i=e},getNotifier:a,track(e,t){r&&r.watch(e,t)},trackVolatile(){r&&(r.needsRefresh=!0)},notify(e,t){a(e).notify(t)},defineProperty(e,t){c(t)&&(t=new u(t)),l(e).push(t),Reflect.defineProperty(e,t.name,{enumerable:!0,get(){return t.getValue(this)},set(e){t.setValue(this,e)}})},getAccessors:l,binding(e,t,n=this.isVolatileBinding(e)){return new ee(e,t,n)},isVolatileBinding(e){return t.test(e.toString())}})})();function m(e,t){p.defineProperty(e,t)}var _e=(()=>{let e=null;return{get(){return e},set(t){e=t}}})(),ve=Object.freeze({default:{index:0,length:0,get event(){return ve.getEvent()},eventDetail(){return this.event.detail},eventTarget(){return this.event.target}},getEvent(){return _e.get()},setEvent(e){_e.set(e)}}),ye=class extends a{createObserver(e){return p.binding(this.evaluate,e,this.isVolatile)}};function be(e,t,n=p.isVolatileBinding(e)){return new ye(e,t,n)}var h=Object.freeze({none:0,attribute:1,booleanAttribute:2,property:3,content:4,tokenList:5,event:6}),xe=e=>e,Se=globalThis.trustedTypes?globalThis.trustedTypes.createPolicy(`fast-html`,{createHTML:xe}):{createHTML:xe},Ce=Object.freeze({createHTML(e){return Se.createHTML(e)},protect(e,t,n,r){return r}}),we=Ce,Te=Object.freeze({get policy(){return Ce},setPolicy(e){if(Ce!==we)throw d.error(o.onlySetDOMPolicyOnce);Ce=e},setAttribute(e,t,n){n==null?e.removeAttribute(t):e.setAttribute(t,n)},setBooleanAttribute(e,t,n){n?e.setAttribute(t,``):e.removeAttribute(t)}}),Ee=`boolean`,De=`reflect`,Oe=Object.freeze({locate:ne()}),ke={toView(e){return e?``:null},fromView(e){return!!e}};function Ae(e){if(e==null)return null;let t=e*1;return isNaN(t)?null:t}var je={toView(e){let t=Ae(e);return t&&t.toString()},fromView:Ae},Me=class e{constructor(e,t,n=t.toLowerCase(),r=De,i){this.guards=new Set,this.Owner=e,this.name=t,this.attribute=n,this.mode=r,this.converter=i,this.fieldName=`_${t}`,this.callbackName=`${t}Changed`,this.hasCallback=this.callbackName in e.prototype,r===Ee&&i===void 0&&(this.converter=ke)}setValue(e,t){let n=e[this.fieldName],r=this.converter;r!==void 0&&(t=r.fromView(t)),n!==t&&(e[this.fieldName]=t,this.tryReflectToAttribute(e),this.hasCallback&&e[this.callbackName](n,t),e.$fastController.notify(this.name))}getValue(e){return p.track(e,this.name),e[this.fieldName]}onAttributeChangedCallback(e,t){this.guards.has(e)||(this.guards.add(e),this.mode===Ee?this.setValue(e,t!==null):this.setValue(e,t),this.guards.delete(e))}tryReflectToAttribute(e){let t=this.mode,n=this.guards;n.has(e)||t===`fromView`||f.enqueue(()=>{n.add(e);let r=e[this.fieldName];switch(t){case De:{let t=this.converter;Te.setAttribute(e,this.attribute,t===void 0?r:t.toView(r));break}case Ee:Te.setBooleanAttribute(e,this.attribute,r)}n.delete(e)})}static collect(t,...n){let r=[];n.push(Oe.locate(t));for(let i=0,a=n.length;i<a;++i){let a=n[i];if(a!==void 0)for(let n=0,i=a.length;n<i;++n){let i=a[n];c(i)?r.push(new e(t,i)):r.push(new e(t,i.property,i.attribute,i.mode,i.converter))}}return r}};function g(e,t){let n;function r(e,t){arguments.length>1&&(n.property=t),Oe.locate(e.constructor).push(n)}if(arguments.length>1){n={},r(e,t);return}return n=e===void 0?{}:e,r}var Ne;function Pe(e){return e.reduce((e,t)=>(t instanceof Fe?e.push(...Pe(t.styles)):e.push(t),e),[])}var Fe=class e{get strategy(){return this._strategy===null&&(Ne||e.setDefaultStrategy(e.supportsAdoptedStyleSheets?Ie():Re()),this.withStrategy(Ne)),this._strategy}constructor(e){this.styles=e,this.targets=new WeakSet,this._strategy=null}addStylesTo(e){this.strategy.addStylesTo(e),this.targets.add(e)}removeStylesFrom(e){this.strategy.removeStylesFrom(e),this.targets.delete(e)}isAttachedTo(e){return this.targets.has(e)}withStrategy(e){return this._strategy=new e(Pe(this.styles)),this}static setDefaultStrategy(e){Ne=e}static normalize(t){return t===void 0?void 0:Array.isArray(t)?new e(t):t instanceof e?t:new e([t])}};Fe.supportsAdoptedStyleSheets=Array.isArray(document.adoptedStyleSheets)&&`replace`in CSSStyleSheet.prototype;function Ie(){let e=new Map;return class{constructor(t){this.sheets=t.map(t=>{if(t instanceof CSSStyleSheet)return t;let n=e.get(t);return n===void 0&&(n=new CSSStyleSheet,n.replaceSync(t),e.set(t,n)),n})}addStylesTo(e){let t=e;t.adoptedStyleSheets=[...t.adoptedStyleSheets,...this.sheets]}removeStylesFrom(e){let t=e;t.adoptedStyleSheets=t.adoptedStyleSheets.filter(e=>this.sheets.indexOf(e)===-1)}}}var Le=0;function Re(){return class{constructor(e){this.styles=e,this.styleClass=`fast-${++Le}`}addStylesTo(e){let t=e===document?document.body:e;for(let e=0;e<this.styles.length;e++){let n=document.createElement(`style`);n.innerHTML=this.styles[e],n.className=this.styleClass,t.append(n)}}removeStylesFrom(e){let t=e===document?document.body:e,n=t.querySelectorAll(`.${this.styleClass}`);for(let e=0,r=n.length;e<r;++e)t.removeChild(n[e])}}}var ze={},Be=new WeakMap,Ve=te(),He=Object.freeze({register(e){if(!Ve.register(e))return!1;let t=Ue(e.registry);return Object.prototype.hasOwnProperty.call(t,e.name)||p.defineProperty(t,e.name),t[e.name]=e.type,!0},getByType:Ve.getByType,getForInstance:Ve.getForInstance,whenRegistered:Ge});function Ue(e=customElements){if(e===customElements)return ze;let t=Be.get(e);return t||(t={},Be.set(e,t)),t}function We(e){return e===void 0?void 0:He.getByType(e)}function Ge(e,t=customElements){let n=Ue(t);Object.prototype.hasOwnProperty.call(n,e)||p.defineProperty(n,e);let r=We(n[e]);return r===void 0?new Promise(t=>{let r=p.getNotifier(n),i={handleChange:()=>{let a=We(n[e]);a!==void 0&&(r.unsubscribe(i,e),t(a))}};r.subscribe(i,e)}):Promise.resolve(r)}var Ke={mode:`open`},qe={},Je=new Set,Ye=new WeakMap,Xe=new WeakMap,Ze=new WeakMap,Qe=new WeakMap,$e=new WeakMap;function et(e){return s(e)}function tt(e){return typeof e?.then==`function`}function nt(e,t){if(Xe.delete(e),e.template===void 0&&t!==void 0&&(e.template=t),e.template!==void 0)return Ze.delete(e),Ye.delete(e),e.template}function rt(e,t=e.registry,n){if(!n?.length)return;let r=e,i=Qe.get(r);if(!i?.has(t)){i===void 0&&(i=new WeakSet,Qe.set(r,i)),i.add(t);for(let t of n)t(e)}}function it(e){return $e.get(e)??null}function at(e){if(e.template!==void 0)return Ze.delete(e),e.template;let t=Xe.get(e);if(t)return t;let n=Ye.get(e);if(!n)return;Ze.delete(e);let r;try{r=n(e)}catch(t){throw Ze.set(e,t),t}if(tt(r)){let t=Promise.resolve(r).then(t=>nt(e,t)).catch(t=>{throw Xe.delete(e),Ze.set(e,t),t});return Xe.set(e,t),t}return nt(e,r)}function ot(e,t){let n=e;if(t===void 0){Ze.delete(n);return}Ze.set(n,t)}var st=class e{get isDefined(){return this.platformDefined}constructor(e,t=e.definition){this.platformDefined=!1,c(t)&&(t={name:t}),this.type=e,this.name=t.name,this.registry=t.registry??customElements,et(t.template)?Ye.set(this,t.template):this.template=t.template;let n=e.prototype,r=Me.collect(e,t.attributes),i=Array(r.length),a={},o={};for(let e=0,t=r.length;e<t;++e){let t=r[e];i[e]=t.attribute,a[t.name]=t,o[t.attribute]=t,p.defineProperty(n,t)}Reflect.defineProperty(e,"observedAttributes",{value:i,enumerable:!0}),this.attributes=r,this.propertyLookup=a,this.attributeLookup=o,this.shadowOptions=t.shadowOptions===void 0?Ke:t.shadowOptions===null?void 0:Object.assign(Object.assign({},Ke),t.shadowOptions),this.elementOptions=t.elementOptions===void 0?qe:Object.assign(Object.assign({},qe),t.elementOptions),this.styles=Fe.normalize(t.styles),this.schema=t.schema,He.register(this)}define(e=this.registry,t){let n=this.type;if(!e.get(this.name)){if(rt(this,e,t),this.template===void 0&&Ye.has(this))return Promise.resolve().then(()=>at(this)).then(t=>{t!==void 0&&!e.get(this.name)&&(this.platformDefined=!0,e.define(this.name,n,this.elementOptions))}).catch(e=>{ot(this,e),p.notify(this,`template`)}),this;this.platformDefined=!0,e.define(this.name,n,this.elementOptions)}return this}static compose(t,n){let r=Je.has(t)||He.getByType(t)?new e(class extends t{},n):new e(t,n);return Promise.resolve(r)}static registerBaseType(e){Je.add(e)}};st.getByType=He.getByType,st.getForInstance=He.getForInstance,p.defineProperty(st.prototype,`template`);var ct={bubbles:!0,composed:!0,cancelable:!0},lt=`isConnected`,ut=new WeakMap,dt=Symbol(`fast-late-attribute-observer`);function ft(e){return e.shadowRoot??ut.get(e)??null}var pt,mt;(function(e){e[e.connecting=0]=`connecting`,e[e.connected=1]=`connected`,e[e.disconnecting=2]=`disconnecting`,e[e.disconnected=3]=`disconnected`})(mt||={});var ht=class e{get isConnected(){return p.track(this,lt),this.stage===mt.connected}get context(){return this.view?.context??ve.default}get isBound(){return this.view?.isBound??!1}get sourceLifetime(){return this.view?.sourceLifetime}get template(){if(this._template===null){let e=this.definition;this.source.resolveTemplate?this._template=this.source.resolveTemplate():e.template&&(this._template=e.template??null)}return this._template}set template(e){this._template!==e&&(this._template=e,this.needsInitialization||this.renderTemplate(e))}get shadowOptions(){return this._shadowRootOptions}set shadowOptions(e){if(this._shadowRootOptions===void 0&&e!==void 0){this._shadowRootOptions=e;let t=this.source.shadowRoot;t?this.hasExistingShadowRoot=!0:(t=this.source.attachShadow(e),e.mode===`closed`&&ut.set(this.source,t))}}get mainStyles(){if(this._mainStyles===null){let e=this.definition;this.source.resolveStyles?this._mainStyles=this.source.resolveStyles():e.styles&&(this._mainStyles=e.styles??null)}return this._mainStyles}set mainStyles(e){this._mainStyles!==e&&(this._mainStyles!==null&&this.removeStyles(this._mainStyles),this._mainStyles=e,this.needsInitialization||this.addStyles(e))}constructor(e,t){this.boundObservables=null,this.needsInitialization=!0,this.hasExistingShadowRoot=!1,this.isPrerendered=new Promise(e=>{this._resolvePrerendered=e}),this.isHydrated=new Promise(e=>{this._resolveHydrated=e}),this._template=null,this.stage=mt.disconnected,this.guardBehaviorConnection=!1,this.behaviors=null,this.behaviorsConnected=!1,this._mainStyles=null,this.$fastController=this,this.view=null,this._notifier=new se(e),this.source=e,this.definition=t,this.shadowOptions=t.shadowOptions;let n=Reflect.getPrototypeOf(e),r=n===null?[]:p.getAccessors(n);if(r.length>0){let t=this.boundObservables=Object.create(null);for(let n=0,i=r.length;n<i;++n){let i=r[n].name,a=e[i];a!==void 0&&(delete e[i],t[i]=a)}Object.keys(t).length===0&&(this.boundObservables=null)}this.captureBoundObservables()}get subject(){return this._notifier.subject}notify(e){this._notifier.notify(e)}subscribe(e,t){this._notifier.subscribe(e,t)}unsubscribe(e,t){this._notifier.unsubscribe(e,t)}onUnbind(e){var t;(t=this.view)==null||t.onUnbind(e)}addBehavior(e){let t=this.behaviors??=new Map,n=t.get(e)??0;n===0?(t.set(e,1),e.addedCallback&&e.addedCallback(this),e.connectedCallback&&!this.guardBehaviorConnection&&(this.stage===mt.connected||this.stage===mt.connecting)&&e.connectedCallback(this)):t.set(e,n+1)}removeBehavior(e,t=!1){let n=this.behaviors;if(n===null)return;let r=n.get(e);r!==void 0&&(r===1||t?(n.delete(e),e.disconnectedCallback&&this.stage!==mt.disconnected&&e.disconnectedCallback(this),e.removedCallback&&e.removedCallback(this)):n.set(e,r-1))}addStyles(e){if(!e)return;let t=this.source;e instanceof HTMLElement?(ft(t)??this.source).append(e):e.isAttachedTo(t)||e.addStylesTo(t)}removeStyles(e){if(!e)return;let t=this.source;e instanceof HTMLElement?(ft(t)??t).removeChild(e):e.isAttachedTo(t)&&e.removeStylesFrom(t)}connect(){this.stage===mt.disconnected&&(this.stage=mt.connecting,this.captureBoundObservables(),this.syncLateAttributes(),this.observeLateAttributes(),this.bindObservables(),this.connectBehaviors(),this.needsInitialization?(this.renderTemplate(this.template),this.addStyles(this.mainStyles),this.needsInitialization=!1):this.view!==null&&this.view.bind(this.source),this.stage=mt.connected,p.notify(this,lt))}bindObservables(){if(this.boundObservables!==null){let e=this.source,t=this.boundObservables,n=Object.keys(t);for(let r=0,i=n.length;r<i;++r){let i=n[r];e[i]=t[i]}this.boundObservables=null}}captureBoundObservables(){let e=this.source,t=Object.getOwnPropertyNames(e),n=t=>{let n=Reflect.getPrototypeOf(e);for(;n!==null;){let e=Reflect.getOwnPropertyDescriptor(n,t);if(e?.get||e?.set)return!0;n=Reflect.getPrototypeOf(n)}return!1},r=this.boundObservables;for(let i=0,a=t.length;i<a;++i){let a=t[i];if(!n(a))continue;let o=e[a];if(o===void 0){delete e[a];continue}delete e[a],(r??=this.boundObservables=Object.create(null))[a]=o}}syncLateAttributes(){let e=it(this.definition);if(e!==null)for(let t of Object.keys(e))this.source.hasAttribute(t)&&this.onAttributeChangedCallback(t,null,this.source.getAttribute(t))}observeLateAttributes(){let e=it(this.definition);if(e===null)return;let t=this.source;t[dt]===void 0&&(t[dt]=new MutationObserver(e=>{let n=t.$fastController,r=it(n.definition);if(r!==null)for(let i=0,a=e.length;i<a;++i){let a=e[i].attributeName;a!==null&&r[a]!==void 0&&n.onAttributeChangedCallback(a,null,t.getAttribute(a))}}),t[dt].observe(t,{attributes:!0,attributeFilter:Object.keys(e)}))}connectBehaviors(){if(this.behaviorsConnected===!1){let e=this.behaviors;if(e!==null){this.guardBehaviorConnection=!0;for(let t of e.keys())t.connectedCallback&&t.connectedCallback(this);this.guardBehaviorConnection=!1}this.behaviorsConnected=!0}}disconnectBehaviors(){if(this.behaviorsConnected===!0){let e=this.behaviors;if(e!==null)for(let t of e.keys())t.disconnectedCallback&&t.disconnectedCallback(this);this.behaviorsConnected=!1}}disconnect(){this.stage===mt.connected&&(this.stage=mt.disconnecting,p.notify(this,lt),this.view!==null&&this.view.unbind(),this.disconnectBehaviors(),this.stage=mt.disconnected)}onAttributeChangedCallback(e,t,n){let r=this.definition.attributeLookup[e];r!==void 0&&r.onAttributeChangedCallback(this.source,n)}emit(e,t,n){return this.stage===mt.connected&&this.source.dispatchEvent(new CustomEvent(e,Object.assign(Object.assign({detail:t},ct),n)))}renderTemplate(t){let n=this.source,r=ft(n)??n;if(this.view!==null)this.view.dispose(),this.view=null;else if((!this.needsInitialization||this.hasExistingShadowRoot)&&(!this.hasExistingShadowRoot||!this.needsInitialization))for(let e=r.firstChild;e!==null;e=r.firstChild)r.removeChild(e);if(t){let i=this.hasExistingShadowRoot&&this.needsInitialization,a=!1;i&&e.hydrationHook&&(a=e.hydrationHook(this,t,n,r)),a||this.renderClientSide(t,n,r),this._resolvePrerendered(i),this._resolveHydrated(a)}else this.needsInitialization&&(this._resolvePrerendered(!1),this._resolveHydrated(!1))}renderClientSide(e,t,n){if(this.hasExistingShadowRoot){for(let e=n.firstChild;e!==null;e=n.firstChild)n.removeChild(e);this.hasExistingShadowRoot=!1}this.view=e.render(t,n,t),this.view.sourceLifetime=ge.coupled}static forCustomElement(t,n=!1){let r=t.$fastController;if(r!==void 0&&!n)return r;let i=st.getForInstance(t);if(i===void 0)throw d.error(o.missingElementDefinition);return p.getNotifier(i).subscribe({handleChange:()=>{e.forCustomElement(t,!0),t.$fastController.connect()}},`template`),p.getNotifier(i).subscribe({handleChange:()=>{e.forCustomElement(t,!0),t.$fastController.connect()}},`shadowOptions`),t.$fastController=new pt(t,i)}static setStrategy(e){pt=e}static installHydrationHook(t){e.hydrationHook=t}};ht.hydrationHook=null,re(ht),ht.setStrategy(ht);function gt(e){return`adoptedStyleSheets`in e?e:ft(e)??e.getRootNode()}var _t=class e{constructor(t){let n=e.styleSheetCache;this.sheets=t.map(e=>{if(e instanceof CSSStyleSheet)return e;let t=n.get(e);return t===void 0&&(t=new CSSStyleSheet,t.replaceSync(e),n.set(e,t)),t})}addStylesTo(e){St(gt(e),this.sheets)}removeStylesFrom(e){Ct(gt(e),this.sheets)}};_t.styleSheetCache=new Map;var vt=0,yt=()=>`fast-${++vt}`;function bt(e){return e===document?document.body:e}var xt=class{constructor(e){this.styles=e,this.styleClass=yt()}addStylesTo(e){e=bt(gt(e));let t=this.styles,n=this.styleClass;for(let r=0;r<t.length;r++){let i=document.createElement(`style`);i.innerHTML=t[r],i.className=n,e.append(i)}}removeStylesFrom(e){e=bt(gt(e));let t=e.querySelectorAll(`.${this.styleClass}`);for(let n=0,r=t.length;n<r;++n)e.removeChild(t[n])}},St=(e,t)=>{e.adoptedStyleSheets=[...e.adoptedStyleSheets,...t]},Ct=(e,t)=>{e.adoptedStyleSheets=e.adoptedStyleSheets.filter(e=>t.indexOf(e)===-1)};if(Fe.supportsAdoptedStyleSheets){try{document.adoptedStyleSheets.push(),document.adoptedStyleSheets.splice(),St=(e,t)=>{e.adoptedStyleSheets.push(...t)},Ct=(e,t)=>{for(let n of t){let t=e.adoptedStyleSheets.indexOf(n);t!==-1&&e.adoptedStyleSheets.splice(t,1)}}}catch{}Fe.setDefaultStrategy(_t)}else Fe.setDefaultStrategy(xt);function wt(e){let t=class extends e{constructor(){super(),ht.forCustomElement(this)}$emit(e,t,n){return this.$fastController.emit(e,t,n)}connectedCallback(){this.$fastController.connect()}disconnectedCallback(){this.$fastController.disconnect()}attributeChangedCallback(e,t,n){this.$fastController.onAttributeChangedCallback(e,t,n)}};return st.registerBaseType(t),t}function Tt(e){return typeof e?.then==`function`}function Et(e,t,n){return Array.isArray(t)&&(n=t,t=void 0),(s(e)?st.compose(e,t):st.compose(this,e)).then(e=>{rt(e,e.registry,n);let t=at(e);return Tt(t)?t.then(()=>e.define().type):e.define().type})}function Dt(e){return wt(e)}var _=Object.assign(wt(HTMLElement),{from:Dt,define:Et});function Ot(e,t,n){return Object.assign({},n,{get(){return p.trackVolatile(),n.get.apply(this)}})}var kt=te(),At=Object.freeze({getForInstance:kt.getForInstance,getByType:kt.getByType,define(e){return kt.register({type:e}),e}});function jt(e,t){let n=[],r=``;for(let i=0,a=e.length-1;i<a;++i){r+=e[i];let a=t[i];At.getForInstance(a)!==void 0&&(a=a.createCSS()),a instanceof Fe||a instanceof CSSStyleSheet?(r.trim()!==``&&(n.push(r),r=``),n.push(a)):r+=a}return r+=e[e.length-1],r.trim()!==``&&n.push(r),n}var v=((e,...t)=>new Fe(jt(e,t))),Mt=class{constructor(e){this.value=e.length===0?``:e.length===1?e[0]:new Fe(e)}createCSS(){return this.value}};At.define(Mt),v.partial=(e,...t)=>new Mt(jt(e,t));var Nt=`fast-${Math.random().toString(36).substring(2,8)}`,Pt=`${Nt}{`,Ft=`}${Nt}`,It=Ft.length,Lt=0,Rt=()=>`${Nt}-${++Lt}`,zt=Object.freeze({interpolation:e=>`${Pt}${e}${Ft}`,attribute:e=>`${Rt()}="${Pt}${e}${Ft}"`,comment:e=>`<!--${Pt}${e}${Ft}-->`}),Bt=Object.freeze({parse(e,t){let n=e.split(Pt);if(n.length===1)return null;let r=[];for(let e=0,i=n.length;e<i;++e){let i=n[e],a=i.indexOf(Ft),o;if(a===-1)o=i;else{let e=i.substring(0,a);r.push(t[e]),o=i.substring(a+It)}o!==``&&r.push(o)}return r}}),Vt=te(),Ht=Object.freeze({getForInstance:Vt.getForInstance,getByType:Vt.getByType,define(e,t){return t||={},t.type=e,Vt.register(t),e},assignAspect(e,t){if(!t){e.aspectType=h.content;return}switch(e.sourceAspect=t,t[0]){case`:`:e.targetAspect=t.substring(1),e.aspectType=e.targetAspect===`classList`?h.tokenList:h.property;break;case`?`:e.targetAspect=t.substring(1),e.aspectType=h.booleanAttribute;break;case`@`:e.targetAspect=t.substring(1),e.aspectType=h.event;break;default:e.targetAspect=t,e.aspectType=h.attribute}}}),Ut=class{constructor(e){this.options=e}createHTML(e){return zt.attribute(e(this))}createBehavior(){return this}};re(Ut);var Wt=e=>e.nodeType===1,Gt=e=>e?t=>t.nodeType===1&&t.matches(e):Wt,Kt=class extends Ut{get id(){return this._id}set id(e){this._id=e,this._controllerProperty=`${e}-c`}bind(e){let t=e.targets[this.targetNodeId];t[this._controllerProperty]=e,this.updateTarget(e.source,this.computeNodes(t)),this.observe(t),e.onUnbind(this)}unbind(e){let t=e.targets[this.targetNodeId];this.updateTarget(e.source,ee),this.disconnect(t),t[this._controllerProperty]=null}getSource(e){return e[this._controllerProperty].source}updateTarget(e,t){e[this.options.property]=t}computeNodes(e){let t=this.getNodes(e);return`filter`in this.options&&(t=t.filter(this.options.filter)),t}},qt=/fe-b\$\$start\$\$(\d+)\$\$(.+)\$\$fe-b/,Jt=/fe-b\$\$end\$\$(\d+)\$\$(.+)\$\$fe-b/,Yt=/fe-repeat\$\$start\$\$(\d+)\$\$fe-repeat/,Xt=/fe-repeat\$\$end\$\$(\d+)\$\$fe-repeat/,Zt=/^(?:.{0,1000})fe-eb\$\$start\$\$(.+?)\$\$fe-eb/,Qt=/fe-eb\$\$end\$\$(.{0,1000})\$\$fe-eb(?:.{0,1000})$/;function $t(e){return e&&e.nodeType===Node.COMMENT_NODE}var en=Object.freeze({attributeMarkerName:`data-fe`,legacyAttributeMarkerName:`data-fe-b`,legacyCompactAttributeMarkerName:`data-fe-c`,contentBindingStartMarker(){return`fe:b`},contentBindingEndMarker(){return`fe:/b`},repeatStartMarker(){return`fe:r`},repeatEndMarker(){return`fe:/r`},elementBoundaryStartMarker(){return`fe:e`},elementBoundaryEndMarker(){return`fe:/e`},isContentBindingStartMarker(e){return e===`fe:b`||qt.test(e)},isContentBindingEndMarker(e){return e===`fe:/b`||Jt.test(e)},isRepeatViewStartMarker(e){return e===`fe:r`||Yt.test(e)},isRepeatViewEndMarker(e){return e===`fe:/r`||Xt.test(e)},isElementBoundaryStartMarker(e){return $t(e)&&(e.data===`fe:e`||Zt.test(e.data))},isElementBoundaryEndMarker(e){return $t(e)&&(e.data===`fe:/e`||Qt.test(e.data))},parseAttributeBindingCount(e){let t=e.getAttribute(this.attributeMarkerName);if(t===null)return null;let n=t.trim();if(!/^\d+$/.test(n))throw d.error(o.invalidHydrationAttributeMarker,{value:t});let r=parseInt(n,10);if(r<1)throw d.error(o.invalidHydrationAttributeMarker,{value:t});return r},parseLegacyAttributeBindingIndices(e){let t=[],n=e.getAttribute(this.legacyAttributeMarkerName);if(n!==null)for(let e of n.trim().split(/\s+/)){if(e===``)continue;let r=Number(e);if(!Number.isInteger(r)||r<0)throw d.error(o.invalidHydrationAttributeMarker,{value:n});t.push(r)}let r=`${this.legacyAttributeMarkerName}-`,i=`${this.legacyCompactAttributeMarkerName}-`;for(let n of e.getAttributeNames())if(n.startsWith(r)){let e=Number(n.slice(r.length));if(!Number.isInteger(e)||e<0)throw d.error(o.invalidHydrationAttributeMarker,{value:n});t.push(e)}else if(n.startsWith(i)){let[e,r]=n.slice(i.length).split(`-`).map(e=>Number(e));if(!Number.isInteger(e)||!Number.isInteger(r)||e<0||r<1)throw d.error(o.invalidHydrationAttributeMarker,{value:n});for(let n=0;n<r;n++)t.push(e+n)}return t.length===0?null:t},removeLegacyAttributeBindingMarkers(e){e.removeAttribute(this.legacyAttributeMarkerName);for(let t of e.getAttributeNames())(t.startsWith(`${this.legacyAttributeMarkerName}-`)||t.startsWith(`${this.legacyCompactAttributeMarkerName}-`))&&e.removeAttribute(t)},parseLegacyContentBindingStartIndex(e){return tn(qt,e)}});function tn(e,t){let n=e.exec(t);return n===null?null:Number(n[1])}var nn=Symbol.for(`fe-hydration`);function rn(e){return e[nn]===nn}var an=`unknown`;function on(e,t){return`Hydration mismatch in <${e}>${t?`: ${t}`:``}. Install hydrationDebugger() from "@microsoft/fast-element/hydration.js" and pass it as enableHydration({ debugger: hydrationDebugger() }) for an "Expected / Received" report including the SSR HTML snippet.`}var sn="content following `<!--fe:b-->` content binding marker",cn="matching `<!--fe:/b-->` content binding close marker",ln="matching `<!--fe:/e-->` element boundary close marker";function un(e){return`no more attribute bindings (template defines ${e})`}function dn(e){return`no more content bindings (template defines ${e})`}function fn(e,t){return on((e??an).toLowerCase(),t)}var pn={formatBindingMismatch(e,t,n,r){return{message:fn(r,void 0)}},formatStructuralError(e,t,n){return{message:fn(t,n)}}};function mn(){return pn}function hn(e){if(e)return e.getRootNode().host?.nodeName}var gn=class extends Error{constructor(e,t,n,r,i){super(e),this.factories=t,this.node=n,this.expected=r,this.received=i}};function _n(e){return e.nodeType===Node.COMMENT_NODE}function vn(e){return e.nodeType===Node.TEXT_NODE}function yn(e,t){let n=document.createRange();return n.setStart(e,0),n.setEnd(t,_n(t)||vn(t)?t.data.length:t.childNodes.length),n}function bn(e,t,n){let r=yn(e,t),i=r.commonAncestorContainer,a=document.createTreeWalker(i,NodeFilter.SHOW_ELEMENT+NodeFilter.SHOW_COMMENT+NodeFilter.SHOW_TEXT,{acceptNode(e){return r.comparePoint(e,0)===0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}}),o={},s={},c=Cn(n),l=c,u=a.currentNode=e;for(;u!==null;){switch(u.nodeType){case Node.ELEMENT_NODE:{let e=u,t=en.parseLegacyAttributeBindingIndices(e);if(t!==null){for(let r of t){let t=r+c,i=n[t];if(!i){let t=un(n.length),r=mn().formatStructuralError(u,hn(u),t);throw new gn(r.message,n,e,r.expected,r.received)}wn(i,u,o),l=Math.max(l,t+1)}en.removeLegacyAttributeBindingMarkers(e);break}let r=en.parseAttributeBindingCount(e);if(r!==null){for(let e=0;e<r;e++){let e=n[l++];if(!e){let e=un(n.length),t=mn().formatStructuralError(u,hn(u),e);throw new gn(t.message,n,u,t.expected,t.received)}wn(e,u,o)}e.removeAttribute(en.attributeMarkerName)}break}case Node.COMMENT_NODE:{let e=u.data;if(en.isElementBoundaryStartMarker(u))u.data=``,Sn(a,n,u);else if(en.isContentBindingStartMarker(e)){let t=en.parseLegacyContentBindingStartIndex(e),r=t===null?l++:t+c,i=n[r];if(l=Math.max(l,r+1),!i){let e=dn(n.length),t=mn().formatStructuralError(u,hn(u),e);throw new gn(t.message,n,u,t.expected,t.received)}xn(u,a,i,n,o,s)}break}}u=a.nextNode()}return r.detach(),{targets:o,boundaries:s}}function xn(e,t,n,r,i,a){let o=[],s=t.nextSibling();if(e.data=``,s===null){let t=sn,n=mn().formatStructuralError(e,hn(e),t);throw new gn(n.message,r,e,n.expected,n.received)}let c=s,l=0;for(;s!==null;){if(_n(s)){if(en.isContentBindingStartMarker(s.data))l++;else if(en.isContentBindingEndMarker(s.data)){if(l===0)break;l--}}o.push(s),s=t.nextSibling()}if(s===null){let t=cn,n=mn().formatStructuralError(e,hn(e),t);throw new gn(n.message,r,e,n.expected,n.received)}s.data=``,o.length===1&&vn(o[0])?wn(n,o[0],i):(s!==c&&s.previousSibling!==null&&(a[n.targetNodeId]={first:c,last:s.previousSibling}),wn(n,s.parentNode.insertBefore(document.createTextNode(``),s),i))}function Sn(e,t,n){let r=0,i=e.nextSibling();for(;i!==null;){if(_n(i)){if(en.isElementBoundaryStartMarker(i))i.data=``,r++;else if(en.isElementBoundaryEndMarker(i)){if(r===0){i.data=``;return}i.data=``,r--}}i=e.nextSibling()}let a=ln,o=mn().formatStructuralError(n,hn(n),a);throw new gn(o.message,t,n,o.expected,o.received)}function Cn(e){let t=0;for(let n=0,r=e.length;n<r&&e[n].targetNodeId===`h`;++n)t++;return t}function wn(e,t,n){if(e.targetNodeId===void 0)throw Error(`Factory could not be target to the node`);n[e.targetNodeId]=t}function Tn(e,t){let n=e.parentNode,r=e,i;for(;r!==t;){if(i=r.nextSibling,!i)throw Error(`Unmatched first/last child inside "${t.getRootNode().host.nodeName}".`);n.removeChild(r),r=i}n.removeChild(t)}var En=class{constructor(){this.index=0,this.length=0}get event(){return ve.getEvent()}get isEven(){return this.index%2==0}get isOdd(){return this.index%2!=0}get isFirst(){return this.index===0}get isInMiddle(){return!this.isFirst&&!this.isLast}get isLast(){return this.index===this.length-1}eventDetail(){return this.event.detail}eventTarget(){return this.event.target}},Dn=class extends En{constructor(e,t,n){super(),this.fragment=e,this.factories=t,this.targets=n,this.behaviors=null,this.unbindables=[],this.source=null,this.isBound=!1,this.sourceLifetime=ge.unknown,this._skipAttrUpdates=!1,this.isPrerendered=Promise.resolve(!1),this.isHydrated=Promise.resolve(!1),this.context=this,this.firstChild=e.firstChild,this.lastChild=e.lastChild}appendTo(e){e.appendChild(this.fragment)}insertBefore(e){if(this.fragment.hasChildNodes())e.parentNode.insertBefore(this.fragment,e);else{let t=this.lastChild;if(e.previousSibling===t)return;let n=e.parentNode,r=this.firstChild,i;for(;r!==t;)i=r.nextSibling,n.insertBefore(r,e),r=i;n.insertBefore(t,e)}}remove(){let e=this.fragment,t=this.lastChild,n=this.firstChild,r;for(;n!==t;)r=n.nextSibling,e.appendChild(n),n=r;e.appendChild(t)}dispose(){Tn(this.firstChild,this.lastChild),this.unbind()}onUnbind(e){this.unbindables.push(e)}bind(e,t=this){if(this.source===e&&this.context===t)return;let n=this.behaviors;if(n===null){this.source=e,this.context=t,this.behaviors=n=Array(this.factories.length);let r=this.factories;for(let e=0,t=r.length;e<t;++e){let t=r[e].createBehavior();t.bind(this),n[e]=t}}else{this.source!==null&&this.evaluateUnbindables(),this.isBound=!1,this.source=e,this.context=t;for(let e=0,t=n.length;e<t;++e)n[e].bind(this)}this.isBound=!0}unbind(){this.isBound&&this.source!==null&&(this.evaluateUnbindables(),this.source=null,this.context=this,this.isBound=!1)}evaluateUnbindables(){let e=this.unbindables;for(let t=0,n=e.length;t<n;++t)e[t].unbind(this);e.length=0}static disposeContiguousBatch(e){if(e.length!==0){Tn(e[0].firstChild,e[e.length-1].lastChild);for(let t=0,n=e.length;t<n;++t)e[t].unbind()}}};re(Dn),p.defineProperty(Dn.prototype,`index`),p.defineProperty(Dn.prototype,`length`);var On,kn={unhydrated:`unhydrated`,hydrating:`hydrating`,hydrated:`hydrated`},An=class extends Error{constructor(e,t,n,r,i,a){super(e),this.factory=t,this.fragment=n,this.templateString=r,this.expected=i,this.received=a}},jn=class extends En{get hydrationStage(){return this._hydrationStage}get targets(){return this._targets}get bindingViewBoundaries(){return this._bindingViewBoundaries}constructor(e,t,n,r){super(),this.firstChild=e,this.lastChild=t,this.sourceTemplate=n,this.hostBindingTarget=r,this[On]=nn,this.context=this,this.source=null,this.isBound=!1,this.sourceLifetime=ge.unknown,this.unbindables=[],this.fragment=null,this.behaviors=null,this._hydrationStage=kn.unhydrated,this._bindingViewBoundaries={},this._targets={},this.factories=n.compile().factories}insertBefore(e){if(this.fragment!==null){if(this.fragment.hasChildNodes())e.parentNode.insertBefore(this.fragment,e);else{let t=this.lastChild;if(e.previousSibling===t)return;let n=e.parentNode,r=this.firstChild,i;for(;r!==t;)i=r.nextSibling,n.insertBefore(r,e),r=i;n.insertBefore(t,e)}}}appendTo(e){this.fragment!==null&&e.appendChild(this.fragment)}remove(){let e=this.fragment||=document.createDocumentFragment(),t=this.lastChild,n=this.firstChild,r;for(;n!==t;){if(r=n.nextSibling,!r)throw Error(`Unmatched first/last child inside "${t.getRootNode().host.nodeName}".`);e.appendChild(n),n=r}e.appendChild(t)}bind(e,t=this){if(this.source===e&&this.context===t)return;this.hydrationStage!==kn.hydrated&&(this._hydrationStage=kn.hydrating);let n=this.behaviors;if(n===null){this.source=e,this.context=t;try{let{targets:e,boundaries:t}=bn(this.firstChild,this.lastChild,this.factories);this._targets=e,this._bindingViewBoundaries=t}catch(e){if(e instanceof gn){let t=this.sourceTemplate.html;typeof t!=`string`&&(t=t.innerHTML),e.templateString=t}throw e}this.behaviors=n=Array(this.factories.length);let r=this.factories;for(let e=0,t=r.length;e<t;++e){let t=r[e];if(t.targetNodeId===`h`&&this.hostBindingTarget&&wn(t,this.hostBindingTarget,this._targets),t.targetNodeId in this.targets){let r=t.createBehavior();r.bind(this),n[e]=r}else{let e=this.sourceTemplate.html;typeof e!=`string`&&(e=e.innerHTML);let n=yn(this.firstChild,this.lastChild).cloneContents(),r=mn().formatBindingMismatch(t,this.firstChild,this.lastChild,hn(this.firstChild));throw new An(r.message,t,n,e,r.expected,r.received)}}}else{this.source!==null&&this.evaluateUnbindables(),this.isBound=!1,this.source=e,this.context=t;for(let e=0,t=n.length;e<t;++e)n[e].bind(this)}this.isBound=!0,this._hydrationStage=kn.hydrated}unbind(){this.isBound&&this.source!==null&&(this.evaluateUnbindables(),this.source=null,this.context=this,this.isBound=!1)}dispose(){Tn(this.firstChild,this.lastChild),this.unbind()}onUnbind(e){this.unbindables.push(e)}evaluateUnbindables(){let e=this.unbindables;for(let t=0,n=e.length;t<n;++t)e[t].unbind(this);e.length=0}};On=nn,re(jn);function Mn(e){return e.create!==void 0}function Nn(e,t,n,r){if(n??=``,Mn(n)){e.textContent=``;let t=e.$fastView;if(t===void 0){if(rn(r)&&rn(n)&&r.bindingViewBoundaries[this.targetNodeId]!==void 0&&r.hydrationStage!==kn.hydrated){let e=r.bindingViewBoundaries[this.targetNodeId];t=n.hydrate(e.first,e.last)}else t=n.create()}else e.$fastTemplate!==n&&(t.isComposed&&(t.remove(),t.unbind()),t=n.create());t.isComposed?t.needsBindOnly&&(t.needsBindOnly=!1,t.bind(r.source,r.context)):(t.isComposed=!0,t.bind(r.source,r.context),t.insertBefore(e),e.$fastView=t,e.$fastTemplate=n)}else{let t=e.$fastView;if(t!==void 0&&t.isComposed&&(t.isComposed=!1,t.remove(),t.needsBindOnly?t.needsBindOnly=!1:t.unbind()),t===void 0&&rn(r)&&r.hydrationStage!==kn.hydrated){let e=r.bindingViewBoundaries[this.targetNodeId];e!==void 0&&(Tn(e.first,e.last),delete r.bindingViewBoundaries[this.targetNodeId])}e.textContent=n}}function Pn(e,t,n){let r=`${this.id}-t`,i=e[r]??(e[r]={v:0,cv:Object.create(null)}),a=i.cv,o=i.v,s=e[t];if(n!=null&&n.length){let e=n.split(/\s+/);for(let t=0,n=e.length;t<n;++t){let n=e[t];n!==``&&(a[n]=o,s.add(n))}}if(i.v=o+1,o!==0){--o;for(let e in a)a[e]===o&&s.remove(e)}}var Fn={[h.attribute]:Te.setAttribute,[h.booleanAttribute]:Te.setBooleanAttribute,[h.property]:(e,t,n)=>e[t]=n,[h.content]:Nn,[h.tokenList]:Pn,[h.event]:()=>void 0},In=class{constructor(e){this.updateTarget=null,this.aspectType=h.content,this.dataBinding=e}createHTML(e){return zt.interpolation(e(this))}createBehavior(){if(this.updateTarget===null){let e=Fn[this.aspectType],t=this.dataBinding.policy??this.policy;if(!e)throw d.error(o.unsupportedBindingBehavior);this.data=`${this.id}-d`,this.updateTarget=t.protect(this.targetTagName,this.aspectType,this.targetAspect,e)}return this}bind(e){let t=e.targets[this.targetNodeId];switch(this.aspectType){case h.event:t[this.data]=e,t.addEventListener(this.targetAspect,this,this.dataBinding.options);break;case h.content:e.onUnbind(this);default:{let n=t[this.data]??(t[this.data]=this.dataBinding.createObserver(this,this));n.target=t,n.controller=e;let r=n.bind(e);if(e._skipAttrUpdates&&(this.aspectType===h.attribute||this.aspectType===h.booleanAttribute))break;this.updateTarget(t,this.targetAspect,r,e);break}}}unbind(e){let t=e.targets[this.targetNodeId].$fastView;t!==void 0&&t.isComposed&&(t.unbind(),t.needsBindOnly=!0)}handleEvent(e){let t=e.currentTarget[this.data];if(t.isBound){ve.setEvent(e);let n=this.dataBinding.evaluate(t.source,t.context);ve.setEvent(null),n!==!0&&e.preventDefault()}}handleChange(e,t){let n=t.controller;if(!n.isBound)return;let r=t.target;this.updateTarget(r,this.targetAspect,t.bind(n),n)}};Ht.define(In,{aspected:!0});var Ln=(e,t)=>`${e}.${t}`,Rn={},zn={index:0,node:null};function Bn(e){e.startsWith(`fast-`)||d.warn(o.hostBindingWithoutHost,{name:e})}var Vn=new Proxy(document.createElement(`div`),{get(e,t){Bn(t);let n=Reflect.get(e,t);return s(n)?n.bind(e):n},set(e,t,n){return Bn(t),Reflect.set(e,t,n)}}),Hn=class{constructor(e,t,n){this.fragment=e,this.directives=t,this.policy=n,this.proto=null,this.nodeIds=new Set,this.descriptors={},this.factories=[]}addFactory(e,t,n,r,i){this.nodeIds.has(n)||(this.nodeIds.add(n),this.addTargetDescriptor(t,n,r)),e.id=e.id??Rt(),e.targetNodeId=n,e.targetTagName=i,e.policy=e.policy??this.policy,this.factories.push(e)}freeze(){return this.proto=Object.create(null,this.descriptors),this}addTargetDescriptor(e,t,n){let r=this.descriptors;if(t===`r`||t===`h`||r[t])return;if(!r[e]){let t=e.lastIndexOf(`.`),n=e.substring(0,t),r=parseInt(e.substring(t+1),10);this.addTargetDescriptor(n,e,r)}let i=Rn[t];if(!i){let r=`_${t}`;Rn[t]=i={get(){return this[r]??(this[r]=this[e].childNodes[n])}}}r[t]=i}createView(e){let t=this.fragment.cloneNode(!0),n=Object.create(this.proto);n.r=t,n.h=e??Vn;for(let e of this.nodeIds)Reflect.get(n,e);return new Dn(t,this.factories,n)}};function Un(e,t,n,r,i,a=!1){let o=n.attributes,s=e.directives;for(let c=0,l=o.length;c<l;++c){let u=o[c],d=u.value,ee=Bt.parse(d,s),te=null;ee===null?a&&(te=new In(ae(()=>d,e.policy)),Ht.assignAspect(te,u.name)):te=Yn.aggregate(ee,e.policy),te!==null&&(n.removeAttributeNode(u),c--,l--,e.addFactory(te,t,r,i,n.tagName))}}function Wn(e,t,n,r,i){let a=Bt.parse(t.textContent,e.directives);if(a===null)return zn.node=t.nextSibling,zn.index=i+1,zn;let o,s=o=t;for(let t=0,l=a.length;t<l;++t){let l=a[t];t!==0&&(i++,r=Ln(n,i),o=s.parentNode.insertBefore(document.createTextNode(``),s.nextSibling)),c(l)?o.textContent=l:(o.textContent=` `,Ht.assignAspect(l),e.addFactory(l,n,r,i,null)),s=o}return zn.index=i+1,zn.node=s.nextSibling,zn}function Gn(e,t,n){let r=0,i=t.firstChild;for(;i;){let t=Kn(e,n,i,r);i=t.node,r=t.index}}function Kn(e,t,n,r){let i=Ln(t,r);switch(n.nodeType){case 1:Un(e,t,n,i,r),Gn(e,n,i);break;case 3:return Wn(e,n,t,i,r);case 8:{let a=Bt.parse(n.data,e.directives);a!==null&&e.addFactory(Yn.aggregate(a),t,i,r,null);break}}return zn.index=r+1,zn.node=n.nextSibling,zn}function qn(e,t){return e&&e.nodeType===8&&Bt.parse(e.data,t)!==null}var Jn=`TEMPLATE`,Yn={compile(e,t,n=Te.policy){let r;if(c(e)){r=document.createElement(Jn),r.innerHTML=n.createHTML(e);let t=r.content.firstElementChild;t!==null&&t.tagName===Jn&&(r=t)}else r=e;!r.content.firstChild&&!r.content.lastChild&&r.content.appendChild(document.createComment(``));let i=document.adoptNode(r.content),a=new Hn(i,t,n);return Un(a,``,r,`h`,0,!0),(qn(i.firstChild,t)||i.childNodes.length===1&&Object.keys(t).length>0)&&i.insertBefore(document.createComment(``),i.firstChild),Gn(a,i,`r`),zn.node=null,a.freeze()},setDefaultStrategy(e){this.compile=e},aggregate(e,t=Te.policy){if(e.length===1)return e[0];let n,r=!1,i,a=e.length,o=e.map(e=>c(e)?()=>e:(n=e.sourceAspect||n,r||=e.dataBinding.isVolatile,i||=e.dataBinding.policy,e.dataBinding.evaluate)),s=new In(be((e,t)=>{let n=``;for(let r=0;r<a;++r)n+=o[r](e,t);return n},i??t,r));return Ht.assignAspect(s,n),s}},Xn=class extends Ut{bind(e){e.source[this.options]=e.targets[this.targetNodeId]}};Ht.define(Xn);var y=e=>new Xn(e),Zn=/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/,Qn=Object.create(null),$n=class{constructor(e,t=Qn){this.html=e,this.factories=t}createHTML(e){let t=this.factories;for(let n in t)e(t[n]);return this.html}};$n.empty=new $n(``),Ht.define($n);function er(e,t,n,r=Ht.getForInstance(e)){if(r.aspected){let n=Zn.exec(t);n!==null&&Ht.assignAspect(e,n[2])}return e.createHTML(n)}var tr=class e{constructor(e,t={},n){this.policy=n,this.result=null,this.html=e,this.factories=t}compile(){return this.result===null&&(this.result=Yn.compile(this.html,this.factories,this.policy)),this.result}inline(){return new $n(c(this.html)?this.html:this.html.innerHTML,this.factories)}withPolicy(e){if(this.result)throw d.error(o.cannotSetTemplatePolicyAfterCompilation);if(this.policy)throw d.error(o.onlySetTemplatePolicyOnce);return this.policy=e,this}render(e,t,n){let r=this.create(n);return r.bind(e),r.appendTo(t),r}create(e){return this.compile().createView(e)}static create(t,n,r){let i=``,o=Object.create(null),c=e=>{let t=e.id??=Rt();return o[t]=e,t};for(let e=0,r=t.length-1;e<r;++e){let r=t[e],o=n[e],l;if(i+=r,s(o))o=new In(be(o));else if(o instanceof a)o=new In(o);else if(!(l=Ht.getForInstance(o))){let e=o;o=new In(ae(()=>e))}i+=er(o,r,c,l)}return new e(i+t[t.length-1],o,r)}};re(tr);var b=((e,...t)=>{if(Array.isArray(e)&&Array.isArray(e.raw))return tr.create(e,t);throw d.error(o.directCallToHTMLTagNotAllowed)});b.partial=e=>new $n(e);var nr=`slotchange`,rr=class extends Kt{observe(e){e.addEventListener(nr,this)}disconnect(e){e.removeEventListener(nr,this)}getNodes(e){return e.assignedNodes(this.options)}handleEvent(e){let t=e.currentTarget;this.updateTarget(this.getSource(t),this.computeNodes(t))}};Ht.define(rr);function x(e){return c(e)&&(e={property:e}),new rr(e)}var ir=`:host([hidden]){display:none}`;function S(e){return`${ir}:host{display:${e}}`}var C=`var(--colorNeutralForeground1)`,ar=`var(--colorNeutralForeground1Hover)`,or=`var(--colorNeutralForeground1Pressed)`,sr=`var(--colorNeutralForeground2)`,cr=`var(--colorNeutralForeground2Hover)`,lr=`var(--colorNeutralForeground2Pressed)`,ur=`var(--colorNeutralForeground2BrandHover)`,dr=`var(--colorNeutralForeground2BrandPressed)`,w=`var(--colorNeutralForeground3)`,fr=`var(--colorNeutralForeground3Hover)`,pr=`var(--colorNeutralForeground3Pressed)`,mr=`var(--colorNeutralForeground4)`,T=`var(--colorNeutralForegroundDisabled)`,hr=`var(--colorBrandForegroundLink)`,gr=`var(--colorBrandForegroundLinkHover)`,_r=`var(--colorBrandForegroundLinkPressed)`,vr=`var(--colorNeutralForeground2Link)`,yr=`var(--colorNeutralForeground2LinkHover)`,br=`var(--colorNeutralForeground2LinkPressed)`,xr=`var(--colorCompoundBrandForeground1Hover)`,Sr=`var(--colorCompoundBrandForeground1Pressed)`,Cr=`var(--colorNeutralForegroundOnBrand)`,wr=`var(--colorNeutralForegroundInverted)`,Tr=`var(--colorNeutralForegroundInvertedHover)`,Er=`var(--colorNeutralForegroundInvertedPressed)`,Dr=`var(--colorNeutralForegroundStaticInverted)`,Or=`var(--colorBrandForeground1)`,kr=`var(--colorBrandForeground2)`,Ar=`var(--colorNeutralForeground1Static)`,E=`var(--colorNeutralBackground1)`,jr=`var(--colorNeutralBackground1Hover)`,Mr=`var(--colorNeutralBackground1Pressed)`,Nr=`var(--colorNeutralBackground1Selected)`,Pr=`var(--colorNeutralBackground3)`,Fr=`var(--colorNeutralBackground4)`,Ir=`var(--colorNeutralBackground5)`,Lr=`var(--colorNeutralBackground6)`,Rr=`var(--colorNeutralBackgroundInverted)`,zr=`var(--colorSubtleBackground)`,Br=`var(--colorSubtleBackgroundHover)`,Vr=`var(--colorSubtleBackgroundPressed)`,Hr=`var(--colorTransparentBackground)`,Ur=`var(--colorTransparentBackgroundHover)`,Wr=`var(--colorTransparentBackgroundPressed)`,Gr=`var(--colorNeutralBackgroundDisabled)`,Kr=`var(--colorBackgroundOverlay)`,qr=`var(--colorBrandBackground)`,Jr=`var(--colorBrandBackgroundHover)`,Yr=`var(--colorBrandBackgroundPressed)`,Xr=`var(--colorCompoundBrandBackground)`,Zr=`var(--colorCompoundBrandBackgroundHover)`,Qr=`var(--colorCompoundBrandBackgroundPressed)`,$r=`var(--colorBrandBackgroundStatic)`,ei=`var(--colorBrandBackground2)`,ti=`var(--colorNeutralStrokeAccessible)`,ni=`var(--colorNeutralStrokeAccessibleHover)`,ri=`var(--colorNeutralStrokeAccessiblePressed)`,ii=`var(--colorNeutralStroke1)`,ai=`var(--colorNeutralStroke1Hover)`,oi=`var(--colorNeutralStroke1Pressed)`,si=`var(--colorNeutralStroke2)`,ci=`var(--colorBrandStroke2)`,li=`var(--colorCompoundBrandStroke)`,ui=`var(--colorCompoundBrandStrokeHover)`,di=`var(--colorCompoundBrandStrokePressed)`,fi=`var(--colorNeutralStrokeDisabled)`,D=`var(--colorTransparentStroke)`,pi=`var(--colorTransparentStrokeInteractive)`,mi=`var(--colorStrokeFocus1)`,hi=`var(--colorStrokeFocus2)`,gi=`var(--colorPaletteRedBackground1)`,_i=`var(--colorPaletteRedBackground2)`,vi=`var(--colorPaletteRedBackground3)`,yi=`var(--colorPaletteRedBorder1)`,bi=`var(--colorPaletteRedBorder2)`,xi=`var(--colorPaletteRedForeground1)`,Si=`var(--colorPaletteRedForeground2)`,Ci=`var(--colorPaletteRedForeground3)`,wi=`var(--colorPaletteGreenBackground1)`,Ti=`var(--colorPaletteGreenBackground3)`,Ei=`var(--colorPaletteGreenBorder2)`,Di=`var(--colorPaletteGreenForeground1)`,Oi=`var(--colorPaletteGreenForeground2)`,ki=`var(--colorPaletteGreenForeground3)`,Ai=`var(--colorPaletteDarkOrangeBackground1)`,ji=`var(--colorPaletteDarkOrangeBackground3)`,Mi=`var(--colorPaletteDarkOrangeBorder1)`,Ni=`var(--colorPaletteDarkOrangeForeground1)`,Pi=`var(--colorPaletteDarkOrangeForeground3)`,Fi=`var(--colorPaletteYellowBackground1)`,Ii=`var(--colorPaletteYellowBackground3)`,Li=`var(--colorPaletteYellowBorder1)`,Ri=`var(--colorPaletteYellowForeground2)`,zi=`var(--colorPaletteMarigoldBackground2)`,Bi=`var(--colorPaletteMarigoldForeground2)`,Vi=`var(--colorPaletteAnchorBackground2)`,Hi=`var(--colorPaletteAnchorForeground2)`,Ui=`var(--colorPaletteBeigeBackground2)`,Wi=`var(--colorPaletteBeigeForeground2)`,Gi=`var(--colorPaletteBlueBackground2)`,Ki=`var(--colorPaletteBlueForeground2)`,qi=`var(--colorPaletteBrassBackground2)`,Ji=`var(--colorPaletteBrassForeground2)`,Yi=`var(--colorPaletteBrownBackground2)`,Xi=`var(--colorPaletteBrownForeground2)`,Zi=`var(--colorPaletteCornflowerBackground2)`,Qi=`var(--colorPaletteCornflowerForeground2)`,$i=`var(--colorPaletteCranberryBackground2)`,ea=`var(--colorPaletteCranberryForeground2)`,ta=`var(--colorPaletteDarkGreenBackground2)`,na=`var(--colorPaletteDarkGreenForeground2)`,ra=`var(--colorPaletteDarkRedBackground2)`,ia=`var(--colorPaletteDarkRedForeground2)`,aa=`var(--colorPaletteForestBackground2)`,oa=`var(--colorPaletteForestForeground2)`,sa=`var(--colorPaletteGoldBackground2)`,ca=`var(--colorPaletteGoldForeground2)`,la=`var(--colorPaletteGrapeBackground2)`,ua=`var(--colorPaletteGrapeForeground2)`,da=`var(--colorPaletteLavenderBackground2)`,fa=`var(--colorPaletteLavenderForeground2)`,pa=`var(--colorPaletteLightTealBackground2)`,ma=`var(--colorPaletteLightTealForeground2)`,ha=`var(--colorPaletteLilacBackground2)`,ga=`var(--colorPaletteLilacForeground2)`,_a=`var(--colorPaletteMagentaBackground2)`,va=`var(--colorPaletteMagentaForeground2)`,ya=`var(--colorPaletteMinkBackground2)`,ba=`var(--colorPaletteMinkForeground2)`,xa=`var(--colorPaletteNavyBackground2)`,Sa=`var(--colorPaletteNavyForeground2)`,Ca=`var(--colorPalettePeachBackground2)`,wa=`var(--colorPalettePeachForeground2)`,Ta=`var(--colorPalettePinkBackground2)`,Ea=`var(--colorPalettePinkForeground2)`,Da=`var(--colorPalettePlatinumBackground2)`,Oa=`var(--colorPalettePlatinumForeground2)`,ka=`var(--colorPalettePlumBackground2)`,Aa=`var(--colorPalettePlumForeground2)`,ja=`var(--colorPalettePumpkinBackground2)`,Ma=`var(--colorPalettePumpkinForeground2)`,Na=`var(--colorPalettePurpleBackground2)`,Pa=`var(--colorPalettePurpleForeground2)`,Fa=`var(--colorPaletteRoyalBlueBackground2)`,Ia=`var(--colorPaletteRoyalBlueForeground2)`,La=`var(--colorPaletteSeafoamBackground2)`,Ra=`var(--colorPaletteSeafoamForeground2)`,za=`var(--colorPaletteSteelBackground2)`,Ba=`var(--colorPaletteSteelForeground2)`,Va=`var(--colorPaletteTealBackground2)`,Ha=`var(--colorPaletteTealForeground2)`,Ua=`var(--borderRadiusNone)`,Wa=`var(--borderRadiusSmall)`,O=`var(--borderRadiusMedium)`,Ga=`var(--borderRadiusLarge)`,Ka=`var(--borderRadiusXLarge)`,qa=`var(--borderRadiusCircular)`,k=`var(--fontFamilyBase)`,Ja=`var(--fontSizeBase100)`,Ya=`var(--fontSizeBase200)`,A=`var(--fontSizeBase300)`,Xa=`var(--fontSizeBase400)`,Za=`var(--fontSizeBase500)`,Qa=`var(--fontSizeBase600)`,$a=`var(--fontSizeHero700)`,eo=`var(--fontSizeHero800)`,to=`var(--fontSizeHero900)`,no=`var(--fontSizeHero1000)`,j=`var(--fontWeightRegular)`,M=`var(--fontWeightSemibold)`,ro=`var(--fontWeightBold)`,io=`var(--lineHeightBase100)`,ao=`var(--lineHeightBase200)`,N=`var(--lineHeightBase300)`,oo=`var(--lineHeightBase400)`,so=`var(--lineHeightBase500)`,co=`var(--lineHeightBase600)`,lo=`var(--lineHeightHero700)`,uo=`var(--lineHeightHero800)`,fo=`var(--lineHeightHero900)`,po=`var(--lineHeightHero1000)`,mo=`var(--shadow2)`,ho=`var(--shadow4)`,go=`var(--shadow8)`,_o=`var(--shadow16)`,vo=`var(--shadow28)`,yo=`var(--shadow64)`,P=`var(--strokeWidthThin)`,bo=`var(--strokeWidthThick)`,xo=`var(--strokeWidthThicker)`,So=`var(--strokeWidthThickest)`,F=`var(--spacingHorizontalXXS)`,Co=`var(--spacingHorizontalXS)`,wo=`var(--spacingHorizontalSNudge)`,To=`var(--spacingHorizontalS)`,Eo=`var(--spacingHorizontalMNudge)`,Do=`var(--spacingHorizontalM)`,Oo=`var(--spacingHorizontalL)`,ko=`var(--spacingHorizontalXL)`,Ao=`var(--spacingHorizontalXXL)`,jo=`var(--spacingVerticalXXS)`,Mo=`var(--spacingVerticalXS)`,No=`var(--spacingVerticalSNudge)`,Po=`var(--spacingVerticalS)`,Fo=`var(--spacingVerticalMNudge)`,Io=`var(--spacingVerticalM)`,Lo=`var(--spacingVerticalL)`,Ro=`var(--spacingVerticalXXL)`,zo=`var(--durationUltraFast)`,Bo=`var(--durationFaster)`,Vo=`var(--durationNormal)`,Ho=`var(--durationGentle)`,Uo=`var(--durationSlow)`,Wo=`var(--durationSlower)`,Go=`var(--durationUltraSlow)`,Ko=`var(--curveAccelerateMax)`,qo=`var(--curveAccelerateMid)`,Jo=`var(--curveAccelerateMin)`,Yo=`var(--curveDecelerateMax)`,Xo=`var(--curveDecelerateMid)`,Zo=`var(--curveDecelerateMin)`,Qo=`var(--curveEasyEaseMax)`,$o=`var(--curveEasyEase)`,es=`var(--curveLinear)`,ts=v`
  ${S(`inline`)}

  :host {
    position: relative;
    box-sizing: border-box;
    background-color: transparent;
    color: ${hr};
    cursor: pointer;
    font-family: ${k};
    font-size: ${A};
    font-weight: ${j};
    overflow: inherit;
    text-align: start;
    text-decoration: none;
    text-decoration-thickness: ${P};
    text-overflow: inherit;
    user-select: text;
  }

  :host(:hover) {
    outline: none;
    text-decoration-line: underline;
  }

  @media (hover: hover) {
    :host(:hover) {
      color: ${gr};
    }

    :host(:active) {
      color: ${_r};
    }

    :host([appearance='subtle']:hover) {
      color: ${yr};
    }

    :host([appearance='subtle']:active) {
      color: ${br};
    }
  }

  :host([appearance='subtle']) {
    color: ${vr};
  }

  :host-context(:is(h1, h2, h3, h4, h5, h6, p, fluent-text)),
  :host([inline]) {
    font: inherit;
    text-decoration: underline;
  }

  :host(:focus-visible),
  :host-context(:is(h1, h2, h3, h4, h5, h6, p, fluent-text)):focus-visible,
  :host([inline]:focus-visible) {
    outline-style: none;
    text-decoration-line: underline;
    text-decoration-style: double;
    text-decoration-color: ${hi};
  }

  :host(:not([href])) {
    color: inherit;
    text-decoration: none;
  }

  ::slotted(a) {
    position: absolute;
    inset: 0;
  }

  @media (forced-colors: active) {
    :host {
      color: LinkText;
    }
  }
`;function ns(){return b`
    <template
      tabindex="0"
      @click="${(e,t)=>e.clickHandler(t.event)}"
      @keydown="${(e,t)=>e.keydownHandler(t.event)}"
    >
      <slot></slot>
    </template>
  `}var rs=ns(),is={name:i,registry:e.registry,styles:ts,template:rs};function I(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a}var as=class extends _{constructor(){super(),this.isMac=navigator.userAgent.includes(`Mac`),this.elementInternals=this.attachInternals(),this.internalProxyAnchor=this.createProxyElement(),this.elementInternals.role=`link`}connectedCallback(){super.connectedCallback(),this.tabIndex=Number(this.getAttribute(`tabindex`)??0)<0?-1:0,p.getNotifier(this).subscribe(this),Object.keys(this.$fastController.definition.attributeLookup).forEach(e=>{this.handleChange(this,e)}),this.append(this.internalProxyAnchor)}disconnectedCallback(){super.disconnectedCallback(),p.getNotifier(this).unsubscribe(this)}handleChange(e,t){if(t in r){let e=this.$fastController.definition.attributeLookup[t]?.attribute;e&&this.handleProxyAttributeChange(e,this[t])}}clickHandler(e){if(e.composedPath()[0]===this.internalProxyAnchor)return e.stopImmediatePropagation(),!0;if(this.href){let t=e.ctrlKey||e.metaKey;this.handleNavigation(t)}return!0}keydownHandler(e){if(this.href&&e.key===`Enter`){let t=this.isMac&&e.metaKey||e.ctrlKey;this.handleNavigation(t);return}return!0}handleNavigation(e){e?window.open(this.href,`_blank`):this.internalProxyAnchor.click()}handleProxyAttributeChange(e,t){t?this.internalProxyAnchor.setAttribute(e,t):this.internalProxyAnchor.removeAttribute(e)}createProxyElement(){let e=this.internalProxyAnchor??document.createElement(`a`);return e.inert=!0,e}};I([g],as.prototype,`download`,void 0),I([g],as.prototype,`href`,void 0),I([g],as.prototype,`hreflang`,void 0),I([g],as.prototype,`ping`,void 0),I([g],as.prototype,`referrerpolicy`,void 0),I([g],as.prototype,`rel`,void 0),I([g],as.prototype,`target`,void 0),I([g],as.prototype,`type`,void 0);var os=class extends as{constructor(){super(...arguments),this.inline=!1}};I([g],os.prototype,`appearance`,void 0),I([g({mode:`boolean`})],os.prototype,`inline`,void 0),os.define(is);var ss=v`
  ${v`
  ${S(`inline-flex`)}

  :host {
    --icon-spacing: ${wo};
    position: relative;
    contain: layout style;
    vertical-align: middle;
    align-items: center;
    box-sizing: border-box;
    justify-content: center;
    text-align: center;
    text-decoration-line: none;
    margin: 0;
    min-height: 32px;
    outline-style: none;
    background-color: ${E};
    color: ${C};
    border: ${P} solid ${ii};
    padding: 0 ${Do};
    min-width: 96px;
    border-radius: ${O};
    font-size: ${A};
    font-family: ${k};
    font-weight: ${M};
    line-height: ${N};
    transition-duration: ${Bo};
    transition-property: background, border, color;
    transition-timing-function: ${$o};
    cursor: pointer;
    user-select: none;
  }

  .content {
    display: inherit;
  }

  :host(:hover) {
    background-color: ${jr};
    color: ${ar};
    border-color: ${ai};
  }

  :host(:hover:active) {
    background-color: ${Mr};
    border-color: ${oi};
    color: ${or};
    outline-style: none;
  }

  :host(:focus-visible) {
    border-color: ${D};
    outline: ${bo} solid ${D};
    box-shadow: ${ho}, 0 0 0 2px ${hi};
  }

  @media screen and (prefers-reduced-motion: reduce) {
    :host {
      transition-duration: 0.01ms;
    }
  }

  ::slotted(svg) {
    font-size: 20px;
    height: 20px;
    width: 20px;
    fill: currentColor;
  }

  ::slotted([slot='start']) {
    margin-inline-end: var(--icon-spacing);
  }

  ::slotted([slot='end']),
  [slot='end'] {
    flex-shrink: 0;
    margin-inline-start: var(--icon-spacing);
  }

  :host([icon-only]) {
    min-width: 32px;
    max-width: 32px;
  }

  :host([size='small']) {
    --icon-spacing: ${Co};
    min-height: 24px;
    min-width: 64px;
    padding: 0 ${To};
    border-radius: ${Wa};
    font-size: ${Ya};
    line-height: ${ao};
    font-weight: ${j};
  }

  :host([size='small'][icon-only]) {
    min-width: 24px;
    max-width: 24px;
  }

  :host([size='large']) {
    min-height: 40px;
    border-radius: ${Ga};
    padding: 0 ${Oo};
    font-size: ${Xa};
    line-height: ${oo};
  }

  :host([size='large'][icon-only]) {
    min-width: 40px;
    max-width: 40px;
  }

  :host([size='large']) ::slotted(svg) {
    font-size: 24px;
    height: 24px;
    width: 24px;
  }

  :host(:is([shape='circular'], [shape='circular']:focus-visible)) {
    border-radius: ${qa};
  }

  :host(:is([shape='square'], [shape='square']:focus-visible)) {
    border-radius: ${Ua};
  }

  :host([appearance='primary']) {
    background-color: ${qr};
    color: ${Cr};
    border-color: transparent;
  }

  :host([appearance='primary']:hover) {
    background-color: ${Jr};
  }

  :host([appearance='primary']:is(:hover, :hover:active):not(:focus-visible)) {
    border-color: transparent;
  }

  :host([appearance='primary']:is(:hover, :hover:active)) {
    color: ${Cr};
  }

  :host([appearance='primary']:hover:active) {
    background-color: ${Yr};
  }

  :host([appearance='primary']:focus-visible) {
    border-color: ${Cr};
    box-shadow: ${mo}, 0 0 0 2px ${hi};
  }

  :host([appearance='outline']) {
    background-color: ${Hr};
  }

  :host([appearance='outline']:hover) {
    background-color: ${Ur};
  }

  :host([appearance='outline']:hover:active) {
    background-color: ${Wr};
  }

  :host([appearance='subtle']) {
    background-color: ${zr};
    color: ${sr};
    border-color: transparent;
  }

  :host([appearance='subtle']:hover) {
    background-color: ${Br};
    color: ${cr};
    border-color: transparent;
  }

  :host([appearance='subtle']:hover:active) {
    background-color: ${Vr};
    color: ${lr};
    border-color: transparent;
  }

  :host([appearance='subtle']:hover) ::slotted(svg) {
    fill: ${ur};
  }

  :host([appearance='subtle']:hover:active) ::slotted(svg) {
    fill: ${dr};
  }

  :host([appearance='transparent']) {
    background-color: ${Hr};
    color: ${sr};
  }

  :host([appearance='transparent']:hover) {
    background-color: ${Ur};
    color: ${ur};
  }

  :host([appearance='transparent']:hover:active) {
    background-color: ${Wr};
    color: ${dr};
  }

  :host(:is([appearance='transparent'], [appearance='transparent']:is(:hover, :active))) {
    border-color: transparent;
  }
`}

  :host(:is(:disabled, [disabled], [disabled-focusable], [appearance]:disabled, [appearance][disabled], [appearance][disabled-focusable])),
  :host(:is(:disabled, [disabled], [disabled-focusable], [appearance]:disabled, [appearance][disabled], [appearance][disabled-focusable]):hover),
  :host(:is(:disabled, [disabled], [disabled-focusable], [appearance]:disabled, [appearance][disabled], [appearance][disabled-focusable]):hover:active) {
    background-color: ${Gr};
    border-color: ${fi};
    color: ${T};
    cursor: not-allowed;
  }

  :host([appearance='primary']:is(:disabled, [disabled], [disabled-focusable])),
  :host([appearance='primary']:is(:disabled, [disabled], [disabled-focusable]):is(:hover, :hover:active)) {
    border-color: transparent;
  }

  :host([appearance='outline']:is(:disabled, [disabled], [disabled-focusable])),
  :host([appearance='outline']:is(:disabled, [disabled], [disabled-focusable]):is(:hover, :hover:active)) {
    background-color: ${Hr};
  }

  :host([appearance='subtle']:is(:disabled, [disabled], [disabled-focusable])),
  :host([appearance='subtle']:is(:disabled, [disabled], [disabled-focusable]):is(:hover, :hover:active)) {
    background-color: ${Hr};
    border-color: transparent;
  }

  :host([appearance='transparent']:is(:disabled, [disabled], [disabled-focusable])),
  :host([appearance='transparent']:is(:disabled, [disabled], [disabled-focusable]):is(:hover, :hover:active)) {
    border-color: transparent;
    background-color: ${Hr};
  }

  @media (forced-colors: active) {
    :host {
      background-color: ButtonFace;
      color: ButtonText;
    }

    :host(:is(:hover, :focus-visible)) {
      border-color: Highlight !important;
    }

    :host([appearance='primary']:not(:is(:hover, :focus-visible))) {
      background-color: Highlight;
      color: HighlightText;
      forced-color-adjust: none;
    }

    :host(
        :is(
            :disabled,
            [disabled],
            [disabled-focusable],
            [appearance]:disabled,
            [appearance][disabled],
            [appearance][disabled-focusable]
          )
      ) {
      background-color: ButtonFace;
      color: GrayText;
      border-color: ButtonText;
    }
  }
`;function cs(e){return e?typeof e==`string`?new $n(e):`inline`in e?e.inline():e:$n.empty}var ls=class{};function us(e){return b` <slot name="end" ${y(`end`)}>${cs(e.end)}</slot> `.inline()}function ds(e){return b` <slot name="start" ${y(`start`)}>${cs(e.start)}</slot> `.inline()}function fs(e={}){return b`
    <template
      @click="${(e,t)=>e.clickHandler(t.event)}"
      @keypress="${(e,t)=>e.keypressHandler(t.event)}"
    >
      ${ds(e)}
      <span class="content" part="content">
        <slot ${x(`defaultSlottedContent`)}></slot>
      </span>
      ${us(e)}
    </template>
  `}var ps=fs(),ms={name:n,registry:e.registry,styles:ss,template:ps};function hs(e,...t){let n=Oe.locate(e);t.forEach(t=>{Object.getOwnPropertyNames(t.prototype).forEach(n=>{n!==`constructor`&&Object.defineProperty(e.prototype,n,Object.getOwnPropertyDescriptor(t.prototype,n))}),Oe.locate(t).forEach(e=>n.push(e))})}function gs(e){let t=e.ownerDocument;e?.isConnected&&e?.hasAttribute(`autofocus`)&&e?.checkVisibility?.({contentVisibilityAuto:!0,visibilityProperty:!0})&&[null,e,t.body,t.documentElement].includes(t.activeElement)&&f.enqueue(()=>{e.focus()})}var _s=class extends _{disabledChanged(){this.setTabIndex()}disabledFocusableChanged(e,t){this.elementInternals&&(this.elementInternals.ariaDisabled=`${!!t}`)}get form(){return this.elementInternals.form}static{this.formAssociated=!0}get labels(){return Object.freeze(Array.from(this.elementInternals.labels))}typeChanged(e,n){n!==t.submit&&(this.formSubmissionFallbackControl?.remove(),this.shadowRoot?.querySelector(`slot[name="internal"]`)?.remove())}clickHandler(e){if(e&&this.disabledFocusable){e.stopImmediatePropagation();return}return this.press(),!0}connectedCallback(){super.connectedCallback(),this.elementInternals.ariaDisabled=`${!!this.disabledFocusable}`,this.setTabIndex(),gs(this)}constructor(){super(),this.disabledFocusable=!1,this.elementInternals=this.attachInternals(),this.elementInternals.role=`button`}createAndInsertFormSubmissionFallbackControl(){let e=this.formSubmissionFallbackControlSlot??document.createElement(`slot`);e.setAttribute(`name`,`internal`),this.shadowRoot?.appendChild(e),this.formSubmissionFallbackControlSlot=e;let t=this.formSubmissionFallbackControl??document.createElement(`button`);t.style.display=`none`,t.setAttribute(`type`,`submit`),t.setAttribute(`slot`,`internal`),this.formNoValidate&&t.toggleAttribute(`formnovalidate`,!0),this.elementInternals.form?.id&&t.setAttribute(`form`,this.elementInternals.form.id),this.name&&t.setAttribute(`name`,this.name),this.value&&t.setAttribute(`value`,this.value),this.formAction&&t.setAttribute(`formaction`,this.formAction??``),this.formEnctype&&t.setAttribute(`formenctype`,this.formEnctype??``),this.formMethod&&t.setAttribute(`formmethod`,this.formMethod??``),this.formTarget&&t.setAttribute(`formtarget`,this.formTarget??``),this.append(t),this.formSubmissionFallbackControl=t}formDisabledCallback(e){this.disabled=e}keypressHandler(e){if(e&&this.disabledFocusable){e.stopImmediatePropagation();return}if(e.key===`Enter`||e.key===` `){this.click();return}return!0}press(){switch(this.type){case t.reset:this.resetForm();break;case t.submit:this.submitForm()}}resetForm(){this.elementInternals.form?.reset()}setTabIndex(){if(this.disabled){this.removeAttribute(`tabindex`);return}this.tabIndex=Number(this.getAttribute(`tabindex`)??0)<0?-1:0}submitForm(){if(this.elementInternals.form&&!this.disabled&&this.type===t.submit){if(!this.name&&!this.formAction&&!this.formEnctype&&!this.formAttribute&&!this.formMethod&&!this.formNoValidate&&!this.formTarget){this.elementInternals.form.requestSubmit();return}try{this.elementInternals.setFormValue(this.value??``),this.elementInternals.form.requestSubmit(this)}catch{this.createAndInsertFormSubmissionFallbackControl(),this.elementInternals.setFormValue(null),this.elementInternals.form.requestSubmit(this.formSubmissionFallbackControl)}}}};I([m],_s.prototype,`defaultSlottedContent`,void 0),I([g({mode:`boolean`})],_s.prototype,`disabled`,void 0),I([g({attribute:`disabled-focusable`,mode:`boolean`})],_s.prototype,`disabledFocusable`,void 0),I([g({attribute:`formaction`})],_s.prototype,`formAction`,void 0),I([g({attribute:`form`})],_s.prototype,`formAttribute`,void 0),I([g({attribute:`formenctype`})],_s.prototype,`formEnctype`,void 0),I([g({attribute:`formmethod`})],_s.prototype,`formMethod`,void 0),I([g({attribute:`formnovalidate`,mode:`boolean`})],_s.prototype,`formNoValidate`,void 0),I([g({attribute:`formtarget`})],_s.prototype,`formTarget`,void 0),I([g],_s.prototype,`name`,void 0),I([g],_s.prototype,`type`,void 0),I([g],_s.prototype,`value`,void 0);var vs=class extends _s{constructor(){super(...arguments),this.iconOnly=!1}};I([g],vs.prototype,`appearance`,void 0),I([g],vs.prototype,`shape`,void 0),I([g],vs.prototype,`size`,void 0),I([g({attribute:`icon-only`,mode:`boolean`})],vs.prototype,`iconOnly`,void 0),hs(vs,ls),vs.define(ms);var ys=`${e.prefix}-checkbox`,bs=CSS.supports(`anchor-name: --a`);`anchor`in HTMLElement.prototype;var xs=CSS.supports(`selector(:state(g))`),Ss=new Map;function L(e){return Ss.get(e)??Ss.set(e,xs?`:state(${e})`:`[state--${e}]`).get(e)}function R(e,t,n){if(t&&e){if(!xs){e.shadowRoot.host.toggleAttribute(`state--${t}`,n);return}if(n??!e.states.has(t)){e.states.add(t);return}e.states.delete(t)}}var Cs=new WeakMap;function ws(e,t){if(!e||!t)return!1;if(Cs.has(e))return Cs.get(e).has(t);let n=new Set(Object.values(e));return Cs.set(e,n),n.has(t)}function Ts(e,t=``,n=``,r,i=``){R(e,`${i}${t}`,!1),(!r||ws(r,n))&&R(e,`${i}${n}`,!0)}var Es=L(`active`),Ds=L(`bad-input`),z=L(`checked`),Os=L(`custom-error`),ks=L(`description`),As=L(`disabled`),B=`:is([disabled], :disabled)`;L(`error`);var js=L(`flip-block`),Ms=L(`focus-visible`);L(`has-message`);var Ns=L(`indeterminate`),Ps=L(`multiple`),Fs=L(`open`),Is=L(`pattern-mismatch`),Ls=L(`placeholder-shown`);L(`pressed`);var Rs=L(`range-overflow`),zs=L(`range-underflow`),Bs=L(`required`),Vs=L(`selected`),Hs=L(`step-mismatch`),Us=L(`submenu`),Ws=L(`too-long`),Gs=L(`too-short`),Ks=L(`type-mismatch`),qs=L(`user-invalid`),Js=L(`valid`),Ys=L(`value-missing`),Xs=v`
  ${S(`inline-flex`)}

  :host {
    --size: 16px;
    background-color: ${E};
    border-radius: ${Wa};
    border: ${P} solid ${ti};
    box-sizing: border-box;
    cursor: pointer;
    position: relative;
    width: var(--size);
  }

  :host,
  .indeterminate-indicator,
  .checked-indicator {
    aspect-ratio: 1;
  }

  :host(:hover) {
    border-color: ${ni};
  }

  :host(:active) {
    border-color: ${ri};
  }

  :host(${z}:hover) {
    background-color: ${Zr};
    border-color: ${ui};
  }

  :host(${z}:active) {
    background-color: ${Qr};
    border-color: ${di};
  }

  :host(:focus-visible) {
    outline: none;
  }

  :host(:not([slot='input']))::after {
    content: '';
    position: absolute;
    inset: -8px;
    box-sizing: border-box;
    outline: none;
    border: ${bo} solid ${D};
    border-radius: ${O};
  }

  :host(:not([slot='input']):focus-visible)::after {
    border-color: ${hi};
  }

  .indeterminate-indicator,
  .checked-indicator {
    color: ${wr};
    inset: 0;
    margin: auto;
    position: absolute;
  }

  ::slotted([slot='checked-indicator']),
  .checked-indicator {
    fill: currentColor;
    display: inline-flex;
    flex: 1 0 auto;
    width: 12px;
  }

  :host(:not(${z})) *:is(::slotted([slot='checked-indicator']), .checked-indicator) {
    display: none;
  }

  :host(${z}),
  :host(${Ns}) {
    border-color: ${li};
  }

  :host(${z}),
  :host(${Ns}) .indeterminate-indicator {
    background-color: ${Xr};
  }

  :host(${Ns}) .indeterminate-indicator {
    border-radius: ${Wa};
    position: absolute;
    width: calc(var(--size) / 2);
    inset: 0;
  }

  :host([size='large']) {
    --size: 20px;
  }

  :host([size='large']) ::slotted([slot='checked-indicator']),
  :host([size='large']) .checked-indicator {
    width: 16px;
  }

  :host([shape='circular']),
  :host([shape='circular']) .indeterminate-indicator {
    border-radius: ${qa};
  }

  :host(${B}),
  :host(${B}${z}) {
    background-color: ${Gr};
    border-color: ${fi};
  }

  :host(${B}) {
    cursor: unset;
  }

  :host(${B}${Ns}) .indeterminate-indicator {
    background-color: ${fi};
  }

  :host(${B}${z}) .checked-indicator {
    color: ${fi};
  }

  @media (forced-colors: active) {
    :host {
      border-color: FieldText;
    }

    :host(:not([slot='input']:focus-visible))::after {
      border-color: Canvas;
    }

    :host(:not(${B}):hover),
    :host(${z}:not(${B}):hover),
    :host(:not([slot='input']):focus-visible)::after {
      border-color: Highlight;
    }

    .indeterminate-indicator,
    .checked-indicator {
      color: HighlightText;
    }

    :host(${z}),
    :host(${Ns}) .indeterminate-indicator {
      background-color: FieldText;
    }

    :host(${z}:not(${B}):hover),
    :host(${Ns}:not(${B}):hover) .indeterminate-indicator {
      background-color: Highlight;
    }

    :host(${B}) {
      border-color: GrayText;
    }

    :host(${B}${Ns}) .indeterminate-indicator {
      background-color: GrayText;
    }

    :host(${B}),
    :host(${B}${z}) .checked-indicator {
      color: GrayText;
    }
  }
`,Zs=b.partial(`
    <svg
        fill="currentColor"
        aria-hidden="true"
        class="checked-indicator"
        width="1em"
        height="1em"
        viewBox="0 0 12 12"
        xmlns="http://www.w3.org/2000/svg">
            <path d="M9.76 3.2c.3.29.32.76.04 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02L2.22 6.53a.75.75 0 0 1 1.06-1.06l1.7 1.7L8.7 3.24a.75.75 0 0 1 1.06-.04Z" fill="currentColor"></path>
    </svg>
`),Qs=b.partial(`
    <span class="indeterminate-indicator"></span>
`);function $s(e={}){return b`
    <template
      @click="${(e,t)=>e.clickHandler(t.event)}"
      @input="${(e,t)=>e.inputHandler(t.event)}"
      @keydown="${(e,t)=>e.keydownHandler(t.event)}"
      @keyup="${(e,t)=>e.keyupHandler(t.event)}"
    >
      <slot name="checked-indicator">${cs(e.checkedIndicator)}</slot>
      <slot name="indeterminate-indicator">${cs(e.indeterminateIndicator)}</slot>
    </template>
  `}var ec=$s({checkedIndicator:Zs,indeterminateIndicator:Qs}),tc={name:ys,registry:e.registry,styles:Xs,template:ec},nc=class extends _{constructor(){super(...arguments),this.initialValue=`on`,this._keydownPressed=!1,this.dirtyChecked=!1,this.elementInternals=this.attachInternals(),this._validationFallbackMessage=``,this._value=this.initialValue}get checked(){return p.track(this,`checked`),!!this._checked}set checked(e){this._checked=e,this.setFormValue(e?this.value:null),this.setValidity(),this.setAriaChecked(),R(this.elementInternals,`checked`,e),p.notify(this,`checked`)}disabledChanged(e,t){this.disabled?this.removeAttribute(`tabindex`):this.tabIndex=Number(this.getAttribute(`tabindex`)??0)<0?-1:0,this.elementInternals.ariaDisabled=this.disabled?`true`:`false`,R(this.elementInternals,`disabled`,this.disabled)}disabledAttributeChanged(e,t){this.disabled=!!t}initialCheckedChanged(e,t){this.dirtyChecked||(this.checked=!!t)}initialValueChanged(e,t){this._value=t}requiredChanged(e,t){this.elementInternals&&(this.setValidity(),this.elementInternals.ariaRequired=this.required?`true`:`false`)}get form(){return this.elementInternals.form}static{this.formAssociated=!0}get labels(){return Object.freeze(Array.from(this.elementInternals.labels))}get validationMessage(){if(this.elementInternals?.validationMessage)return this.elementInternals.validationMessage;if(!this._validationFallbackMessage){let e=document.createElement(`input`);e.type=`checkbox`,e.required=!0,e.checked=!1,this._validationFallbackMessage=e.validationMessage}return this._validationFallbackMessage}get validity(){return this.elementInternals.validity}get value(){return p.track(this,`value`),this._value}set value(e){this._value=e,this.elementInternals&&(this.setFormValue(e),this.setValidity()),p.notify(this,`value`)}get willValidate(){return this.elementInternals.willValidate}checkValidity(){return this.elementInternals.checkValidity()}clickHandler(e){if(this.disabled)return;this.dirtyChecked=!0;let t=this.checked;return this.toggleChecked(),t!==this.checked&&(this.$emit(`change`),this.$emit(`input`)),!0}connectedCallback(){super.connectedCallback(),this.disabled=!!this.disabledAttribute,this.setAriaChecked(),this.setValidity(),gs(this)}inputHandler(e){return this.setFormValue(this.value),this.setValidity(),!0}keydownHandler(e){if(e.key!==` `)return!0;this._keydownPressed=!0}keyupHandler(e){if(!this._keydownPressed||e.key!==` `)return!0;this._keydownPressed=!1,this.click()}formResetCallback(){this.checked=this.initialChecked??!1,this.dirtyChecked=!1,this.setValidity()}reportValidity(){return this.elementInternals.reportValidity()}setAriaChecked(e=this.checked){this.elementInternals&&(this.elementInternals.ariaChecked=e?`true`:`false`)}setFormValue(e,t){this.elementInternals?.setFormValue(e,e??t)}setCustomValidity(e){this.elementInternals.setValidity({customError:!0},e),this.setValidity()}setValidity(e,t,n){if(this.elementInternals){if(this.disabled||!this.required){this.elementInternals.setValidity({});return}this.elementInternals.setValidity({valueMissing:!!this.required&&!this.checked,...e},t??this.validationMessage,n)}}toggleChecked(e=!this.checked){this.checked=e}};I([m],nc.prototype,`disabled`,void 0),I([g({attribute:`disabled`,mode:`boolean`})],nc.prototype,`disabledAttribute`,void 0),I([g({attribute:`form`})],nc.prototype,`formAttribute`,void 0),I([g({attribute:`checked`,mode:`boolean`})],nc.prototype,`initialChecked`,void 0),I([g({attribute:`value`,mode:`fromView`})],nc.prototype,`initialValue`,void 0),I([g],nc.prototype,`name`,void 0),I([g({mode:`boolean`})],nc.prototype,`required`,void 0);var rc=class extends nc{indeterminateChanged(e,t){this.setAriaChecked(),R(this.elementInternals,`indeterminate`,t)}constructor(){super(),this.elementInternals.role=`checkbox`}setAriaChecked(e=this.checked){if(this.indeterminate){this.elementInternals.ariaChecked=`mixed`;return}super.setAriaChecked(e)}toggleChecked(e=!this.checked){this.indeterminate=!1,super.toggleChecked(e)}};I([m],rc.prototype,`indeterminate`,void 0),I([g],rc.prototype,`shape`,void 0),I([g],rc.prototype,`size`,void 0),rc.define(tc);var ic=`${e.prefix}-switch`,ac=v`
  ${S(`inline-flex`)}

  :host {
    box-sizing: border-box;
    align-items: center;
    flex-direction: row;
    outline: none;
    user-select: none;
    contain: content;
    padding: 0 ${F};
    width: 40px;
    height: 20px;
    background-color: ${Hr};
    border: 1px solid ${ti};
    border-radius: ${qa};
  }

  :host(:enabled) {
    cursor: pointer;
  }

  :host(:hover) {
    background: none;
    border-color: ${ni};
  }
  :host(:active) {
    border-color: ${ri};
  }
  :host(${B}),
  :host([readonly]) {
    border: 1px solid ${fi};
    background-color: none;
    pointer: default;
  }
  :host(${z}) {
    background: ${Xr};
    border-color: ${Xr};
  }
  :host(${z}:hover) {
    background: ${Zr};
    border-color: ${Zr};
  }
  :host(${z}:active) {
    background: ${Qr};
    border-color: ${Qr};
  }
  :host(${z}${B}) {
    background: ${Gr};
    border-color: ${fi};
  }
  .checked-indicator {
    height: 14px;
    width: 14px;
    border-radius: 50%;
    margin-inline-start: 0;
    background-color: ${w};
    transition-duration: ${Vo};
    transition-timing-function: ${$o};
    transition-property: margin-inline-start;
  }
  :host(${z}) .checked-indicator {
    background-color: ${wr};
    margin-inline-start: calc(100% - 14px);
  }
  :host(${z}:hover) .checked-indicator {
    background: ${Tr};
  }
  :host(${z}:active) .checked-indicator {
    background: ${Er};
  }
  :host(:hover) .checked-indicator {
    background-color: ${fr};
  }
  :host(:active) .checked-indicator {
    background-color: ${pr};
  }
  :host(${B}) .checked-indicator,
  :host([readonly]) .checked-indicator {
    background: ${T};
  }
  :host(${z}${B}) .checked-indicator {
    background: ${T};
  }

  :host(:focus-visible) {
    outline: none;
  }

  :host(:not([slot='input']):focus-visible) {
    border-color: ${D};
    outline: ${bo} solid ${D};
    outline-offset: 1px;
    box-shadow: ${ho}, 0 0 0 2px ${hi};
  }

  @media (forced-colors: active) {
    :host {
      border-color: InactiveBorder;
    }
    :host(${z}),
    :host(${z}:active),
    :host(${z}:hover) {
      background: Highlight;
      border-color: Highlight;
    }
    .checked-indicator,
    :host(:hover) .checked-indicator,
    :host(:active) .checked-indicator {
      background-color: ActiveCaption;
    }
    :host(${z}) .checked-indicator,
    :host(${z}:hover) .checked-indicator,
    :host(${z}:active) .checked-indicator {
      background-color: ButtonFace;
    }
    :host(${B}) .checked-indicator,
    :host(${z}${B}) .checked-indicator {
      background-color: GrayText;
    }
  }
`;function oc(e={}){return b`
    <template
      @click="${(e,t)=>e.clickHandler(t.event)}"
      @input="${(e,t)=>e.inputHandler(t.event)}"
      @keydown="${(e,t)=>e.keydownHandler(t.event)}"
      @keyup="${(e,t)=>e.keyupHandler(t.event)}"
    >
      <slot name="switch">${cs(e.switch)}</slot>
    </template>
  `}var sc=oc({switch:`<span class="checked-indicator" part="checked-indicator"></span>`}),cc={name:ic,registry:e.registry,styles:ac,template:sc};(class extends nc{constructor(){super(),this.elementInternals.role=`switch`}}).define(cc);var lc={filled:`filled`,ghost:`ghost`,outline:`outline`,tint:`tint`},uc={brand:`brand`,danger:`danger`,important:`important`,informative:`informative`,severe:`severe`,subtle:`subtle`,success:`success`,warning:`warning`},dc=`${e.prefix}-badge`,fc=v.partial`
  ${S(`inline-flex`)} :host {
    position: relative;
    box-sizing: border-box;
    align-items: center;
    justify-content: center;
    font-family: ${k};
    font-weight: ${M};
    font-size: ${Ya};
    line-height: ${ao};
    min-width: 20px;
    height: 20px;
    padding-inline: calc(${Co} + ${F});
    border-radius: ${qa};
    border-color: ${D};
    background-color: ${qr};
    color: ${Cr};
    contain: content;
  }

  ::slotted(svg) {
    font-size: 12px;
  }

  :host(:not([appearance='ghost']))::after {
    position: absolute;
    content: '';
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    border-style: solid;
    border-width: ${P};
    border-color: inherit;
    border-radius: inherit;
  }
`,pc=v.partial`
  :host([size='tiny']) {
    width: 6px;
    height: 6px;
    font-size: 4px;
    line-height: 4px;
    padding-inline: 0;
    min-width: unset;
  }
  :host([size='tiny']) ::slotted(svg) {
    font-size: 6px;
  }
  :host([size='extra-small']) {
    width: 10px;
    height: 10px;
    font-size: 6px;
    line-height: 6px;
    padding-inline: 0;
    min-width: unset;
  }
  :host([size='extra-small']) ::slotted(svg) {
    font-size: 10px;
  }
  :host([size='small']) {
    min-width: 16px;
    height: 16px;
    font-size: ${Ja};
    line-height: ${io};
    padding-inline: calc(${F} + ${F});
  }
  :host([size='small']) ::slotted(svg) {
    font-size: 12px;
  }
  :host([size='large']) {
    min-width: 24px;
    height: 24px;
    font-size: ${Ya};
    line-height: ${ao};
    padding-inline: calc(${Co} + ${F});
  }
  :host([size='large']) ::slotted(svg) {
    font-size: 16px;
  }
  :host([size='extra-large']) {
    min-width: 32px;
    height: 32px;
    font-size: ${Ya};
    line-height: ${ao};
    padding-inline: calc(${wo} + ${F});
  }
  :host([size='extra-large']) ::slotted(svg) {
    font-size: 20px;
  }
`,mc=v.partial`
  :host([color='danger']) {
    background-color: ${vi};
    color: ${Cr};
  }

  :host([color='important']) {
    background-color: ${C};
    color: ${E};
  }

  :host([color='informative']) {
    background-color: ${Ir};
    color: ${w};
  }

  :host([color='severe']) {
    background-color: ${ji};
    color: ${Cr};
  }

  :host([color='subtle']) {
    background-color: ${E};
    color: ${C};
  }

  :host([color='success']) {
    background-color: ${Ti};
    color: ${Cr};
  }

  :host([color='warning']) {
    background-color: ${Ii};
    color: ${Ar};
  }
`,hc=v.partial`
  :host([appearance='ghost']) {
    color: ${Or};
    background-color: initial;
  }

  :host([appearance='ghost'][color='danger']) {
    color: ${Ci};
  }

  :host([appearance='ghost'][color='important']) {
    color: ${C};
  }

  :host([appearance='ghost'][color='informative']) {
    color: ${w};
  }

  :host([appearance='ghost'][color='severe']) {
    color: ${Pi};
  }

  :host([appearance='ghost'][color='subtle']) {
    color: ${wr};
  }

  :host([appearance='ghost'][color='success']) {
    color: ${ki};
  }

  :host([appearance='ghost'][color='warning']) {
    color: ${Ri};
  }
`,gc=v.partial`
  :host([appearance='outline']) {
    border-color: currentColor;
    color: ${Or};
    background-color: initial;
  }

  :host([appearance='outline'][color='danger']) {
    color: ${Ci};
  }

  :host([appearance='outline'][color='important']) {
    color: ${w};
    border-color: ${ti};
  }

  :host([appearance='outline'][color='informative']) {
    color: ${w};
    border-color: ${si};
  }

  :host([appearance='outline'][color='severe']) {
    color: ${Pi};
  }

  :host([appearance='outline'][color='subtle']) {
    color: ${Dr};
  }

  :host([appearance='outline'][color='success']) {
    color: ${Oi};
  }

  :host([appearance='outline'][color='warning']) {
    color: ${Ri};
  }
`,_c=v`
  :host([shape='square']) {
    border-radius: ${Ua};
  }

  :host([shape='rounded']) {
    border-radius: ${O};
  }

  :host([shape='rounded']:is([size='tiny'], [size='extra-small'], [size='small'])) {
    border-radius: ${Wa};
  }

  ${v.partial`
  :host([appearance='tint']) {
    background-color: ${ei};
    color: ${kr};
    border-color: ${ci};
  }

  :host([appearance='tint'][color='danger']) {
    background-color: ${gi};
    color: ${xi};
    border-color: ${yi};
  }

  :host([appearance='tint'][color='important']) {
    background-color: ${w};
    color: ${E};
    border-color: ${D};
  }

  :host([appearance='tint'][color='informative']) {
    background-color: ${Fr};
    color: ${w};
    border-color: ${si};
  }

  :host([appearance='tint'][color='severe']) {
    background-color: ${Ai};
    color: ${Ni};
    border-color: ${Mi};
  }

  :host([appearance='tint'][color='subtle']) {
    background-color: ${E};
    color: ${w};
    border-color: ${si};
  }

  :host([appearance='tint'][color='success']) {
    background-color: ${wi};
    color: ${Di};
    border-color: ${Ei};
  }

  :host([appearance='tint'][color='warning']) {
    background-color: ${Fi};
    color: ${Ri};
    border-color: ${Li};
  }
`}
  ${gc}
  ${hc}
  ${mc}
  ${pc}
  ${fc}

  @media (forced-colors: active) {
    :host,
    :host([appearance='outline']),
    :host([appearance='tint']) {
      border-color: CanvasText;
    }
  }
`;function vc(e={}){return b`
    ${ds(e)}
    <slot>${cs(e.defaultContent)}</slot>
    ${us(e)}
  `}var yc=vc(),bc={name:dc,registry:e.registry,styles:_c,template:yc},xc=class extends _{constructor(){super(...arguments),this.appearance=lc.filled,this.color=uc.brand}};I([g],xc.prototype,`appearance`,void 0),I([g],xc.prototype,`color`,void 0),I([g],xc.prototype,`shape`,void 0),I([g],xc.prototype,`size`,void 0),hs(xc,ls),xc.define(bc);var Sc={darkRed:`dark-red`,cranberry:`cranberry`,red:`red`,pumpkin:`pumpkin`,peach:`peach`,marigold:`marigold`,gold:`gold`,brass:`brass`,brown:`brown`,forest:`forest`,seafoam:`seafoam`,darkGreen:`dark-green`,lightTeal:`light-teal`,teal:`teal`,steel:`steel`,blue:`blue`,royalBlue:`royal-blue`,cornflower:`cornflower`,navy:`navy`,lavender:`lavender`,purple:`purple`,grape:`grape`,lilac:`lilac`,pink:`pink`,magenta:`magenta`,plum:`plum`,beige:`beige`,mink:`mink`,platinum:`platinum`,anchor:`anchor`},Cc={neutral:`neutral`,brand:`brand`,colorful:`colorful`,...Sc},wc=`${e.prefix}-avatar`,Tc={fastOutSlowInMax:Yo,fastOutSlowInMid:Xo,fastOutSlowInMin:Zo,slowOutFastInMax:Ko,slowOutFastInMid:qo,slowOutFastInMin:Jo,fastEase:Qo,normalEase:$o,nullEasing:es},Ec=v`
  ${S(`inline-grid`)} :host {
    position: relative;
    place-items: center;
    place-content: center;
    grid-template: 1fr / 1fr;
    flex-shrink: 0;
    width: 32px;
    height: 32px;
    font-family: ${k};
    font-weight: ${M};
    font-size: ${A};
    border-radius: ${qa};
    color: ${w};
    background-color: ${Lr};
    contain: layout style;
  }

  .monogram,
  .default-icon {
    grid-area: 1 / 1 / -1 / -1;
  }

  .monogram:empty {
    display: none;
  }

  .default-slot:is(.has-slotted, :has-slotted) ~ .default-icon,
  .default-slot:is(.has-slotted, :has-slotted) ~ .monogram,
  :host(:is([name]):not([name=''])) .default-icon,
  :host(:is([initials]):not([initials=''])) .default-icon {
    display: none;
  }

  .default-icon,
  ::slotted(svg) {
    width: 20px;
    height: 20px;
    font-size: 20px;
  }

  ::slotted(img) {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    border-radius: ${qa};
  }

  ::slotted([slot='badge']) {
    position: absolute;
    bottom: 0;
    right: 0;
    box-shadow: 0 0 0 ${P} ${E};
  }

  :host([size='64']) ::slotted([slot='badge']),
  :host([size='72']) ::slotted([slot='badge']),
  :host([size='96']) ::slotted([slot='badge']),
  :host([size='120']) ::slotted([slot='badge']),
  :host([size='128']) ::slotted([slot='badge']) {
    box-shadow: 0 0 0 ${bo} ${E};
  }

  :host([size='16']),
  :host([size='20']),
  :host([size='24']) {
    font-size: ${Ja};
    font-weight: ${j};
  }

  :host([size='16']) {
    width: 16px;
    height: 16px;
  }

  :host([size='20']) {
    width: 20px;
    height: 20px;
  }

  :host([size='24']) {
    width: 24px;
    height: 24px;
  }

  :host([size='16']) .default-icon,
  :host([size='16']) ::slotted(svg) {
    width: 12px;
    height: 12px;
    font-size: 12px;
  }

  :host([size='20']) .default-icon,
  :host([size='24']) .default-icon,
  :host([size='20']) ::slotted(svg),
  :host([size='24']) ::slotted(svg) {
    width: 16px;
    height: 16px;
    font-size: 16px;
  }

  :host([size='28']) {
    width: 28px;
    height: 28px;
    font-size: ${Ya};
  }

  :host([size='36']) {
    width: 36px;
    height: 36px;
  }

  :host([size='40']) {
    width: 40px;
    height: 40px;
  }

  :host([size='48']),
  :host([size='56']) {
    font-size: ${Xa};
  }

  :host([size='48']) {
    width: 48px;
    height: 48px;
  }

  :host([size='48']) .default-icon,
  :host([size='48']) ::slotted(svg) {
    width: 24px;
    height: 24px;
    font-size: 24px;
  }

  :host([size='56']) {
    width: 56px;
    height: 56px;
  }

  :host([size='56']) .default-icon,
  :host([size='56']) ::slotted(svg) {
    width: 28px;
    height: 28px;
    font-size: 28px;
  }

  :host([size='64']),
  :host([size='72']),
  :host([size='96']) {
    font-size: ${Za};
  }

  :host([size='64']) .default-icon,
  :host([size='72']) .default-icon,
  :host([size='64']) ::slotted(svg),
  :host([size='72']) ::slotted(svg) {
    width: 32px;
    height: 32px;
    font-size: 32px;
  }

  :host([size='64']) {
    width: 64px;
    height: 64px;
  }

  :host([size='72']) {
    width: 72px;
    height: 72px;
  }

  :host([size='96']) {
    width: 96px;
    height: 96px;
  }

  :host([size='96']) .default-icon,
  :host([size='120']) .default-icon,
  :host([size='128']) .default-icon,
  :host([size='96']) ::slotted(svg),
  :host([size='120']) ::slotted(svg),
  :host([size='128']) ::slotted(svg) {
    width: 48px;
    height: 48px;
    font-size: 48px;
  }

  :host([size='120']),
  :host([size='128']) {
    font-size: ${Qa};
  }

  :host([size='120']) {
    width: 120px;
    height: 120px;
  }

  :host([size='128']) {
    width: 128px;
    height: 128px;
  }

  :host([shape='square']) {
    border-radius: ${O};
  }

  :host([shape='square'][size='20']),
  :host([shape='square'][size='24']) {
    border-radius: ${Wa};
  }

  :host([shape='square'][size='56']),
  :host([shape='square'][size='64']),
  :host([shape='square'][size='72']) {
    border-radius: ${Ga};
  }
  :host([shape='square'][size='96']),
  :host([shape='square'][size='120']),
  :host([shape='square'][size='128']) {
    border-radius: ${Ka};
  }

  :host([data-color='brand']) {
    color: ${Dr};
    background-color: ${$r};
  }

  :host([data-color='dark-red']) {
    color: ${ia};
    background-color: ${ra};
  }

  :host([data-color='cranberry']) {
    color: ${ea};
    background-color: ${$i};
  }

  :host([data-color='red']) {
    color: ${Si};
    background-color: ${_i};
  }

  :host([data-color='pumpkin']) {
    color: ${Ma};
    background-color: ${ja};
  }

  :host([data-color='peach']) {
    color: ${wa};
    background-color: ${Ca};
  }

  :host([data-color='marigold']) {
    color: ${Bi};
    background-color: ${zi};
  }

  :host([data-color='gold']) {
    color: ${ca};
    background-color: ${sa};
  }

  :host([data-color='brass']) {
    color: ${Ji};
    background-color: ${qi};
  }

  :host([data-color='brown']) {
    color: ${Xi};
    background-color: ${Yi};
  }

  :host([data-color='forest']) {
    color: ${oa};
    background-color: ${aa};
  }

  :host([data-color='seafoam']) {
    color: ${Ra};
    background-color: ${La};
  }

  :host([data-color='dark-green']) {
    color: ${na};
    background-color: ${ta};
  }

  :host([data-color='light-teal']) {
    color: ${ma};
    background-color: ${pa};
  }

  :host([data-color='teal']) {
    color: ${Ha};
    background-color: ${Va};
  }

  :host([data-color='steel']) {
    color: ${Ba};
    background-color: ${za};
  }

  :host([data-color='blue']) {
    color: ${Ki};
    background-color: ${Gi};
  }

  :host([data-color='royal-blue']) {
    color: ${Ia};
    background-color: ${Fa};
  }

  :host([data-color='cornflower']) {
    color: ${Qi};
    background-color: ${Zi};
  }

  :host([data-color='navy']) {
    color: ${Sa};
    background-color: ${xa};
  }

  :host([data-color='lavender']) {
    color: ${fa};
    background-color: ${da};
  }

  :host([data-color='purple']) {
    color: ${Pa};
    background-color: ${Na};
  }

  :host([data-color='grape']) {
    color: ${ua};
    background-color: ${la};
  }

  :host([data-color='lilac']) {
    color: ${ga};
    background-color: ${ha};
  }

  :host([data-color='pink']) {
    color: ${Ea};
    background-color: ${Ta};
  }

  :host([data-color='magenta']) {
    color: ${va};
    background-color: ${_a};
  }

  :host([data-color='plum']) {
    color: ${Aa};
    background-color: ${ka};
  }

  :host([data-color='beige']) {
    color: ${Wi};
    background-color: ${Ui};
  }

  :host([data-color='mink']) {
    color: ${ba};
    background-color: ${ya};
  }

  :host([data-color='platinum']) {
    color: ${Oa};
    background-color: ${Da};
  }

  :host([data-color='anchor']) {
    color: ${Hi};
    background-color: ${Vi};
  }

  :host([active]) {
    /* Work-around for text pixel snapping at the end of the animation */
    transform: perspective(1px);
    transition-property: transform, opacity;
    transition-duration: ${Go}, ${Bo};
    transition-delay: ${Tc.fastEase}, ${Tc.nullEasing};
  }

  :host([active])::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    border-radius: inherit;
    transition-property: margin, opacity;
    transition-duration: ${Go}, ${Wo};
    transition-delay: ${Tc.fastEase}, ${Tc.nullEasing};
  }
  :host([active])::before {
    box-shadow: ${go};
    border-style: solid;
    border-color: ${$r};
  }

  :host([active][appearance='shadow'])::before {
    border-style: none;
    border-color: none;
  }

  :host([active]:not([appearance='shadow']))::before {
    margin: calc(-2 * ${bo});
    border-width: ${bo};
  }

  :host([size='56'][active]:not([appearance='shadow']))::before,
  :host([size='64'][active]:not([appearance='shadow']))::before {
    margin: calc(-2 * ${xo});
    border-width: ${xo};
  }

  :host([size='72'][active]:not([appearance='shadow']))::before,
  :host([size='96'][active]:not([appearance='shadow']))::before,
  :host([size='120'][active]:not([appearance='shadow']))::before,
  :host([size='128'][active]:not([appearance='shadow']))::before {
    margin: calc(-2 * ${So});
    border-width: ${So};
  }

  :host([size='20'][active][appearance])::before,
  :host([size='24'][active][appearance])::before,
  :host([size='28'][active][appearance])::before {
    box-shadow: ${ho};
  }

  :host([size='56'][active][appearance])::before,
  :host([size='64'][active][appearance])::before {
    box-shadow: ${_o};
  }

  :host([size='72'][active][appearance])::before,
  :host([size='96'][active][appearance])::before,
  :host([size='120'][active][appearance])::before,
  :host([size='128'][active][appearance])::before {
    box-shadow: ${vo};
  }

  :host([active][appearance='ring'])::before {
    box-shadow: none;
  }

  :host([active='inactive']) {
    opacity: 0.8;
    transform: scale(0.875);
    transition-property: transform, opacity;
    transition-duration: ${Go}, ${Bo};
    transition-delay: ${Tc.fastOutSlowInMin}, ${Tc.nullEasing};
  }

  :host([active='inactive'])::before {
    margin: 0;
    opacity: 0;
    transition-property: margin, opacity;
    transition-duration: ${Go}, ${Wo};
    transition-delay: ${Tc.fastOutSlowInMin}, ${Tc.nullEasing};
  }

  @media screen and (prefers-reduced-motion: reduce) {
    :host([active]) {
      transition-duration: 0.01ms;
    }

    :host([active])::before {
      transition-duration: 0.01ms;
      transition-delay: 0.01ms;
    }
  }
`,Dc=b`<svg
  width="1em"
  height="1em"
  viewBox="0 0 20 20"
  class="default-icon"
  fill="currentcolor"
  aria-hidden="true"
>
  <path
    d="M10 2a4 4 0 100 8 4 4 0 000-8zM7 6a3 3 0 116 0 3 3 0 01-6 0zm-2 5a2 2 0 00-2 2c0 1.7.83 2.97 2.13 3.8A9.14 9.14 0 0010 18c1.85 0 3.58-.39 4.87-1.2A4.35 4.35 0 0017 13a2 2 0 00-2-2H5zm-1 2a1 1 0 011-1h10a1 1 0 011 1c0 1.3-.62 2.28-1.67 2.95A8.16 8.16 0 0110 17a8.16 8.16 0 01-4.33-1.05A3.36 3.36 0 014 13z"
  ></path>
</svg>`;function Oc(){return b`
    <slot class="default-slot" ${x(`slottedDefaults`)} ${y(`defaultSlot`)}></slot>
    <span class="monogram" ${y(`monogram`)}>${e=>e.initials}</span>
    ${Dc}
    <slot name="badge"></slot>
  `}var kc=Oc(),Ac={name:wc,registry:e.registry,styles:Ec,template:kc},jc=/[\(\[\{][^\)\]\}]*[\)\]\}]/g,Mc=/[\0-\u001F\!-/:-@\[-`\{-\u00BF\u0250-\u036F\uD800-\uFFFF]/g,Nc=/^\d+[\d\s]*(:?ext|x|)\s*\d+$/i,Pc=/\s+/g,Fc=/[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\u1100-\u11FF\u3130-\u318F\uA960-\uA97F\uAC00-\uD7AF\uD7B0-\uD7FF\u3040-\u309F\u30A0-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]|[\uD840-\uD869][\uDC00-\uDED6]/;function Ic(e,t,n){let r=``,i=e.split(` `);return i.length!==0&&(r+=i[0].charAt(0).toUpperCase()),n||(i.length===2?r+=i[1].charAt(0).toUpperCase():i.length===3&&(r+=i[2].charAt(0).toUpperCase())),t&&r.length>1?r.charAt(1)+r.charAt(0):r}function Lc(e){return e=e.replace(jc,``),e=e.replace(Mc,``),e=e.replace(Pc,` `),e=e.trim(),e}function Rc(e,t,n){return!e||(e=Lc(e),Fc.test(e)||!n?.allowPhoneInitials&&Nc.test(e))?``:Ic(e,t,n?.firstInitialOnly)}var zc=class extends _{defaultSlotChanged(){if(!CSS.supports(`selector(:has-slotted)`)){let e=this.defaultSlot.assignedElements();this.defaultSlot.classList.toggle(`has-slotted`,e.length>0)}f.enqueue(()=>{this.cleanupSlottedContent()})}monogramChanged(){this.updateMonogram()}slottedDefaultsChanged(){this.defaultSlot&&this.cleanupSlottedContent()}nameChanged(){this.updateMonogram()}initialsChanged(){this.updateMonogram()}constructor(){super(),this.slottedDefaults=[],this.elementInternals=this.attachInternals(),this.elementInternals.role=`img`}generateInitials(){return this.initials||Rc(this.name,window.getComputedStyle(this).direction===`rtl`)}updateMonogram(){this.monogram&&(this.monogram.textContent=this.generateInitials()??``)}cleanupSlottedContent(){this.normalize(),CSS.supports(`selector(:has-slotted)`)||this.defaultSlot.classList.toggle(`has-slotted`,!!this.slottedDefaults.length),this.innerText.trim()||this.slottedDefaults.forEach(e=>{e.nodeType===Node.TEXT_NODE&&e.remove()})}};I([m],zc.prototype,`defaultSlot`,void 0),I([m],zc.prototype,`monogram`,void 0),I([m],zc.prototype,`slottedDefaults`,void 0),I([g],zc.prototype,`name`,void 0),I([g],zc.prototype,`initials`,void 0);var Bc=class e extends zc{handleChange(e,t){switch(t){case`color`:case`colorId`:this.generateColor()}}generateInitials(){if(!this.name&&!this.initials)return;let e=this.size??32;return this.initials||Rc(this.name,window.getComputedStyle(this).direction===`rtl`,{firstInitialOnly:e<=16})}generateColor(){let t=this.color===Cc.colorful;this.currentColor,this.currentColor=t&&this.colorId?this.colorId:t?e.colors[Vc(this.name??``)%e.colors.length]:this.color??Cc.neutral,this.setAttribute(`data-color`,this.currentColor)}static{this.colors=Object.values(Sc)}connectedCallback(){super.connectedCallback(),p.getNotifier(this).subscribe(this),this.generateColor()}disconnectedCallback(){super.disconnectedCallback(),p.getNotifier(this).unsubscribe(this)}};I([g],Bc.prototype,`active`,void 0),I([g],Bc.prototype,`shape`,void 0),I([g],Bc.prototype,`appearance`,void 0),I([g({converter:je})],Bc.prototype,`size`,void 0),I([g],Bc.prototype,`color`,void 0),I([g({attribute:`color-id`})],Bc.prototype,`colorId`,void 0);var Vc=e=>{let t=0;for(let n=e.length-1;n>=0;n--){let r=e.charCodeAt(n),i=n%8;t^=(r<<i)+(r>>8-i)}return t};Bc.define(Ac);var Hc={above:`above`,after:`after`,before:`before`},Uc={badInput:`bad-input`,customError:`custom-error`,patternMismatch:`pattern-mismatch`,rangeOverflow:`range-overflow`,rangeUnderflow:`range-underflow`,stepMismatch:`step-mismatch`,tooLong:`too-long`,tooShort:`too-short`,typeMismatch:`type-mismatch`,valueMissing:`value-missing`,valid:`valid`},Wc=`${e.prefix}-field`,Gc=v`
  ${S(`inline-grid`)}

  :host {
    color: ${C};
    align-items: center;
    gap: 0 ${Do};
    justify-items: start;
  }

  :has([slot='message']) {
    color: ${C};
    row-gap: ${Po};
  }

  :not(::slotted([slot='label'])) {
    gap: 0;
  }

  :host([label-position='before']) {
    grid-template-areas: 'label input' 'label message';
  }

  :host([label-position='after']) {
    gap: 0;
    grid-template-areas: 'input label' 'message message';
    grid-template-columns: auto 1fr;
  }

  :host([label-position='after']) ::slotted([slot='input']) {
    margin-inline-end: ${Do};
  }

  :host([label-position='above']) {
    grid-template-areas: 'label' 'input' 'message';
    row-gap: ${jo};
  }

  :host([label-position='below']) {
    grid-template-areas: 'input' 'label' 'message';
    justify-items: center;
  }

  :host([label-position='below']) ::slotted([slot='label']) {
    margin-block-start: ${Io};
  }

  :host(${Bs}) ::slotted([slot='label'])::after {
    content: '*' / '';
    color: ${xi};
    margin-inline-start: ${Co};
  }

  ::slotted([slot='input']) {
    grid-area: input;
  }

  ::slotted([slot='message']) {
    color: ${w};
    font-family: ${k};
    font-size: ${Ya};
    font-weight: ${j};
    grid-area: message;
    line-height: ${ao};
    margin-block-start: ${jo};
  }

  :host(${Ms}:focus-within) {
    border-radius: ${O};
    outline: ${bo} solid ${hi};
  }

  ::slotted(label),
  ::slotted([slot='label']) {
    cursor: inherit;
    display: inline-flex;
    font-family: ${k};
    font-size: ${A};
    font-weight: ${j};
    grid-area: label;
    line-height: ${N};
    justify-self: stretch;
    user-select: none;
  }

  :host([size='small']) ::slotted(label) {
    font-size: ${Ya};
    line-height: ${ao};
  }

  :host([size='large']) ::slotted(label) {
    font-size: ${Xa};
    line-height: ${oo};
  }

  :host([size='large']) ::slotted(label),
  :host([weight='semibold']) ::slotted(label) {
    font-weight: ${M};
  }

  :host(${As}) {
    cursor: default;
  }

  ::slotted([flag]) {
    display: none;
  }

  :host(${Ds}) ::slotted([flag='${Uc.badInput}']),
  :host(${Os}) ::slotted([flag='${Uc.customError}']),
  :host(${Is}) ::slotted([flag='${Uc.patternMismatch}']),
  :host(${Rs}) ::slotted([flag='${Uc.rangeOverflow}']),
  :host(${zs}) ::slotted([flag='${Uc.rangeUnderflow}']),
  :host(${Hs}) ::slotted([flag='${Uc.stepMismatch}']),
  :host(${Ws}) ::slotted([flag='${Uc.tooLong}']),
  :host(${Gs}) ::slotted([flag='${Uc.tooShort}']),
  :host(${Ks}) ::slotted([flag='${Uc.typeMismatch}']),
  :host(${Ys}) ::slotted([flag='${Uc.valueMissing}']),
  :host(${Js}) ::slotted([flag='${Uc.valid}']) {
    display: block;
  }
`,Kc=b`
  <template
    @click="${(e,t)=>e.clickHandler(t.event)}"
    @change="${(e,t)=>e.changeHandler(t.event)}"
    @focusin="${(e,t)=>e.focusinHandler(t.event)}"
    @focusout="${(e,t)=>e.focusoutHandler(t.event)}"
  >
    <slot name="label" part="label" ${x(`labelSlot`)}></slot>
    <slot name="input" part="input" ${x(`slottedInputs`)}></slot>
    <slot name="message" part="message" ${x({property:`messageSlot`,filter:Gt(`[flag]`)})}></slot>
  </template>
`,qc={name:Wc,registry:e.registry,shadowOptions:{delegatesFocus:!0},styles:Gc,template:Kc},Jc=0;function Yc(e=`id-`){let t=`${e}${Jc++}`;return document.getElementById(t)?Yc(e):t}var Xc=class extends _{get slottedInputObserver(){return this._slottedInputObserver??=new MutationObserver(()=>{this.setStates()}),this._slottedInputObserver}labelSlotChanged(e,t){t&&this.input&&(this.setLabelProperties(),this.setStates())}messageSlotChanged(e,t){R(this.elementInternals,`has-message`,!!t.length)}slottedInputsChanged(e,t){let n=t?.filter(e=>e.nodeType===Node.ELEMENT_NODE)??[];n?.length&&(this.input=n?.[0])}inputChanged(e,t){t&&(this.setStates(),this.setLabelProperties(),this.slottedInputObserver.observe(t,{attributes:!0,attributeFilter:[`disabled`,`required`,`readonly`],subtree:!0}))}changeHandler(e){return this.setStates(),this.setValidationStates(),!0}clickHandler(e){return this===e.target&&this.input.click(),!0}constructor(){super(),this.labelSlot=[],this.elementInternals=this.attachInternals(),this.elementInternals.role=`presentation`}connectedCallback(){super.connectedCallback(),this.addEventListener(`invalid`,this.invalidHandler,{capture:!0})}disconnectedCallback(){this.slottedInputObserver.disconnect(),this.removeEventListener(`invalid`,this.invalidHandler,{capture:!0}),super.disconnectedCallback()}focusinHandler(e){return this.matches(`:focus-within:has(> :focus-visible)`)&&R(this.elementInternals,`focus-visible`,!0),!0}focusoutHandler(e){return R(this.elementInternals,`focus-visible`,!1),!0}invalidHandler(e){this.messageSlot.length&&e.preventDefault(),this.setValidationStates()}setLabelProperties(){this.$fastController.isConnected&&(this.input.id=this.input.id||Yc(`input`),this.labelSlot?.forEach(e=>{e instanceof HTMLLabelElement&&(e.htmlFor=e.htmlFor||this.input.id,e.id=e.id||`${this.input.id}--label`,this.input.setAttribute(`aria-labelledby`,e.id))}))}setStates(){this.elementInternals&&this.input&&(R(this.elementInternals,`disabled`,!!this.input.disabled),R(this.elementInternals,`readonly`,!!this.input.readOnly),R(this.elementInternals,`required`,!!this.input.required),R(this.elementInternals,`checked`,!!this.input.checked))}setValidationStates(){if(this.input?.validity)for(let[e,t]of Object.entries(Uc))R(this.elementInternals,t,this.input.validity[e])}};I([m],Xc.prototype,`labelSlot`,void 0),I([m],Xc.prototype,`messageSlot`,void 0),I([m],Xc.prototype,`slottedInputs`,void 0),I([m],Xc.prototype,`input`,void 0);var Zc=class extends Xc{constructor(){super(...arguments),this.labelPosition=Hc.above}};I([g({attribute:`label-position`})],Zc.prototype,`labelPosition`,void 0),Zc.define(qc);var Qc={email:`email`,password:`password`,tel:`tel`,text:`text`,url:`url`},$c=[`date`,`datetime-local`,`email`,`month`,`number`,`password`,`search`,`tel`,`text`,`time`,`url`,`week`],el=`${e.prefix}-text-input`,tl=v`
  ${S(`block`)}

  :host {
    font-family: ${k};
    font-size: ${A};
    font-weight: ${j};
    line-height: ${N};
    max-width: 400px;
  }
  .label {
    display: flex;
    color: ${C};
    padding-bottom: ${Mo};
    flex-shrink: 0;
    padding-inline-end: ${Co};
  }

  .label[hidden],
  :host(:empty) .label {
    display: none;
  }

  .root {
    align-items: center;
    background-color: ${E};
    border: ${P} solid ${ii};
    border-bottom-color: ${ti};
    border-radius: ${O};
    box-sizing: border-box;
    height: 32px;
    display: inline-flex;
    flex-direction: row;
    gap: ${F};
    padding: 0 ${Eo};
    position: relative;
    width: 100%;
  }

  :has(.control:user-invalid) {
    border-color: ${bi};
  }

  .root::after {
    box-sizing: border-box;
    content: '';
    position: absolute;
    left: -1px;
    bottom: 0px;
    right: -1px;
    height: max(2px, ${O});
    border-radius: 0 0 ${O} ${O};
    border-bottom: 2px solid ${li};
    clip-path: inset(calc(100% - 2px) 1px 0px);
    transform: scaleX(0);
    transition-property: transform;
    transition-duration: ${zo};
    transition-delay: ${qo};
  }
  .control {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    color: ${C};
    border-radius: ${O};
    background: ${Hr};
    font-family: ${k};
    font-weight: ${j};
    font-size: ${A};
    border: none;
    vertical-align: center;
  }
  .control:focus-visible {
    outline: 0;
    border: 0;
  }
  .control::placeholder {
    color: ${mr};
  }
  :host ::slotted([slot='start']),
  :host ::slotted([slot='end']) {
    display: flex;
    align-items: center;
    justify-content: center;
    color: ${w};
    font-size: ${Za};
  }
  :host ::slotted([slot='start']) {
    padding-right: ${F};
  }
  :host ::slotted([slot='end']) {
    padding-left: ${F};
    gap: ${Co};
  }
  :host(:hover) .root {
    border-color: ${ai};
    border-bottom-color: ${ni};
  }
  :host(:active) .root {
    border-color: ${oi};
  }
  :host(:focus-within) .root {
    outline: transparent solid 2px;
    border-bottom: 0;
  }
  :host(:focus-within) .root::after {
    transform: scaleX(1);
    transition-property: transform;
    transition-duration: ${Vo};
    transition-delay: ${Xo};
  }
  :host(:focus-within:active) .root:after {
    border-bottom-color: ${di};
  }
  :host([appearance='outline']:focus-within) .root {
    border: ${P} solid ${ii};
  }
  :host(:focus-within) .control {
    color: ${C};
  }
  :host(${B}) .root {
    background: ${Hr};
    border: ${P} solid ${fi};
  }
  :host(${B}) .control::placeholder,
  :host(${B}) ::slotted([slot='start']),
  :host(${B}) ::slotted([slot='end']) {
    color: ${T};
  }
  ::selection {
    color: ${wr};
    background-color: ${Rr};
  }
  :host([control-size='small']) .control {
    font-size: ${Ya};
    font-weight: ${j};
    line-height: ${ao};
  }
  :host([control-size='small']) .root {
    height: 24px;
    gap: ${F};
    padding: 0 ${wo};
  }
  :host([control-size='small']) ::slotted([slot='start']),
  :host([control-size='small']) ::slotted([slot='end']) {
    font-size: ${Xa};
  }
  :host([control-size='large']) .control {
    font-size: ${Xa};
    font-weight: ${j};
    line-height: ${oo};
  }
  :host([control-size='large']) .root {
    height: 40px;
    gap: ${To};
    padding: 0 ${Do};
  }
  :host([control-size='large']) ::slotted([slot='start']),
  :host([control-size='large']) ::slotted([slot='end']) {
    font-size: ${Qa};
  }
  :host([appearance='underline']) .root {
    background: ${Hr};
    border: 0;
    border-radius: 0;
    border-bottom: ${P} solid ${ti};
  }
  :host([appearance='underline']:hover) .root {
    border-bottom-color: ${ni};
  }
  :host([appearance='underline']:active) .root {
    border-bottom-color: ${ri};
  }
  :host([appearance='underline']:focus-within) .root {
    border: 0;
    border-bottom-color: ${ri};
  }
  :host([appearance='underline']${B}) .root {
    border-bottom-color: ${fi};
  }
  :host([appearance='filled-lighter']) .root,
  :host([appearance='filled-darker']) .root {
    border: ${P} solid ${D};
    box-shadow: ${mo};
  }
  :host([appearance='filled-lighter']) .root {
    background: ${E};
  }
  :host([appearance='filled-darker']) .root {
    background: ${Pr};
  }
  :host([appearance='filled-lighter']:hover) .root,
  :host([appearance='filled-darker']:hover) .root {
    border-color: ${pi};
  }
  :host([appearance='filled-lighter']:active) .root,
  :host([appearance='filled-darker']:active) .root {
    border-color: ${pi};
    background: ${Pr};
  }
`;function nl(e={}){return b`
    <template @keydown="${(e,t)=>e.keydownHandler(t.event)}">
      <label part="label" for="control" class="label" ${y(`controlLabel`)}>
        <slot ${x(`defaultSlottedNodes`)}></slot>
      </label>
      <div class="root" part="root">
        ${ds(e)}
        <input
          class="control"
          part="control"
          id="control"
          @change="${(e,t)=>e.changeHandler(t.event)}"
          @input="${(e,t)=>e.inputHandler(t.event)}"
          autocomplete="${e=>e.autocomplete}"
          ?disabled="${e=>e.disabled}"
          list="${e=>e.list}"
          maxlength="${e=>e.maxlength}"
          minlength="${e=>e.minlength}"
          ?multiple="${e=>e.multiple}"
          name="${e=>e.name}"
          pattern="${e=>e.pattern}"
          placeholder="${e=>e.placeholder}"
          ?readonly="${e=>e.readOnly}"
          ?required="${e=>e.required}"
          size="${e=>e.size}"
          spellcheck="${e=>e.spellcheck}"
          type="${e=>e.type}"
          value="${e=>e.value}"
          ${y(`control`)}
        />
        ${us(e)}
      </div>
    </template>
  `}var rl=nl(),il={name:el,registry:e.registry,shadowOptions:{delegatesFocus:!0},styles:tl,template:rl},V=class extends _{constructor(){super(...arguments),this.type=Qc.text,this.dirtyValue=!1,this.elementInternals=this.attachInternals()}currentValueChanged(e,t){this.value=t}defaultSlottedNodesChanged(e,t){f.enqueue(()=>{this.controlLabel&&(this.controlLabel.hidden=!t?.some(e=>e.nodeType===Node.ELEMENT_NODE||e.nodeType===Node.TEXT_NODE&&!!e.textContent?.trim()))})}initialValueChanged(){this.dirtyValue||(this.value=this.initialValue)}readOnlyChanged(){this.$fastController.isConnected&&(this.elementInternals.ariaReadOnly=`${!!this.readOnly}`)}requiredChanged(e,t){this.$fastController.isConnected&&(this.elementInternals.ariaRequired=`${!!t}`)}controlChanged(e,t){f.enqueue(()=>{this.$fastController.isConnected&&this.setValidity()})}static{this.formAssociated=!0}get validity(){return this.elementInternals.validity}get validationMessage(){return this.elementInternals.validationMessage||this.control.validationMessage}get value(){return p.track(this,`value`),this.currentValue}set value(e){this.currentValue=e,this.elementInternals&&this.control&&(this.control.value=e??``,this.setFormValue(e),this.setValidity(),p.notify(this,`value`))}get willValidate(){return this.elementInternals.willValidate}get form(){return this.elementInternals.form}changeHandler(e){return this.setValidity(),this.$emit(`change`,e,{bubbles:!0,composed:!0}),!0}checkValidity(){return this.elementInternals.checkValidity()}clickHandler(e){return e.target===this&&this.control?.click(),!0}connectedCallback(){super.connectedCallback(),this.setFormValue(this.value),this.setValidity(),gs(this)}formResetCallback(){this.value=this.initialValue,this.dirtyValue=!1}implicitSubmit(){if(!this.elementInternals.form)return;if(this.elementInternals.form.elements.length===1){this.elementInternals.form.requestSubmit();return}let e=[...this.elementInternals.form.elements],t=e.find(e=>e.getAttribute(`type`)===`submit`);if(t){t.click();return}e.filter(e=>$c.includes(e.getAttribute(`type`)??``)).length>1||this.elementInternals.form.requestSubmit()}inputHandler(e){return this.dirtyValue=!0,this.value=this.control.value,!0}keydownHandler(e){return e.key===`Enter`&&this.implicitSubmit(),!0}select(){this.control.select(),this.$emit(`select`)}setCustomValidity(e){this.elementInternals.setValidity({customError:!0},e),this.reportValidity()}reportValidity(){return this.elementInternals.reportValidity()}setFormValue(e,t){this.elementInternals?.setFormValue(e,e??t)}setValidity(e,t,n){if(this.elementInternals&&this.control){if(this.disabled){this.elementInternals.setValidity({});return}this.elementInternals.setValidity(e??this.control.validity,t??this.validationMessage,n??this.control)}}};I([g],V.prototype,`autocomplete`,void 0),I([g({attribute:`current-value`})],V.prototype,`currentValue`,void 0),I([m],V.prototype,`defaultSlottedNodes`,void 0),I([g],V.prototype,`dirname`,void 0),I([g({mode:`boolean`})],V.prototype,`disabled`,void 0),I([g({attribute:`form`})],V.prototype,`formAttribute`,void 0),I([g({attribute:`value`,mode:`fromView`})],V.prototype,`initialValue`,void 0),I([g],V.prototype,`list`,void 0),I([g({converter:je})],V.prototype,`maxlength`,void 0),I([g({converter:je})],V.prototype,`minlength`,void 0),I([g({mode:`boolean`})],V.prototype,`multiple`,void 0),I([g],V.prototype,`name`,void 0),I([g],V.prototype,`pattern`,void 0),I([g],V.prototype,`placeholder`,void 0),I([g({attribute:`readonly`,mode:`boolean`})],V.prototype,`readOnly`,void 0),I([g({mode:`boolean`})],V.prototype,`required`,void 0),I([g({converter:je})],V.prototype,`size`,void 0),I([g({converter:{fromView:e=>typeof e==`string`?[`true`,``].includes(e.trim().toLowerCase()):null,toView:e=>e.toString()}})],V.prototype,`spellcheck`,void 0),I([g],V.prototype,`type`,void 0),I([m],V.prototype,`control`,void 0),I([m],V.prototype,`controlLabel`,void 0);var al=class extends V{};I([g],al.prototype,`appearance`,void 0),I([g({attribute:`control-size`})],al.prototype,`controlSize`,void 0),hs(al,ls),al.define(il);var ol={outline:`outline`,filledLighter:`filled-lighter`,filledDarker:`filled-darker`};ol.filledLighter,ol.filledDarker;var sl={none:`none`,both:`both`,horizontal:`horizontal`,vertical:`vertical`},cl=`${e.prefix}-textarea`,ll=v`
  ${S(`inline-block`)}

  :host {
    /* typography */
    --font-size: ${A};
    --line-height: ${N};

    /* layout */
    --padding-inline: ${Eo};
    --padding-block: ${No};
    --min-block-size: 52px;
    --block-size: var(--min-block-size);
    --inline-size: 18rem;
    --border-width: ${P};
    --control-padding-inline: ${F};

    /* colors */
    --color: ${C};
    --background-color: ${E};
    --border-color: ${ii};
    --border-block-end-color: ${ti};
    --placeholder-color: ${mr};
    --focus-indicator-color: ${li};

    /* elevations */
    --box-shadow: none;

    /* others */
    --contain-size: size;
    --resize: none;

    color: var(--color);
    font-family: ${k};
    font-size: var(--font-size);
    font-weight: ${j};
    line-height: var(--line-height);
    position: relative;
  }

  :host(:hover) {
    --border-color: ${ai};
    --border-block-end-color: ${ni};
  }

  :host(:active) {
    --border-color: ${oi};
    --border-block-end-color: ${ri};
  }

  :host(:focus-within) {
    outline: none;
  }

  :host([block]:not([hidden])) {
    display: block;
  }

  :host([size='small']) {
    --font-size: ${Ya};
    --line-height: ${ao};
    --min-block-size: 40px;
    --padding-block: ${Mo};
    --padding-inline: ${wo};
    --control-padding-inline: ${F};
  }

  :host([size='large']) {
    --font-size: ${Xa};
    --line-height: ${oo};
    --min-block-size: 64px;
    --padding-block: ${Po};
    --padding-inline: ${Do};
    --control-padding-inline: ${wo};
  }

  :host([resize='both']:not(${B})) {
    --resize: both;
  }

  :host([resize='horizontal']:not(${B})) {
    --resize: horizontal;
  }

  :host([resize='vertical']:not(${B})) {
    --resize: vertical;
  }

  :host([auto-resize]) {
    --block-size: auto;
    --contain-size: inline-size;
  }

  :host([appearance='filled-darker']) {
    --background-color: ${Pr};
    --border-color: var(--background-color);
    --border-block-end-color: var(--border-color);
  }

  :host([appearance='filled-lighter']) {
    --border-color: var(--background-color);
    --border-block-end-color: var(--border-color);
  }

  :host([appearance='filled-darker'][display-shadow]),
  :host([appearance='filled-lighter'][display-shadow]) {
    --box-shadow: ${mo};
  }

  :host(${qs}) {
    --border-color: ${bi};
    --border-block-end-color: ${bi};
  }

  :host(${B}) {
    --color: ${T};
    --background-color: ${Hr};
    --border-color: ${fi};
    --border-block-end-color: var(--border-color);
    --box-shadow: none;
    --placeholder-color: ${T};

    cursor: no-drop;
    user-select: none;
  }

  .root {
    background-color: var(--background-color);
    border: var(--border-width) solid var(--border-color);
    border-block-end-color: var(--border-block-end-color);
    border-radius: ${O};
    box-sizing: border-box;
    box-shadow: var(--box-shadow);
    contain: paint layout style var(--contain-size);
    display: grid;
    grid-template: 1fr / 1fr;
    inline-size: var(--inline-size);
    min-block-size: var(--min-block-size);
    block-size: var(--block-size);
    overflow: hidden;
    padding: var(--padding-block) var(--padding-inline);
    position: relative;
    resize: var(--resize);
  }

  :host([block]) .root {
    inline-size: auto;
  }

  .root::after {
    border-bottom: 2px solid var(--focus-indicator-color);
    border-radius: 0 0 ${O} ${O};
    box-sizing: border-box;
    clip-path: inset(calc(100% - 2px) 1px 0px);
    content: '';
    height: max(2px, ${O});
    inset: auto -1px 0;
    position: absolute;
    transform: scaleX(0);
    transition-delay: ${qo};
    transition-duration: ${zo};
    transition-property: transform;
  }

  :host(:focus-within) .root::after {
    transform: scaleX(1);
    transition-property: transform;
    transition-duration: ${Vo};
    transition-delay: ${Xo};
  }

  :host([readonly]) .root::after,
  :host(${B}) .root::after {
    content: none;
  }

  label {
    color: var(--color);
    display: flex;
    inline-size: fit-content;
    padding-block-end: ${Mo};
    padding-inline-end: ${Co};
  }

  :host(:empty) label,
  label[hidden] {
    display: none;
  }

  .auto-sizer,
  .control {
    box-sizing: border-box;
    font: inherit;
    grid-column: 1 / -1;
    grid-row: 1 / -1;
    letter-space: inherit;
    padding: 0 var(--control-padding-inline);
  }

  .auto-sizer {
    display: none;
    padding-block-end: 2px; /* avoid scroll bar in Firefox */
    pointer-events: none;
    visibility: hidden;
    white-space: pre-wrap;
  }

  :host([auto-resize]) .auto-sizer {
    display: block;
  }

  .control {
    appearance: none;
    background-color: transparent;
    border: 0;
    color: inherit;
    field-sizing: content;
    max-block-size: 100%;
    outline: 0;
    overflow: auto;
    resize: none;
    text-align: inherit;
  }

  .control:disabled {
    cursor: inherit;
  }

  .control::placeholder {
    color: var(--placeholder-color);
  }

  ::selection {
    color: ${wr};
    background-color: ${Rr};
  }

  @media (forced-colors: active) {
    :host {
      --border-color: FieldText;
      --border-block-end-color: FieldText;
      --focus-indicator-color: Highlight;
      --placeholder-color: FieldText;
    }

    :host(:hover),
    :host(:active),
    :host(:focus-within) {
      --border-color: Highlight;
      --border-block-end-color: Highlight;
    }

    :host(${B}) {
      --color: GrayText;
      --border-color: GrayText;
      --border-block-end-color: GrayText;
      --placeholder-color: GrayText;
    }
  }
`;function ul(){return b`
    <template>
      <label ${y(`labelEl`)} for="control" part="label">
        <slot name="label" ${x(`labelSlottedNodes`)}></slot>
      </label>
      <div class="root" part="root" ${y(`rootEl`)}>
        <textarea
          ${y(`controlEl`)}
          id="control"
          class="control"
          part="control"
          ?required="${e=>e.required}"
          ?disabled="${e=>e.disabled}"
          ?readonly="${e=>e.readOnly}"
          ?spellcheck="${e=>e.spellcheck}"
          autocomplete="${e=>e.autocomplete}"
          maxlength="${e=>e.maxLength}"
          minlength="${e=>e.minLength}"
          placeholder="${e=>e.placeholder}"
          @change="${e=>e.handleControlChange()}"
          @select="${e=>e.handleControlSelect()}"
          @input="${e=>e.handleControlInput()}"
        ></textarea>
      </div>
      <div hidden>
        <slot ${x(`defaultSlottedNodes`)}></slot>
      </div>
    </template>
  `}var dl=ul(),fl={name:cl,registry:e.registry,shadowOptions:{delegatesFocus:!0},styles:ll,template:dl},pl=e=>e.nodeType!==Node.TEXT_NODE||!!e.nodeValue?.trim().length,H=class extends _{static{this.formAssociated=!0}controlElChanged(){this.controlElAttrObserver=new MutationObserver(()=>{this.setValidity()}),this.controlElAttrObserver.observe(this.controlEl,{attributes:!0,attributeFilter:[`disabled`,`required`,`readonly`,`maxlength`,`minlength`]}),this.controlEl.addEventListener(`input`,()=>this.userInteracted=!0,{once:!0})}defaultSlottedNodesChanged(){f.enqueue(()=>{let e=this.getContent();this.defaultValue=e,this.value=e})}labelSlottedNodesChanged(){this.filteredLabelSlottedNodes=this.labelSlottedNodes.filter(pl),this.labelEl&&(this.labelEl.hidden=!this.filteredLabelSlottedNodes.length),this.filteredLabelSlottedNodes.forEach(e=>{e.disabled=this.disabled,e.required=this.required})}autoResizeChanged(){this.maybeCreateAutoSizerEl(),R(this.elementInternals,`auto-resize`,this.autoResize)}disabledChanged(){this.setDisabledSideEffect(this.disabled)}get form(){return this.elementInternals.form}get labels(){return this.elementInternals.labels}readOnlyChanged(){this.elementInternals&&(this.elementInternals.ariaReadOnly=`${!!this.readOnly}`,this.setValidity())}requiredChanged(){this.elementInternals.ariaRequired=`${!!this.required}`,this.filteredLabelSlottedNodes?.length&&this.filteredLabelSlottedNodes.forEach(e=>e.required=this.required)}resizeChanged(e,t){Ts(this.elementInternals,e,t,sl,`resize-`),R(this.elementInternals,`resize`,ws(sl,t)&&t!==sl.none)}get textLength(){return this.controlEl.textLength}get type(){return`textarea`}get validity(){return this.elementInternals.validity}get validationMessage(){return this.elementInternals.validationMessage||this.controlEl.validationMessage}get willValidate(){return this.elementInternals.willValidate}get defaultValue(){return this.controlEl?.defaultValue??this.preConnectControlEl.defaultValue}set defaultValue(e){let t=this.controlEl??this.preConnectControlEl;t.defaultValue=e,this.controlEl&&!this.userInteracted&&(this.controlEl.value=e)}get value(){return this.controlEl?.value??this.preConnectControlEl.value}set value(e){let t=this.controlEl??this.preConnectControlEl;t.value=e,this.setFormValue(e),this.setValidity()}constructor(){super(),this.elementInternals=this.attachInternals(),this.filteredLabelSlottedNodes=[],this.labelSlottedNodes=[],this.userInteracted=!1,this.preConnectControlEl=document.createElement(`textarea`),this.autoResize=!1,this.disabled=!1,this.displayShadow=!1,this.readOnly=!1,this.required=!1,this.resize=sl.none,this.spellcheck=!1}connectedCallback(){super.connectedCallback(),requestAnimationFrame(()=>{if(!this.$fastController.isConnected)return;let e=this.preConnectControlEl,t=this.getContent();this.defaultValue=t||e?.defaultValue||``,this.value=e?.value||this.defaultValue,this.setFormValue(this.value),this.setValidity(),this.preConnectControlEl=null,this.maybeCreateAutoSizerEl(),gs(this)})}disconnectedCallback(){super.disconnectedCallback(),this.autoSizerObserver?.disconnect(),this.controlElAttrObserver?.disconnect()}formResetCallback(){this.value=this.defaultValue}formDisabledCallback(e){this.setDisabledSideEffect(e),this.setValidity()}setFormValue(e,t){this.elementInternals.setFormValue(e,e??t)}checkValidity(){return this.elementInternals.checkValidity()}reportValidity(){return this.elementInternals.reportValidity()}setCustomValidity(e){this.elementInternals?.setValidity({customError:!!e},e?e.toString():void 0),this.reportValidity()}setValidity(e,t,n){this.elementInternals&&(this.disabled||this.readOnly?this.elementInternals.setValidity({}):this.elementInternals.setValidity(e??this.controlEl?.validity,t??this.controlEl?.validationMessage,n??this.controlEl),this.userInteracted&&this.toggleUserValidityState())}select(){this.controlEl.select()}getContent(){return this.defaultSlottedNodes?.map(e=>{switch(e.nodeType){case Node.ELEMENT_NODE:return e.outerHTML;case Node.TEXT_NODE:return e.textContent.trim();default:return``}}).join(``)||``}setDisabledSideEffect(e){this.elementInternals.ariaDisabled=`${e}`,this.controlEl&&(this.controlEl.disabled=e),this.filteredLabelSlottedNodes?.length&&this.filteredLabelSlottedNodes.forEach(e=>e.disabled=this.disabled)}toggleUserValidityState(){R(this.elementInternals,`user-invalid`,!this.validity.valid),R(this.elementInternals,`user-valid`,this.validity.valid)}maybeCreateAutoSizerEl(){if(!CSS.supports(`field-sizing: content`)){if(!this.autoResize){this.autoSizerEl?.remove(),this.autoSizerObserver?.disconnect();return}this.autoSizerEl||(this.autoSizerEl=document.createElement(`div`),this.autoSizerEl.classList.add(`auto-sizer`),this.autoSizerEl.ariaHidden=`true`),this.rootEl?.prepend(this.autoSizerEl),this.autoSizerObserver||=new ResizeObserver((e,t)=>{let n=window.getComputedStyle(this).writingMode.startsWith(`horizontal`)?`height`:`width`;this.style.getPropertyValue(n)!==``&&(this.autoSizerEl?.remove(),t.disconnect())}),this.autoSizerObserver.observe(this)}}handleControlInput(){this.autoResize&&this.autoSizerEl&&(this.autoSizerEl.textContent=this.value+` `),this.setFormValue(this.value),this.setValidity()}handleControlChange(){this.toggleUserValidityState(),this.$emit(`change`)}handleControlSelect(){this.$emit(`select`)}};I([m],H.prototype,`controlEl`,void 0),I([m],H.prototype,`defaultSlottedNodes`,void 0),I([m],H.prototype,`labelSlottedNodes`,void 0),I([g],H.prototype,`autocomplete`,void 0),I([g({attribute:`auto-resize`,mode:`boolean`})],H.prototype,`autoResize`,void 0),I([g({attribute:`dirname`})],H.prototype,`dirName`,void 0),I([g({mode:`boolean`})],H.prototype,`disabled`,void 0),I([g({attribute:`display-shadow`,mode:`boolean`})],H.prototype,`displayShadow`,void 0),I([g({attribute:`form`})],H.prototype,`initialForm`,void 0),I([g({attribute:`maxlength`,converter:je})],H.prototype,`maxLength`,void 0),I([g({attribute:`minlength`,converter:je})],H.prototype,`minLength`,void 0),I([g],H.prototype,`name`,void 0),I([g],H.prototype,`placeholder`,void 0),I([g({attribute:`readonly`,mode:`boolean`})],H.prototype,`readOnly`,void 0),I([g({mode:`boolean`})],H.prototype,`required`,void 0),I([g({mode:`fromView`})],H.prototype,`resize`,void 0),I([g({mode:`boolean`})],H.prototype,`spellcheck`,void 0);var ml=class extends H{constructor(){super(...arguments),this.appearance=ol.outline,this.block=!1}labelSlottedNodesChanged(){super.labelSlottedNodesChanged(),this.labelSlottedNodes.forEach(e=>{e.size=this.size})}handleChange(e,t){t===`size`&&this.labelSlottedNodes.forEach(e=>{e.size=this.size})}connectedCallback(){super.connectedCallback(),p.getNotifier(this).subscribe(this,`size`)}disconnectedCallback(){super.disconnectedCallback(),p.getNotifier(this).unsubscribe(this,`size`)}};I([g({mode:`fromView`})],ml.prototype,`appearance`,void 0),I([g({mode:`boolean`})],ml.prototype,`block`,void 0),I([g],ml.prototype,`size`,void 0),ml.define(fl);var hl={filledDarker:`filled-darker`,filledLighter:`filled-lighter`,outline:`outline`,transparent:`transparent`},gl={combobox:`combobox`,dropdown:`dropdown`,select:`select`},_l=`${e.prefix}-dropdown`,vl=v.partial`
  font-family: ${k};
  font-size: ${A};
  line-height: ${N};
  font-weight: ${j};
`;v.partial`
  font-family: ${k};
  font-size: ${A};
  line-height: ${N};
  font-weight: ${M};
`,v.partial`
  font-family: ${k};
  font-size: ${A};
  line-height: ${N};
  font-weight: ${ro};
`;var yl=v.partial`
  font-family: ${k};
  font-size: ${Xa};
  line-height: ${oo};
  font-weight: ${j};
`,bl=v.partial`
  font-family: ${k};
  font-size: ${Ya};
  line-height: ${ao};
  font-weight: ${j};
`;v.partial`
  font-family: ${k};
  font-size: ${Ya};
  line-height: ${ao};
  font-weight: ${M};
`,v.partial`
  font-family: ${k};
  font-size: ${Ya};
  line-height: ${ao};
  font-weight: ${ro};
`,v.partial`
  font-family: ${k};
  font-size: ${Ja};
  line-height: ${io};
  font-weight: ${j};
`,v.partial`
  font-family: ${k};
  font-size: ${Ja};
  line-height: ${io};
  font-weight: ${M};
`;var xl=v.partial`
  font-family: ${k};
  font-size: ${Za};
  line-height: ${so};
  font-weight: ${M};
`;v.partial`
  font-family: ${k};
  font-size: ${Xa};
  line-height: ${oo};
  font-weight: ${M};
`,v.partial`
  font-family: ${k};
  font-size: ${Xa};
  line-height: ${oo};
  font-weight: ${ro};
`,v.partial`
  font-family: ${k};
  font-size: ${eo};
  line-height: ${uo};
  font-weight: ${M};
`,v.partial`
  font-family: ${k};
  font-size: ${$a};
  line-height: ${lo};
  font-weight: ${M};
`,v.partial`
  font-family: ${k};
  font-size: ${Qa};
  line-height: ${co};
  font-weight: ${M};
`,v.partial`
  font-family: ${k};
  font-size: ${to};
  line-height: ${fo};
  font-weight: ${M};
`,v.partial`
  font-family: ${k};
  font-size: ${no};
  line-height: ${po};
  font-weight: ${M};
`;var Sl=v`
  ${S(`inline-flex`)}

  :host {
    box-sizing: border-box;
    color: ${C};
    cursor: pointer;
  }

  :host(${Ls}) {
    color: ${mr};
  }

  .control {
    appearance: none;
    background-color: ${E};
    border-radius: ${O};
    border: ${P} solid ${D};
    box-shadow: inset 0 0 0 ${P} var(--control-border-color);
    box-sizing: border-box;
    color: inherit;
    column-gap: ${F};
    display: inline-flex;
    justify-content: space-between;
    min-width: 160px;
    overflow: hidden;
    padding: ${No} ${Eo};
    white-space: normal;
    position: relative;
    text-align: start;
    width: 100%;
    z-index: 1;
    ${vl}
  }

  :host([size='small']) .control {
    column-gap: ${F};
    padding: ${Mo} ${wo};
    ${bl}
  }

  :host([size='large']) .control {
    column-gap: ${To};
    padding: ${Po} ${Do};
    ${yl}
  }

  ::slotted(:is(input, button)) {
    all: unset;
    flex: 1 1 auto;
  }

  ::slotted(button) {
    cursor: pointer;
  }

  ::slotted(input) {
    cursor: text;
  }

  :where(slot[name='indicator'] > *, ::slotted([slot='indicator'])) {
    all: unset;
    align-items: center;
    appearance: none;
    aspect-ratio: 1;
    color: ${w};
    display: inline-flex;
    justify-content: center;
    width: 20px;
  }

  :host([size='small']) :where(slot[name='indicator'] > *, ::slotted([slot='indicator'])) {
    width: 16px;
  }

  :host([size='large']) :where(slot[name='indicator'] > *, ::slotted([slot='indicator'])) {
    width: 24px;
  }

  .control::after,
  .control::before {
    content: '' / '';
    inset: auto 0 0;
    pointer-events: none;
    position: absolute;
  }

  .control::before {
    height: ${P};
  }

  .control::after {
    background-color: ${li};
    height: ${bo};
    scale: 0 1;
    transition: scale ${zo} ${Xo};
  }

  /**
  * focus-ring style uses lingering :focus-within selector due to platform limitations
  * TODO: Convert selector to \`:host(:has(:focus-visible)) .control\` when browser support increases
  * ISSUE: https://issues.chromium.org/issues/40062355
  */
  :host(:where(:focus-within)) .control {
    border-radius: ${O};
    box-shadow: inset 0 0 0 1px ${mi};
    outline: ${bo} solid ${hi};
  }

  :host(:where(${Fs}, :focus-within)) .control::after {
    scale: 1 1;
    transition-duration: ${Vo};
    transition-timing-function: ${qo};
  }

  :host(:where([appearance='outline'], [appearance='transparent'])) .control::before {
    background-color: ${ti};
  }

  :host([appearance='transparent']) .control {
    --control-border-color: ${pi};
    background-color: ${Hr};
    border-radius: ${Ua};
  }

  :host([appearance='outline']) .control {
    --control-border-color: ${ii};
  }

  :host([appearance='outline']) .control:hover {
    --control-border-color: ${ai};
  }

  :host(:where([appearance='outline'], [appearance='transparent'])) .control:hover::before {
    background-color: ${ni};
  }

  :host([appearance='outline']) .control:hover::after {
    background-color: ${Zr};
  }

  :host([appearance='outline']) .control:active {
    --control-border-color: ${oi};
  }

  :host(:where([appearance='outline'], [appearance='transparent'])) .control:active::before {
    background-color: ${ri};
  }

  :host(:where([appearance='outline'], [appearance='transparent'])) .control:active::after {
    background-color: ${Qr};
  }

  :host([appearance='filled-darker']) .control {
    background-color: ${Pr};
  }

  :host(:where([appearance='filled-lighter'], [appearance='filled-darker'])) .control {
    --control-border-color: ${D};
  }

  :host(${B}),
  :host(${B}) ::slotted(:where(button, input)) {
    cursor: not-allowed;
  }

  :host(${B}) .control::before,
  :host(${B}) .control::after {
    content: none;
  }

  :host(${B}) .control:is(*, :active, :hover),
  :host(${B}) :where(slot[name='indicator'] > *, ::slotted([slot='indicator'])) {
    --control-border-color: ${fi};
    background-color: ${Gr};
    color: ${T};
  }

  ::slotted(:not([slot]):not([popover])),
  ::slotted([popover]:not(:popover-open)) {
    display: none;
  }

  @supports not (anchor-name: --anchor) {
    :host {
      --listbox-max-height: 50vh;
      --margin-offset: calc(${N} + (${No} * 2) + ${P});
    }

    :host([size='small']) {
      --margin-offset: calc(${ao} + (${Mo} * 2) + ${P});
    }

    :host([size='large']) {
      --margin-offset: calc(${oo} + (${Po} * 2) + ${P});
    }
  }

  @media (forced-colors: active) {
    :host(${B}) .control {
      border-color: GrayText;
    }
    :host(${B}) :where(slot[name='indicator'] > *, ::slotted([slot='indicator'])) {
      color: GrayText;
    }
  }
`,Cl=b`
  <svg class="chevron-down-20-regular" aria-hidden="true" slot="indicator" viewBox="0 0 20 20" ${y(`indicator`)}>
    <path
      d="M15.85 7.65a.5.5 0 0 1 0 .7l-5.46 5.49a.55.55 0 0 1-.78 0L4.15 8.35a.5.5 0 1 1 .7-.7L10 12.8l5.15-5.16a.5.5 0 0 1 .7 0"
      fill="currentColor"
    />
  </svg>
`,wl=b`
  <input
    @input="${(e,t)=>e.inputHandler(t.event)}"
    @change="${(e,t)=>e.changeHandler(t.event)}"
    aria-activedescendant="${e=>e.activeDescendant}"
    aria-controls="${e=>e.listbox?.id??null}"
    aria-labelledby="${e=>e.ariaLabelledBy}"
    aria-expanded="${e=>e.open}"
    aria-haspopup="listbox"
    placeholder="${e=>e.placeholder}"
    role="combobox"
    ?disabled="${e=>e.disabled}"
    type="${e=>e.type}"
    value="${e=>e.valueAttribute}"
    slot="control"
    ${y(`control`)}
  />
`,Tl=b`
  <button
    aria-activedescendant="${e=>e.activeDescendant}"
    aria-controls="${e=>e.listbox?.id??null}"
    aria-expanded="${e=>e.open}"
    aria-haspopup="listbox"
    role="combobox"
    ?disabled="${e=>e.disabled}"
    type="button"
    slot="control"
    ${y(`control`)}
  >
    ${e=>e.displayValue}
  </button>
`;function El(e={}){return b`
    <template
      @click="${(e,t)=>e.clickHandler(t.event)}"
      @focusout="${(e,t)=>e.focusoutHandler(t.event)}"
      @keydown="${(e,t)=>e.keydownHandler(t.event)}"
      @mousedown="${(e,t)=>e.mousedownHandler(t.event)}"
    >
      <div class="control">
        <slot name="control" ${y(`controlSlot`)}></slot>
        <slot name="indicator" ${y(`indicatorSlot`)}>${cs(e.indicator)}</slot>
      </div>
      <slot @slotchange="${(e,t)=>e.slotchangeHandler(t.event)}"></slot>
    </template>
  `}var Dl=El({indicator:Cl}),Ol={name:_l,registry:e.registry,styles:Sl,template:Dl};function kl(e,t=`-listbox`){return e?.nodeType===Node.ELEMENT_NODE&&e.tagName.toLowerCase().endsWith(t)}var Al=`${e.prefix}-listbox`;function jl(e,t=`-option`){return e?.nodeType===Node.ELEMENT_NODE&&e.tagName.toLowerCase().endsWith(t)}var Ml=`${e.prefix}-option`,Nl={ltr:`ltr`,rtl:`rtl`},Pl=e=>e.closest(`[dir]`)?.dir===`rtl`?Nl.rtl:Nl.ltr;function Fl(e){return e.closest(`[lang]`)?.lang??`en`}function Il(e,t){if(`requestIdleCallback`in globalThis)return globalThis.requestIdleCallback(e,t);let n=Date.now();return setTimeout(()=>{e({didTimeout:t?.timeout?Date.now()-n>=t.timeout:!1,timeRemaining:()=>0})},t?.timeout??1)}function Ll(e,t,n){let r=n?.shallow??!1,i=n?.timeout??50,a=n?.idleCallback??!1,o=`${r?`:scope > `:``}:not(:defined)`,s=n=>{if(e.querySelector(o)===null||n&&n.timeRemaining()<=0){a?Il(t,{timeout:i}):t();return}Il(s,{timeout:i})};s()}var U=class e extends _{get activeDescendant(){if(this.open)return this.enabledOptions[this.activeIndex]?.id}activeIndexChanged(e,t){if(typeof t==`number`){let e=this.matches(`:has(:focus-visible)`)?t:-1;this.enabledOptions.forEach((t,n)=>{t.active=n===e}),this.open&&this.enabledOptions[e]?.scrollIntoView({block:`nearest`})}}controlChanged(e,t){t&&(t.id=t.id||Yc(`input-`))}disabledChanged(e,t){this.listbox&&f.enqueue(()=>{this.options.forEach(e=>{e.disabled=e.disabledAttribute||this.disabled})})}get displayValue(){if(!this.$fastController.isConnected||!this.control||this.isCombobox&&this.multiple)return R(this.elementInternals,`placeholder-shown`,!1),``;this.listFormatter=this.listFormatter??new Intl.ListFormat(Fl(this),{type:`conjunction`,style:`narrow`});let e=this.listFormatter.format(this.selectedOptions.map(e=>e.text));return R(this.elementInternals,`placeholder-shown`,!e),this.isCombobox?e:e||this.placeholder}listboxChanged(e,t){if(e&&p.getNotifier(this).unsubscribe(e),t){t.dropdown=this,t.popover=`manual`,t.tabIndex=-1;let e=p.getNotifier(this);if(e.subscribe(t),e.notify(`multiple`),f.enqueue(()=>{this.options.forEach(e=>{e.disabled=e.disabledAttribute||this.disabled,e.name=this.name}),this.enabledOptions.filter(e=>e.defaultSelected).forEach((e,t)=>{e.selected=this.multiple||t===0}),this.setValidity()}),bs){let e=Yc(`--dropdown-anchor-`);this.style.setProperty(`anchor-name`,e),this.listbox.style.setProperty(`position-anchor`,e)}}}multipleChanged(e,t){this.elementInternals.ariaMultiSelectable=t?`true`:`false`,R(this.elementInternals,`multiple`,t),this.value=null}nameChanged(e,t){this.listbox&&f.enqueue(()=>{this.options.forEach(e=>{e.name=t})})}openChanged(e,t){R(this.elementInternals,`open`,t),this.elementInternals.ariaExpanded=t?`true`:`false`,this.activeIndex=this.selectedIndex??-1,bs||this.anchorPositionFallback(t)}typeChanged(e,t){this.$fastController.isConnected&&this.insertControl()}get enabledOptions(){return this.listbox?.enabledOptions??Array.from(this.querySelectorAll(`*`)).filter(e=>jl(e)&&!e.disabled)}static{this.formAssociated=!0}get freeformOption(){return this.enabledOptions.find(e=>e.freeform)}get isCombobox(){return this.type===gl.combobox}get labels(){return Object.freeze(Array.from(this.elementInternals.labels))}get options(){return this.listbox?.options??Array.from(this.querySelectorAll(`*`)).filter(e=>jl(e))}get selectedIndex(){return this.enabledOptions.findIndex(e=>e.selected)??-1}get selectedOptions(){return this.listbox?.selectedOptions??[]}get validationMessage(){if(this.elementInternals.validationMessage)return this.elementInternals.validationMessage;if(!this._validationFallbackMessage){let e=document.createElement(`input`);e.type=`radio`,e.name=`validation-message-fallback`,e.required=!0,e.checked=!1,this._validationFallbackMessage=e.validationMessage}return!this.disabled&&this.required&&this.listbox.selectedOptions.length===0?this._validationFallbackMessage:``}get validity(){return this.elementInternals.validity}get value(){return p.notify(this,`value`),this.enabledOptions.find(e=>e.selected)?.value??null}set value(e){this.multiple||(this.selectOption(this.enabledOptions.findIndex(t=>t.value===e)),p.track(this,`value`))}get willValidate(){return this.elementInternals.willValidate}changeHandler(e){if(this===e.target)return!0;let t=this.isCombobox?this.enabledOptions.findIndex(e=>e.text===this.control.value):this.enabledOptions.indexOf(e.target);return this.selectOption(t,!0),!0}checkValidity(){return this.elementInternals.checkValidity()}clickHandler(e){if(this.disabled)return;let t=e.target;if(this.focus(),(t===this.control||e.composedPath().includes(this.indicator))&&!this.isCombobox)return this.listbox.togglePopover(),!0;if(!this.open)return this.listbox.showPopover(),!0;if(jl(t)){if(t.disabled)return;this.selectOption(this.enabledOptions.indexOf(t),!0),this.multiple||(this.isCombobox&&(this.control.value=t.text,this.updateFreeformOption()),this.listbox.hidePopover())}return!0}constructor(){super(),this.activeIndex=0,this.id=Yc(`dropdown-`),this.required=!1,this.type=gl.dropdown,this.valueAttribute=``,this.repositionListbox=()=>{this.frameId&&cancelAnimationFrame(this.frameId),this.frameId=requestAnimationFrame(()=>{let e=this.getBoundingClientRect(),t=window.innerWidth-e.right,n=e.left;this.listbox.style.minWidth=`${e.width}px`,this.listbox.style.top=`${e.top}px`,n+e.width>window.innerWidth||Pl(this)===`rtl`&&t-e.width>0?(this.listbox.style.right=`${t}px`,this.listbox.style.left=`unset`):(this.listbox.style.left=`${n}px`,this.listbox.style.right=`unset`)})},this.elementInternals=this.attachInternals(),this._insertingControl=!1,this.searchTimeoutMs=500,this.searchString=``,this.elementInternals.role=`presentation`}filterOptions(e,t=this.enabledOptions){return this.listCollator||=new Intl.Collator(Fl(this),{usage:`search`,sensitivity:`base`}),t.filter(t=>this.listCollator.compare(t.text.substring(0,Math.min(t.text.length,e.length)),e)===0)}focus(e){this.disabled||this.control.focus(e)}focusoutHandler(e){let t=e.relatedTarget;return this.open&&!this.contains(t)&&this.listbox.togglePopover(),!0}formResetCallback(){this.enabledOptions.forEach((e,t)=>{if(this.multiple){e.selected=!!e.defaultSelected;return}if(!e.defaultSelected){e.selected=!1;return}this.selectOption(t)}),this.setValidity()}getEnabledIndexInBounds(e,t=this.enabledOptions.length||0){return t===0?-1:(e+t)%t}inputHandler(e){this.open||this.listbox.showPopover(),this.updateFreeformOption();let t=this.control.value,n=this.enabledOptions.indexOf(this.filterOptions(t)[0]??null);return this.activeIndex=n,!0}insertControl(){if(!this._insertingControl){if(this._insertingControl=!0,this.controlSlot?.assignedNodes().forEach(e=>this.removeChild(e)),this.type===gl.combobox){wl.render(this,this);return}Tl.render(this,this),this._insertingControl=!1}}handleSearchCharacter(e){let t=this.searchString===e.repeat(this.searchString.length);this.searchString+=e;let n=this.searchString.length>1?this.filterOptions(this.searchString):[],r=!1;if(!n.length&&t&&(n=this.filterOptions(e),r=!0),n.length){let e=this.enabledOptions[this.activeIndex],t=n.indexOf(e),i=r?n[this.getEnabledIndexInBounds(t+1,n.length)]:t>=0?e:n[0];this.activeIndex=this.enabledOptions.indexOf(i)}clearTimeout(this.searchTimeout),this.searchTimeout=setTimeout(()=>{this.searchString=``,this.searchTimeout=void 0},this.searchTimeoutMs)}keydownHandler(e){let t=0;switch(e.key){case`ArrowUp`:e.preventDefault(),t=-1;break;case`ArrowDown`:e.preventDefault(),t=1;break;case` `:case`Enter`:case`Tab`:if(e.key===` `){if(this.isCombobox)break;e.preventDefault()}if(this.open){if(this.selectOption(this.activeIndex,!0),this.multiple)break;return this.listbox.hidePopover(),e.key===`Tab`}this.listbox.showPopover();break;case`Escape`:this.activeIndex=this.multiple?0:this.selectedIndex,this.listbox.hidePopover()}if(!t)return!this.isCombobox&&e.key.length===1&&e.key!==` `&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&(this.open||this.listbox.showPopover(),this.handleSearchCharacter(e.key)),!0;if(!this.open){this.listbox.showPopover();return}let n=this.activeIndex;n+=t;let r=this.getEnabledIndexInBounds(n);return r===0&&this.freeformOption?.hidden&&(r=this.getEnabledIndexInBounds(n+t)),this.activeIndex=r,!0}mousedownHandler(e){if(!(this.disabled||e.target===this.control&&!this.isCombobox))return!jl(e.target)}reportValidity(){return this.elementInternals.reportValidity()}selectOption(e=this.selectedIndex,t=!1){this.listbox.selectOption(e),this.control&&(this.control.value=this.displayValue),this.setValidity(),this.updateFreeformOption(),t&&this.$emit(`change`)}setValidity(e,t,n){if(!this.elementInternals)return;if(this.disabled||!this.required){this.elementInternals.setValidity({});return}let r=this.required&&this.listbox.selectedOptions.length===0;this.elementInternals.setValidity({valueMissing:r,...e},t??this.validationMessage,n??this.control)}slotchangeHandler(e){let t=e.target;Ll(this,()=>{let e=t.assignedElements().find(e=>kl(e));e&&(this.listbox=e)})}updateFreeformOption(e=this.control.value){if(this.freeformOption){if(e===``||this.filterOptions(e,this.enabledOptions.filter(e=>!e.freeform)).length){this.freeformOption.value=``,this.freeformOption.selected=!1,this.freeformOption.hidden=!0;return}this.freeformOption.value=e,this.freeformOption.hidden=!1}}connectedCallback(){super.connectedCallback(),f.enqueue(()=>{this.insertControl()}),gs(this)}disconnectedCallback(){e.AnchorPositionFallbackObserver?.disconnect(),this.debounceController?.abort(),this.searchTimeout&&(clearTimeout(this.searchTimeout),this.searchTimeout=void 0,this.searchString=``),super.disconnectedCallback()}anchorPositionFallback(t){if(e.AnchorPositionFallbackObserver||=new IntersectionObserver(e=>{e.forEach(({boundingClientRect:e,isIntersecting:t,target:n})=>{if(kl(n)){if(e.bottom>window.innerHeight){R(n.elementInternals,`flip-block`,!0);return}e.top<0&&R(n.elementInternals,`flip-block`,!1)}})},{threshold:1}),t){this.debounceController=new AbortController,e.AnchorPositionFallbackObserver.observe(this.listbox),window.addEventListener(`scroll`,this.repositionListbox,{passive:!0,capture:!0,signal:this.debounceController.signal}),window.addEventListener(`resize`,this.repositionListbox,{passive:!0,signal:this.debounceController.signal}),this.repositionListbox();return}e.AnchorPositionFallbackObserver.unobserve(this.listbox),this.debounceController?.abort(),this.frameId&&=(cancelAnimationFrame(this.frameId),void 0)}};I([Ot],U.prototype,`activeDescendant`,null),I([m],U.prototype,`activeIndex`,void 0),I([g({attribute:`aria-labelledby`,mode:`fromView`})],U.prototype,`ariaLabelledBy`,void 0),I([m],U.prototype,`control`,void 0),I([g({mode:`boolean`})],U.prototype,`disabled`,void 0),I([Ot],U.prototype,`displayValue`,null),I([g({attribute:`id`})],U.prototype,`id`,void 0),I([m],U.prototype,`indicator`,void 0),I([m],U.prototype,`indicatorSlot`,void 0),I([g({attribute:`value`,mode:`fromView`})],U.prototype,`initialValue`,void 0),I([m],U.prototype,`listbox`,void 0),I([g({mode:`boolean`})],U.prototype,`multiple`,void 0),I([g],U.prototype,`name`,void 0),I([m],U.prototype,`open`,void 0),I([g],U.prototype,`placeholder`,void 0),I([g({mode:`boolean`})],U.prototype,`required`,void 0),I([g],U.prototype,`type`,void 0),I([g({attribute:`value`})],U.prototype,`valueAttribute`,void 0);var Rl=class extends U{constructor(){super(...arguments),this.appearance=hl.outline}};I([g],Rl.prototype,`appearance`,void 0),I([g],Rl.prototype,`size`,void 0),Rl.define(Ol);var zl=v`
  ${S(`inline-flex`)}

  :host {
    background-color: ${E};
    border-radius: ${O};
    border: ${P} solid ${D};
    box-shadow: ${_o};
    box-sizing: border-box;
    flex-direction: column;
    margin: 0;
    min-inline-size: 160px;
    padding: ${Co};
    row-gap: ${F};
    width: auto;
  }

  :host([popover]) {
    inset: unset;
    overflow: auto;
  }

  @supports (anchor-name: --anchor) {
    :host([popover]) {
      position: fixed;
      max-block-size: var(--listbox-max-height, calc(50vh - anchor-size(self-block)));
      min-inline-size: anchor-size(inline);
      inset-block-start: anchor(outside);
      inset-inline-start: anchor(inside);
      position-try-fallbacks: flip-block, flip-inline, flip-inline flip-block;
    }
  }

  @supports not (anchor-name: --anchor) {
    :host([popover]) {
      margin-block-start: var(--margin-offset, 0);
      max-block-size: var(--listbox-max-height, 50vh);
      position: absolute;
    }

    :host([popover]${js}) {
      margin-block-start: revert;
      translate: 0 -100%;
    }
  }
`;function Bl(){return b`
    <template
      @beforetoggle="${(e,t)=>e.beforetoggleHandler(t.event)}"
      @click="${(e,t)=>e.clickHandler(t.event)}"
    >
      <slot ${y(`defaultSlot`)} @slotchange="${(e,t)=>e.slotchangeHandler(t.event)}"></slot>
    </template>
  `}var Vl=Bl(),Hl={name:Al,registry:e.registry,styles:zl,template:Vl},Ul=class extends _{defaultSlotChanged(){this.slotchangeHandler()}multipleChanged(e,t){this.elementInternals.ariaMultiSelectable=t?`true`:`false`,R(this.elementInternals,`multiple`,t),f.enqueue(()=>{this.options.forEach(e=>{e.multiple=!!t})})}optionsChanged(e,t){t?.forEach((e,n)=>{e.elementInternals.ariaPosInSet=`${n+1}`,e.elementInternals.ariaSetSize=`${t.length}`})}beforetoggleHandler(e){if(!this.dropdown)return!0;if(this.dropdown.disabled){this.dropdown.open=!1;return}return this.dropdown.open=e.newState===`open`,!0}get enabledOptions(){return this.options?.filter(e=>!e.disabled)??Array.from(this.querySelectorAll(`*`)).filter(e=>jl(e)&&!e.disabled)??[]}get selectedOptions(){return this.options?.filter(e=>e.selected)??[]}clickHandler(e){if(this.dropdown)return!0;let t=e.target;return jl(t)&&this.selectOption(this.enabledOptions.indexOf(t)),!0}constructor(){super(),this.elementInternals=this.attachInternals(),this.elementInternals.role=`listbox`}connectedCallback(){super.connectedCallback(),Ll(this,()=>{this.id=this.id||Yc(`listbox-`)},{shallow:!0})}handleChange(e,t){if(t===`multiple`){this.multiple=e.multiple;return}}selectOption(e=this.selectedIndex){let t=this.selectedIndex;if(!this.multiple)this.enabledOptions.forEach((n,r)=>{let i=r===e;n.selected=i,i&&(t=r)});else{let n=this.enabledOptions[e];n&&(n.selected=!n.selected),t=e}this.selectedIndex=t}slotchangeHandler(e){Ll(this,()=>{if(this.defaultSlot){let e=this.defaultSlot.assignedElements().filter(e=>jl(e));this.options=e}})}};I([m],Ul.prototype,`defaultSlot`,void 0),I([m],Ul.prototype,`multiple`,void 0),I([m],Ul.prototype,`options`,void 0),I([m],Ul.prototype,`selectedIndex`,void 0),I([m],Ul.prototype,`dropdown`,void 0),Ul.define(Hl);var Wl=v`
  ${S(`inline-grid`)}

  :host {
    -webkit-tap-highlight-color: transparent;
    ${vl}
    align-items: center;
    background-color: ${E};
    border-radius: ${O};
    box-sizing: border-box;
    color: ${sr};
    column-gap: ${Co};
    cursor: pointer;
    grid-template-areas: 'indicator start content';
    grid-template-columns: auto auto 1fr;
    min-height: 32px;
    padding: ${wo};
    text-align: start;
  }

  .content {
    grid-area: content;
    line-height: 1;
  }

  ::slotted([slot='start']) {
    grid-area: start;
  }

  :host(:hover) {
    background-color: ${jr};
    color: ${cr};
  }

  :host(:active) {
    background-color: ${Mr};
    color: ${lr};
  }

  :host(${B}) {
    background-color: ${E};
    color: ${T};
    cursor: default;
  }

  .checkmark-16-filled {
    fill: currentColor;
    width: 16px;
  }

  slot[name='checked-indicator'] > *,
  ::slotted([slot='checked-indicator']) {
    aspect-ratio: 1;
    flex: 0 0 auto;
    grid-area: indicator;
    visibility: hidden;
  }

  :host(${Vs}) :is(slot[name='checked-indicator'] > *, ::slotted([slot='checked-indicator'])) {
    visibility: visible;
  }

  :host(${Ps}) .checkmark-16-filled,
  :host(:not(${Ps})) .checkmark-12-regular {
    display: none;
  }

  :host(${Ps}) .checkmark-12-regular {
    background-color: ${E};
    border-radius: ${Wa};
    border: ${P} solid ${ti};
    box-sizing: border-box;
    cursor: pointer;
    fill: transparent;
    position: relative;
    visibility: visible;
    width: 16px;
  }

  :host(${Ps}${Vs}) .checkmark-12-regular {
    background-color: ${Xr};
    border-color: ${li};
    fill: ${wr};
  }

  :host(${B}${Ps}) .checkmark-12-regular {
    border-color: ${fi};
  }

  :host(${B}${Ps}${Vs}) .checkmark-12-regular {
    background-color: ${Gr};
  }

  :host(${Es}) {
    border: ${bo} solid ${hi};
  }

  @supports (selector(:host(:has(*)))) {
    :host(:has([slot='start']:not([size='16']))) {
      column-gap: ${wo};
    }
  }

  :host(${ks}) {
    column-gap: ${wo};
    grid-template-areas:
      'indicator start content'
      'indicator start description';
  }

  ::slotted([slot='description']) {
    color: ${w};
    grid-area: description;
    ${bl}
  }

  @media (forced-colors: active) {
    :host(${B}) {
      color: GrayText;
    }
  }
`,Gl=b.partial(`
  <svg aria-hidden="true" class="checkmark-16-filled" viewBox="0 0 16 16">
    <path
      d="M14.046 3.486a.75.75 0 0 1-.032 1.06l-7.93 7.474a.85.85 0 0 1-1.188-.022l-2.68-2.72a.75.75 0 1 1 1.068-1.053l2.234 2.267l7.468-7.038a.75.75 0 0 1 1.06.032"
    />
  </svg>
  <svg aria-hidden="true" class="checkmark-12-regular" viewBox="0 0 12 12">
    <path
      d="M9.854 3.146a.5.5 0 0 1 0 .708l-4.5 4.5a.5.5 0 0 1-.708 0l-2-2a.5.5 0 1 1 .708-.708L5 7.293l4.146-4.147a.5.5 0 0 1 .708 0"
    />
  </svg>
`);function Kl(e={}){return b`
    <slot name="checked-indicator">${cs(e.checkedIndicator)}</slot>
    ${ds(e)}
    <div class="content" part="content">
      <slot ${x({property:`freeformOutputs`,filter:Gt(`output`)})}></slot>
    </div>
    <div class="description" part="description">
      <slot name="description" ${x(`descriptionSlot`)}></slot>
    </div>
  `}var ql=Kl({checkedIndicator:Gl}),Jl={name:Ml,registry:e.registry,styles:Wl,template:ql},W=class extends _{activeChanged(e,t){R(this.elementInternals,`active`,t)}currentSelectedChanged(e,t){this.selected=!!t}defaultSelectedChanged(e,t){this.selected=!!t}descriptionSlotChanged(e,t){R(this.elementInternals,`description`,!!t?.length)}disabledChanged(e,t){this.elementInternals.ariaDisabled=this.disabled?`true`:`false`,R(this.elementInternals,`disabled`,this.disabled),this.setFormValue(!this.disabled&&this.selected?this.value:null)}disabledAttributeChanged(e,t){this.disabled=!!t}initialValueChanged(e,t){this._value=t}multipleChanged(e,t){R(this.elementInternals,`multiple`,t),this.selected=!1}get form(){return this.elementInternals.form}static{this.formAssociated=!0}get labels(){return Object.freeze(Array.from(this.elementInternals.labels))}get selected(){return p.track(this,`selected`),!!this.currentSelected}set selected(e){this.currentSelected=e,f.enqueue(()=>{this.elementInternals&&(this.setFormValue(e?this.value:null),this.elementInternals.ariaSelected=e?`true`:`false`,R(this.elementInternals,`selected`,e))}),p.notify(this,`selected`)}get text(){return this.freeform?this.value.replace(/\s+/g,` `).trim():(this.textAttribute??this.textContent)?.replace(/\s+/g,` `).trim()??``}get value(){return p.track(this,`value`),this._value??this.text}set value(e){this._value=e,this.$fastController.isConnected&&(this.setFormValue(this.selected?e:null),this.freeformOutputs?.forEach(t=>{t.value=e}),p.notify(this,`value`))}connectedCallback(){super.connectedCallback(),this.freeform&&(this.value=``,this.hidden=!0,this.selected=!1)}constructor(){super(),this.active=!1,this.id=Yc(`option-`),this.initialValue=``,this.multiple=!1,this.elementInternals=this.attachInternals(),this._value=this.initialValue,this.elementInternals.role=`option`}setFormValue(e,t){if(this.disabled){this.elementInternals.setFormValue(null);return}this.elementInternals.setFormValue(e,e??t)}toggleSelected(e=!this.selected){this.selected=e}};I([m],W.prototype,`active`,void 0),I([g({attribute:`current-selected`,mode:`boolean`})],W.prototype,`currentSelected`,void 0),I([g({attribute:`selected`,mode:`boolean`})],W.prototype,`defaultSelected`,void 0),I([m],W.prototype,`descriptionSlot`,void 0),I([m],W.prototype,`disabled`,void 0),I([g({attribute:`disabled`,mode:`boolean`})],W.prototype,`disabledAttribute`,void 0),I([g({attribute:`form`})],W.prototype,`formAttribute`,void 0),I([g({mode:`boolean`})],W.prototype,`freeform`,void 0),I([g({attribute:`id`})],W.prototype,`id`,void 0),I([g({attribute:`value`,mode:`fromView`})],W.prototype,`initialValue`,void 0),I([m],W.prototype,`multiple`,void 0),I([g],W.prototype,`name`,void 0),I([m],W.prototype,`start`,void 0),I([g({attribute:`text`,mode:`fromView`})],W.prototype,`textAttribute`,void 0),W.define(Jl);var Yl={horizontal:`horizontal`,vertical:`vertical`},Xl={subtle:`subtle`,transparent:`transparent`},Zl=Yl,Ql=`${e.prefix}-tablist`,$l=v`
  ${S(`flex`)}

  :host {
    --tabPaddingInline: ${Eo};
    --tabPaddingBlock: ${Do};
    --tabIndicatorInsetInline: var(--tabPaddingInline);
    --tabIndicatorInsetBlock: 0;
    box-sizing: border-box;
    color: ${sr};
    flex-direction: row;
    position: relative;
  }

  :host([size='small']) {
    --tabPaddingBlock: ${No};
    --tabPaddingInline: ${wo};
  }

  :host([size='large']) {
    --tabPaddingBlock: ${Lo};
    --tabPaddingInline: ${Eo};
  }

  :host([orientation='vertical']) {
    --tabPaddingBlock: ${Po};
    --tabIndicatorInsetBlock: ${Po};
    --_col-start-width: 0px;
    display: grid;
    grid-template-columns: ${Eo} var(--_col-start-width) 1fr auto ${Eo};
  }

  :host(:has([slot='start'])) {
    --_col-start-width: 24px;
  }

  @scope {
    :scope:has([slot='start']) {
      --_col-start-width: 24px;
    }
  }

  :host([orientation='vertical'][size='small']) {
    --tabPaddingBlock: ${jo};
    --tabIndicatorInsetBlock: ${No};
  }

  :host([orientation='vertical'][size='large']) {
    --tabPaddingBlock: ${Po};
    --tabIndicatorInsetBlock: ${Fo};
  }

  ::slotted([slot='tab']) {
    padding-inline: var(--tabPaddingInline);
    padding-block: var(--tabPaddingBlock);
  }

  :host([orientation='vertical']) ::slotted([role='tab']) {
    justify-content: flex-start;
    display: grid;
    gap: 0;
    grid-column: 1 / -1;
    grid-template-columns: subgrid;
    grid-row: unset;
    padding-inline: 0;
  }

  :host ::slotted([slot='tab'])::after {
    height: ${xo};
    margin-block-start: auto;
  }

  :host([orientation='vertical']) ::slotted([slot='tab'])::after {
    width: ${xo};
    height: unset;
    margin-block-start: unset;
  }

  /* ::before adds a secondary indicator placeholder that appears right after click on the active tab */
  :host ::slotted([slot='tab'])::before {
    height: ${xo};
    border-radius: ${qa};
    content: '';
    inset-inline: var(--tabIndicatorInsetInline);
    inset-block: var(--tabIndicatorInsetBlock);
    position: absolute;
    margin-top: auto;
  }

  :host ::slotted([slot='tab'])::before {
    inset-inline: var(--tabIndicatorInsetInline);
    inset-block: var(--tabIndicatorInsetBlock);
  }

  :host ::slotted([slot='tab'][aria-selected='true'])::before {
    background-color: ${T};
  }

  :host ::slotted([slot='tab'][aria-selected='false']:hover)::after {
    height: ${xo};
    margin-block-start: auto;
    transform-origin: left;
  }

  :host([orientation='vertical']) ::slotted([slot='tab'])::before,
  :host([orientation='vertical']) ::slotted([slot='tab'][aria-selected='false']:hover)::after {
    height: unset;
    width: ${xo};
    margin-inline-end: auto;
    transform-origin: top;
  }

  :host([size='small']) ::slotted([slot='tab']) {
    font-size: ${A};
    line-height: ${N};
  }

  :host([size='large']) ::slotted([slot='tab']) {
    font-size: ${Xa};
    line-height: ${oo};
  }

  /* horizontal spacing for indicator */
  :host ::slotted([slot='tab'])::after,
  :host ::slotted([slot='tab'])::before,
  :host ::slotted([slot='tab']:hover)::after {
    inset-inline: var(--tabIndicatorInsetInline);
  }

  :host([orientation='vertical']) ::slotted([slot='tab'])::after,
  :host([orientation='vertical']) ::slotted([slot='tab'])::before,
  :host([orientation='vertical']) ::slotted([slot='tab']:hover)::after {
    inset-inline: 0;
    inset-block: var(--tabIndicatorInsetBlock);
  }

  /* disabled styles */
  :host([disabled]) {
    cursor: not-allowed;
    color: ${T};
  }

  :host([disabled]) ::slotted([slot='tab']) {
    pointer-events: none;
    cursor: not-allowed;
    color: ${T};
  }

  :host([disabled]) ::slotted([slot='tab']:after) {
    background-color: ${T};
  }

  :host([disabled]) ::slotted([slot='tab'][aria-selected='true'])::after {
    background-color: ${T};
  }

  :host([disabled]) ::slotted([slot='tab']:hover):before {
    content: unset;
  }

  :host([appearance='subtle']) ::slotted([slot='tab']:hover) {
    background-color: ${Br};
    color: ${ar};
    fill: ${xr};
  }

  :host([appearance='subtle']) ::slotted([slot='tab']:active) {
    background-color: ${Vr};
    fill: ${Vr};
    color: ${C};
  }

  /*
   * TODO: Remove '(text-size-adjust: auto)' after this bug is fixed:
   * https://bugs.webkit.org/show_bug.cgi?id=298646
   * Also remove the same trick from tab.styles.ts.
   * Using '@supports (text-size-adjust: auto)' here to exclude Safari 26.0 from
   * using CSS Anchor Positioning here because it crashes.
   */
  @supports (anchor-name: --a) and (text-size-adjust: auto) {
    ::slotted([slot='tab'][aria-selected='true']) {
      anchor-name: --tab;
    }

    :host::after {
      background-color: ${li};
      content: '';
      inline-size: 100%;
      inset-block: auto anchor(end);
      inset-inline: anchor(center) auto;
      position: fixed;
      position-anchor: --tab;
      transform: translateX(-50%);
      transition-property: inset-inline, width;
      transition-duration: ${Uo};
      transition-timing-function: ${Yo};
      z-index: 3;

      /* These styles should be in sync with tab.styles.ts’s :host::after */
      border-radius: ${qa};
      width: calc(anchor-size() - var(--tabIndicatorInsetInline) * 2);
      height: ${xo};
    }

    :host(:dir(rtl))::after {
      transform: translateX(50%);
    }

    :host([orientation='vertical'])::after {
      inset-block: anchor(center) auto;
      inset-inline: anchor(start) auto;
      transform: translateY(-50%);
      transition-property: inset-block, height;

      /* These styles should be in sync with #vertical-tab-highlight above */
      width: ${xo};
      height: calc(anchor-size() - var(--tabIndicatorInsetBlock) * 2);
    }

    :host([disabled])::after {
      background-color: ${T};
    }
  }
`,eu=b`
  <template
    role="tablist"
    focusgroup="tablist inline block"
    @click="${(e,t)=>e.handleClick(t.event)}"
    @focusin="${(e,t)=>e.handleFocusIn(t.event)}"
  >
    <slot name="tab" ${x(`slottedTabs`)}></slot>
  </template>
`,tu={name:Ql,registry:e.registry,styles:$l,template:eu},nu={INFERRED_ROLE:`data-fg-ir`,ITEM:`data-fg-item`,AUTHOR_TABINDEX:`data-fg-ati`,SEGMENT:`data-fg-seg`,SEGMENT_START:`data-fg-segs`},ru={TOOLBAR:`toolbar`,TABLIST:`tablist`,RADIOGROUP:`radiogroup`,LISTBOX:`listbox`,MENU:`menu`,MENUBAR:`menubar`,NONE:`none`};ru.TOOLBAR,ru.TABLIST,ru.RADIOGROUP,ru.LISTBOX,ru.MENU,ru.MENUBAR,ru.NONE;function iu(e,t){return e.contains(t)}function au(){return`focusgroup`in(globalThis?.HTMLElement?.prototype??{})||`focusGroup`in(globalThis?.HTMLElement?.prototype??{})}function ou(e,t,n){let r=`forward`,i=`backward`,a=`block`,o=`inline`;if(su(e.composedPath()[0]))return e.key===`Tab`?e.shiftKey?i:r:null;if(e.shiftKey||e.ctrlKey||e.metaKey)return null;let{writingMode:s,direction:c}=window.getComputedStyle(t),l=!s.startsWith(`horizontal-`),u=c===`rtl`,d=l?a:o,ee=l?o:a,te=l?s.endsWith(`-rl`)!==u:u,ne=l&&u,re={ArrowUp:{axis:ee,dir:ne?r:i},ArrowDown:{axis:ee,dir:ne?i:r},ArrowLeft:{axis:d,dir:te?r:i},ArrowRight:{axis:d,dir:te?i:r},Home:{dir:`start`},End:{dir:`end`}}[e.key];return!re||n&&re.axis&&re.axis!==n?null:re.dir}function su(e){return e?.nodeType===Node.ELEMENT_NODE&&([`INPUT`,`TEXTAREA`,`SELECT`].includes(e.nodeName)&&![`checkbox`,`radio`].includes(e.getAttribute(`type`))||e.isContentEditable||[`AUDIO`,`VIDEO`].includes(e.nodeName)&&e.hasAttribute(`controls`)||[`IFRAME`,`OBJECT`].includes(e.nodeName))}globalThis.__FOCUSGROUP_POLYFILL__??={o:new Set,b:!1};var cu=globalThis.__FOCUSGROUP_POLYFILL__.o;function lu(){for(let e of cu)e.takeRecords()}var uu=class{#e;#t;#n=null;#r=void 0;#i=!1;#a=!0;#o;#s=null;#c=!1;#l=null;#u=new AbortController;#d;#f;constructor(e,t,n={}){if(au()||!e)return;this.#e=e,this.#t=t,this.#d=n.decorateOwner,this.#f=n.decorateItem,this.#p(n.definition),this.#d?.(this.#e,this.#n),this.#m();let r={signal:this.#u.signal};this.#e.addEventListener(`keydown`,this.#g.bind(this),r),this.#e.addEventListener(`focusin`,this.#_.bind(this),r),this.#e.addEventListener(`focusout`,this.#v.bind(this),r)}disconnect(){this.#b(),this.#u.abort(),this.#t?.disconnect?.(),this.#e=null}update(e={}){if(this.#e){if(e.definition!==void 0&&(this.#p(e.definition),this.#d?.(this.#e,this.#n)),e.authorTabindexChanges)for(let t of e.authorTabindexChanges)t.setAttribute(nu.AUTHOR_TABINDEX,t.getAttribute(`tabindex`)??`none`);this.#h(),this.#m()}}#p(e){this.#n=e?.behavior??null,this.#i=e?.wrap??!1,this.#r=e?.axis,this.#a=e?.memory??!0,this.#a||(this.#s=null)}#m(){if(!this.#n||this.#n===ru.NONE){this.#h();return}this.#t.decorate?.();for(let{element:e,segmentBoundary:t}of this.#t.items())this.#f?.(e,this.#n),e.setAttribute(nu.AUTHOR_TABINDEX,e.getAttribute(`tabindex`)??`none`),e.tabIndex=t?0:-1;(!this.#s?.isConnected||!(this.#t.isItem?.(this.#s)??this.#t.contains(this.#s)))&&(this.#s=null);let e=this.#s??this.#t.start??this.#t.first?.()??null;e&&(e.tabIndex=0,this.#o=e,this.#b(),this.#y(e)),this.#t.flush?.()}#h(){this.#b();let e=!1;for(let{element:t}of this.#t.items()){e=!0,this.#f?.(t,null);let n=t.getAttribute(nu.AUTHOR_TABINDEX);n&&(n===`none`?t.removeAttribute(`tabindex`):t.setAttribute(`tabindex`,n),t.removeAttribute(nu.AUTHOR_TABINDEX))}this.#t.undecorate?.(),e&&this.#t.flush?.()}#g(e){let t=e.composedPath()[0];if(e.defaultPrevented||t===this.#e||!this.#t.contains(t))return;let n;switch(ou(e,t,this.#r)){case`start`:n=this.#t.first();break;case`end`:n=this.#t.last();break;case`forward`:n=this.#t.next(t),!n&&this.#i&&(n=this.#t.first());break;case`backward`:n=this.#t.previous(t),!n&&this.#i&&(n=this.#t.last())}n&&n!==t&&(this.#x(t,n,!0),this.#s=n,e.preventDefault())}#_(e){let t=e.composedPath()[0];if(t===this.#e&&this.#c&&(!e.relatedTarget||!iu(this.#e,e.relatedTarget))){let t=this.#s||this.#o;this.#b(),t&&t.focus(),e.stopPropagation();return}if(!this.#t.contains(t))return;this.#c&&this.#b();let n=this.#s;if(this.#s=t,n!==t&&t.tabIndex<0){let e=n??this.#o;e&&this.#x(e,t)}}#v(e){if(!e.relatedTarget||!iu(this.#e,e.relatedTarget)){let e=this.#a&&this.#s||this.#o;e&&this.#y(e)}if(e.relatedTarget&&iu(this.#e,e.relatedTarget)||this.#a||!this.#o)return;let t=this.#s;this.#s=null;let n=this.#t.start??this.#t.first?.()??null;if(t!==this.#o||n!==this.#o){for(let{element:e,segmentBoundary:t}of this.#t.items())e.tabIndex=t?0:-1;n&&(n.tabIndex=0,this.#o=n),this.#t.flush?.()}}#y(e){let t=(e.assignedSlot??e).getRootNode(),n=t instanceof ShadowRoot&&t.host.hasAttribute(nu.AUTHOR_TABINDEX);this.#c||!n||(this.#l=this.#e.getAttribute(`tabindex`),this.#e.tabIndex=0,this.#c=!0,lu())}#b(){this.#c&&(this.#l===null?this.#e.removeAttribute(`tabindex`):this.#e.setAttribute(`tabindex`,this.#l),this.#c=!1,this.#l=null,this.#t.flush?.(),lu())}#x(e,t,n=!1){t.tabIndex=0,n&&t.focus(),e.tabIndex=this.#t.sameSegment?.(e,t)??!0?-1:0,this.#b(),lu()}},du=class{constructor(e,t){this.getItems=e,this.getStart=t}get start(){return this.getStart?.()??null}first(){return this.getItems()[0]??null}last(){let e=this.getItems();return e[e.length-1]??null}next(e){let t=this.getItems(),n=t.indexOf(e);return n===-1?null:t[n+1]??null}previous(e){let t=this.getItems(),n=t.indexOf(e);return n<=0?null:t[n-1]??null}*items(){for(let e of this.getItems())yield{element:e}}contains(e){return this.getItems().includes(e)}};function fu(e,t=`-tab`){return e?.nodeType===Node.ELEMENT_NODE&&e.tagName.toLowerCase().endsWith(t)}var pu=`${e.prefix}-tab`,mu=class extends _{disabledChanged(e,t){this.elementInternals&&R(this.elementInternals,`disabled`,t),this.setTabs({forceDisabled:!0})}orientationChanged(e,t){this.elementInternals&&(this.elementInternals.ariaOrientation=t??Zl.horizontal,Ts(this.elementInternals,e,t,Zl)),this.setTabs()}activeidChanged(e,t){this.tabs?.length>0&&this.changeTab(e,t)}slottedTabsChanged(e,t){this.tabs=t?.filter(e=>fu(e))??[]}tabsChanged(e,t){this.tabs?.length>0&&this.setTabs({connectToPanel:!0})}setTabs({connectToPanel:e=!1,forceDisabled:t=!1}={}){if(!this.tabs)return;let n=this.getRootNode(),r=``;for(let i of this.tabs){if(i.slot!==`tab`)continue;i.id||=Yc(`tab-`),i.disabled=t?this.disabled:i.disabled||this.disabled,!r&&!i.disabled&&(r=i.id);let a=this.activeid===i.id;if(i.toggleAttribute(`focusgroupstart`,a),i.setAttribute(`aria-selected`,a.toString()),e){let e=i.getAttribute(`aria-controls`)??``,t=n.getElementById(e);e&&t&&(t.role??=`tabpanel`,t.hidden=this.activeid!==i.id,this.tabPanelMap.set(i,t))}}this.disabled||(this.activeid?this.changeTab(void 0,this.activeid):r&&(this.activeid=r))}handleFocusIn(e){this.activeid=e.target.id}handleClick(e){e.isTrusted||(this.activeid=e.target.id)}changeTab(e,t){let n=this.getRootNode(),r=e?n.getElementById(e):null,i=n.getElementById(t);if(!fu(i)||i.disabled||!this.contains(i))return;if(r){r.setAttribute(`aria-selected`,`false`);let e=this.tabPanelMap.get(r);e&&(e.hidden=!0)}i.setAttribute(`aria-selected`,`true`);let a=this.tabPanelMap.get(i);a&&(a.hidden=!1),this.activetab=i,this.change()}constructor(){super(),this.elementInternals=this.attachInternals(),this.disabled=!1,this.orientation=Zl.horizontal,this.tabs=[],this.tabPanelMap=new WeakMap,this.change=()=>{this.$emit(`change`,this.activetab)},this.elementInternals.role=`tablist`,this.elementInternals.ariaOrientation=this.orientation??Zl.horizontal}connectedCallback(){super.connectedCallback(),Ll(this,()=>{this.setTabs()},{shallow:!0})}};I([g({mode:`boolean`})],mu.prototype,`disabled`,void 0),I([g],mu.prototype,`orientation`,void 0),I([g],mu.prototype,`activeid`,void 0),I([m],mu.prototype,`slottedTabs`,void 0),I([m],mu.prototype,`tabs`,void 0);var hu=class extends mu{constructor(){super(...arguments),this.appearance=Xl.transparent}disconnectedCallback(){this.fg?.disconnect(),super.disconnectedCallback()}tabsChanged(e,t){super.tabsChanged(e,t),this.fgItems??=new du(()=>this.tabs?.filter(e=>(e.getAttribute(`aria-selected`)===`true`||!e.disabled)&&!e.hidden)??[],()=>this.activetab??null),this.fg?this.fg.update():this.fg=new uu(this,this.fgItems,{definition:{behavior:`tablist`,axis:void 0,memory:!1,wrap:!0}})}};I([g],hu.prototype,`appearance`,void 0),I([g],hu.prototype,`size`,void 0),hu.define(tu);var gu=v`
  ${S(`inline-flex`)}

  :host {
    position: relative;
    flex-direction: row;
    align-items: center;
    cursor: pointer;
    box-sizing: border-box;
    justify-content: center;
    line-height: ${N};
    font-family: ${k};
    font-size: ${A};
    color: ${sr};
    fill: currentcolor;
    grid-row: 1;
    padding: ${Do} ${Eo};
    border-radius: ${O};
    gap: 4px;
  }

  :host .tab-content {
    display: inline-flex;
    flex-direction: column;
    padding: 0 2px;
    grid-column: 3;
  }

  :host([aria-selected='true']) {
    color: ${C};
    font-weight: ${M};
  }

  /* adds hidden textContent to prevent shifting ui on bold / unbolding of text */
  :host .tab-content::after {
    content: var(--textContent);
    visibility: hidden;
    height: 0;
    line-height: ${N};
    font-weight: ${M};
  }

  :host([aria-selected='true'])::after {
    background-color: ${li};
    border-radius: ${qa};
    content: '';
    inset: 0;
    position: absolute;
    z-index: 2;
  }

  :host([aria-selected='false']:hover)::after {
    background-color: ${ai};
    border-radius: ${qa};
    content: '';
    inset: 0;
    position: absolute;
    z-index: 1;
  }

  /*
   * TODO: Remove '(text-size-adjust: auto)' after this bug is fixed:
   * https://bugs.webkit.org/show_bug.cgi?id=298646
   * Also remove the same trick from tablist.styles.ts.
   * Using '@supports (text-size-adjust: auto)' here to exclude Safari 26 from
   * using CSS Anchor Positioning here because it crashes.
   */
  @supports (anchor-name: --a) and (text-size-adjust: auto) {
    :host([aria-selected='true'])::after {
      background-color: transparent;
    }

    :host([aria-selected='true']:hover)::after {
      background-color: ${ai};
    }
  }

  :host([aria-selected='true'][disabled])::after {
    background-color: ${T};
  }

  ::slotted([slot='start']) {
    grid-column: 2;
  }

  ::slotted([slot='end']) {
    grid-column: -1;
  }

  ::slotted([slot='start']),
  ::slotted([slot='end']) {
    display: flex;
  }
  :host([disabled]) {
    cursor: not-allowed;
    fill: ${T};
    color: ${T};
    pointer-events: none;
  }

  :host([disabled]:hover)::after {
    background-color: unset;
  }

  :host(:focus) {
    outline: none;
  }

  :host(:focus-visible) {
    border-radius: ${Wa};
    box-shadow: 0 0 0 3px ${hi};
    outline: 1px solid ${mi};
  }

  @media (forced-colors: active) {
    :host([aria-selected='true'])::after {
      background-color: Highlight;
    }
  }
`;function _u(e={}){return b`
    <template slot="tab" role="tab">
      ${ds(e)}
      <span class="tab-content"><slot></slot></span>
      ${us(e)}
    </template>
  `}var vu=_u({}),yu={name:pu,registry:e.registry,styles:gu,template:vu},bu=class extends _{disabledChanged(e,t){this.setDisabledSideEffect(t)}constructor(){super(),this.elementInternals=this.attachInternals(),this.elementInternals.role=`tab`}connectedCallback(){super.connectedCallback(),this.slot||=`tab`,this.setDisabledSideEffect(this.disabled),this.styles&&this.$fastController.removeStyles(this.styles),this.styles=v`
      :host {
        --textContent: '${this.textContent}';
      }
    `,this.$fastController.addStyles(this.styles),gs(this)}setDisabledSideEffect(e){e?this.setAttribute(`aria-disabled`,`true`):this.removeAttribute(`aria-disabled`),this.tabIndex=e&&this.getAttribute(`aria-selected`)!==`true`?-1:0}};I([g({mode:`boolean`})],bu.prototype,`disabled`,void 0),hs(bu,ls),bu.define(yu);var xu={single:`single`,multi:`multi`},Su=`${e.prefix}-accordion`,Cu=v`
  ${S(`flex`)}

  :host {
    flex-direction: column;
    width: 100%;
    contain: content;
  }
`;function wu(){return b`
    <template>
      <slot ${x({property:`slottedAccordionItems`,filter:Gt()})}></slot>
    </template>
  `}var Tu=wu(),Eu={name:Su,registry:e.registry,styles:Cu,template:Tu};function Du(e){return t=>t?.nodeType===Node.ELEMENT_NODE&&t.tagName.toLowerCase().endsWith(e)}function Ou(...e){return e.every(e=>e instanceof HTMLElement)}function ku(e,t=`-accordion-item`){return Du(t)(e)}var Au=`${e.prefix}-accordion-item`,ju=class extends _{constructor(){super(...arguments),this._isAdjusting=!1,this.activeItemIndex=0,this.setItems=()=>{Ll(this,()=>{if(!this.slottedAccordionItems?.length)return;let e=Array.from(this.children);if(this.removeItemListeners(e),e.forEach(e=>p.getNotifier(e).subscribe(this,`disabled`)),this.accordionItems=e.filter(e=>!e.hasAttribute(`disabled`)),this.accordionItems.forEach((e,t)=>{e.addEventListener(`click`,this.expandedChangedHandler),p.getNotifier(e).subscribe(this,`expanded`)}),this.isSingleExpandMode()){let e=this.findExpandedItem();this.setSingleExpandMode(e)}})},this.removeItemListeners=e=>{e.forEach((e,t)=>{p.getNotifier(e).unsubscribe(this,`disabled`),p.getNotifier(e).unsubscribe(this,`expanded`),e.removeEventListener(`click`,this.expandedChangedHandler)})},this.expandedChangedHandler=e=>{let t=e.target;ku(t)&&(this.isSingleExpandMode()?this.setSingleExpandMode(t):(t.expanded=!t.expanded,this.activeItemIndex=this.accordionItems.indexOf(t)),this.$emit(`change`))}}expandmodeChanged(e,t){if(!this.$fastController.isConnected)return;let n=this.findExpandedItem();if(n){if(t===xu.single){this.setSingleExpandMode(n);return}n?.expandbutton?.removeAttribute(`aria-disabled`)}}slottedAccordionItemsChanged(e,t){this.setItems()}handleChange(e,t){t===`disabled`?this.setItems():t===`expanded`&&e.expanded&&this.isSingleExpandMode()&&!this._isAdjusting&&(this._isAdjusting=!0,this.setSingleExpandMode(e),this._isAdjusting=!1)}findExpandedItem(){return!this.accordionItems||this.accordionItems?.length===0?null:this.accordionItems.find(e=>ku(e)&&e.expanded)??this.accordionItems[0]}isSingleExpandMode(){return this.expandmode===xu.single}setSingleExpandMode(e){if(this.accordionItems.length===0)return;let t=Array.from(this.accordionItems);this.activeItemIndex=t.indexOf(e),t.forEach((e,t)=>{ku(e)&&(this.activeItemIndex===t?(e.expanded=!0,e.expandbutton?.setAttribute(`aria-disabled`,`true`)):(e.expanded=!1,e.hasAttribute(`disabled`)||e.expandbutton?.removeAttribute(`aria-disabled`)))})}connectedCallback(){super.connectedCallback(),this.expandmode=this.expandmode||xu.multi,this.setItems()}};I([g({attribute:`expand-mode`})],ju.prototype,`expandmode`,void 0),I([m],ju.prototype,`slottedAccordionItems`,void 0),ju.define(Eu);var Mu=v`
  ${S(`block`)}

  :host {
    max-width: fit-content;
    contain: content;
    color: ${C};
  }

  .heading {
    height: 44px;
    display: grid;
    position: relative;
    padding-inline: ${Do} ${Eo};
    border-radius: ${O};
    font-family: ${k};
    font-size: ${A};
    font-weight: ${j};
    line-height: ${N};
    grid-template-columns: auto auto 1fr auto;
  }

  .button {
    appearance: none;
    background: ${Hr};
    border: none;
    box-sizing: border-box;
    color: inherit;
    cursor: pointer;
    font: inherit;
    grid-column: auto / span 2;
    grid-row: 1;
    height: 44px;
    outline: none;
    padding: 0;
    text-align: start;
  }

  .button::before {
    content: '';
    position: absolute;
    inset: 0px;
    cursor: pointer;
    border-radius: ${Wa};
  }

  :where(.default-marker-collapsed, .default-marker-expanded),
  ::slotted(:is([slot='marker-collapsed'], [slot='marker-expanded'])) {
    display: flex;
    align-items: center;
    justify-content: center;
    pointer-events: none;
    position: relative;
    height: 100%;
    padding-inline-end: ${To};
    grid-column: 1 / span 1;
    grid-row: 1;
  }

  .content {
    margin: 0 ${Do};
  }

  ::slotted([slot='start']) {
    display: flex;
    justify-content: center;
    align-items: center;
    padding-right: ${To};
    grid-column: 2 / span 1;
    grid-row: 1;
  }

  button:focus-visible::after {
    content: '';
    position: absolute;
    inset: 0px;
    cursor: pointer;
    border-radius: ${Wa};
    outline: none;
    border: 2px solid ${mi};
    box-shadow: inset 0 0 0 1px ${hi};
  }

  /* --- Disabled attr styles --- */

  :host([disabled]) .button {
    color: ${T};
  }

  :host([disabled]) svg {
    filter: invert(89%) sepia(0%) saturate(569%) hue-rotate(155deg) brightness(88%) contrast(87%);
  }

  /* --- Expanded attr styles --- */

  :host([expanded]) .content {
    display: block;
  }

  :host([expanded]) .default-marker-collapsed,
  :host([expanded]) ::slotted([slot='marker-collapsed']),
  :host(:not([expanded])) :is(.default-marker-expanded, .content),
  :host(:not([expanded])) ::slotted([slot='marker-expanded']) {
    display: none;
  }

  :host([expanded]) ::slotted([slot='marker-expanded']),
  :host(:not([expanded])) ::slotted([slot='marker-collapsed']) {
    display: flex;
  }

  /* --- Appearance attr styles --- */

  .heading {
    font-size: ${A};
    line-height: ${N};
  }

  :host([size='small']) .heading {
    font-size: ${Ya};
    line-height: ${ao};
  }

  :host([size='large']) .heading {
    font-size: ${Xa};
    line-height: ${oo};
  }

  :host([size='extra-large']) .heading {
    font-size: ${Za};
    line-height: ${so};
  }

  /* --- marker-position attr styles --- */

  :host([marker-position='end']) ::slotted([slot='start']) {
    grid-column: 1 / span 1;
    color: currentColor;
  }

  :host([marker-position='end']) :is(.default-marker-collapsed, .default-marker-expanded) {
    grid-column: 4 / span 1;
    padding-inline-start: ${To};
    padding-inline-end: 0;
  }

  :host([marker-position='end']) .button {
    grid-column: 2 / span 3;
  }

  /* --- Block attr styles --- */

  :host([block]) {
    max-width: 100%;
  }

  :host([marker-position='end']) .heading {
    grid-template-columns: auto auto 28px;
    padding-inline: ${Do};
  }

  :host([marker-position='end']:has([slot='start'])) .heading {
    padding-inline: ${Eo} ${Do};
  }

  :host([block][marker-position='end']) .heading {
    grid-template-columns: auto 1fr;
  }

  :host([marker-position='end']) :is(.default-marker-collapsed, .default-marker-expanded) {
    grid-column: 5 / span 1;
  }
`,Nu=b.partial(`<svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  class="default-marker-collapsed"
  aria-hidden="true"
>
  <path
    d="M7.73271 4.20694C8.03263 3.92125 8.50737 3.93279 8.79306 4.23271L13.7944 9.48318C14.0703 9.77285 14.0703 10.2281 13.7944 10.5178L8.79306 15.7682C8.50737 16.0681 8.03263 16.0797 7.73271 15.794C7.43279 15.5083 7.42125 15.0336 7.70694 14.7336L12.2155 10.0005L7.70694 5.26729C7.42125 4.96737 7.43279 4.49264 7.73271 4.20694Z"
    fill="currentColor"
  />
</svg>`),Pu=b.partial(`<svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  class="default-marker-expanded"
  aria-hidden="true"
>
  <path
    d="M15.794 7.73271C16.0797 8.03263 16.0681 8.50737 15.7682 8.79306L10.5178 13.7944C10.2281 14.0703 9.77285 14.0703 9.48318 13.7944L4.23271 8.79306C3.93279 8.50737 3.92125 8.03263 4.20694 7.73271C4.49264 7.43279 4.96737 7.42125 5.26729 7.70694L10.0005 12.2155L14.7336 7.70694C15.0336 7.42125 15.5083 7.43279 15.794 7.73271Z"
    fill="currentColor"
  />
</svg>`);function Fu(e={}){return b`
    <div class="heading" part="heading" role="heading" aria-level="${e=>e.headinglevel}">
      <button
        class="button"
        part="button"
        id="control"
        aria-controls="panel"
        aria-expanded="${e=>e.expanded}"
        ?disabled="${e=>e.disabled}"
        ${y(`expandbutton`)}
      >
        <slot name="heading"></slot>
      </button>
      ${ds(e)}
      <slot name="marker-expanded"> ${cs(e.expandedIcon)} </slot>
      <slot name="marker-collapsed"> ${cs(e.collapsedIcon)} </slot>
    </div>
    <div class="content" part="content" id="panel" role="region" aria-labelledby="control">
      <slot></slot>
    </div>
  `}var Iu=Fu({collapsedIcon:Nu,expandedIcon:Pu}),Lu={name:Au,registry:e.registry,styles:Mu,template:Iu},Ru=class extends _{constructor(){super(...arguments),this.elementInternals=this.attachInternals(),this.headinglevel=2,this.expanded=!1,this.disabled=!1}};I([g({attribute:`heading-level`,mode:`fromView`,converter:je})],Ru.prototype,`headinglevel`,void 0),I([g({mode:`boolean`})],Ru.prototype,`expanded`,void 0),I([g({mode:`boolean`})],Ru.prototype,`disabled`,void 0),I([m],Ru.prototype,`expandbutton`,void 0);var zu=class extends Ru{constructor(){super(...arguments),this.block=!1}};I([g],zu.prototype,`size`,void 0),I([g({attribute:`marker-position`})],zu.prototype,`markerPosition`,void 0),I([g({mode:`boolean`})],zu.prototype,`block`,void 0),hs(zu,ls),zu.define(Lu);function Bu(e,t=`-radio`){return Du(t)(e)}var Vu=`${e.prefix}-radio`,Hu=v`
  ${S(`inline-flex`)}

  :host {
    --size: 16px;
    aspect-ratio: 1;
    background-color: ${E};
    border: ${P} solid ${ti};
    border-radius: ${qa};
    box-sizing: border-box;
    position: relative;
    width: var(--size);
  }

  :host([size='large']) {
    --size: 20px;
  }

  .checked-indicator {
    aspect-ratio: 1;
    border-radius: ${qa};
    color: ${wr};
    inset: 0;
    margin: auto;
    position: absolute;
    width: calc(var(--size) * 0.625);
  }

  :host(:not([slot='input']))::after {
    content: '' / '';
    position: absolute;
    display: block;
    inset: -8px;
    box-sizing: border-box;
    outline: none;
    border: ${bo} solid ${D};
    border-radius: ${O};
  }

  :host(:not([slot='input']):focus-visible)::after {
    border-color: ${hi};
  }

  :host(:hover) {
    border-color: ${ni};
  }

  :host(${z}) {
    border-color: ${li};
  }

  :host(${z}) .checked-indicator {
    background-color: ${Xr};
  }

  :host(${z}:hover) .checked-indicator {
    background-color: ${Zr};
  }

  :host(:active) {
    border-color: ${ri};
  }

  :host(${z}:active) .checked-indicator {
    background-color: ${Qr};
  }

  :host(:focus-visible) {
    outline: none;
  }

  :host(${As}) {
    background-color: ${Gr};
    border-color: ${fi};
  }

  :host(${z}${As}) .checked-indicator {
    background-color: ${fi};
  }

  @media (forced-colors: active) {
    :host {
      border-color: FieldText;
    }

    :host(:not([slot='input']:focus-visible))::after {
      border-color: Canvas;
    }

    :host(:not(${As}):hover),
    :host(:not([slot='input']):focus-visible)::after {
      border-color: Highlight;
    }

    .checked-indicator {
      color: HighlightText;
    }

    :host(${z}) .checked-indicator {
      background-color: FieldText;
    }

    :host(${z}:not(${As}):hover) .checked-indicator {
      background-color: Highlight;
    }

    :host(${As}) {
      border-color: GrayText;
      color: GrayText;
    }

    :host(${As}${z}) .checked-indicator {
      background-color: GrayText;
    }
  }
`,Uu=b.partial(`
    <span part="checked-indicator" class="checked-indicator" role="presentation"></span>
`);function Wu(e={}){return b`
    <template
      @click="${(e,t)=>e.clickHandler(t.event)}"
      @keydown="${(e,t)=>e.keydownHandler(t.event)}"
      @keyup="${(e,t)=>e.keyupHandler(t.event)}"
    >
      <slot name="checked-indicator">${cs(e.checkedIndicator)}</slot>
    </template>
  `}var Gu=Wu({checkedIndicator:Uu}),Ku={name:Vu,registry:e.registry,styles:Hu,template:Gu};(class extends nc{constructor(){super(),this.elementInternals.role=`radio`}disabledChanged(e,t){super.disabledChanged(e,t),this.$emit(`disabled`,t,{bubbles:!0})}requiredChanged(){}setFormValue(){}setValidity(){this.elementInternals.setValidity({})}toggleChecked(e=!0){super.toggleChecked(e)}}).define(Ku);var qu=Yl,Ju=`${e.prefix}-radio-group`,Yu=v`
  ${S(`flex`)}

  :host {
    -webkit-tap-highlight-color: transparent;
    cursor: pointer;
    gap: ${Lo};
  }

  :host([orientation='vertical']) {
    flex-direction: column;
    justify-content: flex-start;
  }

  :host([orientation='horizontal']) {
    flex-direction: row;
  }

  ::slotted(*) {
    color: ${w};
  }

  ::slotted(:hover) {
    color: ${sr};
  }

  ::slotted(:active) {
    color: ${C};
  }

  ::slotted(${As}) {
    color: ${T};
  }

  ::slotted(${z}) {
    color: ${C};
  }

  :host([slot='input']) {
    margin: ${Po} ${To};
  }
`;function Xu(){return b`
    <template
      focusgroup="radiogroup wrap"
      @disabled="${(e,t)=>e.disabledRadioHandler(t.event)}"
      @change="${(e,t)=>e.changeHandler(t.event)}"
      @click="${(e,t)=>e.clickHandler(t.event)}"
      @focusin="${(e,t)=>e.focusinHandler(t.event)}"
      @keydown="${(e,t)=>e.keydownHandler(t.event)}"
    >
      <slot ${x(`slottedRadios`)}></slot>
    </template>
  `}var Zu=Xu(),Qu={name:Ju,registry:e.registry,styles:Yu,template:Zu},$u=class extends _{checkedIndexChanged(e,t){this.enabledRadios&&this.checkRadio(t)}disabledChanged(e,t){this.radios&&(this.checkedIndex=-1,this.radios?.forEach(e=>{e.disabled=!!e.disabledAttribute||!!this.disabled}))}initialValueChanged(e,t){this.value=t??``}nameChanged(e,t){this.isConnected&&t&&this.radios?.forEach(e=>{e.name=this.name})}orientationChanged(e,t){this.elementInternals.ariaOrientation=this.orientation??qu.horizontal}radiosChanged(e,t){let n=t?.length;if(!n)return;!this.name&&t.every(e=>e.name===t[0].name)&&(this.name=t[0].name);let r=this.enabledRadios.findLastIndex(e=>e.initialChecked);t.forEach((e,t)=>{e.ariaPosInSet=`${t+1}`,e.ariaSetSize=`${n}`,e.checked=this.initialValue&&!this.dirtyState?e.value===this.initialValue:t===r,e.name=this.name??e.name,e.disabled=!!this.disabled||!!e.disabledAttribute,e.toggleAttribute(`focusgroupstart`,e.checked&&!e.disabled)}),!this.dirtyState&&this.initialValue&&(this.value=this.initialValue),(!this.value||this.value&&typeof this.checkedIndex!=`number`&&r>=0)&&(this.checkedIndex=r);let i=t.map(e=>e.id).join(` `).trim();i&&this.setAttribute(`aria-owns`,i)}requiredChanged(e,t){this.elementInternals.ariaRequired=t?`true`:null,this.setValidity()}slottedRadiosChanged(e,t){f.enqueue(()=>{this.radios=[...this.querySelectorAll(`*`)].filter(e=>Bu(e))})}get enabledRadios(){return this.disabled?[]:this.radios?.filter(e=>!e.disabled)??[]}static{this.formAssociated=!0}get validationMessage(){if(this.elementInternals.validationMessage)return this.elementInternals.validationMessage;if(this.enabledRadios?.[0]?.validationMessage)return this.enabledRadios[0].validationMessage;if(!this._validationFallbackMessage){let e=document.createElement(`input`);e.type=`radio`,e.required=!0,e.checked=!1,this._validationFallbackMessage=e.validationMessage}return this._validationFallbackMessage}get validity(){return this.elementInternals.validity}get value(){return p.notify(this,`value`),this.enabledRadios.find(e=>e.checked)?.value??null}set value(e){let t=this.enabledRadios.findIndex(t=>t.value===e);this.checkedIndex=t,this.$fastController.isConnected&&(this.setFormValue(e),this.setValidity()),p.track(this,`value`)}changeHandler(e){if(this===e.target)return!0;this.dirtyState=!0;let t=this.enabledRadios.indexOf(e.target);return this.checkRadio(t),this.radios?.filter(e=>e.disabled)?.forEach(e=>{e.checked=!1}),!0}checkRadio(e=this.checkedIndex,t=!1){let n=this.checkedIndex;this.enabledRadios.forEach((r,i)=>{let a=i===e;r.checked=a,a&&(n=i,t&&r.$emit(`change`))}),this.checkedIndex=n,this.setFormValue(this.value),this.setValidity()}checkValidity(){return this.elementInternals.checkValidity()}clickHandler(e){return this===e.target&&this.enabledRadios[Math.max(0,this.checkedIndex)]?.focus(),!0}constructor(){super(),this.isNavigating=!1,this.dirtyState=!1,this.elementInternals=this.attachInternals(),this.elementInternals.role=`radiogroup`,this.elementInternals.ariaOrientation=this.orientation??qu.horizontal}focus(){this.enabledRadios[Math.max(0,this.checkedIndex)]?.focus()}formResetCallback(){this.dirtyState=!1,this.checkedIndex=-1,this.setFormValue(this.value),this.setValidity()}focusinHandler(e){if(!this.disabled&&(this.isNavigating||this.value)){this.radios?.forEach(e=>{e.disabled&&e.checked&&(e.checked=!1)});let t=this.enabledRadios.indexOf(e.target);t>-1&&this.checkRadio(t,!0),this.isNavigating=!1}return!0}keydownHandler(e){switch(e.key){case`ArrowUp`:case`ArrowDown`:case`ArrowLeft`:case`ArrowRight`:case`Home`:case`End`:this.isNavigating=!0;break;case` `:this.checkRadio()}return!0}disabledRadioHandler(e){e.detail===!0&&e.target.checked&&(this.checkedIndex=-1)}reportValidity(){return this.elementInternals.reportValidity()}setFormValue(e,t){this.elementInternals.setFormValue(e,e??t)}setValidity(e,t,n){if(this.$fastController.isConnected){if(!this.required||this.value||this.disabled){this.enabledRadios?.forEach(e=>{e.elementInternals.setValidity({})});return}let n={valueMissing:!0,...e},r=t??this.validationMessage;this.enabledRadios?.forEach((e,t)=>{t===0?e.elementInternals.setValidity(n,r,e):e.elementInternals.setValidity({})})}}};I([m],$u.prototype,`checkedIndex`,void 0),I([g({attribute:`disabled`,mode:`boolean`})],$u.prototype,`disabled`,void 0),I([g({attribute:`value`,mode:`fromView`})],$u.prototype,`initialValue`,void 0),I([g],$u.prototype,`name`,void 0),I([g],$u.prototype,`orientation`,void 0),I([m],$u.prototype,`radios`,void 0),I([g({mode:`boolean`})],$u.prototype,`required`,void 0),I([m],$u.prototype,`slottedRadios`,void 0),class extends $u{disconnectedCallback(){this.fg?.disconnect(),super.disconnectedCallback()}radiosChanged(e,t){super.radiosChanged(e,t),this.fgItems??=new du(()=>this.enabledRadios?.filter(e=>!e.hidden)??[],()=>this.enabledRadios?.find(e=>e.checked)??null),this.fg?this.fg.update():this.fg=new uu(this,this.fgItems,{definition:{behavior:`radiogroup`,axis:void 0,wrap:!0}})}}.define(Qu);var ed=Yl,td={singleValue:`single-value`},nd=`${e.prefix}-slider`,rd=v`
  ${S(`inline-grid`)}

  :host {
    --thumb-size: 20px;
    --track-margin-inline: calc(var(--thumb-size) / 2);
    --track-size: 4px;
    --track-overhang: calc(var(--track-size) / -2);
    --rail-color: ${Xr};
    --track-color: ${ti};
    --slider-direction: 90deg;
    --border-radius: ${O};
    --step-marker-inset: var(--track-overhang) -1px;

    position: relative;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
    outline: none;
    user-select: none;
    touch-action: none;
    min-width: 120px;
    min-height: 32px;
    grid-template-rows: 1fr var(--thumb-size) 1fr;
    grid-template-columns: var(--track-margin-inline) 1fr var(--track-margin-inline);
  }

  :host(:hover) {
    --rail-color: ${Zr};
  }

  :host(:active) {
    --rail-color: ${Qr};
  }

  :host(${B}) {
    --rail-color: ${T};
    --track-color: ${Gr};
  }

  :host(:not(${B})) {
    cursor: pointer;
  }

  :host(:dir(rtl)) {
    --slider-direction: -90deg;
  }

  :host([size='small']) {
    --thumb-size: 16px;
    --track-overhang: -1px;
    --track-size: 2px;
    --border-radius: ${Wa};
  }

  :host([orientation='vertical']) {
    --slider-direction: 0deg;
    --step-marker-inset: -1px var(--track-overhang);
    min-height: 120px;
    grid-template-rows: var(--track-margin-inline) 1fr var(--track-margin-inline);
    grid-template-columns: 1fr var(--thumb-size) 1fr;
    width: unset;
    min-width: 32px;
    justify-items: center;
  }

  :host(:not([slot='input']):focus-visible) {
    box-shadow: 0 0 0 2pt ${hi};
    outline: 1px solid ${mi};
  }

  :host:after,
  .track {
    height: var(--track-size);
    width: 100%;
  }

  :host:after {
    background-image: linear-gradient(
      var(--slider-direction),
      var(--rail-color) 0%,
      var(--rail-color) 50%,
      var(--track-color) 50.1%,
      var(--track-color) 100%
    );
    border-radius: var(--border-radius);
    content: '';
    grid-row: 1 / -1;
    grid-column: 1 / -1;
  }

  .track {
    position: relative;
    background-color: var(--track-color);
    grid-row: 2 / 2;
    grid-column: 2 / 2;
    forced-color-adjust: none;
    overflow: hidden;
  }

  :host([orientation='vertical'])::after,
  :host([orientation='vertical']) .track {
    height: 100%;
    width: var(--track-size);
  }

  .track::before {
    content: '';
    position: absolute;
    height: 100%;
    border-radius: inherit;
    inset-inline-start: 0;
    width: var(--slider-progress);
  }

  :host(:dir(rtl)) .track::before {
    width: calc(100% - var(--slider-progress));
  }

  :host([orientation='vertical']) .track::before {
    width: 100%;
    bottom: 0;
    height: var(--slider-progress);
  }

  :host([step]) .track::after {
    content: '';
    position: absolute;
    border-radius: inherit;
    inset: var(--step-marker-inset);
    background-image: repeating-linear-gradient(
      var(--slider-direction),
      #0000 0%,
      #0000 calc(var(--step-rate) - 1px),
      ${E} calc(var(--step-rate) - 1px),
      ${E} var(--step-rate)
    );
  }

  .thumb-container {
    position: absolute;
    grid-row: 2 / 2;
    grid-column: 2 / 2;
    transform: translateX(-50%);
    left: var(--slider-thumb);
  }

  :host([orientation='vertical']) .thumb-container {
    transform: translateY(50%);
    left: unset;
    bottom: var(--slider-thumb);
  }

  :host(:not(:active)) :is(.thumb-container, .track::before) {
    transition: all 0.2s ease;
  }

  .thumb {
    width: var(--thumb-size);
    height: var(--thumb-size);
    border-radius: ${qa};
    box-shadow: 0 0 0 calc(var(--thumb-size) * 0.2) ${E} inset;
    border: calc(var(--thumb-size) * 0.05) solid ${ii};
    box-sizing: border-box;
  }

  .thumb,
  .track::before {
    background-color: var(--rail-color);
  }

  @media (forced-colors: active) {
    .track:hover,
    .track:active,
    .track {
      background: WindowText;
    }
    .thumb:hover,
    .thumb:active,
    .thumb {
      background: ButtonText;
    }

    :host(:hover) .track::before,
    :host(:active) .track::before,
    .track::before {
      background: Highlight;
    }
  }
`;function id(e={}){return b`
    <template
      @pointerdown="${(e,t)=>e.handlePointerDown(t.event)}"
      @keydown="${(e,t)=>e.handleKeydown(t.event)}"
    >
      <div ${y(`track`)} part="track-container" class="track" style="${e=>e.position}"></div>
      <div
        ${y(`thumb`)}
        part="thumb-container"
        class="thumb-container"
        style="${e=>e.position}"
        @pointerdown="${(e,t)=>e.handleThumbPointerDown(t.event)}"
      >
        <slot name="thumb">${cs(e.thumb)}</slot>
      </div>
    </template>
  `}var ad=id({thumb:`<div class="thumb"></div>`}),od={name:nd,registry:e.registry,styles:rd,template:ad};function sd(e,t,n){return Math.min(Math.max(n,e),t)}var cd={fromView(e){let t=parseFloat(e);return Number.isNaN(t)?``:t.toString()},toView(e){let t=parseFloat(e);return Number.isNaN(t)?void 0:t.toString()}};function ld(e,t,n,r){let i=sd(0,1,(e-t)/(n-t));return r===Nl.rtl&&(i=1-i),i}var G=class extends _{static{this.formAssociated=!0}get labels(){return Object.freeze(Array.from(this.elementInternals.labels))}handleChange(e,t){switch(t){case`min`:case`max`:this.setSliderPosition();case`step`:this.handleStepStyles()}}handleStepStyles(){if(this.step){let e=100/Math.floor((this.maxAsNumber-this.minAsNumber)/this.stepAsNumber);this.stepStyles!==void 0&&this.$fastController.removeStyles(this.stepStyles),this.stepStyles=v`
        :host {
          --step-rate: ${e}%;
        }
      `,this.$fastController.addStyles(this.stepStyles)}else this.stepStyles!==void 0&&this.$fastController.removeStyles(this.stepStyles)}initialValueChanged(e,t){this.$fastController.isConnected?this.value=t:this._value=t}get validity(){return this.elementInternals.validity}get validationMessage(){return this.elementInternals.validationMessage}get willValidate(){return this.elementInternals.willValidate}checkValidity(){return this.elementInternals.checkValidity()}reportValidity(){return this.elementInternals.reportValidity()}setCustomValidity(e){this.setValidity({customError:!!e},e)}setValidity(e,t,n){if(this.$fastController.isConnected){if(this.isDisabled){this.elementInternals.setValidity({});return}this.elementInternals.setValidity({customError:!!t,...e},t??this.validationMessage,n)}}get value(){return p.track(this,`value`),this._value?.toString()??``}set value(e){if(!this.$fastController.isConnected){this._value=e.toString();return}let t=parseFloat(e),n=sd(this.minAsNumber,this.maxAsNumber,this.convertToConstrainedValue(t)).toString();if(n!==e){this.value=n;return}this._value=e.toString(),this.elementInternals.ariaValueNow=this._value,this.elementInternals.ariaValueText=this.valueTextFormatter(this._value),this.setSliderPosition(),this.$emit(`change`),this.setFormValue(e),p.notify(this,`value`)}formResetCallback(){this.value=this.initialValue??this.midpoint}formDisabledCallback(e){this.setDisabledSideEffect(e)}setFormValue(e,t){this.elementInternals.setFormValue(e,e??t)}directionChanged(){this.setSliderPosition()}get valueAsNumber(){return parseFloat(this.value)}set valueAsNumber(e){this.value=e.toString()}valueTextFormatterChanged(){typeof this.valueTextFormatter==`function`?this.elementInternals.ariaValueText=this.valueTextFormatter(this._value):this.elementInternals.ariaValueText=``}disabledChanged(){this.setDisabledSideEffect(this.disabled)}get isDisabled(){return this.disabled||this.elementInternals?.ariaDisabled===`true`||this.isConnected&&this.matches(`:disabled`)}minChanged(){this.elementInternals.ariaValueMin=`${this.minAsNumber}`,this.$fastController.isConnected&&this.minAsNumber>this.valueAsNumber&&(this.value=this.min)}get minAsNumber(){if(this.min!==void 0){let e=parseFloat(this.min);if(!Number.isNaN(e))return e}return 0}maxChanged(){this.elementInternals.ariaValueMax=`${this.maxAsNumber}`,this.$fastController.isConnected&&this.maxAsNumber<this.valueAsNumber&&(this.value=this.max)}get maxAsNumber(){if(this.max!==void 0){let e=parseFloat(this.max);if(!Number.isNaN(e))return e}return 100}stepChanged(){this.updateStepMultiplier(),this.$fastController.isConnected&&(this.value=this._value)}get stepAsNumber(){if(this.step!==void 0){let e=parseFloat(this.step);if(!Number.isNaN(e)&&e>0)return e}return 1}orientationChanged(e,t){this.elementInternals.ariaOrientation=t??Yl.horizontal,this.$fastController.isConnected&&this.setSliderPosition()}constructor(){super(),this.elementInternals=this.attachInternals(),this.direction=Nl.ltr,this.isDragging=!1,this.trackWidth=0,this.trackMinWidth=0,this.trackHeight=0,this.trackLeft=0,this.trackMinHeight=0,this.valueTextFormatter=()=>``,this.disabled=!1,this.min=``,this.max=``,this.step=``,this.mode=td.singleValue,this.setupTrackConstraints=()=>{let e=this.track.getBoundingClientRect();this.trackWidth=this.track.clientWidth,this.trackMinWidth=this.track.clientLeft,this.trackHeight=e.top,this.trackMinHeight=e.bottom,this.trackLeft=this.getBoundingClientRect().left,this.trackWidth===0&&(this.trackWidth=1)},this.handleThumbPointerDown=e=>{if(this.isDisabled)return!0;let t=e===null?window.removeEventListener:window.addEventListener;return t(`pointerup`,this.handleWindowPointerUp),t(`pointermove`,this.handlePointerMove,{passive:!0}),t(`touchmove`,this.handlePointerMove,{passive:!0}),t(`touchend`,this.handleWindowPointerUp),this.isDragging=e!==null,!0},this.handlePointerMove=e=>{if(this.isDisabled||e.defaultPrevented)return;let t=window.TouchEvent&&e instanceof TouchEvent?e.touches[0]:e,n=this.thumb.getBoundingClientRect().width,r=this.orientation===Yl.vertical?t.pageY-document.documentElement.scrollTop:t.pageX-document.documentElement.scrollLeft-this.trackLeft-n/2;this.value=`${this.calculateNewValue(r)}`},this.handleWindowPointerUp=()=>{this.stopDragging()},this.stopDragging=()=>{this.isDragging=!1,this.handlePointerDown(null),this.handleThumbPointerDown(null)},this.handlePointerDown=e=>{if(e===null||!this.isDisabled){let t=e===null?window.removeEventListener:window.addEventListener,n=e===null?document.removeEventListener:document.addEventListener;t(`pointerup`,this.handleWindowPointerUp),n(`mouseleave`,this.handleWindowPointerUp),t(`pointermove`,this.handlePointerMove);let r=this.thumb.getBoundingClientRect().width;if(e){this.setupTrackConstraints();let t=this.orientation===Yl.vertical?e.pageY-document.documentElement.scrollTop:e.pageX-document.documentElement.scrollLeft-this.trackLeft-r/2;this.value=`${this.calculateNewValue(t)}`}}return!0},this.elementInternals.role=`slider`,this.elementInternals.ariaOrientation=this.orientation??ed.horizontal}connectedCallback(){super.connectedCallback(),requestAnimationFrame(()=>{if(!this.$fastController.isConnected)return;this.direction=Pl(this),this.setDisabledSideEffect(this.disabled),this.updateStepMultiplier(),this.setupTrackConstraints(),this.setupDefaultValue(),this.setSliderPosition(),this.handleStepStyles();let e=p.getNotifier(this);e.subscribe(this,`max`),e.subscribe(this,`min`),e.subscribe(this,`step`)}),gs(this)}disconnectedCallback(){super.disconnectedCallback();let e=p.getNotifier(this);e.unsubscribe(this,`max`),e.unsubscribe(this,`min`),e.unsubscribe(this,`step`)}increment(){let e=this.direction===Nl.rtl?Number(this.value)-this.stepAsNumber:Number(this.value)+this.stepAsNumber,t=this.convertToConstrainedValue(e),n=t<this.maxAsNumber?`${t}`:`${this.maxAsNumber}`;this.value=n}decrement(){let e=this.direction===Nl.rtl?Number(this.value)+Number(this.stepAsNumber):Number(this.value)-Number(this.stepAsNumber),t=this.convertToConstrainedValue(e),n=t>this.minAsNumber?`${t}`:`${this.minAsNumber}`;this.value=n}handleKeydown(e){if(this.isDisabled)return!0;switch(e.key){case`Home`:e.preventDefault(),this.value=this.direction!==Nl.rtl&&this.orientation!==Yl.vertical?`${this.minAsNumber}`:`${this.maxAsNumber}`;break;case`End`:e.preventDefault(),this.value=this.direction!==Nl.rtl&&this.orientation!==Yl.vertical?`${this.maxAsNumber}`:`${this.minAsNumber}`;break;case`ArrowRight`:case`ArrowUp`:e.shiftKey||(e.preventDefault(),this.increment());break;case`ArrowLeft`:case`ArrowDown`:e.shiftKey||(e.preventDefault(),this.decrement())}return!0}setSliderPosition(){let e=ld(parseFloat(this.value),this.minAsNumber,this.maxAsNumber,this.orientation===Yl.vertical?void 0:this.direction)*100;this.position=`--slider-thumb: ${e}%; --slider-progress: ${e}%`}updateStepMultiplier(){let e=this.stepAsNumber+``,t=this.stepAsNumber%1?e.length-e.indexOf(`.`)-1:0;this.stepMultiplier=10**t}get midpoint(){return`${this.convertToConstrainedValue((this.maxAsNumber+this.minAsNumber)/2)}`}setupDefaultValue(){this._value||(this.value=this.initialValue??this.midpoint),!Number.isNaN(this.valueAsNumber)&&(this.valueAsNumber<this.minAsNumber||this.valueAsNumber>this.maxAsNumber)&&(this.value=this.midpoint),this.elementInternals.ariaValueNow=this.value}calculateNewValue(e){this.setupTrackConstraints();let t=ld(e,this.orientation===Yl.vertical?this.trackMinHeight:this.trackMinWidth,this.orientation===Yl.vertical?this.trackHeight:this.trackWidth,this.orientation===Yl.vertical?void 0:this.direction),n=(this.maxAsNumber-this.minAsNumber)*t+this.minAsNumber;return this.convertToConstrainedValue(n)}convertToConstrainedValue(e){isNaN(e)&&(e=this.minAsNumber);let t=e-this.minAsNumber,n=Math.round(t/this.stepAsNumber),r=t-n*(this.stepMultiplier*this.stepAsNumber)/this.stepMultiplier;return t=r>=Number(this.stepAsNumber)/2?t-r+Number(this.stepAsNumber):t-r,t+this.minAsNumber}setDisabledSideEffect(e=this.isDisabled){f.enqueue(()=>{this.elementInternals.ariaDisabled=e.toString(),this.tabIndex=e?-1:0})}};I([g],G.prototype,`size`,void 0),I([g({attribute:`value`,mode:`fromView`})],G.prototype,`initialValue`,void 0),I([m],G.prototype,`direction`,void 0),I([m],G.prototype,`isDragging`,void 0),I([m],G.prototype,`position`,void 0),I([m],G.prototype,`trackWidth`,void 0),I([m],G.prototype,`trackMinWidth`,void 0),I([m],G.prototype,`trackHeight`,void 0),I([m],G.prototype,`trackLeft`,void 0),I([m],G.prototype,`trackMinHeight`,void 0),I([m],G.prototype,`valueTextFormatter`,void 0),I([g({mode:`boolean`})],G.prototype,`disabled`,void 0),I([g({converter:cd})],G.prototype,`min`,void 0),I([g({converter:cd})],G.prototype,`max`,void 0),I([g({converter:cd})],G.prototype,`step`,void 0),I([g],G.prototype,`orientation`,void 0),I([g],G.prototype,`mode`,void 0),G.define(od);var ud={success:`success`,warning:`warning`,error:`error`},dd=`${e.prefix}-progress-bar`,fd=v`
  ${S(`block`)}

  :host {
    width: 100%;
    height: 2px;
    overflow-x: hidden;
    background-color: ${Lr};
    border-radius: ${O};
    contain: content;

    @supports (width: attr(value type(<number>))) {
      --max: attr(max type(<number>), 100);
      --min: attr(min type(<number>), 0);
      --value: attr(value type(<number>), 0);
      --indicator-width: clamp(0%, calc((var(--value) - var(--min)) / (var(--max) - var(--min)) * 100%), 100%);
    }
  }

  :host([thickness='large']) {
    height: 4px;
  }

  :host([shape='square']) {
    border-radius: ${Ua};
  }

  .indicator {
    background-color: ${Xr};
    border-radius: inherit;
    height: 100%;
  }

  :host([value]) .indicator {
    transition: all 0.2s ease-in-out;

    @supports (width: attr(value type(<number>))) {
      width: var(--indicator-width);
    }
  }

  :host(:not([value])) .indicator {
    position: relative;
    width: 33%;
    background-image: linear-gradient(
      to right,
      ${Lr} 0%,
      ${Hr} 50%,
      ${Lr} 100%
    );
    animation-name: indeterminate;
    animation-duration: 3s;
    animation-timing-function: linear;
    animation-iteration-count: infinite;
  }

  :host([validation-state='error']) .indicator {
    background-color: ${vi};
  }

  :host([validation-state='warning']) .indicator {
    background-color: ${ji};
  }

  :host([validation-state='success']) .indicator {
    background-color: ${Ti};
  }

  @layer animations {
    /* Disable animations for reduced motion */
    @media (prefers-reduced-motion: no-preference) {
      :host([value]) {
        transition: none;
      }
      :host(:not([value])) .indicator {
        animation-duration: 0.01ms;
        animation-iteration-count: 1;
      }
    }
  }

  @keyframes indeterminate {
    0% {
      inset-inline-start: -33%;
    }
    100% {
      inset-inline-start: 100%;
    }
  }

  @media (forced-colors: active) {
    :host {
      background-color: CanvasText;
    }
    .indicator,
    :host(:is([validation-state='success'], [validation-state='warning'], [validation-state='error'])) .indicator {
      background-color: Highlight;
    }
  }
`;function pd(){return b` <div class="indicator" part="indicator" ${y(`indicator`)}></div> `}var md=pd(),hd={name:dd,registry:e.registry,styles:fd,template:md},gd=class extends _{indicatorChanged(){this.setIndicatorWidth()}validationStateChanged(e,t){Ts(this.elementInternals,e,t,ud)}valueChanged(e,t){this.elementInternals&&(this.elementInternals.ariaValueNow=typeof t==`number`?`${t}`:null),this.setIndicatorWidth()}minChanged(e,t){this.elementInternals&&(this.elementInternals.ariaValueMin=typeof t==`number`?`${t}`:null),this.setIndicatorWidth()}maxChanged(e,t){this.elementInternals&&(this.elementInternals.ariaValueMax=typeof t==`number`?`${t}`:null),this.setIndicatorWidth()}constructor(){super(),this.elementInternals=this.attachInternals(),this.validationState=null,this.elementInternals.role=`progressbar`}setIndicatorWidth(){CSS.supports(`width: attr(value type(<number>))`)||f.enqueue(()=>{if(typeof this.value!=`number`){this.indicator?.style.removeProperty(`width`);return}let e=this.min??0,t=this.max??100,n=this.value??0,r=t-e,i=r===0?0:Math.fround((n-e)/r*100);this.indicator?.style.setProperty(`width`,`${i}%`)})}};I([m],gd.prototype,`indicator`,void 0),I([g({attribute:`validation-state`})],gd.prototype,`validationState`,void 0),I([g({converter:je})],gd.prototype,`value`,void 0),I([g({converter:je})],gd.prototype,`min`,void 0),I([g({converter:je})],gd.prototype,`max`,void 0);var _d=class extends gd{};I([g],_d.prototype,`thickness`,void 0),I([g],_d.prototype,`shape`,void 0),_d.define(hd);var vd={modal:`modal`,nonModal:`non-modal`,alert:`alert`};function yd(e,t=`-dialog`){return e?.nodeType===Node.ELEMENT_NODE&&e.tagName.toLowerCase().endsWith(t)}var bd=`${e.prefix}-dialog`,xd=v`
  @layer base {
    :host {
      --dialog-backdrop: ${Kr};
      --dialog-starting-scale: 0.85;
    }

    ::backdrop {
      background: var(--dialog-backdrop, rgba(0, 0, 0, 0.4));
    }

    dialog {
      background: ${E};
      border-radius: ${Ka};
      border: none;
      box-shadow: ${yo};
      color: ${C};
      max-height: 100vh;
      padding: 0;
      width: 100%;
      max-width: 600px;
    }

    :host([type='non-modal']) dialog {
      inset: 0;
      z-index: 2;
      overflow: auto;
    }

    @supports (max-height: 1dvh) {
      dialog {
        max-height: 100dvh;
      }
    }
  }

  @layer animations {
    /* Disable animations for reduced motion */
    @media (prefers-reduced-motion: no-preference) {
      dialog,
      ::backdrop {
        transition: display allow-discrete, opacity, overlay allow-discrete, scale;
        transition-duration: ${Ho};
        transition-timing-function: ${Xo};
        /* Set opacity to 0 when closed */
        opacity: 0;
      }
      ::backdrop {
        transition-timing-function: ${es};
      }

      /* Set opacity to 1 when open */
      [open],
      [open]::backdrop {
        opacity: 1;
      }

      /* Exit styles for dialog */
      dialog:not([open]) {
        /* Make small when leaving */
        scale: var(--dialog-starting-scale);
        /* Faster leaving the stage then entering */
        transition-timing-function: ${qo};
      }
    }

    @starting-style {
      [open],
      [open]::backdrop {
        opacity: 0;
      }

      dialog {
        scale: var(--dialog-starting-scale);
      }
    }
  }

  @media (forced-colors: active) {
    @layer base {
      dialog {
        border: ${P} solid ${D};
      }
    }
  }
`,Sd=b`
  <dialog
    class="dialog"
    part="dialog"
    aria-modal="${e=>e.dialogModal}"
    aria-describedby="${e=>e.dialogDescribedby}"
    aria-labelledby="${e=>e.dialogLabelledby}"
    aria-label="${e=>e.dialogLabel}"
    role="${e=>e.dialogRole}"
    @click="${(e,t)=>e.clickHandler(t.event)}"
    @cancel="${e=>e.hide()}"
    ${y(`dialog`)}
  >
    <div tabindex="-1"></div>
    <slot></slot>
  </dialog>
`,Cd={name:bd,registry:e.registry,styles:xd,template:Sd},wd=class extends _{constructor(){super(...arguments),this.emitToggle=()=>{this.$emit(`toggle`,{oldState:this.dialog.open?`closed`:`open`,newState:this.dialog.open?`open`:`closed`})}}get dialogDescribedby(){if(this.dialog)return this.ariaDescribedby}get dialogLabel(){if(this.dialog)return this.ariaLabel}get dialogLabelledby(){if(this.dialog)return this.ariaLabelledby}get dialogModal(){if(this.dialog&&this.type!==vd.nonModal)return!0}get dialogRole(){if(this.dialog&&this.type===vd.alert)return`alertdialog`}connectedCallback(){super.connectedCallback(),f.enqueue(()=>{this.type=this.type??vd.modal})}emitBeforeToggle(){this.$emit(`beforetoggle`,{oldState:this.dialog.open?`open`:`closed`,newState:this.dialog.open?`closed`:`open`})}show(){f.enqueue(()=>{this.emitBeforeToggle(),this.type===vd.alert||this.type===vd.modal?this.dialog.showModal():this.type===vd.nonModal&&this.dialog.show(),this.querySelector(`[autofocus]`)?.focus?.(),this.emitToggle()})}hide(){this.emitBeforeToggle(),this.dialog.close(),this.emitToggle()}clickHandler(e){return this.dialog.open&&this.type!==vd.alert&&e.target===this.dialog&&this.hide(),!0}};I([m],wd.prototype,`dialog`,void 0),I([g({attribute:`aria-describedby`})],wd.prototype,`ariaDescribedby`,void 0),I([g({attribute:`aria-labelledby`})],wd.prototype,`ariaLabelledby`,void 0),I([g({attribute:`aria-label`})],wd.prototype,`ariaLabel`,void 0),I([g],wd.prototype,`type`,void 0),I([Ot],wd.prototype,`dialogDescribedby`,null),I([Ot],wd.prototype,`dialogLabel`,null),I([Ot],wd.prototype,`dialogLabelledby`,null),I([Ot],wd.prototype,`dialogModal`,null),I([Ot],wd.prototype,`dialogRole`,null),wd.define(Cd);var Td=`${e.prefix}-dialog-body`,Ed=v`
  ${S(`grid`)}

  :host {
    background: ${E};
    box-sizing: border-box;
    gap: ${Po};
    padding: ${Ro} ${Ao};
    container: dialog-body / inline-size;
  }

  .title {
    box-sizing: border-box;
    align-items: flex-start;
    background: ${E};
    color: ${C};
    column-gap: 8px;
    display: flex;
    font-family: ${k};
    font-size: ${Za};
    font-weight: ${M};
    inset-block-start: 0;
    justify-content: space-between;
    line-height: ${so};
    margin-block-end: calc(${Po} * -1);
    margin-block-start: calc(${Ro} * -1);
    padding-block-end: ${Po};
    padding-block-start: ${Ro};
  }

  .content {
    box-sizing: border-box;
    color: ${C};
    font-family: ${k};
    font-size: ${A};
    font-weight: ${j};
    line-height: ${N};
    min-height: 32px;
  }

  .actions {
    box-sizing: border-box;
    background: ${E};
    display: flex;
    flex-direction: column;
    gap: ${Po};
    inset-block-end: 0;
    margin-block-end: calc(${Ro} * -1);
    padding-block-end: ${Ro};
    padding-block-start: ${Lo};
  }

  ::slotted([slot='title-action']) {
    margin-inline-start: auto;
  }

  ::slotted([slot='title']) {
    font: inherit;
    padding: 0;
    margin: 0;
  }

  /* align  title content to the end when there is no title*/
  :not(:has(:is([slot='title'], [slot='title-action']))) .title {
    justify-content: end;
  }

  @container (min-width: 480px) {
    .actions {
      align-items: center;
      flex-direction: row;
      justify-content: flex-end;
      margin-block-start: calc(${Po} * -1);
      padding-block-start: ${Po};
    }
  }

  /* For a11y, set sticky position for title and actions when the viewport is tall enough */
  @media (min-height: 480px) {
    .title {
      position: sticky;
      z-index: 1;
    }
    .actions {
      position: sticky;
      z-index: 2;
    }
  }
`,Dd=b`
  <template>
    <div class="title" part="title">
      <slot name="title"></slot>
      <slot name="title-action"></slot>
      <slot name="close" @click="${(e,t)=>e.clickHandler(t.event)}"></slot>
    </div>
    <div class="content" part="content"><slot></slot></div>
    <div class="actions" part="actions"><slot name="action"></slot></div>
  </template>
`,Od={name:Td,registry:e.registry,styles:Ed,template:Dd};(class extends _{clickHandler(e){if(!e.defaultPrevented){let e=this.parentElement;yd(e)&&e.hide()}return!0}}).define(Od);var kd={start:`start`,end:`end`},Ad={small:`small`,medium:`medium`,large:`large`,full:`full`},jd={nonModal:`non-modal`,modal:`modal`,inline:`inline`},Md=`${e.prefix}-drawer`,Nd=v`
  ${S(`block`)}

  :host {
    --dialog-backdrop: ${Kr};
  }

  :host([type='non-modal']) dialog[open]::backdrop {
    display: none;
  }

  :host([type='non-modal']) dialog {
    position: fixed;
    top: 0;
    bottom: 0;
  }

  :host([type='inline']) {
    height: 100%;
    width: fit-content;
  }

  :host([type='inline']) dialog[open] {
    box-shadow: none;
    position: relative;
  }

  :host([size='small']) dialog {
    width: 320px;
    max-width: 320px;
  }

  :host([size='large']) dialog {
    width: 940px;
    max-width: 940px;
  }

  :host([size='full']) dialog {
    width: 100%;
    max-width: 100%;
  }

  :host([position='end']) dialog {
    margin-inline-start: auto;
    margin-inline-end: 0;
  }

  dialog {
    background: ${E};
    border-radius: 0;
    border: ${P} solid ${D};
    border-inline-end-color: ${D};
    border-inline-start-color: var(--drawer-separator, ${D});
    box-shadow: ${yo};
    box-sizing: border-box;
    color: ${C};
    font-family: ${k};
    font-size: ${A};
    font-weight: ${j};
    height: 100%;
    line-height: ${N};
    margin-inline-end: auto;
    margin-inline-start: 0;
    max-height: 100vh;
    max-width: calc(100vw - ${Ao});
    outline: none;
    padding: 0;
    bottom: 0;
    top: 0;
    width: var(--drawer-width, 592px);
    z-index: var(--drawer-elevation, 1000);
  }

  dialog::backdrop {
    background: var(--dialog-backdrop);
  }

  @layer animations {
    /* Disable animations for reduced motion */
    @media (prefers-reduced-motion: no-preference) {
      dialog {
        transition: display allow-discrete, opacity, overlay allow-discrete, transform;
        transition-duration: ${Ho};
        transition-timing-function: ${Xo};
      }

      /* Exit styles for dialog */
      :host dialog:not([open]) {
        transform: translateX(-100%);
        transition-timing-function: ${qo};
      }
      :host([position='end']) dialog:not([open]) {
        transform: translateX(100%);
        transition-timing-function: ${qo};
      }

      dialog[open] {
        transform: translateX(0);
      }

      dialog::backdrop {
        transition: display allow-discrete, opacity, overlay allow-discrete, scale;
        transition-duration: ${Ho};
        transition-timing-function: ${Xo};
        background: var(--dialog-backdrop, ${Kr});
        opacity: 0;
      }

      dialog[open]::backdrop {
        opacity: 1;
      }

      dialog::backdrop {
        transition-timing-function: ${es};
      }
    }

    @starting-style {
      dialog[open] {
        transform: translateX(-100%);
      }
      :host([position='end']) dialog[open] {
        transform: translateX(100%);
      }
      dialog[open]::backdrop {
        opacity: 0;
      }
    }
  }
`;function Pd(){return b`
    <dialog
      class="dialog"
      part="dialog"
      aria-describedby="${e=>e.dialogDescribedby}"
      aria-labelledby="${e=>e.dialogLabelledby}"
      aria-label="${e=>e.dialogLabel}"
      aria-modal="${e=>e.dialogModal}"
      role="${e=>e.dialogRole}"
      size="${e=>e.size}"
      position="${e=>e.position}"
      @click="${(e,t)=>e.clickHandler(t.event)}"
      @cancel="${e=>e.cancelHandler()}"
      ${y(`dialog`)}
    >
      <slot></slot>
    </dialog>
  `}var Fd=Pd(),Id={name:Md,registry:e.registry,styles:Nd,template:Fd},Ld=class extends _{constructor(){super(...arguments),this.position=kd.start,this.size=Ad.medium,this.emitToggle=()=>{this.$emit(`toggle`,{oldState:this.dialog.open?`closed`:`open`,newState:this.dialog.open?`open`:`closed`})},this.emitBeforeToggle=()=>{this.$emit(`beforetoggle`,{oldState:this.dialog.open?`open`:`closed`,newState:this.dialog.open?`closed`:`open`})}}get dialogDescribedby(){if(this.dialog)return this.ariaDescribedby}get dialogLabel(){if(this.dialog)return this.ariaLabel}get dialogLabelledby(){if(this.dialog)return this.ariaLabelledby}get dialogModal(){if(this.dialog&&this.type===jd.modal)return!0}get dialogRole(){return this.dialog&&this.type===jd.modal?`dialog`:this.role}connectedCallback(){super.connectedCallback(),f.enqueue(()=>{this.type=this.type??jd.modal})}show(){f.enqueue(()=>{this.emitBeforeToggle(),this.type===jd.inline||this.type===jd.nonModal?this.dialog.show():this.dialog.showModal(),this.querySelector(`[autofocus]`)?.focus?.(),this.emitToggle()})}hide(){this.emitBeforeToggle(),this.dialog.close(),this.emitToggle()}clickHandler(e){return this.dialog.open&&e.target===this.dialog&&this.hide(),!0}cancelHandler(){this.hide()}};I([g],Ld.prototype,`type`,void 0),I([g({attribute:`aria-labelledby`})],Ld.prototype,`ariaLabelledby`,void 0),I([g({attribute:`aria-describedby`})],Ld.prototype,`ariaDescribedby`,void 0),I([g],Ld.prototype,`position`,void 0),I([m],Ld.prototype,`role`,void 0),I([g({attribute:`size`})],Ld.prototype,`size`,void 0),I([m],Ld.prototype,`dialog`,void 0),I([Ot],Ld.prototype,`dialogDescribedby`,null),I([Ot],Ld.prototype,`dialogLabel`,null),I([Ot],Ld.prototype,`dialogLabelledby`,null),I([Ot],Ld.prototype,`dialogModal`,null),I([Ot],Ld.prototype,`dialogRole`,null),Ld.define(Id);var Rd=`${e.prefix}-drawer-body`,zd=v`
  ${S(`grid`)}
  :host {
    box-sizing: border-box;
    grid-template-rows: min-content auto min-content;
    position: relative;
    height: 100%;
    padding: ${ko};
    max-height: 100svh;
  }
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    ${xl}
  }

  .footer {
    display: flex;
    justify-content: flex-start;
    gap: ${Do};
  }

  ::slotted([slot='title']) {
    font: inherit;
    padding: 0;
    margin: 0;
  }
`;function Bd(){return b`
    <div class="header" part="header">
      <slot name="title"></slot>
      <slot name="close" @click="${(e,t)=>e.clickHandler(t.event)}"></slot>
    </div>
    <div class="content" part="content">
      <slot></slot>
    </div>
    <div class="footer" part="footer">
      <slot name="footer"></slot>
    </div>
  `}var Vd=Bd(),Hd={name:Rd,registry:e.registry,styles:zd,template:Vd};(class extends _{clickHandler(e){if(!e.defaultPrevented){let e=this.parentElement;yd(e,`-drawer`)&&e.hide()}return!0}}).define(Hd);var Ud=`${e.prefix}-menu`,Wd=v`
  ${S(`inline-block`)}

  ::slotted([slot='trigger']) {
    anchor-name: --menu-trigger;
  }

  ::slotted([popover]) {
    margin: 0;
    max-height: var(--menu-max-height, auto);
    position-anchor: --menu-trigger;
    inset: unset;
    inset-block-start: anchor(outside);
    inset-inline-start: anchor(self-start);
    position-try-fallbacks: flip-block, flip-inline, flip-block flip-inline;
    position: fixed;
    z-index: 1;
  }

  :host([split]) ::slotted([popover]) {
    inset-inline-start: unset;
    inset-inline-end: anchor(self-end);
  }

  ::slotted([popover]:not(:popover-open)) {
    display: none;
  }

  :host([split]) {
    display: inline-flex;
  }

  :host([split]) ::slotted([slot='primary-action']) {
    border-inline-end: ${P} solid ${ii};
    border-start-end-radius: 0;
    border-end-end-radius: 0;
  }

  /* Keeps focus visible visuals above trigger slot*/
  :host([split]) ::slotted([slot='primary-action']:focus-visible) {
    z-index: 1;
  }

  :host([split]) ::slotted([slot='primary-action'][appearance='primary']) {
    border-inline-end: ${P} solid white;
  }

  :host([split]) ::slotted([slot='trigger']) {
    border-inline-start: 0;
    border-start-start-radius: 0;
    border-end-start-radius: 0;
  }
`;function Gd(){return b`
    <template @keydown="${(e,t)=>e.menuKeydownHandler(t.event)}">
      <slot name="primary-action" ${y(`primaryAction`)}></slot>
      <slot name="trigger" ${x({property:`slottedTriggers`,filter:Gt()})}></slot>
      <slot ${x({property:`slottedMenuList`,filter:Gt()})}></slot>
    </template>
  `}var Kd=Gd(),qd={name:Ud,registry:e.registry,styles:Wd,template:Kd},K={menuitem:`menuitem`,menuitemcheckbox:`menuitemcheckbox`,menuitemradio:`menuitemradio`};K.menuitem,K.menuitemcheckbox,K.menuitemradio;function Jd(e,t=`-menu-item`){return e?.nodeType===Node.ELEMENT_NODE&&e.tagName.toLowerCase().endsWith(t)}var Yd=`${e.prefix}-menu-item`,Xd=class extends _{constructor(){super(...arguments),this.elementInternals=this.attachInternals(),this.role=K.menuitem,this.checked=!1,this.handleMenuItemKeyDown=e=>{if(e.defaultPrevented)return!1;switch(e.key){case`Enter`:case` `:return this.invoke(),!1;case`ArrowRight`:return this.disabled||(this.submenu?.togglePopover(!0),this.submenu?.focus()),!1;case`ArrowLeft`:return this.parentElement?.hasAttribute(`popover`)&&(this.parentElement.togglePopover(!1),this.parentElement.parentElement?.focus()),!1}return!0},this.handleMenuItemClick=e=>(e.defaultPrevented||this.disabled||this.invoke(),!1),this.handleMouseOver=e=>(this.disabled||this.submenu?.togglePopover(!0),!1),this.handleMouseOut=e=>(this.contains(document.activeElement)||this.submenu?.togglePopover(!1),!1),this.handleToggle=e=>{e instanceof ToggleEvent&&(e.newState===`open`&&(this.elementInternals.ariaExpanded=`true`,this.setSubmenuPosition()),e.newState===`closed`&&(this.elementInternals.ariaExpanded=`false`),this.submenu?.setAttribute(`focusgroup`,e.newState===`open`?`menu`:`none`))},this.handleSubmenuFocusOut=e=>{e.relatedTarget&&this.submenu?.contains(e.relatedTarget)||this.submenu?.togglePopover(!1)},this.invoke=()=>{if(!this.disabled)switch(this.role){case K.menuitemcheckbox:this.checked=!this.checked;break;case K.menuitem:if(this.submenu){this.submenu.togglePopover(!0),this.submenu.focus();break}this.$emit(`change`);break;case K.menuitemradio:this.checked||=!0}},this.setSubmenuPosition=()=>{if(!CSS.supports(`anchor-name`,`--anchor`)&&this.submenu){let e=this.getBoundingClientRect(),t=this.submenu.getBoundingClientRect(),n=getComputedStyle(this).direction===`ltr`?`right`:`left`;if(e.width+t.width>window.innerWidth*.75){this.submenu.style.translate=`0 -100%`;return}if(e[n]+t.width>window.innerWidth){this.submenu.style.translate=`-100% 0`;return}this.submenu.style.translate=`${e.width-8}px 0`}}}disabledChanged(e,t){this.elementInternals.ariaDisabled=t?`${t}`:null,R(this.elementInternals,`disabled`,t)}roleChanged(e,t){this.elementInternals.role=t??K.menuitem}checkedChanged(e,t){let n=this.role!==K.menuitem;this.elementInternals.ariaChecked=n?`${!!t}`:null,R(this.elementInternals,`checked`,n?t:!1),this.$fastController.isConnected&&this.$emit(`change`,t,{bubbles:!0})}slottedSubmenuChanged(e,t){this.submenu?.removeEventListener(`toggle`,this.handleToggle),this.submenu?.removeEventListener(`focusout`,this.handleSubmenuFocusOut),t.length?(this.submenu=t[0],this.submenu.toggleAttribute(`popover`,!0),this.submenu.setAttribute(`focusgroup`,`none`),this.submenu.addEventListener(`toggle`,this.handleToggle),this.submenu.addEventListener(`focusout`,this.handleSubmenuFocusOut),this.elementInternals.ariaHasPopup=`menu`,R(this.elementInternals,`submenu`,!0)):(this.elementInternals.ariaHasPopup=null,R(this.elementInternals,`submenu`,!1))}connectedCallback(){super.connectedCallback(),this.elementInternals.role=this.role??K.menuitem,this.elementInternals.ariaChecked=this.role===K.menuitem?null:`${!!this.checked}`,gs(this)}};I([g({mode:`boolean`})],Xd.prototype,`disabled`,void 0),I([g],Xd.prototype,`role`,void 0),I([g({mode:`boolean`})],Xd.prototype,`checked`,void 0),I([g({mode:`boolean`})],Xd.prototype,`hidden`,void 0),I([m],Xd.prototype,`slottedSubmenu`,void 0),I([m],Xd.prototype,`submenu`,void 0),hs(Xd,ls);var Zd=class extends _{constructor(){super(...arguments),this._open=!1,this.toggleMenu=()=>{this._menuList?.togglePopover(!this._open)},this.closeMenu=e=>{e?.target instanceof Xd&&(e.target.getAttribute(`role`)===K.menuitemcheckbox||e.target.getAttribute(`role`)===K.menuitemradio)||(this._menuList?.togglePopover(!1),this.closeOnScroll&&document.removeEventListener(`scroll`,this.closeMenu))},this.openMenu=e=>{this._menuList?.togglePopover(!0),e&&this.openOnContext&&e.preventDefault(),this.closeOnScroll&&document.addEventListener(`scroll`,this.closeMenu)},this.toggleHandler=e=>{if(e.type===`toggle`&&e.newState){let t=e.newState===`open`;this._trigger?.setAttribute(`aria-expanded`,`${t}`),this._menuList?.setAttribute(`focusgroup`,t?`menu`:`none`),this._open=t,this._open&&this.focusMenuList()}},this.triggerKeydownHandler=e=>{if(!e.defaultPrevented)switch(e.key){case` `:case`Enter`:e.preventDefault(),this.toggleMenu();break;default:return!0}},this.documentClickHandler=e=>{e.composedPath().some(e=>e===this._trigger||e===this._menuList)||this.closeMenu()}}slottedMenuListChanged(e,t){this._menuListAbortController?.abort(),t?.length&&(this._menuList=t[0],this._menuList.popover=this.openOnContext?`manual`:``,this.addMenuListListeners())}slottedTriggersChanged(e,t){if(this._triggerAbortController?.abort(),t?.length){let e=t[0];this._trigger=e,this._trigger?.isConnected&&(this._trigger.setAttribute(`aria-haspopup`,`true`),this._trigger.setAttribute(`aria-expanded`,`${this._open}`),this.addTriggerListeners())}}connectedCallback(){super.connectedCallback(),this.setComponent()}disconnectedCallback(){super.disconnectedCallback(),this._triggerAbortController?.abort(),this._menuListAbortController?.abort()}setComponent(){}focusMenuList(){f.enqueue(()=>{this._menuList.focus()})}focusTrigger(){f.enqueue(()=>{this._trigger.focus()})}openOnHoverChanged(e,t){this._trigger&&(this._triggerAbortController?.abort(),this.addTriggerListeners())}persistOnItemClickChanged(e,t){this._menuList&&(this._menuListAbortController?.abort(),this.addMenuListListeners())}openOnContextChanged(e,t){t?this._menuList?.setAttribute(`popover`,`manual`):this._menuList?.setAttribute(`popover`,``),this._trigger&&(this._triggerAbortController?.abort(),this.addTriggerListeners())}closeOnScrollChanged(e,t){t?document.addEventListener(`scroll`,this.closeMenu):document.removeEventListener(`scroll`,this.closeMenu)}addTriggerListeners(){this._triggerAbortController=new AbortController;let{signal:e}=this._triggerAbortController;this._trigger?.addEventListener(`keydown`,this.triggerKeydownHandler,{signal:e}),this.openOnHover?this._trigger?.addEventListener(`mouseover`,this.openMenu,{signal:e}):this.openOnContext?(this._trigger?.addEventListener(`contextmenu`,this.openMenu,{signal:e}),document.addEventListener(`click`,this.documentClickHandler,{signal:e})):this._trigger?.addEventListener(`click`,this.toggleMenu,{signal:e})}addMenuListListeners(){this._menuListAbortController=new AbortController;let{signal:e}=this._menuListAbortController;this._menuList?.addEventListener(`toggle`,this.toggleHandler,{signal:e}),this.persistOnItemClick||this._menuList?.addEventListener(`change`,this.closeMenu,{signal:e})}menuKeydownHandler(e){if(!e.defaultPrevented)switch(e.key){case`Escape`:e.preventDefault(),this._open&&(this.closeMenu(),this.focusTrigger());break;case`Tab`:if(this._open&&this.closeMenu(),e.shiftKey&&e.composedPath()[0]!==this._trigger&&e.composedPath()[0].assignedSlot!==this.primaryAction)this.focusTrigger();else if(e.shiftKey)return!0;default:return!0}}};I([g({attribute:`open-on-hover`,mode:`boolean`})],Zd.prototype,`openOnHover`,void 0),I([g({attribute:`open-on-context`,mode:`boolean`})],Zd.prototype,`openOnContext`,void 0),I([g({attribute:`close-on-scroll`,mode:`boolean`})],Zd.prototype,`closeOnScroll`,void 0),I([g({attribute:`persist-on-item-click`,mode:`boolean`})],Zd.prototype,`persistOnItemClick`,void 0),I([g({mode:`boolean`})],Zd.prototype,`split`,void 0),I([m],Zd.prototype,`slottedMenuList`,void 0),I([m],Zd.prototype,`slottedTriggers`,void 0),I([m],Zd.prototype,`primaryAction`,void 0),Zd.define(qd);var Qd=`${e.prefix}-menu-button`,$d=ss,ef=fs({end:b.partial(`
    <svg slot="end" fill="currentColor" aria-hidden="true" width="1em" height="1em" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
      <path d="M15.85 7.65c.2.2.2.5 0 .7l-5.46 5.49a.55.55 0 0 1-.78 0L4.15 8.35a.5.5 0 1 1 .7-.7L10 12.8l5.15-5.16c.2-.2.5-.2.7 0Z" fill="currentColor"></path>
    </svg>
  `)}),tf={name:Qd,registry:e.registry,styles:$d,template:ef};(class extends vs{}).define(tf);var nf=`${e.prefix}-menu-list`,rf=v`
  ${S(`grid`)}

  :host {
    --_col-indicator-width: 0px;
    --_col-start-width: 0px;
    --_col-content-width: 1fr;
    --_col-end-width: 0px;
    --_col-submenu-width: 0px;

    contain: layout style;
    block-size: auto;
    max-inline-size: 300px;
    min-inline-size: 160px;
    inline-size: auto;
    background-color: ${E};
    border: 1px solid ${D};
    border-radius: ${O};
    box-shadow: ${_o};
    grid-template-columns:
      10px
      var(--_col-indicator-width)
      var(--_col-start-width)
      var(--_col-content-width)
      var(--_col-end-width)
      var(--_col-submenu-width)
      10px;
    gap: 2px 0;
    padding: 4px;
  }

  ::slotted(*) {
    grid-column: 1 / -1;
  }

  :host(:has(> [role='menuitemradio'], > [role='menuitemcheckbox'])) {
    --_col-indicator-width: 24px;
  }

  :host(:has(> * > [slot='start'])) {
    --_col-start-width: 24px;
  }

  :host(:has(> * > [slot='end'])) {
    --_col-end-width: 24px;
  }

  :host(:has(> * > [slot='submenu'])) {
    --_col-submenu-width: 24px;
  }

  @scope {
    :scope:has(> [role='menuitemradio'], > [role='menuitemcheckbox']) {
      --_col-indicator-width: 24px;
    }

    :scope:has(> * > [slot='start']) {
      --_col-start-width: 24px;
    }

    :scope:has(> * > [slot='end']) {
      --_col-end-width: 24px;
    }

    :scope:has(> * > [slot='submenu']) {
      --_col-submenu-width: 24px;
    }
  }
`;function af(){return b`
    <template focusgroup="menu">
      <slot ${x(`items`)}></slot>
    </template>
  `}var of=af(),sf={name:nf,registry:e.registry,styles:rf,template:of},cf=class e extends _{itemsChanged(e,t){this.$fastController.isConnected&&this.menuChildren!==void 0&&this.setItems()}static{this.focusableElementRoles=K}constructor(){super(),this.elementInternals=this.attachInternals(),this.isNestedMenu=()=>this.parentElement!==null&&Ou(this.parentElement)&&this.parentElement.getAttribute(`role`)===`menuitem`,this.changedMenuItemHandler=e=>{if(this.menuChildren===void 0)return;let t=e.target,n=this.menuChildren.indexOf(t);if(n!==-1&&t.role===`menuitemradio`&&t.checked===!0){for(let e=n-1;e>=0;--e){let t=this.menuChildren[e],n=t.role;if(n===K.menuitemradio&&(t.checked=!1),n===`separator`)break}let e=this.menuChildren.length-1;for(let t=n+1;t<=e;++t){let e=this.menuChildren[t],n=e.role;if(n===K.menuitemradio&&(e.checked=!1),n===`separator`)break}}},this.elementInternals.role=`menu`}connectedCallback(){super.connectedCallback(),!this.slot&&this.isNestedMenu()&&(this.slot=`submenu`),f.enqueue(()=>{this.setItems()}),this.addEventListener(`change`,this.changedMenuItemHandler)}disconnectedCallback(){super.disconnectedCallback(),Array.from(this.children).forEach(e=>{p.getNotifier(e).unsubscribe(this,`hidden`)}),this.menuChildren=void 0,this.removeEventListener(`change`,this.changedMenuItemHandler)}focus(){this.menuItems?.find(e=>!e.disabled)?.focus()}setItems(){let e=Array.from(this.children);e.forEach(e=>{p.getNotifier(e).subscribe(this,`hidden`)}),this.menuChildren=e.filter(e=>!e.hasAttribute(`hidden`)),this.menuItems=this.menuChildren?.filter(this.isMenuItemElement)}handleChange(e,t){t===`hidden`&&this.setItems()}isMenuItemElement(t){return Jd(t)||Ou(t)&&!!t.role&&t.role in e.focusableElementRoles}};I([m],cf.prototype,`items`,void 0),class extends cf{disconnectedCallback(){this.fg?.disconnect(),super.disconnectedCallback()}setItems(){super.setItems(),this.fgItems??=new du(()=>this.menuItems?.filter(e=>!e.hidden)??[]),this.fg?this.fg.update():this.fg=new uu(this,this.fgItems,{definition:{behavior:`menu`,axis:`block`,wrap:!0}})}}.define(sf);var lf=v`
  ${S(`flex`)}

  :host {
    align-items: center;
    background: ${E};
    border-radius: ${O};
    box-sizing: border-box;
    color: ${sr};
    cursor: pointer;
    font: ${j} ${A} / ${N} ${k};
    gap: 4px;
    min-block-size: 32px;
    overflow: visible;
    padding-inline: 10px;
  }

  @supports (grid-template-columns: subgrid) {
    :host {
      display: grid;
      gap: 0;
      grid-template-columns: subgrid;
      padding-inline: unset;
    }
  }

  :host(:hover) {
    background: ${jr};
    color: ${cr};
  }

  :host(:active) {
    background-color: ${Nr};
    color: ${lr};
  }

  :host(:active) ::slotted([slot='start']) {
    color: ${Sr};
  }

  :host(${As}) {
    background-color: ${Gr};
    color: ${T};
  }

  :host(${As}) ::slotted([slot='start']),
  :host(${As}) ::slotted([slot='end']) {
    color: ${T};
  }

  :host(:focus-visible) {
    border-radius: ${O};
    outline: 2px solid ${hi};
  }

  :host(:not(${z})) .indicator,
  :host(:not(${z})) ::slotted([slot='indicator']),
  :host(:not(${Us})) .submenu-glyph,
  :host(:not(${Us})) ::slotted([slot='submenu-glyph']) {
    display: none;
  }

  ::slotted([slot='end']) {
    color: ${w};
    font: ${j} ${Ya} / ${ao} ${k};
    white-space: nowrap;
  }

  .indicator,
  ::slotted([slot='indicator']) {
    grid-column: 2 / span 1;
    width: 20px;
  }

  ::slotted([slot='start']) {
    display: inline-flex;
    grid-column: 3 / span 1;
  }

  .content {
    flex-grow: 1;
    grid-column: 4 / span 1;
    padding: 0 2px;
    white-space: nowrap;
  }

  ::slotted([slot='end']) {
    grid-column: 5 / span 1;
    justify-self: end;
  }

  .submenu-glyph,
  ::slotted([slot='submenu-glyph']) {
    grid-column: 6 / span 1;
    justify-self: end;
  }

  @layer popover {
    :host {
      anchor-name: --menu-trigger;
      position: relative;
    }

    @position-try --inline-inside {
      inset-inline-start: unset;
      inset-inline-end: anchor(inside);
    }

    ::slotted([popover]) {
      margin: 0;
      max-block-size: var(--menu-max-height, auto);
      position: fixed;
      position-anchor: --menu-trigger;
      inset: unset;
      inset-block-start: anchor(inside);
      inset-inline-start: anchor(outside);
      position-try-fallbacks: --inline-inside, flip-block, flip-block --inline-inside;
      z-index: 1;
    }

    ::slotted([popover]:not(:popover-open)) {
      display: none;
    }

    /* Fallback for no anchor-positioning */
    @supports not (anchor-name: --menu-trigger) {
      ::slotted([popover]) {
        align-self: start;
      }
    }
  }

  @media (forced-colors: active) {
    :host(${As}),
    :host(${As}) ::slotted([slot='start']),
    :host(${As}) ::slotted([slot='end']) {
      color: GrayText;
    }
  }
`,uf=b.partial(`<svg class="indicator" fill="currentColor" aria-hidden="true" width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M14.05 3.49c.28.3.27.77-.04 1.06l-7.93 7.47A.85.85 0 014.9 12L2.22 9.28a.75.75 0 111.06-1.06l2.24 2.27 7.47-7.04a.75.75 0 011.06.04z" fill="currentColor"></path></svg>`),df=b.partial(`<svg class="submenu-glyph" fill="currentColor" aria-hidden="true" width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M5.74 3.2a.75.75 0 00-.04 1.06L9.23 8 5.7 11.74a.75.75 0 101.1 1.02l4-4.25a.75.75 0 000-1.02l-4-4.25a.75.75 0 00-1.06-.04z" fill="currentColor"></path></svg>`);function ff(e={}){return b`
    <template
      tabindex="0"
      @keydown="${(e,t)=>e.handleMenuItemKeyDown(t.event)}"
      @click="${(e,t)=>e.handleMenuItemClick(t.event)}"
      @mouseover="${(e,t)=>e.handleMouseOver(t.event)}"
      @mouseout="${(e,t)=>e.handleMouseOut(t.event)}"
      @toggle="${(e,t)=>e.handleToggle(t.event)}"
    >
      <slot name="indicator"> ${cs(e.indicator)} </slot>
      ${ds(e)}
      <div part="content" class="content">
        <slot></slot>
      </div>
      ${us(e)}
      <slot name="submenu-glyph"> ${cs(e.submenuGlyph)} </slot>
      <slot name="submenu" ${x({property:`slottedSubmenu`})}></slot>
    </template>
  `}var pf=ff({indicator:uf,submenuGlyph:df}),mf={name:Yd,registry:e.registry,styles:lf,template:pf};Xd.define(mf);var hf=`adoptedStyleSheets`in document,gf=`CSSScopeRule`in window,_f=new Map,vf=new Map,yf=new Map,bf=new Map,xf=new CSSStyleSheet;function Sf(e,t=document){if(t&&Of(t)){if(!hf||t instanceof HTMLElement&&!t.shadowRoot&&!gf){Nf(e,t===document?document.documentElement:t);return}[document,document.documentElement,document.body].includes(t)?kf(e):Af(e,t)}}var Cf=/^[a-zA-Z_-][a-zA-Z0-9_-]*$/;function wf(e){return Cf.test(e)?e:``}var Tf=/(;|{|}|\/\*|\*\/|@import|url\s*\(|expression\s*\(|javascript:)/i;function Ef(e){return Tf.test(e)?``:e}function Df(e){return _f.has(e)||_f.set(e,Object.keys(e).reduce((t,n)=>{let r=wf(n),i=Ef(e[n].toString());return r&&i?`${t}--${r}:${i};`:t},``)),_f.get(e)}function Of(e){return[document,document.documentElement].includes(e)||e instanceof HTMLElement&&!!e.closest(`body`)}function kf(e){if(e===null){document.adoptedStyleSheets.includes(xf)&&xf.replaceSync(``);return}xf.replaceSync(`
    html {
      ${Df(e)}
    }
  `),document.adoptedStyleSheets.includes(xf)||document.adoptedStyleSheets.push(xf)}function Af(e,t){if(e===null){t.shadowRoot&&yf.has(t)?yf.get(t).replaceSync(``):(delete t.dataset.fluentTheme,If(t));return}t.shadowRoot?jf(t).replaceSync(`
      :host {
        ${Df(e)}
      }
    `):(t.dataset.fluentTheme=Mf(e),If(t))}function jf(e){if(!yf.has(e)){let t=new CSSStyleSheet;yf.set(e,t),e.shadowRoot?.adoptedStyleSheets.push(t)}return yf.get(e)}function Mf(e){if(!vf.has(e)){let t=Yc(`fluent-theme-`),n=new CSSStyleSheet;vf.set(e,t),n.replaceSync(`
      @scope ([data-fluent-theme="${t}"]) {
        :scope {
          ${Df(e)}
        }
      }
    `),document.adoptedStyleSheets.push(n)}return vf.get(e)}function Nf(e,t){let n;if(e===null){if(!bf.has(t))return;n=bf.get(t)}else bf.set(t,e),n=e;for(let[r,i]of Object.entries(n))e===null?t.style.removeProperty(`--${r}`):t.style.setProperty(`--${r}`,i.toString())}var{userAgent:Pf}=navigator,Ff=/\bAppleWebKit\/[\d+\.]+\b/.test(Pf);function If(e){if(!Ff)return;let t=`visibility`,n=e.style.getPropertyValue(t);e.style.setProperty(t,`hidden`),f.process(),e.style.setProperty(t,n)}var q={2:`#050505`,4:`#0a0a0a`,6:`#0f0f0f`,8:`#141414`,10:`#1a1a1a`,12:`#1f1f1f`,14:`#242424`,16:`#292929`,18:`#2e2e2e`,20:`#333333`,22:`#383838`,24:`#3d3d3d`,26:`#424242`,28:`#474747`,30:`#4d4d4d`,32:`#525252`,34:`#575757`,36:`#5c5c5c`,38:`#616161`,40:`#666666`,42:`#6b6b6b`,44:`#707070`,46:`#757575`,48:`#7a7a7a`,50:`#808080`,52:`#858585`,54:`#8a8a8a`,56:`#8f8f8f`,58:`#949494`,60:`#999999`,62:`#9e9e9e`,64:`#a3a3a3`,66:`#a8a8a8`,68:`#adadad`,70:`#b3b3b3`,72:`#b8b8b8`,74:`#bdbdbd`,76:`#c2c2c2`,78:`#c7c7c7`,80:`#cccccc`,82:`#d1d1d1`,84:`#d6d6d6`,86:`#dbdbdb`,88:`#e0e0e0`,90:`#e6e6e6`,92:`#ebebeb`,94:`#f0f0f0`,96:`#f5f5f5`,98:`#fafafa`,99:`#fcfcfc`},Lf={5:`rgba(255, 255, 255, 0.05)`,10:`rgba(255, 255, 255, 0.1)`,20:`rgba(255, 255, 255, 0.2)`,30:`rgba(255, 255, 255, 0.3)`,40:`rgba(255, 255, 255, 0.4)`,50:`rgba(255, 255, 255, 0.5)`,60:`rgba(255, 255, 255, 0.6)`,70:`rgba(255, 255, 255, 0.7)`,80:`rgba(255, 255, 255, 0.8)`,90:`rgba(255, 255, 255, 0.9)`},Rf={5:`rgba(0, 0, 0, 0.05)`,10:`rgba(0, 0, 0, 0.1)`,20:`rgba(0, 0, 0, 0.2)`,30:`rgba(0, 0, 0, 0.3)`,40:`rgba(0, 0, 0, 0.4)`,50:`rgba(0, 0, 0, 0.5)`,60:`rgba(0, 0, 0, 0.6)`,70:`rgba(0, 0, 0, 0.7)`,80:`rgba(0, 0, 0, 0.8)`,90:`rgba(0, 0, 0, 0.9)`},J=`#ffffff`,zf=`#000000`,Bf={shade50:`#130204`,shade40:`#230308`,shade30:`#420610`,shade20:`#590815`,shade10:`#690a19`,primary:`#750b1c`,tint10:`#861b2c`,tint20:`#962f3f`,tint30:`#ac4f5e`,tint40:`#d69ca5`,tint50:`#e9c7cd`,tint60:`#f9f0f2`},Vf={shade50:`#200205`,shade40:`#3b0509`,shade30:`#6e0811`,shade20:`#960b18`,shade10:`#b10e1c`,primary:`#c50f1f`,tint10:`#cc2635`,tint20:`#d33f4c`,tint30:`#dc626d`,tint40:`#eeacb2`,tint50:`#f6d1d5`,tint60:`#fdf3f4`},Hf={shade50:`#210809`,shade40:`#3f1011`,shade30:`#751d1f`,shade20:`#9f282b`,shade10:`#bc2f32`,primary:`#d13438`,tint10:`#d7494c`,tint20:`#dc5e62`,tint30:`#e37d80`,tint40:`#f1bbbc`,tint50:`#f8dadb`,tint60:`#fdf6f6`},Uf={shade50:`#230900`,shade40:`#411200`,shade30:`#7a2101`,shade20:`#a62d01`,shade10:`#c43501`,primary:`#da3b01`,tint10:`#de501c`,tint20:`#e36537`,tint30:`#e9835e`,tint40:`#f4bfab`,tint50:`#f9dcd1`,tint60:`#fdf6f3`},Wf={shade50:`#200d03`,shade40:`#3d1805`,shade30:`#712d09`,shade20:`#9a3d0c`,shade10:`#b6480e`,primary:`#ca5010`,tint10:`#d06228`,tint20:`#d77440`,tint30:`#df8e64`,tint40:`#efc4ad`,tint50:`#f7dfd2`,tint60:`#fdf7f4`},Gf={shade50:`#271002`,shade40:`#4a1e04`,shade30:`#8a3707`,shade20:`#bc4b09`,shade10:`#de590b`,primary:`#f7630c`,tint10:`#f87528`,tint20:`#f98845`,tint30:`#faa06b`,tint40:`#fdcfb4`,tint50:`#fee5d7`,tint60:`#fff9f5`},Kf={shade50:`#291600`,shade40:`#4d2a00`,shade30:`#8f4e00`,shade20:`#c26a00`,shade10:`#e67e00`,primary:`#ff8c00`,tint10:`#ff9a1f`,tint20:`#ffa83d`,tint30:`#ffba66`,tint40:`#ffddb3`,tint50:`#ffedd6`,tint60:`#fffaf5`},qf={shade50:`#251a00`,shade40:`#463100`,shade30:`#835b00`,shade20:`#b27c00`,shade10:`#d39300`,primary:`#eaa300`,tint10:`#edad1c`,tint20:`#efb839`,tint30:`#f2c661`,tint40:`#f9e2ae`,tint50:`#fcefd3`,tint60:`#fefbf4`},Jf={shade50:`#282400`,shade40:`#4c4400`,shade30:`#817400`,shade20:`#c0ad00`,shade10:`#e4cc00`,primary:`#fde300`,tint10:`#fde61e`,tint20:`#fdea3d`,tint30:`#feee66`,tint40:`#fef7b2`,tint50:`#fffad6`,tint60:`#fffef5`},Yf={shade50:`#1f1900`,shade40:`#3a2f00`,shade30:`#6c5700`,shade20:`#937700`,shade10:`#ae8c00`,primary:`#c19c00`,tint10:`#c8a718`,tint20:`#d0b232`,tint30:`#dac157`,tint40:`#ecdfa5`,tint50:`#f5eece`,tint60:`#fdfbf2`},Xf={shade50:`#181202`,shade40:`#2e2103`,shade30:`#553e06`,shade20:`#745408`,shade10:`#89640a`,primary:`#986f0b`,tint10:`#a47d1e`,tint20:`#b18c34`,tint30:`#c1a256`,tint40:`#e0cea2`,tint50:`#efe4cb`,tint60:`#fbf8f2`},Zf={shade50:`#170e07`,shade40:`#2b1a0e`,shade30:`#50301a`,shade20:`#6c4123`,shade10:`#804d29`,primary:`#8e562e`,tint10:`#9c663f`,tint20:`#a97652`,tint30:`#bb8f6f`,tint40:`#ddc3b0`,tint50:`#edded3`,tint60:`#faf7f4`},Qf={shade50:`#0c1501`,shade40:`#162702`,shade30:`#294903`,shade20:`#376304`,shade10:`#427505`,primary:`#498205`,tint10:`#599116`,tint20:`#6ba02b`,tint30:`#85b44c`,tint40:`#bdd99b`,tint50:`#dbebc7`,tint60:`#f6faf0`},$f={shade50:`#002111`,shade40:`#003d20`,shade30:`#00723b`,shade20:`#009b51`,shade10:`#00b85f`,primary:`#00cc6a`,tint10:`#19d279`,tint20:`#34d889`,tint30:`#5ae0a0`,tint40:`#a8f0cd`,tint50:`#cff7e4`,tint60:`#f3fdf8`},ep={shade50:`#031a02`,shade40:`#063004`,shade30:`#0b5a08`,shade20:`#0e7a0b`,shade10:`#11910d`,primary:`#13a10e`,tint10:`#27ac22`,tint20:`#3db838`,tint30:`#5ec75a`,tint40:`#a7e3a5`,tint50:`#cef0cd`,tint60:`#f2fbf2`},tp={shade50:`#031403`,shade40:`#052505`,shade30:`#094509`,shade20:`#0c5e0c`,shade10:`#0e700e`,primary:`#107c10`,tint10:`#218c21`,tint20:`#359b35`,tint30:`#54b054`,tint40:`#9fd89f`,tint50:`#c9eac9`,tint60:`#f1faf1`},np={shade50:`#021102`,shade40:`#032003`,shade30:`#063b06`,shade20:`#085108`,shade10:`#0a5f0a`,primary:`#0b6a0b`,tint10:`#1a7c1a`,tint20:`#2d8e2d`,tint30:`#4da64d`,tint40:`#9ad29a`,tint50:`#c6e7c6`,tint60:`#f0f9f0`},rp={shade50:`#001d1f`,shade40:`#00373a`,shade30:`#00666d`,shade20:`#008b94`,shade10:`#00a5af`,primary:`#00b7c3`,tint10:`#18bfca`,tint20:`#32c8d1`,tint30:`#58d3db`,tint40:`#a6e9ed`,tint50:`#cef3f5`,tint60:`#f2fcfd`},ip={shade50:`#001516`,shade40:`#012728`,shade30:`#02494c`,shade20:`#026467`,shade10:`#037679`,primary:`#038387`,tint10:`#159195`,tint20:`#2aa0a4`,tint30:`#4cb4b7`,tint40:`#9bd9db`,tint50:`#c7ebec`,tint60:`#f0fafa`},ap={shade50:`#000f12`,shade40:`#001b22`,shade30:`#00333f`,shade20:`#004555`,shade10:`#005265`,primary:`#005b70`,tint10:`#0f6c81`,tint20:`#237d92`,tint30:`#4496a9`,tint40:`#94c8d4`,tint50:`#c3e1e8`,tint60:`#eff7f9`},op={shade50:`#001322`,shade40:`#002440`,shade30:`#004377`,shade20:`#005ba1`,shade10:`#006cbf`,primary:`#0078d4`,tint10:`#1a86d9`,tint20:`#3595de`,tint30:`#5caae5`,tint40:`#a9d3f2`,tint50:`#d0e7f8`,tint60:`#f3f9fd`},sp={shade50:`#000c16`,shade40:`#00172a`,shade30:`#002c4e`,shade20:`#003b6a`,shade10:`#00467e`,primary:`#004e8c`,tint10:`#125e9a`,tint20:`#286fa8`,tint30:`#4a89ba`,tint40:`#9abfdc`,tint50:`#c7dced`,tint60:`#f0f6fa`},cp={shade50:`#0d1126`,shade40:`#182047`,shade30:`#2c3c85`,shade20:`#3c51b4`,shade10:`#4760d5`,primary:`#4f6bed`,tint10:`#637cef`,tint20:`#778df1`,tint30:`#93a4f4`,tint40:`#c8d1fa`,tint50:`#e1e6fc`,tint60:`#f7f9fe`},lp={shade50:`#00061d`,shade40:`#000c36`,shade30:`#001665`,shade20:`#001e89`,shade10:`#0023a2`,primary:`#0027b4`,tint10:`#173bbd`,tint20:`#3050c6`,tint30:`#546fd2`,tint40:`#a3b2e8`,tint50:`#ccd5f3`,tint60:`#f2f4fc`},up={shade50:`#120f25`,shade40:`#221d46`,shade30:`#3f3682`,shade20:`#5649b0`,shade10:`#6656d1`,primary:`#7160e8`,tint10:`#8172eb`,tint20:`#9184ee`,tint30:`#a79cf1`,tint40:`#d2ccf8`,tint50:`#e7e4fb`,tint60:`#f9f8fe`},dp={shade50:`#0f0717`,shade40:`#1c0e2b`,shade30:`#341a51`,shade20:`#46236e`,shade10:`#532982`,primary:`#5c2e91`,tint10:`#6b3f9e`,tint20:`#7c52ab`,tint30:`#9470bd`,tint40:`#c6b1de`,tint50:`#e0d3ed`,tint60:`#f7f4fb`},fp={shade50:`#160418`,shade40:`#29072e`,shade30:`#4c0d55`,shade20:`#671174`,shade10:`#7a1589`,primary:`#881798`,tint10:`#952aa4`,tint20:`#a33fb1`,tint30:`#b55fc1`,tint40:`#d9a7e0`,tint50:`#eaceef`,tint60:`#faf2fb`},pp={shade50:`#1f091d`,shade40:`#3a1136`,shade30:`#6d2064`,shade20:`#932b88`,shade10:`#af33a1`,primary:`#c239b3`,tint10:`#c94cbc`,tint20:`#d161c4`,tint30:`#da7ed0`,tint40:`#edbbe7`,tint50:`#f5daf2`,tint60:`#fdf5fc`},mp={shade50:`#1c0b1f`,shade40:`#35153a`,shade30:`#63276d`,shade20:`#863593`,shade10:`#9f3faf`,primary:`#b146c2`,tint10:`#ba58c9`,tint20:`#c36bd1`,tint30:`#cf87da`,tint40:`#e6bfed`,tint50:`#f2dcf5`,tint60:`#fcf6fd`},hp={shade50:`#24091b`,shade40:`#441232`,shade30:`#80215d`,shade20:`#ad2d7e`,shade10:`#cd3595`,primary:`#e43ba6`,tint10:`#e750b0`,tint20:`#ea66ba`,tint30:`#ef85c8`,tint40:`#f7c0e3`,tint50:`#fbddf0`,tint60:`#fef6fb`},gp={shade50:`#1f0013`,shade40:`#390024`,shade30:`#6b0043`,shade20:`#91005a`,shade10:`#ac006b`,primary:`#bf0077`,tint10:`#c71885`,tint20:`#ce3293`,tint30:`#d957a8`,tint40:`#eca5d1`,tint50:`#f5cee6`,tint60:`#fcf2f9`},_p={shade50:`#13000c`,shade40:`#240017`,shade30:`#43002b`,shade20:`#5a003b`,shade10:`#6b0045`,primary:`#77004d`,tint10:`#87105d`,tint20:`#98246f`,tint30:`#ad4589`,tint40:`#d696c0`,tint50:`#e9c4dc`,tint60:`#faf0f6`},vp={shade50:`#141313`,shade40:`#252323`,shade30:`#444241`,shade20:`#5d5958`,shade10:`#6e6968`,primary:`#7a7574`,tint10:`#8a8584`,tint20:`#9a9594`,tint30:`#afabaa`,tint40:`#d7d4d4`,tint50:`#eae8e8`,tint60:`#faf9f9`},yp={shade50:`#0f0e0e`,shade40:`#1c1b1a`,shade30:`#343231`,shade20:`#474443`,shade10:`#54514f`,primary:`#5d5a58`,tint10:`#706d6b`,tint20:`#84817e`,tint30:`#9e9b99`,tint40:`#cecccb`,tint50:`#e5e4e3`,tint60:`#f8f8f8`},bp={shade50:`#111314`,shade40:`#1f2426`,shade30:`#3b4447`,shade20:`#505c60`,shade10:`#5f6d71`,primary:`#69797e`,tint10:`#79898d`,tint20:`#89989d`,tint30:`#a0adb2`,tint40:`#cdd6d8`,tint50:`#e4e9ea`,tint60:`#f8f9fa`},xp={shade50:`#090a0b`,shade40:`#111315`,shade30:`#202427`,shade20:`#2b3135`,shade10:`#333a3f`,primary:`#394146`,tint10:`#4d565c`,tint20:`#626c72`,tint30:`#808a90`,tint40:`#bcc3c7`,tint50:`#dbdfe1`,tint60:`#f6f7f8`},Sp={red:Hf,green:tp,darkOrange:Uf,yellow:Jf,berry:pp,lightGreen:ep,marigold:qf},Cp={darkRed:Bf,cranberry:Vf,pumpkin:Wf,peach:Kf,gold:Yf,brass:Xf,brown:Zf,forest:Qf,seafoam:$f,darkGreen:np,lightTeal:rp,teal:ip,steel:ap,blue:op,royalBlue:sp,cornflower:cp,navy:lp,lavender:up,purple:dp,grape:fp,lilac:mp,pink:hp,magenta:gp,plum:_p,beige:vp,mink:yp,platinum:bp,anchor:xp},Y={cranberry:Vf,green:tp,orange:Gf},wp=[`red`,`green`,`darkOrange`,`yellow`,`berry`,`lightGreen`,`marigold`],Tp=`darkRed.cranberry.pumpkin.peach.gold.brass.brown.forest.seafoam.darkGreen.lightTeal.teal.steel.blue.royalBlue.cornflower.navy.lavender.purple.grape.lilac.pink.magenta.plum.beige.mink.platinum.anchor`.split(`.`),Ep={success:`green`,warning:`orange`,danger:`cranberry`},Dp=wp.reduce((e,t)=>{let n=t.slice(0,1).toUpperCase()+t.slice(1),r={[`colorPalette${n}Background1`]:Sp[t].tint60,[`colorPalette${n}Background2`]:Sp[t].tint40,[`colorPalette${n}Background3`]:Sp[t].primary,[`colorPalette${n}Foreground1`]:Sp[t].shade10,[`colorPalette${n}Foreground2`]:Sp[t].shade30,[`colorPalette${n}Foreground3`]:Sp[t].primary,[`colorPalette${n}BorderActive`]:Sp[t].primary,[`colorPalette${n}Border1`]:Sp[t].tint40,[`colorPalette${n}Border2`]:Sp[t].primary};return Object.assign(e,r)},{});Dp.colorPaletteYellowForeground1=Sp.yellow.shade30,Dp.colorPaletteRedForegroundInverted=Sp.red.tint20,Dp.colorPaletteGreenForegroundInverted=Sp.green.tint20,Dp.colorPaletteYellowForegroundInverted=Sp.yellow.tint40;var Op=Tp.reduce((e,t)=>{let n=t.slice(0,1).toUpperCase()+t.slice(1),r={[`colorPalette${n}Background2`]:Cp[t].tint40,[`colorPalette${n}Foreground2`]:Cp[t].shade30,[`colorPalette${n}BorderActive`]:Cp[t].primary};return Object.assign(e,r)},{}),kp={...Dp,...Op},Ap=Object.entries(Ep).reduce((e,[t,n])=>{let r=t.slice(0,1).toUpperCase()+t.slice(1),i={[`colorStatus${r}Background1`]:Y[n].tint60,[`colorStatus${r}Background2`]:Y[n].tint40,[`colorStatus${r}Background3`]:Y[n].primary,[`colorStatus${r}Foreground1`]:Y[n].shade10,[`colorStatus${r}Foreground2`]:Y[n].shade30,[`colorStatus${r}Foreground3`]:Y[n].primary,[`colorStatus${r}ForegroundInverted`]:Y[n].tint30,[`colorStatus${r}BorderActive`]:Y[n].primary,[`colorStatus${r}Border1`]:Y[n].tint40,[`colorStatus${r}Border2`]:Y[n].primary};return Object.assign(e,i)},{});Ap.colorStatusDangerBackground3Hover=Y[Ep.danger].shade10,Ap.colorStatusDangerBackground3Pressed=Y[Ep.danger].shade20,Ap.colorStatusWarningForeground1=Y[Ep.warning].shade20,Ap.colorStatusWarningForeground3=Y[Ep.warning].shade20,Ap.colorStatusWarningBorder2=Y[Ep.warning].shade20;var jp=e=>({colorNeutralForeground1:q[14],colorNeutralForeground1Hover:q[14],colorNeutralForeground1Pressed:q[14],colorNeutralForeground1Selected:q[14],colorNeutralForeground2:q[26],colorNeutralForeground2Hover:q[14],colorNeutralForeground2Pressed:q[14],colorNeutralForeground2Selected:q[14],colorNeutralForeground2BrandHover:e[80],colorNeutralForeground2BrandPressed:e[70],colorNeutralForeground2BrandSelected:e[80],colorNeutralForeground3:q[38],colorNeutralForeground3Hover:q[26],colorNeutralForeground3Pressed:q[26],colorNeutralForeground3Selected:q[26],colorNeutralForeground3BrandHover:e[80],colorNeutralForeground3BrandPressed:e[70],colorNeutralForeground3BrandSelected:e[80],colorNeutralForeground4:q[44],colorNeutralForeground5:q[38],colorNeutralForeground5Hover:q[14],colorNeutralForeground5Pressed:q[14],colorNeutralForeground5Selected:q[14],colorNeutralForegroundDisabled:q[74],colorNeutralForegroundInvertedDisabled:Lf[40],colorBrandForegroundLink:e[70],colorBrandForegroundLinkHover:e[60],colorBrandForegroundLinkPressed:e[40],colorBrandForegroundLinkSelected:e[70],colorNeutralForeground2Link:q[26],colorNeutralForeground2LinkHover:q[14],colorNeutralForeground2LinkPressed:q[14],colorNeutralForeground2LinkSelected:q[14],colorCompoundBrandForeground1:e[80],colorCompoundBrandForeground1Hover:e[70],colorCompoundBrandForeground1Pressed:e[60],colorBrandForeground1:e[80],colorBrandForeground2:e[70],colorBrandForeground2Hover:e[60],colorBrandForeground2Pressed:e[30],colorNeutralForeground1Static:q[14],colorNeutralForegroundStaticInverted:J,colorNeutralForegroundInverted:J,colorNeutralForegroundInvertedHover:J,colorNeutralForegroundInvertedPressed:J,colorNeutralForegroundInvertedSelected:J,colorNeutralForegroundInverted2:J,colorNeutralForegroundOnBrand:J,colorNeutralForegroundInvertedLink:J,colorNeutralForegroundInvertedLinkHover:J,colorNeutralForegroundInvertedLinkPressed:J,colorNeutralForegroundInvertedLinkSelected:J,colorBrandForegroundInverted:e[100],colorBrandForegroundInvertedHover:e[110],colorBrandForegroundInvertedPressed:e[100],colorBrandForegroundOnLight:e[80],colorBrandForegroundOnLightHover:e[70],colorBrandForegroundOnLightPressed:e[50],colorBrandForegroundOnLightSelected:e[60],colorNeutralBackground1:J,colorNeutralBackground1Hover:q[96],colorNeutralBackground1Pressed:q[88],colorNeutralBackground1Selected:q[92],colorNeutralBackground2:q[98],colorNeutralBackground2Hover:q[94],colorNeutralBackground2Pressed:q[86],colorNeutralBackground2Selected:q[90],colorNeutralBackground3:q[96],colorNeutralBackground3Hover:q[92],colorNeutralBackground3Pressed:q[84],colorNeutralBackground3Selected:q[88],colorNeutralBackground4:q[94],colorNeutralBackground4Hover:q[98],colorNeutralBackground4Pressed:q[96],colorNeutralBackground4Selected:J,colorNeutralBackground5:q[92],colorNeutralBackground5Hover:q[96],colorNeutralBackground5Pressed:q[94],colorNeutralBackground5Selected:q[98],colorNeutralBackground6:q[90],colorNeutralBackground7:`#00000000`,colorNeutralBackground7Hover:q[92],colorNeutralBackground7Pressed:q[84],colorNeutralBackground7Selected:`#00000000`,colorNeutralBackground8:q[99],colorNeutralBackgroundInverted:q[16],colorNeutralBackgroundInvertedHover:q[24],colorNeutralBackgroundInvertedPressed:q[12],colorNeutralBackgroundInvertedSelected:q[22],colorNeutralBackgroundStatic:q[20],colorNeutralBackgroundAlpha:Lf[50],colorNeutralBackgroundAlpha2:Lf[80],colorSubtleBackground:`transparent`,colorSubtleBackgroundHover:q[96],colorSubtleBackgroundPressed:q[88],colorSubtleBackgroundSelected:q[92],colorSubtleBackgroundLightAlphaHover:Lf[70],colorSubtleBackgroundLightAlphaPressed:Lf[50],colorSubtleBackgroundLightAlphaSelected:`transparent`,colorSubtleBackgroundInverted:`transparent`,colorSubtleBackgroundInvertedHover:Rf[10],colorSubtleBackgroundInvertedPressed:Rf[30],colorSubtleBackgroundInvertedSelected:Rf[20],colorTransparentBackground:`transparent`,colorTransparentBackgroundHover:`transparent`,colorTransparentBackgroundPressed:`transparent`,colorTransparentBackgroundSelected:`transparent`,colorNeutralBackgroundDisabled:q[94],colorNeutralBackgroundDisabled2:J,colorNeutralBackgroundInvertedDisabled:Lf[10],colorNeutralStencil1:q[90],colorNeutralStencil2:q[98],colorNeutralStencil1Alpha:Rf[10],colorNeutralStencil2Alpha:Rf[5],colorBackgroundOverlay:Rf[40],colorScrollbarOverlay:Rf[50],colorBrandBackground:e[80],colorBrandBackgroundHover:e[70],colorBrandBackgroundPressed:e[40],colorBrandBackgroundSelected:e[60],colorCompoundBrandBackground:e[80],colorCompoundBrandBackgroundHover:e[70],colorCompoundBrandBackgroundPressed:e[60],colorBrandBackgroundStatic:e[80],colorBrandBackground2:e[160],colorBrandBackground2Hover:e[150],colorBrandBackground2Pressed:e[130],colorBrandBackground3Static:e[60],colorBrandBackground4Static:e[40],colorBrandBackgroundInverted:J,colorBrandBackgroundInvertedHover:e[160],colorBrandBackgroundInvertedPressed:e[140],colorBrandBackgroundInvertedSelected:e[150],colorNeutralCardBackground:q[98],colorNeutralCardBackgroundHover:J,colorNeutralCardBackgroundPressed:q[96],colorNeutralCardBackgroundSelected:q[92],colorNeutralCardBackgroundDisabled:q[94],colorNeutralStrokeAccessible:q[38],colorNeutralStrokeAccessibleHover:q[34],colorNeutralStrokeAccessiblePressed:q[30],colorNeutralStrokeAccessibleSelected:e[80],colorNeutralStroke1:q[82],colorNeutralStroke1Hover:q[78],colorNeutralStroke1Pressed:q[70],colorNeutralStroke1Selected:q[74],colorNeutralStroke2:q[88],colorNeutralStroke3:q[94],colorNeutralStroke4:q[92],colorNeutralStroke4Hover:q[88],colorNeutralStroke4Pressed:q[84],colorNeutralStroke4Selected:q[92],colorNeutralStrokeSubtle:q[88],colorNeutralStrokeOnBrand:J,colorNeutralStrokeOnBrand2:J,colorNeutralStrokeOnBrand2Hover:J,colorNeutralStrokeOnBrand2Pressed:J,colorNeutralStrokeOnBrand2Selected:J,colorBrandStroke1:e[80],colorBrandStroke2:e[140],colorBrandStroke2Hover:e[120],colorBrandStroke2Pressed:e[80],colorBrandStroke2Contrast:e[140],colorCompoundBrandStroke:e[80],colorCompoundBrandStrokeHover:e[70],colorCompoundBrandStrokePressed:e[60],colorNeutralStrokeDisabled:q[88],colorNeutralStrokeDisabled2:q[92],colorNeutralStrokeInvertedDisabled:Lf[40],colorTransparentStroke:`transparent`,colorTransparentStrokeInteractive:`transparent`,colorTransparentStrokeDisabled:`transparent`,colorNeutralStrokeAlpha:Rf[5],colorNeutralStrokeAlpha2:Lf[20],colorStrokeFocus1:J,colorStrokeFocus2:zf,colorNeutralShadowAmbient:`rgba(0,0,0,0.12)`,colorNeutralShadowKey:`rgba(0,0,0,0.14)`,colorNeutralShadowAmbientLighter:`rgba(0,0,0,0.06)`,colorNeutralShadowKeyLighter:`rgba(0,0,0,0.07)`,colorNeutralShadowAmbientDarker:`rgba(0,0,0,0.20)`,colorNeutralShadowKeyDarker:`rgba(0,0,0,0.24)`,colorBrandShadowAmbient:`rgba(0,0,0,0.30)`,colorBrandShadowKey:`rgba(0,0,0,0.25)`}),Mp={borderRadiusNone:`0`,borderRadiusSmall:`2px`,borderRadiusMedium:`4px`,borderRadiusLarge:`6px`,borderRadiusXLarge:`8px`,borderRadius2XLarge:`12px`,borderRadius3XLarge:`16px`,borderRadius4XLarge:`24px`,borderRadius5XLarge:`32px`,borderRadius6XLarge:`40px`,borderRadiusCircular:`10000px`},Np={curveAccelerateMax:`cubic-bezier(0.9,0.1,1,0.2)`,curveAccelerateMid:`cubic-bezier(1,0,1,1)`,curveAccelerateMin:`cubic-bezier(0.8,0,0.78,1)`,curveDecelerateMax:`cubic-bezier(0.1,0.9,0.2,1)`,curveDecelerateMid:`cubic-bezier(0,0,0,1)`,curveDecelerateMin:`cubic-bezier(0.33,0,0.1,1)`,curveEasyEaseMax:`cubic-bezier(0.8,0,0.2,1)`,curveEasyEase:`cubic-bezier(0.33,0,0.67,1)`,curveLinear:`cubic-bezier(0,0,1,1)`},Pp={durationUltraFast:`50ms`,durationFaster:`100ms`,durationFast:`150ms`,durationNormal:`200ms`,durationGentle:`250ms`,durationSlow:`300ms`,durationSlower:`400ms`,durationUltraSlow:`500ms`},Fp={fontSizeBase100:`10px`,fontSizeBase200:`12px`,fontSizeBase300:`14px`,fontSizeBase400:`16px`,fontSizeBase500:`20px`,fontSizeBase600:`24px`,fontSizeHero700:`28px`,fontSizeHero800:`32px`,fontSizeHero900:`40px`,fontSizeHero1000:`68px`},Ip={lineHeightBase100:`14px`,lineHeightBase200:`16px`,lineHeightBase300:`20px`,lineHeightBase400:`22px`,lineHeightBase500:`28px`,lineHeightBase600:`32px`,lineHeightHero700:`36px`,lineHeightHero800:`40px`,lineHeightHero900:`52px`,lineHeightHero1000:`92px`},Lp={fontWeightRegular:400,fontWeightMedium:500,fontWeightSemibold:600,fontWeightBold:700},Rp={fontFamilyBase:`'Segoe UI', 'Segoe UI Web (West European)', -apple-system, BlinkMacSystemFont, Roboto, 'Helvetica Neue', sans-serif`,fontFamilyMonospace:`Consolas, 'Courier New', Courier, monospace`,fontFamilyNumeric:`Bahnschrift, 'Segoe UI', 'Segoe UI Web (West European)', -apple-system, BlinkMacSystemFont, Roboto, 'Helvetica Neue', sans-serif`},X={none:`0`,xxs:`2px`,xs:`4px`,sNudge:`6px`,s:`8px`,mNudge:`10px`,m:`12px`,l:`16px`,xl:`20px`,xxl:`24px`,xxxl:`32px`},zp={spacingHorizontalNone:X.none,spacingHorizontalXXS:X.xxs,spacingHorizontalXS:X.xs,spacingHorizontalSNudge:X.sNudge,spacingHorizontalS:X.s,spacingHorizontalMNudge:X.mNudge,spacingHorizontalM:X.m,spacingHorizontalL:X.l,spacingHorizontalXL:X.xl,spacingHorizontalXXL:X.xxl,spacingHorizontalXXXL:X.xxxl},Bp={spacingVerticalNone:X.none,spacingVerticalXXS:X.xxs,spacingVerticalXS:X.xs,spacingVerticalSNudge:X.sNudge,spacingVerticalS:X.s,spacingVerticalMNudge:X.mNudge,spacingVerticalM:X.m,spacingVerticalL:X.l,spacingVerticalXL:X.xl,spacingVerticalXXL:X.xxl,spacingVerticalXXXL:X.xxxl},Vp={strokeWidthThin:`1px`,strokeWidthThick:`2px`,strokeWidthThicker:`3px`,strokeWidthThickest:`4px`};function Hp(e,t,n=``){return{[`shadow2${n}`]:`0 0 2px ${e}, 0 1px 2px ${t}`,[`shadow4${n}`]:`0 0 2px ${e}, 0 2px 4px ${t}`,[`shadow8${n}`]:`0 0 2px ${e}, 0 4px 8px ${t}`,[`shadow16${n}`]:`0 0 2px ${e}, 0 8px 16px ${t}`,[`shadow28${n}`]:`0 0 8px ${e}, 0 14px 28px ${t}`,[`shadow64${n}`]:`0 0 8px ${e}, 0 32px 64px ${t}`}}Sf((e=>{let t=jp(e);return{...Mp,...Fp,...Ip,...Rp,...Lp,...Vp,...zp,...Bp,...Pp,...Np,...t,...kp,...Ap,...Hp(t.colorNeutralShadowAmbient,t.colorNeutralShadowKey),...Hp(t.colorBrandShadowAmbient,t.colorBrandShadowKey,`Brand`)}})({10:`#061724`,20:`#082338`,30:`#0a2e4a`,40:`#0c3b5e`,50:`#0e4775`,60:`#0f548c`,70:`#115ea3`,80:`#0f6cbd`,90:`#2886de`,100:`#479ef5`,110:`#62abf5`,120:`#77b7f7`,130:`#96c6fa`,140:`#b4d6fa`,150:`#cfe4fa`,160:`#ebf3fc`}));var Up=`Fluent 2 Web Components`,Wp=e=>e,Gp=e=>`<div class="native-card">${e}</div>`,Kp=(e,t,n=!1,r=``)=>`<fluent-button appearance="${n?`secondary`:`primary`}" data-action="${t}" ${r}>${e}</fluent-button>`,qp=(e,t,n)=>`<fluent-field><label slot="label" for="${e}">${t}</label>${n}</fluent-field>`,Jp=(e,t,n=``,r=`text`,i=``)=>qp(e,t,r===`textarea`?`<fluent-textarea id="${e}" slot="input" aria-label="${t}" placeholder="${n}" value="${i}" rows="3"></fluent-textarea>`:`<fluent-text-input id="${e}" slot="input" aria-label="${t}" type="${r}" placeholder="${n}" value="${i}"></fluent-text-input>`),Yp=(e,t,n=!1)=>`<div class="row"><fluent-checkbox id="${e}" aria-label="${t}" ${n?`checked`:``}></fluent-checkbox><label for="${e}">${t}</label></div>`,Xp=(e,t,n=!1)=>`<div class="row"><fluent-switch id="${e}" aria-label="${t}" ${n?`checked`:``}></fluent-switch><label for="${e}">${t}</label></div>`,Zp=(e,t=``)=>`<fluent-badge ${t?`id="${t}"`:``}>${e}</fluent-badge>`,Qp=e=>`<fluent-avatar name="${e}" aria-label="${e}"></fluent-avatar>`,$p=(e,t,n,r=n[0],i=`dropdown`)=>qp(e,t,`<fluent-dropdown id="${e}" slot="input" aria-label="${t}" type="${i}" value="${r}"><fluent-listbox>${n.map(e=>`<fluent-option value="${e}" ${r===e?`selected`:``}>${e}</fluent-option>`).join(``)}</fluent-listbox></fluent-dropdown>`),em=(e,t,n)=>$p(e,t,n,``,`combobox`),tm=(e,t,n)=>$p(e,t,n),nm=e=>`<fluent-tablist id="brief-tabs" aria-label="Creative brief">${e.map((e,t)=>`<fluent-tab id="tab-${e.id}" ${t===0?`selected`:``} aria-controls="panel-${e.id}">${e.label}</fluent-tab>`).join(``)}</fluent-tablist>${e.map((e,t)=>`<div role="tabpanel" id="panel-${e.id}" aria-labelledby="tab-${e.id}" ${t?`hidden`:``}>${e.content}</div>`).join(``)}`,rm=(e,t)=>`<fluent-accordion><fluent-accordion-item><span slot="heading">${e}</span><p>${t}</p></fluent-accordion-item></fluent-accordion>`,im=(e,t)=>`<fluent-radio-group aria-label="${e}">${t.map((e,t)=>`<div class="row"><fluent-radio id="quality-${t}" value="${e}" aria-label="${e}" ${t?``:`checked`}></fluent-radio><label for="quality-${t}">${e}</label></div>`).join(``)}</fluent-radio-group>`,am=(e,t,n)=>qp(e,t,`<fluent-slider slot="input" id="${e}" aria-label="${t}" value="${n}" min="0" max="100" step="1"></fluent-slider>`),om=(e,t,n)=>Jp(e,t,``,`number`,n),sm=(e,t,n)=>qp(e,t,`<input slot="input" id="${e}" aria-label="${t}" type="color" value="${n}">`),cm=(e,t,n)=>`<fluent-progress-bar id="${e}" aria-label="Review checklist" value="${t}" max="${n}"></fluent-progress-bar>`,lm=(e,t,n)=>`<fluent-dialog id="${e}-dialog" aria-label="${t}"><fluent-dialog-body><h2 slot="title">${t}</h2><div class="stack">${n}</div><div slot="action">${Kp(`Close`,`close:`+e,!0)}</div></fluent-dialog-body></fluent-dialog>`,um=(e,t,n)=>`<fluent-drawer id="${e}-dialog" position="end" aria-label="${t}"><fluent-drawer-body><h2 slot="title">${t}</h2><div class="stack">${n}</div><div slot="footer">${Kp(`Close`,`close:`+e,!0)}</div></fluent-drawer-body></fluent-drawer>`,dm=(e,t)=>`<fluent-menu><fluent-menu-button slot="trigger">${e}</fluent-menu-button><fluent-menu-list>${t.map(([e,t])=>`<fluent-menu-item data-action="${t}">${e}</fluent-menu-item>`).join(``)}</fluent-menu-list></fluent-menu>`,fm=0,pm=(e,t)=>{let n=`help-`+ ++fm;return`<fluent-button appearance="secondary" data-popover="${n}" aria-controls="${n}" aria-expanded="false">${e}</fluent-button><div popover id="${n}" class="native-popover"><div class="stack">${t}</div></div>`},mm=e=>e.show(),hm=e=>e.hide(),gm=e=>e.value??``,_m=(e,t)=>{e.value=t},vm=e=>e.checked,ym=(e,t,n)=>{e.value=t,e.max=n};function bm(){document.addEventListener(`toggle`,e=>{let t=e.target;t instanceof HTMLElement&&t.hasAttribute(`popover`)&&document.querySelector(`[data-popover="${t.id}"]`)?.setAttribute(`aria-expanded`,String(t.matches(`:popover-open`)))},!0),document.addEventListener(`click`,e=>{let t=e.composedPath().find(e=>e instanceof HTMLElement&&e.dataset.popover);if(t){let e=document.getElementById(t.dataset.popover);e.togglePopover(),t.setAttribute(`aria-expanded`,String(e.matches(`:popover-open`)))}}),document.addEventListener(`change`,e=>{let t=e.composedPath().find(e=>e.id===`brief-tabs`);if(t){let e=t.activetab;if(e)for(let t of document.querySelectorAll(`[id^="panel-"]`))t.hidden=t.id!==e.getAttribute(`aria-controls`)}})}var xm=(e,t)=>`<fluent-link href="${e}">${t}</fluent-link>`;if(new URLSearchParams(location.search).has(`progress-report`)){let e=document.createElement(`a`);e.className=`progress-return`,e.href=`http://127.0.0.1:4177`,e.textContent=`Progress Report`,document.body.append(e)}var Sm=e=>String(e).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]),Cm=[`Ada Lovelace`,`Rafael Silva`,`Jun Park`],wm=[`Make something.`,`Around the studio`,`A little direction`,`Small palette. Big possibility.`,`Creative momentum`,`Ready for a first impression`,`One idea, many possibilities`,`What’s your first impression?`,`Set your next milestone`,`Every little detail`,`Your own corner of the studio`,`Keep the useful signals`,`Better, together.`,`A thought to get you started`,`Bring another screen`,`A place for what’s next`],Tm=[`actions`,`navigation`,`brief`,`brand`,`activity`,`readiness`,`asset`,`feedback`,`project`,`output`,`access`,`notifications`,`team`,`chat`,`share`,`library`],Em=[[`Mon`,12],[`Tue`,26],[`Wed`,19],[`Thu`,32],[`Fri`,23],[`Sat`,8]],Dm=[[`Apr`,78],[`May`,104],[`Jun`,86],[`Jul`,124],[`Aug`,96],[`Sep`,112]],Om=`portrait`,km=82,Am=100,jm=[`Mira Chen`,`Omar Haddad`],Mm=e=>`<div class="row">${e}</div>`,Z=Kp,Nm=Jp,Pm=$p,Fm=Yp,Im=e=>`<p class="status" id="${e}-status" role="status"></p>`,Lm=()=>`<div class="art" data-layout="${Om}" role="img" aria-label="${Om} composition with overlapping shapes"><div class="artboard" style="opacity:${km/100}"><i></i><b></b><strong>Make room<br>for a new idea.</strong></div></div>`,Rm=e=>`<figure><div class="bars" aria-hidden="true">${e.map(([t,n])=>`<div><div class="bar" style="height:${n/Math.max(...e.map(e=>e[1]))*110}px"></div><small>${t}</small></div>`).join(``)}</div><figcaption>Contributions to studio projects · sample data</figcaption></figure><details><summary>View activity data</summary><table><caption>Contributions per period</caption><thead><tr><th>Period</th><th>Contributions</th></tr></thead><tbody>${e.map(([e,t])=>`<tr><th>${e}</th><td>${t}</td></tr>`).join(``)}</tbody></table></details><div class="summary"><div>Total contributions<strong>${e.reduce((e,t)=>e+t[1],0)}</strong></div><div>Next review<strong>Friday</strong></div></div>`,zm=()=>jm.map((e,t)=>`<li>${Qp(e)}<div class="person-info"><strong>${Sm(e)}</strong><small>${t===0?`Designer · Owner`:`Collaborator`}</small></div>${Zp(t===0?`You`:`Member`)}</li>`).join(``),Bm={actions:()=>`${Mm(Z(`Create →`,`create`)+Z(`Preview`,`preview`,!0)+Z(`Reset canvas`,`reset-canvas`,!0))}${Nm(`study-name`,`Study name`,`Name your next idea`)}${Nm(`quick-note`,`Quick note`,`Leave a note for your future self…`,`textarea`)}${Mm(Zp(`In progress`)+Zp(`Local draft`)+Xp(`sync`,`Sync`,!0))}<div role="toolbar" aria-label="Canvas orientation">${Mm(Z(`Portrait`,`portrait`,!0)+Z(`Landscape`,`landscape`,!0))}</div>${Mm(dm(`Actions`,[[`Portrait canvas`,`portrait`],[`Landscape canvas`,`landscape`],[`Reset canvas`,`reset-canvas`]])+Z(`All commands`,`commands`,!0))}<p class="status" id="canvas-status" role="status">Canvas: ${Om}.</p>`,navigation:()=>`<nav aria-label="Current study path">${xm(`#showcase-navigation`,`Studio`)} / ${xm(`#showcase-project`,`Projects`)} / New study</nav><div class="pair">${[[`Planning`,[[`Projects`,`project`],[`Activity`,`activity`],[`Reviews`,`readiness`],[`Library`,`library`]]],[`Workspace`,[[`People`,`team`],[`Brand kit`,`brand`],[`Access`,`access`],[`Notifications`,`notifications`]]]].map(([e,t])=>`<nav aria-label="${e}" class="stack">${t.map(([e,t])=>xm(`#showcase-`+t,e)).join(``)}</nav>`).join(``)}</div>`,brief:()=>nm([{id:`idea`,label:`The idea`,content:`<p>A quieter workspace for a brighter idea. Start with a strong shape, an honest headline, and room to breathe.</p>${Fm(`editable`,`Keep the headline editable`,!0)}`},{id:`delivery`,label:`Delivery`,content:im(`Export quality`,[`Review quality`,`Final artwork`])}])+rm(`What makes a useful review?`,`Try one task, note where you hesitate, and share the result with your team.`),brand:()=>`<div class="swatches">${[`Brand`,`Action`,`Surface`].map((e,t)=>`<div><button class="swatch" data-action="copy-color" aria-label="Copy ${e.toLowerCase()} color CSS reference" style="background:${t===2?`var(--art-surface)`:`var(--art-accent)`}"></button><small>${e}</small></div>`).join(``)}</div><p>These three swatches follow the page theme.</p><div class="color-preview" id="color-preview"><span>Studio / 04</span><strong>Color outside<br>the expected.</strong></div>${sm(`accent`,`Study color`,`#6d5ce7`)}<small>Study color changes this artwork only.</small>${Im(`brand`)}`,activity:()=>`<p>A few small steps, every day.</p>${tm(`activity-range`,`Activity period`,[`This week`,`Six months`])}<div id="activity-chart" class="stack">${Rm(Em)}</div>${xm(`https://en-reve-docs.reve-ai-0869.chatgpt.site/workflows/assets`,`Explore the asset workflow ↗`)}`,readiness:()=>`${Mm(`<strong id="ready-count" style="font-size:32px">2 / 4</strong>`+Zp(`In review`,`approval-badge`))}${cm(`ready-progress`,2,4)}${[`The story is clear`,`The layout responds`,`Keyboard review complete`,`Alternative text checked`].map((e,t)=>Fm(`ready-`+t,e,t<2)).join(``)}${Z(`Approve study`,`approve`,!1,`disabled`)}`,asset:()=>`${Lm()}<dl><dt>Study</dt><dd>Shape &amp; space</dd><dt>Format</dt><dd>Editable composition</dd><dt>Owner</dt><dd>Mira Chen</dd></dl>${Mm(Z(`Preview study`,`preview`)+pm(`About this study`,`This editable composition uses the active theme’s colors. Change its orientation in “Make something” and its opacity in “Every little detail.”`))}`,feedback:()=>`${Pm(`rating`,`Study rating`,[`1`,`2`,`3`,`4`,`5`],`4`)}${Nm(`feedback-note`,`Review note`,`What’s working? What could be clearer?`,`textarea`)}${Z(`Add review`,`review`,!0)}${Im(`feedback`)}`,project:()=>`<p>Give an idea a name, a team, and a little momentum.</p>${Nm(`project-name`,`Project name`,`A fresh perspective`)}<div class="pair">${Pm(`project-type`,`Project type`,[`Campaign`,`Identity`,`Product`])}${Nm(`project-date`,`Review date`,``,`date`,`2026-09-18`)}</div>${Z(`Create project`,`project`)}${Im(`project`)}`,output:()=>`<p>Shape the output to fit the idea.</p>${Pm(`export-format`,`Export format`,[`PNG · Raster image`,`SVG · Vector image`,`PDF · Document`])}${am(`opacity`,`Artwork opacity`,km)}${om(`scale`,`Export scale`,Am)}${Fm(`transparent`,`Include transparent background`,!0)}${Nm(`export-notes`,`Export notes`,`Anything the next person should know?`,`textarea`)}${Z(`More export options`,`export`,!0)}<div class="summary"><div>Opacity<strong id="opacity-value">${km}%</strong></div><div>Scale<strong id="scale-value">${Am}%</strong></div></div>`,access:()=>`${Nm(`email`,`Work email`,`you@studio.com`,`email`)}${Nm(`password`,`Password`,``,`password`)}<small>At least 8 characters. Use a sample password here.</small>${Xp(`remember`,`Remember this device`)}${Z(`Check details`,`access`,!0)}${Im(`access`)}`,notifications:()=>`${Xp(`notify-mentions`,`Mentions and replies`,!0)}${Xp(`notify-reviews`,`New review requests`,!0)}${Xp(`notify-digest`,`Weekly studio digest`)}${Z(`Save preferences`,`notifications`,!0)}${Im(`notifications`)}`,team:()=>`<p>A small team with room for another perspective.</p><ul class="people" id="team-list">${zm()}</ul>${em(`person`,`Add a teammate`,Cm)}${Pm(`role`,`Access level`,[`Editor`,`Reviewer`,`Viewer`])}${Z(`Add to demo team`,`invite`)}${Im(`team`)}`,chat:()=>`<div id="chat-welcome" class="welcome"><span style="font-size:32px">✦</span><h3>What are we making today?</h3><p>A rough idea is a good place to start.</p></div><ol class="messages" id="messages" aria-live="polite"></ol>${Nm(`message`,`Message`,`I’m exploring a new direction…`,`textarea`)}<small>Local sample response · no AI connection</small>${Z(`Send`,`send`)}${Im(`chat`)}`,share:()=>`<div class="welcome" style="min-height:100px">↗</div><p>Open this showcase on another screen to compare the layout.</p>${xm(location.pathname,`Open showcase`)}${Z(`Copy showcase link`,`share`,!0)}<small>A localhost address opens only on the computer running this preview.</small>${Im(`share`)}`,library:()=>`<div id="library-content" class="welcome"><h3>No assets yet</h3><p>Every collection starts with one good find.</p>${Z(`Add a sample asset`,`insert`,!0)}</div>${pm(`How this collection works`,`<p>Add an authored sample asset to this page. Use Reset to empty the collection again.</p>${Fm(`keep-source`,`Keep the source editable`,!0)}`)}`},Vm=e=>`<section class="showcase-card" id="showcase-${e}" aria-labelledby="heading-${e}">${Gp(`<div class="card-heading"><h2 id="heading-${e}">${wm[Tm.indexOf(e)]}</h2>${[`navigation`,`asset`].includes(e)?``:Z(`Reset`,`reset:`+e,!0,`aria-label="Reset ${wm[Tm.indexOf(e)]}"`)}</div><div class="card-body">${Bm[e]()}</div>`)}</section>`,Hm=()=>lm(`create`,`Start with a direction`,`<p>Choose a canvas for this local study. You can change it at any time.</p>${Mm(Z(`Portrait`,`choose-portrait`)+Z(`Landscape`,`choose-landscape`))}`)+lm(`preview`,`Shape & space`,`<div id="preview-art">${Lm()}</div><p id="preview-description"></p>${Z(`Back to the studio`,`close:preview`,!0)}`)+lm(`commands`,`Studio commands`,`${Nm(`command-search`,`Find a layout command`,`Search commands…`)}<div id="command-list" class="stack">${Z(`Portrait canvas`,`choose-portrait`)+Z(`Landscape canvas`,`choose-landscape`)+Z(`Reset canvas`,`choose-portrait`)}</div>`)+lm(`approve`,`Ready to approve?`,`<p>This marks the sample study as approved in this page only.</p>${Mm(Z(`Keep reviewing`,`close:approve`,!0)+Z(`Confirm approval`,`confirm`))}`)+um(`export`,`Export options`,`${Fm(`layer-names`,`Keep layer names`,!0)}${Fm(`review-notes`,`Include review notes`)}${Nm(`handoff`,`Handoff message`,``,`textarea`)}${Z(`Done`,`close:export`)}`);document.getElementById(`root`).innerHTML=Wp(`<main id="showcase"><div class="showcase-heading"><h1>Made of ${Up}.</h1><p>Creative work, in sixteen small spaces. Local demos; nothing is sent or saved after reload.</p></div><div class="showcase-grid">${[0,4,8,12].map(e=>`<div class="showcase-column">${Tm.slice(e,e+4).map(Vm).join(``)}</div>`).join(``)}</div>${Hm()}</main>`);var Q=e=>document.getElementById(e),$=e=>gm(Q(e)),Um=(e,t)=>Q(e+`-status`).textContent=t,Wm=()=>{document.querySelectorAll(`.art`).forEach(e=>{e.dataset.layout=Om,e.setAttribute(`aria-label`,Om+` composition with overlapping shapes`)}),document.querySelectorAll(`.artboard`).forEach(e=>e.style.opacity=km/100),Q(`canvas-status`).textContent=`Canvas: ${Om}.`,Q(`opacity-value`).textContent=km+`%`,Q(`scale-value`).textContent=Am+`%`,Q(`preview-description`).textContent=`Canvas: ${Om}. Opacity: ${km}%.`};function Gm(e){let t=e.composedPath().find(e=>e instanceof HTMLElement&&e.id&&(e.id.startsWith(`ready-`)||[`activity-range`,`accent`,`opacity`,`scale`,`command-search`].includes(e.id)));if(!t)return;let n=t.id;if(n.startsWith(`ready-`)){let e=[0,1,2,3].filter(e=>vm(Q(`ready-`+e))).length;Q(`ready-count`).textContent=e+` / 4`,ym(Q(`ready-progress`),e,4),Q(`approval-badge`).textContent=`In review`,document.querySelector(`[data-action=approve]`).disabled=e!==4}n===`activity-range`&&(Q(`activity-chart`).innerHTML=Rm($(n)===`Six months`?Dm:Em)),n===`accent`&&Q(`color-preview`).style.setProperty(`--study-accent`,$(n)),n===`opacity`&&(km=Number($(n)),Wm()),n===`scale`&&(Am=Number($(n)),Wm()),n===`command-search`&&document.querySelectorAll(`#command-list [data-action]`).forEach(e=>e.hidden=!e.textContent.toLowerCase().includes($(n).toLowerCase()))}document.addEventListener(`input`,Gm),document.addEventListener(`change`,Gm),document.addEventListener(`click`,async e=>{let t=e.composedPath().find(e=>e instanceof HTMLElement&&e.dataset.action);if(!t||t.disabled)return;let n=t.dataset.action;if(n.startsWith(`reset:`)){let e=n.slice(6);e===`actions`&&(Om=`portrait`),e===`output`&&(km=82,Am=100),e===`team`&&(jm=[`Mira Chen`,`Omar Haddad`]),Q(`showcase-`+e).querySelector(`.card-body`).innerHTML=Bm[e](),Wm();return}if(n.startsWith(`close:`)){hm(Q(n.slice(6)+`-dialog`));return}if([`create`,`preview`,`commands`,`approve`,`export`].includes(n)){Wm(),mm(Q(n+`-dialog`));return}if([`portrait`,`landscape`,`reset-canvas`,`choose-portrait`,`choose-landscape`].includes(n)){Om=n.includes(`landscape`)?`landscape`:`portrait`,Wm(),n.startsWith(`choose-`)&&(hm(Q(`create-dialog`)),hm(Q(`commands-dialog`)));return}if(n===`confirm`&&(Q(`approval-badge`).textContent=`Approved`,document.querySelector(`[data-action=approve]`).disabled=!0,hm(Q(`approve-dialog`))),n===`review`&&Um(`feedback`,$(`feedback-note`).trim()?$(`rating`)+` / 5 — `+$(`feedback-note`):`Add a review note.`),n===`project`&&Um(`project`,$(`project-name`).trim()&&$(`project-date`)?`${$(`project-name`)} created locally. Review: ${$(`project-date`)}.`:`Add a project name and a valid review date.`),n===`access`&&Um(`access`,/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test($(`email`))&&$(`password`).length>=8?`Local form validated for ${$(`email`)}. No account was created.`:`Enter a valid email and at least 8 password characters.`),n===`notifications`&&Um(`notifications`,`Saved locally: `+[`mentions`,`reviews`,`digest`].filter(e=>vm(Q(`notify-`+e))).join(`, `)+`.`),n===`invite`){let e=$(`person`);Cm.includes(e)?jm.includes(e)?Um(`team`,e+` is already on the team.`):(jm.push(e),Q(`team-list`).innerHTML=zm(),Um(`team`,`${e} added to this demo team as ${$(`role`).toLowerCase()}.`)):Um(`team`,`Choose a teammate from the list.`)}if(n===`send`){let e=$(`message`).trim();if(!e){Um(`chat`,`Write a message first.`);return}Q(`chat-welcome`).hidden=!0,Q(`messages`).insertAdjacentHTML(`beforeend`,`<li><strong>You</strong><p>${Sm(e)}</p></li><li><strong>Demo assistant</strong><p>Try a portrait composition, compare two accent colors, and ask your team for a first impression.</p></li>`),_m(Q(`message`),``),Um(`chat`,`Message added. A sample response is shown below.`)}if(n===`share`||n===`copy-color`)try{await navigator.clipboard.writeText(n===`share`?location.href:`var(--art-accent)`),Um(n===`share`?`share`:`brand`,`Copied.`)}catch{Um(n===`share`?`share`:`brand`,`Copy unavailable.`)}n===`insert`&&(Q(`library-content`).innerHTML=`<h3>First spark</h3><p>Your sample asset is in the collection.</p>`+Zp(`1 asset`))}),bm?.();
//# sourceMappingURL=index-DHbL8u7_.js.map